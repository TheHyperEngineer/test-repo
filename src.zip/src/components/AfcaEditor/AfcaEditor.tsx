import React from "react";
import { useLocation } from "react-router-dom";
import styles from "./AfcaEditor.module.css";

const AfcaEditor: React.FC = () => {
  const location = useLocation();
  const { selectedCategory, selectedTemplate, projectCode, projectName } = location.state || {};

  return (
    <div className={styles.afcaEditor}>
      <h1>AFCA Editor</h1>
      <div className={styles.dataContainer}>
        <h2>Selected Category</h2>
        <pre>{JSON.stringify(selectedCategory, null, 2)}</pre>

        <h2>Selected Template</h2>
        <pre>{JSON.stringify(selectedTemplate, null, 2)}</pre>

        <h2>Project Details</h2>
        <p><strong>Project Code:</strong> {projectCode}</p>
        <p><strong>Project Name:</strong> {projectName}</p>
      </div>
    </div>
  );
};

export default AfcaEditor;