import React from "react";
import { useNavigate } from "react-router-dom";
import FroalaEditorView from "react-froala-wysiwyg/FroalaEditorView";
import "froala-editor/css/froala_editor.pkgd.min.css";
import useAuthStore from "../../stores/authStore";
import useContentStore from "../../stores/contentStore";
import styles from "./PreviewPage.module.css";

const PreviewPage: React.FC = () => {
  const { username } = useAuthStore();
  const { content } = useContentStore();
  const navigate = useNavigate();

  const handleSave = () => {
    alert("Blog saved successfully!");
  };

  const handleDownloadPDF = () => {
    alert("Download PDF feature coming soon!");
  };

  return (
    <div className={styles.previewContainer}>
      <header className={styles.header}>
        <button onClick={() => navigate(-1)} className={styles.backButton}>
          Back
        </button>
        <h1>Blog Preview</h1>
      </header>
      <main className={styles.body}>
        <FroalaEditorView model={content} /> {/* Display read-only content */}
      </main>
      <footer className={styles.footer}>
        <button onClick={handleSave} className={styles.saveButton}>
          Save
        </button>
        <span>MyDiary © 2025</span>
        <button onClick={handleDownloadPDF} className={styles.pdfButton}>
          Download PDF
        </button>
      </footer>
    </div>
  );
};

export default PreviewPage;
