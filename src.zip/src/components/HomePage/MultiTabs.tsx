import React from "react";
import styles from "./MultiTabs.module.css";

interface MultiTabsProps {
  tabs: string[];
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const MultiTabs: React.FC<MultiTabsProps> = ({ tabs, activeTab, onTabChange }) => {
  return (
    <nav className={styles.tabNav}>
      {tabs.map((tab) => (
        <button
          key={tab}
          className={`${styles.tabButton} ${
            activeTab === tab ? styles.activeTab : ""
          }`}
          onClick={() => onTabChange(tab)}
        >
          {tab}
        </button>
      ))}
    </nav>
  );
};

export default MultiTabs;