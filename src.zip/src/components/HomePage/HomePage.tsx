// import React, { useState, useEffect } from "react";
// import { useNavigate } from "react-router-dom";
// import { fetchTemplates } from "../../services/apiService";
// import useTemplateStore, {
//   Category,
//   Template,
// } from "../../stores/templateStore"; // Import Category and Template types
// import SearchBar from "./SearchBar";
// import MultiTabs from "./MultiTabs";
// import AllTemplatesTab from "./AllTemplatesTab";
// import Modal from "../Modal/Modal";
// import styles from "./HomePage.module.css";

// const HomePage: React.FC = () => {
//   const {
//     categories,
//     setCategories,
//     selectedCategory,
//     selectedTemplate,
//     setSelectedCategory,
//     setSelectedTemplate,
//   } = useTemplateStore();
//   const [searchTerm, setSearchTerm] = useState<string>("");
//   const [activeTab, setActiveTab] = useState<string>("All Templates");
//   const navigate = useNavigate(); // Initialize navigation

//   // Fetch templates from backend and set Zustand categories
//   useEffect(() => {
//     const loadTemplates = async () => {
//       try {
//         const data = await fetchTemplates();
//         console.log("Fetched Templates:", data); // Debug API response
//         setCategories(data.categories || []);
//       } catch (err) {
//         console.error("Failed to fetch templates:", err);
//       }
//     };

//     loadTemplates();
//   }, [setCategories]);

//   const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
//     setSearchTerm(event.target.value);
//   };

//   const openModal = (category: Category, template: Template) => {
//     setSelectedCategory(category);
//     setSelectedTemplate(template);
//   };

//   const closeModal = () => {
//     setSelectedCategory(null);
//     setSelectedTemplate(null);
//   };

//   const handleModalSubmit = (projectCode: string, projectName: string) => {
//     if (!selectedTemplate) return;

//     const route =
//       selectedTemplate.code === "AFCA"
//         ? "/afca-editor"
//         : selectedTemplate.code === "PRST"
//         ? "/peer-review-scope-editor"
//         : "/error"; // Default to an error page for unknown codes

//     navigate(route, {
//       state: {
//         selectedCategory,
//         selectedTemplate,
//         projectCode,
//         projectName,
//       },
//     });
//   };

//   const filteredCategories = categories.map((category) => ({
//     ...category,
//     templates: category.templates.filter((template) =>
//       [template.name, template.code, template.title]
//         .filter(Boolean)
//         .some((field) => field.toLowerCase().includes(searchTerm.toLowerCase()))
//     ),
//   }));

//   return (
//     <div className={styles.homePage}>
//       <header className={styles.headerRow}>
//         <h1>HomePage</h1>
//       </header>

//       <section className={styles.bodyRow}>
//         <SearchBar value={searchTerm} onChange={handleSearch} />
//         <MultiTabs
//           tabs={["All Templates", "Report", "Canonical Data"]}
//           activeTab={activeTab}
//           onTabChange={setActiveTab}
//         />
//         <div className={styles.tabContent}>
//           {activeTab === "All Templates" && (
//             <AllTemplatesTab
//               categories={filteredCategories}
//               onTemplateClick={openModal}
//             />
//           )}
//           {activeTab === "Report" && <p>Report section coming soon...</p>}
//           {activeTab === "Canonical Data" && (
//             <p>Canonical Data section coming soon...</p>
//           )}
//         </div>
//       </section>

//       <footer className={styles.footerRow}>
//         <span>MyDiary © 2025</span>
//       </footer>

//       {selectedTemplate && (
//         <Modal
//           title={selectedTemplate.title}
//           onClose={closeModal}
//           onSubmit={handleModalSubmit}
//         >

//           {selectedTemplate.modalFields.map((field) => (
//             <div key={field.id}>
//               <label>
//                 {field.fieldLabel} {field.mandatory && "*"}
//               </label>
//               <input
//                 type={field.fieldType}
//                 defaultValue={
//                   field.fieldName === "templateName"
//                     ? selectedTemplate.name
//                     : field.fieldName === "templateTitle"
//                     ? selectedTemplate.title
//                     : field.fieldName === "templateCode"
//                     ? selectedTemplate.code
//                     : ""
//                 }
//                 readOnly={
//                   field.fieldName === "templateName" ||
//                   field.fieldName === "templateTitle" ||
//                   field.fieldName === "templateCode"
//                 }
//               />
//             </div>
//           ))}
//         </Modal>
//       )}
//     </div>
//   );
// };

// export default HomePage;

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { fetchTemplates } from "../../services/apiService";
import useTemplateStore, { Category, Template } from "../../stores/templateStore";
import SearchBar from "./SearchBar";
import MultiTabs from "./MultiTabs";
import AllTemplatesTab from "./AllTemplatesTab";
import Modal from "../Modal/Modal";
import styles from "./HomePage.module.css";

const HomePage: React.FC = () => {
  const {
    categories,
    selectedCategory,
    selectedTemplate,
    setCategories,
    setSelectedCategory,
    setSelectedTemplate,
    projectCode,
    projectName,
  } = useTemplateStore();
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [activeTab, setActiveTab] = useState<string>("All Templates");
  const navigate = useNavigate();

  useEffect(() => {
    const loadTemplates = async () => {
      try {
        const data = await fetchTemplates();
        setCategories(data.categories || []);
      } catch (err) {
        console.error("Failed to fetch templates:", err);
      }
    };

    loadTemplates();
  }, [setCategories]);

  const handleSearch = (event: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(event.target.value);
  };

  const openModal = (category: Category, template: Template) => {
    setSelectedCategory(category);
    setSelectedTemplate(template);
  };

  const closeModal = () => {
    setSelectedCategory(null);
    setSelectedTemplate(null);
  };

  const navigateToEditor = () => {
    if (!selectedTemplate) return;

    const route = selectedTemplate.code === "AFCA"
      ? "/afca-editor"
      : selectedTemplate.code === "PRST"
      ? "/peer-review-scope-editor"
      : "/error";

    navigate(route, {
      state: {
        selectedCategory,
        selectedTemplate,
        projectCode,
        projectName,
      },
    });
  };

  const filteredCategories = categories.map((category) => ({
    ...category,
    templates: category.templates.filter((template) =>
      [template.name, template.code, template.title]
        .filter(Boolean)
        .some((field) => field.toLowerCase().includes(searchTerm.toLowerCase()))
    ),
  }));

  return (
    <div className={styles.homePage}>
      <header className={styles.headerRow}>
        <h1>HomePage</h1>
      </header>

      <section className={styles.bodyRow}>
        <SearchBar value={searchTerm} onChange={handleSearch} />
        <MultiTabs
          tabs={["All Templates", "Report", "Canonical Data"]}
          activeTab={activeTab}
          onTabChange={setActiveTab}
        />
        <div className={styles.tabContent}>
          {activeTab === "All Templates" && (
            <AllTemplatesTab categories={filteredCategories} onTemplateClick={openModal} />
          )}
          {activeTab === "Report" && <p>Report section coming soon...</p>}
          {activeTab === "Canonical Data" && <p>Canonical Data section coming soon...</p>}
        </div>
      </section>

      <footer className={styles.footerRow}>
        <span>MyDiary © 2025</span>
      </footer>

      {selectedTemplate && (
        <Modal
          title={selectedTemplate.title}
          onClose={closeModal}
          onSubmit={navigateToEditor}
        >
          {selectedTemplate.modalFields.map((field) => (
            <div key={field.id}>
              <label>
                {field.fieldLabel} {field.mandatory && "*"}
              </label>
              <input
                type={field.fieldType}
                defaultValue={
                  field.fieldName === "templateName"
                    ? selectedTemplate.name
                    : field.fieldName === "templateTitle"
                    ? selectedTemplate.title
                    : field.fieldName === "templateCode"
                    ? selectedTemplate.code
                    : ""
                }
                readOnly={
                  field.fieldName === "templateName" ||
                  field.fieldName === "templateTitle" ||
                  field.fieldName === "templateCode"
                }
              />
            </div>
          ))}
        </Modal>
      )}
    </div>
  );
};

export default HomePage;
