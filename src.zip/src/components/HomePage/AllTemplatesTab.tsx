import React from "react";
import styles from "./AllTemplatesTab.module.css";

interface Category {
  id: number;
  name: string;
  templates: any[];
}

interface AllTemplatesTabProps {
  categories: Category[];
  onTemplateClick: (category: Category, template: any) => void;
}

const AllTemplatesTab: React.FC<AllTemplatesTabProps> = ({ categories, onTemplateClick }) => {
  return (
    <div className={styles.allTemplatesContainer}>
      <div className={styles.categories}>
        {categories.map((category) => (
          <details key={category.id} className={styles.category}>
            <summary>{category.name}</summary>
            <ul>
              {category.templates.map((template) => (
                <li
                  key={template.id}
                  onClick={() => onTemplateClick(category, template)}
                  className={styles.templateLink}
                >
                  {template.title}
                </li>
              ))}
            </ul>
          </details>
        ))}
      </div>

      <div className={styles.faqSection}>
        <h3>FAQ & Help</h3>
        <p>Need assistance? Browse our FAQ or reach out for help!</p>
      </div>
    </div>
  );
};

export default AllTemplatesTab;