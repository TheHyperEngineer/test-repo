// import React, { ReactNode } from "react";
// import styles from "./Modal.module.css";

// interface ModalProps {
//   title: string;
//   children: ReactNode;
//   onClose: () => void;
// }

// const Modal: React.FC<ModalProps> = ({ title, children, onClose }) => {
//   return (
//     <div className={styles.modalBackdrop}>
//       <div className={styles.modalContent}>
//         <header className={styles.modalHeader}>
//           <h2>{title}</h2>
//           <button onClick={onClose} className={styles.closeButton}>
//             ✖
//           </button>
//         </header>
//         <div className={styles.modalBody}>{children}</div>
//         <footer className={styles.modalFooter}>
//           <button onClick={onClose} className={styles.modalButton}>
//             Close
//           </button>
//           <button className={styles.modalButton}>Next</button>
//         </footer>
//       </div>
//     </div>
//   );
// };

// export default Modal;

import React, { useState } from "react";
import useTemplateStore from "../../stores/templateStore";
import styles from "./Modal.module.css";

interface ModalProps {
  title: string;
  onClose: () => void;
  onSubmit: () => void;
  children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ title, onClose, onSubmit }) => {
  const { projectCode, projectName, setProjectCode, setProjectName } = useTemplateStore();

  const handleSubmit = () => {
    if (!projectCode || !projectName) {
      alert("Please fill in both Project Code and Project Name.");
      return;
    }
    onSubmit();
  };

  return (
    <div className={styles.modalBackdrop}>
      <div className={styles.modalContent}>
        <header className={styles.modalHeader}>
          <h2>{title}</h2>
          <button onClick={onClose} className={styles.closeButton}>✖</button>
        </header>
        <div className={styles.modalBody}>
          <div className={styles.modalField}>
            <label>Project Code *</label>
            <input
              type="text"
              value={projectCode}
              onChange={(e) => setProjectCode(e.target.value)}
            />
          </div>
          <div className={styles.modalField}>
            <label>Project Name *</label>
            <input
              type="text"
              value={projectName}
              onChange={(e) => setProjectName(e.target.value)}
            />
          </div>
        </div>
        <footer className={styles.modalFooter}>
          <button onClick={onClose} className={styles.modalButton}>Close</button>
          <button onClick={handleSubmit} className={styles.modalButton}>Next</button>
        </footer>
      </div>
    </div>
  );
};

export default Modal;