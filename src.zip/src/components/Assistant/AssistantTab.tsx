import React, { useState } from "react";
import styles from "./AssistantTab.module.css";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import { Context } from "../../stores/context";
import { fetchProjectsByContext } from "../../services/contextService"; // Import service
import useProjectStore from "../../stores/projectStore"; // Import Zustand store for projects

interface AssistantTabProps {
  title?: string; // Default title is "Assistant"
  contextData: { contexts: Context[] }; // Contexts data format
}

const AssistantTab: React.FC<AssistantTabProps> = ({
  title = "Assistant",
  contextData,
}) => {
  const [theme, setTheme] = useState<string>("light"); // Theme state
  const [selectedContext, setSelectedContext] = useState<string | null>(null); // Selected context
  const { projects, setProjects } = useProjectStore(); // Access and set projects

  const toggleTheme = () => {
    setTheme((prev) => (prev === "light" ? "dark" : "light"));
    document.body.className = theme === "light" ? styles.darkMode : styles.lightMode; // Apply theme globally
  };

  const handleContextChange = async (event: React.ChangeEvent<HTMLSelectElement>) => {
    const contextValue = event.target.value;
    setSelectedContext(contextValue);

    try {
      const fetchedProjects = await fetchProjectsByContext(contextValue); // Use service
      setProjects(fetchedProjects); // Update projects in Zustand
    } catch (error) {
      console.error("Failed to fetch projects:", error);
    }
  };

  return (
    <div className={styles.assistantTab}>
      {/* Title Row */}
      <div className={styles.titleRow}>
        <div className={styles.titleText}>{title}</div>
        <button className={styles.themeToggle} onClick={toggleTheme}>
          {theme === "light" ? <Brightness7Icon /> : <Brightness4Icon />}
        </button>
      </div>

      {/* Context Row */}
      <div className={styles.contextRow}>
        <label htmlFor="contextDropdown" className={styles.label}>
          Select Context:
        </label>
        <select
          id="contextDropdown"
          className={styles.dropdown}
          value={selectedContext || ""}
          onChange={handleContextChange}
        >
          <option value="" disabled>
            -- Select --
          </option>
          {contextData.contexts.map((context) => (
            <option key={context.id} value={context.name}>
              {context.name}
            </option>
          ))}
        </select>

        {/* Projects Dropdown */}
        {projects.length > 0 && (
          <>
            <label htmlFor="projectDropdown" className={styles.label}>
              Projects:
            </label>
            <select id="projectDropdown" className={styles.dropdown}>
              {projects.map((project) => (
                <option key={project.id} value={project.name}>
                  {project.name}
                </option>
              ))}
            </select>
          </>
        )}
      </div>

      {/* Related Project Row */}
      <div className={styles.relatedProjectRow}>
        <h2>Related Projects</h2>
        <p>Placeholder for related projects data...</p>
      </div>

      {/* Execution Row */}
      <div className={styles.executionRow}>
        <h2>Execution</h2>
        <p>Placeholder for execution-related functionality...</p>
      </div>

      {/* Message Section Row */}
      <div className={styles.messageSectionRow}>
        <h2>Messages</h2>
        <p>Placeholder for messaging section...</p>
      </div>

      {/* User Chat Section Row */}
      <div className={styles.userChatSectionRow}>
        <h2>User Chat</h2>
        <p>Placeholder for user chat functionality...</p>
      </div>
    </div>
  );
};

export default AssistantTab;