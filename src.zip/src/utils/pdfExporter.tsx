export const exportPDF = (content: string): void => {
    // Logic for exporting PDF
  };