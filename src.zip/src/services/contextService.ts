export const fetchProjectsByContext = async (context: string) => {
    try {
      const response = await fetch("http://localhost:8080/v1/home/context", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ context }),
      });
  
      if (!response.ok) {
        throw new Error(`Failed to fetch projects for context: ${context}`);
      }
  
      const data = await response.json();
      return data.projects || [];
    } catch (error) {
      console.error("Error in fetchProjectsByContext:", error);
      throw error;
    }
  };