const BASE_URL = "http://localhost:8080";

export const fetchTemplates = async () => {
  const response = await fetch(`${BASE_URL}/v1/home/templates`);
  if (!response.ok) {
    throw new Error("Failed to fetch templates");
  }
  return response.json();
};