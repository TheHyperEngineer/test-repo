import React from "react";
import {
  BrowserRouter as Router,
  Route,
  Routes,
  useNavigate,
} from "react-router-dom";
import LoginPage from "./components/LoginPage/LoginPage";
import MainPage from "./components/MainPage/MainPage";
import "froala-editor/css/froala_editor.pkgd.min.css";
import PreviewPage from "./components/PreviewPage/PreviewPage";
import HomePage from "./components/HomePage/HomePage";
import AfcaEditor from "./components/AfcaEditor/AfcaEditor";
import PeerReviewScopeEditor from "./components/PeerReviewScopeEditor/PeerReviewScopeEditor";
import "./App.css";
import AssistantTab from "./components/Assistant/AssistantTab";

const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/main" element={<MainPage />} />
        <Route path="/preview" element={<PreviewPage />} />
        <Route path="/home" element={<HomePage />} />
        <Route path="/afca-editor" element={<AfcaEditor />} />
        <Route
          path="/peer-review-scope-editor"
          element={<PeerReviewScopeEditor />}
        />
        <Route
          path="/assistant"
          element={
            <AssistantTab
              contextData={{
                contexts: [
                  {
                    id: 1,
                    name: "Projects",
                  },
                  {
                    id: 2,
                    name: "Cases",
                  },
                  {
                    id: 3,
                    name: "Races",
                  },
                ],
              }}
            />
          }
        />
      </Routes>
    </Router>
  );
};

export default App;
