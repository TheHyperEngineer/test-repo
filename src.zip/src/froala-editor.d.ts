declare module 'froala-editor';
declare module 'react-froala-wysiwyg';