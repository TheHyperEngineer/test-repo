import { create } from 'zustand';


interface AuthState {
  username: string;
  password: string;
  // content: string;
  // templates: any[];
  // setTemplates: (templates: any[]) => void;
  setUsername: (username: string) => void;
  setPassword: (password: string) => void;
  // setContent: (content: string) => void;
  validateCredentials: (username: string, password: string) => boolean;
}

const useAuthStore = create<AuthState>((set) => ({
  username: '',
  password: '',
  // content: '',
  // templates: [],
  // setTemplates: (templates) => set({ templates }),
  // setContent: (content) => set({ content }),
  setUsername: (username) => set({ username }),
  setPassword: (password) => set({ password }),
  validateCredentials: (username, password) => {
    const defaultUsers: Record<string, string> = {
      admin: 'admin',
      test: 'test',
    };
    return defaultUsers[username] === password;
  },
}));

export default useAuthStore;