import { create } from "zustand";

interface Project {
  id: string;
  name: string;
}

interface ProjectStoreState {
  projects: Project[]; // State to hold projects
  setProjects: (projects: Project[]) => void;
}

const useProjectStore = create<ProjectStoreState>((set) => ({
  projects: [],
  setProjects: (projects) => set({ projects }),
}));

export default useProjectStore;