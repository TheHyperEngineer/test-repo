import { create } from "zustand";

export interface Template {
  name: string;
  code: string;
  title: string;
  modalFields: { id: string; fieldLabel: string; fieldType: string; fieldName: string; mandatory: boolean }[];
}

export interface Category {
  id: number;
  name: string;
  templates: Template[];
}

interface TemplateStoreState {
  categories: Category[];
  selectedCategory: Category | null;
  selectedTemplate: Template | null;
  projectCode: string;
  projectName: string;
  setCategories: (categories: Category[]) => void;
  setSelectedCategory: (category: Category | null) => void;
  setSelectedTemplate: (template: Template | null) => void;
  setProjectCode: (projectCode: string) => void;
  setProjectName: (projectName: string) => void;
}

const useTemplateStore = create<TemplateStoreState>((set) => ({
  categories: [],
  setCategories: (categories) => set({ categories }),
  selectedCategory: null,
  setSelectedCategory: (category) => set({ selectedCategory: category }),
  selectedTemplate: null,
  setSelectedTemplate: (template) => set({ selectedTemplate: template }),
  projectCode: "",
  setProjectCode: (projectCode) => set({ projectCode }),
  projectName: "",
  setProjectName: (projectName) => set({ projectName }),
}));

export default useTemplateStore;