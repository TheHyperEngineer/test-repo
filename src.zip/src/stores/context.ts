export interface Context {
    id: number;
    name: string;
  }