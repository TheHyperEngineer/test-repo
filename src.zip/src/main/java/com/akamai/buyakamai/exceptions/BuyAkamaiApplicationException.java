package com.akamai.buyakamai.exceptions;

import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;

import com.akamai.se.dto.problem.Problem;

public class BuyAkamaiApplicationException extends RuntimeException {

    private String title;
    private String details;
    private Problem problem;
    private HttpStatus httpStatus;
    private List<Problem> errors;
    private String errorKey;
    private Map<String, String> errorData;

    private static final long serialVersionUID = -1738926926314798534L;

    public BuyAkamaiApplicationException(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    //to be used when the problem object is too complicated
    public BuyAkamaiApplicationException(Problem problem, HttpStatus httpStatus) {
        this.problem = problem;
        this.httpStatus = httpStatus;
    }

    public BuyAkamaiApplicationException(String title, String details, HttpStatus httpStatus) {
        this.title = title;
        this.details = details;
        this.httpStatus = httpStatus;
    }

    public BuyAkamaiApplicationException(String title, String details, Problem problem, HttpStatus httpStatus) {
        this.title = title;
        this.details = details;
        this.httpStatus = httpStatus;
        this.problem = problem;
    }
    
	public BuyAkamaiApplicationException(String title, String details, HttpStatus httpStatus, String errorKey) {
		this.title = title;
		this.details = details;
		this.httpStatus = httpStatus;
		this.errorKey = errorKey;
	}

    public Problem getProblem() {
        return problem;
    }

    public void setProblem(Problem problem) {
        this.problem = problem;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getErrorKey() {
        return errorKey;
    }

    public void setErrorKey(String errorKey) {
        this.errorKey = errorKey;
    }

    public List<Problem> getErrors() {
        return errors;
    }

    public void setErrors(List<Problem> errors) {
        this.errors = errors;
    }

    public Map<String, String> getErrorData() {
		return errorData;
	}

	public void setErrorData(Map<String, String> errorData) {
		this.errorData = errorData;
	}

	@Override
	public String toString() {
		return "BuyAkamaiApplicationException [title=" + title + ", details=" + details + ", problem=" + problem
		        + ", httpStatus=" + httpStatus + ", errors=" + errors + ", errorKey=" + errorKey + ", errorData="
		        + errorData + "]";
	}
}