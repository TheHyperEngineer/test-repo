package com.akamai.buyakamai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@SpringBootApplication
@EnableRetry
@EnableAsync
@EnableAspectJAutoProxy(proxyTargetClass = true)
public class Application extends SpringBootServletInitializer {

    public static final int ASYNC_PROCESS_CORE_POOL_SIZE = 6;
    public static final int ASYNC_PROCESS_MAX_POOL_SIZE = 6;
    public static final int ASYNC_PROCESS_QUEUE_CAPACITY = 25;

    private static final int EVENT_POOL_QUEUE_CAPACITY = 25;
    private static final int EVENT_MAX_POOL_SIZE = 6;
    private static final int EVENT_CORE_POOL_SIZE = 1;

    private static final int VALUE_CONFIRMATION_POOL_QUEUE_CAPACITY = 25;
    private static final int VALUE_CONFIRMATION_MAX_POOL_SIZE = 6;
    private static final int VALUE_CONFIRMATION_CORE_POOL_SIZE = 1;


    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }


    @Bean(name = "asyncProcessExecutor")
    public AsyncTaskExecutor getAsyncTaskExecutor(){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(ASYNC_PROCESS_CORE_POOL_SIZE);
        executor.setMaxPoolSize(ASYNC_PROCESS_MAX_POOL_SIZE);
        executor.setQueueCapacity(ASYNC_PROCESS_QUEUE_CAPACITY);
        return executor;
    }

    @Bean(name = "eventProcessorExecutor")
    public TaskExecutor eventTaskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(EVENT_CORE_POOL_SIZE);
        executor.setMaxPoolSize(EVENT_MAX_POOL_SIZE);
        executor.setQueueCapacity(EVENT_POOL_QUEUE_CAPACITY);
        return executor;
    }

    @Bean(name = "valueConfirmationExecutors")
    public AsyncTaskExecutor getValueConfirmationTaskExecutor(){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(VALUE_CONFIRMATION_CORE_POOL_SIZE);
        executor.setMaxPoolSize(VALUE_CONFIRMATION_MAX_POOL_SIZE);
        executor.setQueueCapacity(VALUE_CONFIRMATION_POOL_QUEUE_CAPACITY);
        return executor;
    }
}
