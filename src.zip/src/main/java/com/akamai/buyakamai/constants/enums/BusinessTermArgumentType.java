package com.akamai.buyakamai.constants.enums;

import com.akamai.buyakamai.model.oms.BusinessTermArgument;

public enum  BusinessTermArgumentType {

	NUMBER_RANGE("NUMBER_RANGE") {
		@Override
		public BusinessTermArgument getArgumentObject() {
			BusinessTermArgument arg = new BusinessTermArgument();
			arg.setDefaultValue("100");
			arg.setMinValue("0");
			arg.setMaxVavlue("100");
			arg.setInputType("numberList");
			return arg;
		}
	},DATE("DATE") {
		@Override
		public BusinessTermArgument getArgumentObject() {
			BusinessTermArgument arg = new BusinessTermArgument();
			arg.setInputType("date");
			return arg;
		}
	},TOOL_TIP("TOOL_TIP") {
		@Override
		public BusinessTermArgument getArgumentObject() {
			return null;
		}
	};
	
	public abstract BusinessTermArgument getArgumentObject();

    private String argumentType;

    BusinessTermArgumentType(String type) {
        this.argumentType = type;
    }

	public String getArgumentType() {
		return argumentType;
	}
	
}
