package com.akamai.buyakamai.constants.enums;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toMap;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.ListUtils;

public enum PartnerRole {
	PARTNER_ADMIN("COMMUNITY_START_TRIAL_ACCESS", "PARTNER_ADMIN"), PARTNER_READ_ONLY("COMMUNITY_VIEW_TRIAL_ACCESS", "PARTNER_READ_ONLY");

	private String sfRole;
	
	private String baRole;

	PartnerRole(String sfRole, String baRole) {
		this.sfRole = sfRole;
		this.baRole = baRole;
	}
	
    private static final Map<String, String> ROLE_MAP = stream(PartnerRole.values()).collect(
            toMap(role -> role.sfRole, role -> role.baRole));


    public static String getBARole(String sfRole) {
        return ROLE_MAP.get(sfRole.toUpperCase());
    }

	public static List<String> getPartnerBARoles() {
		return new ArrayList<>(ROLE_MAP.values());
	}
	
	public static boolean isPartnerRole(List<String> roles) {
		return !ListUtils.intersection(roles, getPartnerBARoles()).isEmpty();
	}
}