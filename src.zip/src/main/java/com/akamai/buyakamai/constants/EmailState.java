package com.akamai.buyakamai.constants;

/**
 * Used to categorize the email state.
 * @author vineek
 */
public enum EmailState {
	
	QUEUED , FAILED , COMPLETED

}
