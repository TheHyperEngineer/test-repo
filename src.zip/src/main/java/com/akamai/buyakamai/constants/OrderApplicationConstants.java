package com.akamai.buyakamai.constants;

public class OrderApplicationConstants {

	public static final String GET_ORDER_URL_SUFFIX_KEY = "get_order_url_suffix_key";
	public static final String GET_BASIC_ORDER_URL_SUFFIX_KEY = "get_basic_order_url_suffix_key";
	public static final String GET_ORDERS_FOR_ACCOUNT_URL_SUFFIX_KEY =
			"get_orders_for_account_url_suffix_key";
	public static final String GET_CONTACT_DETAILS_URL = "get_contact_details_url";
	public static final String CREATE_CONTACT_BA_CORE_API_URL = "create_contact_ba_core_url";
	public static final String GET_ACCOUNT_IDS_URL = "get_account_ids_url";
	public static final String SALES_REP_ACCOUNT_HANDLES = "sales_rep_account_handles";
	public static final String LOGGED_IN_USER_TYPE="logged-in-user-type";
	public static final String GET_EVENTS_URL_SUFFIX_KEY = "get_events_url_suffix_key";

	public static final String HAPPINESS_INDEX_RESET_INTERVAL= "happiness_index_reset_interval_days";
	public static final String EVENTS_API_INTERVAL_DAYS = "events_api_interval_days";

	public static final String ORDER_ID_KEY = "orderId";
	
	public static final String CREATE_QUOTE_URL_SUFFIX_KEY = "create_quote_url_suffix_key";
	
	public static final String ACCEPT_TNC_PROSPECT_URL_SUFFIX_KEY = "accept_tnc_prospect_url_suffix_key";
	
	public static final String ACCEPT_TNC_URL_SUFFIX_KEY = "accept_tnc_url_suffix_key";
	
	public static final String GET_USER_REGISTRATION_STATUS_URL ="get_user_registration_status_url_suffix_key";

	public static final String ORDER_EXPIRED_STATUS = "EXPIRED";
	public static final String ORDER_FAILED_STATUS = "FAILED";
	public static final String TNC_NOT_ACCEPTED = "TnC Not Accepted";

	public static final String PROSPECT_TYPE = "Prospect";
	
	public static final String ORDER_APPLICATION_ERROR_KEY = "error_key";
	
	public static final String RESEND_CRDENTIALS_URL_SUFFIX_KEY = "resend_credetials_url_suffix_key";

	public static final String UPDATE_TRIAL_MANAGER_SUFFIX_KEY = "update_trial_manager_suffix_key";

	public static final String PARTNER_GET_ORDERS_URL_SUFFIX_KEY="partner_get_orders_url_suffix_key";

	public static final String PARTNER_BASIC_GET_ORDERS_URL_SUFFIX_KEY="partner_basic_get_orders_url_suffix_key";
	
	public static final String GET_CONTACTS_FOR_ORDER_URL_SUFFIX_KEY = "get_contacts_for_order_url_suffix_key";

	public static final String AWAITING_EXTENSION = "AWAITING_EXTENSION";
	public static final String TRIAL_EXTENDED = "TRIAL_EXTENDED";

	public static final String EXTENSION_DAYS_EVENT_DATA_KEY = "EXTENSION_FREE_DAYS";

	public static final String POC_MARKETING_PROD_ID = "poc_marketing_product_id";

	public static final String URL_GET_PRODUCTS_TO_RECOMMEND = "get_products_to_recommend_url";

	public static final String URL_GET_PRODUCTS_TO_RECOMMEND_WITH_INTEGRATION_TYPE= "get_products_to_recommend_with_integration_type_url";

	public static final String URL_GET_PARTNER_PRODUCTS_TO_RECOMMEND_WITH_INTEGRATION_TYPE="get_partner_products_to_recommend_with_integration_type_url";
	
	public static final String URL_GET_PRICING_FOR_PRODUCT = "get_pricing_for_product";
		
	public static final String URL_GET_TNC_FOR_PRODUCT = "get_tnc_for_product";

	public static final String TRIAL_ORDER_TYPE = "trial";

	public static final String CUSTOMER_CREATE_QUOTE_URL_SUFFIX_KEY = "customer_create_quote_url_suffix_key";

	public static final String ORDER_ONGOING_STATUS = "ongoing";

	public static final String GET_TERMS_CONDITIONS_URL_SUFFIX_KEY = "get_terms_conditions_url_suffix_key";
	
	public static final String GET_ORDER_STATUS_URL_SUFFIX_KEY = "get_order_status_url_suffix_key";

	public static final String ORDER_CANCELLED_STATUS = "Order Cancelled";

	public static final String INTERNAL_ORDER_INITIATOR_CONSTANT = "internal";

	public static final String PRODUCT_CONSTANT = "Product";

	public static final String OPTION_CONSTANT = "Option";
	
	public static final String GET_INDIRECT_CUSTOMER_CONTRACTS = "get_indirect_customer_contracts";
	
	public static final String GET_DIRECT_CUSTOMER_CONTRACTS = "get_direct_customer_contracts";

	public static final String OMS_GET_ORDERS_INFORMATION_URL_SUFFIX = "get_orders_info_oms";
	public static final String BUY_AKAMAI_CONTEXT="buyAkamaiContext";
	public static final String OMS_GET_VERSION_HISTORY_URL_SUFFIX = "get_version_history_url_suffix_key";
	public static final String OMS_GET_ORDER_VERSION_DETAILS_URL_SUFFIX = "get_order_version_details_url_suffix_key";
	public static final String OMS_GET_LATEST_ORDER_VERSION_DETAILS_URL_SUFFIX = "get_latest_order_version_details_url_suffix_key";
	public static final String OMS_CREATE_ORDER_VERSION_URL_SUFFIX = "create_order_version_url_suffix_key";
	public static final String OMS_CREATE_NEW_ORDER_URL_SUFFIX = "create_new_order_url_suffix_key";
	public static final String OMS_LATEST_VERSION="latest";
	public static final String OMS_GET_DRAFT_DETAILS_URL_SUFFIX = "get_draft_details_url_suffix_key";


	public static final String OMS_DRAFT_CREATE_URL_SUFFIX = "create_draft_url_suffix_key";
	public static final String OMS_DRAFT_UPDATE_URL_SUFFIX = "update_draft_url_suffix_key";
	public static final String OMS_SELECT_ORDER_REQUEST_URL_SUFFIX = "select_oms_order_url_suffix_key" ;
	public static final String OMS_UPDATE_ORDER_VERSION_URL_SUFFIX = "oms_update_order_version_url_suffix_key";
	
	public static final String EXCLUSION_OPPORTUNITY_STATE_FOR_BUY = "exclusion_opp_state_for_buy";
	public static final String OMS_GET_REVENUE_URL_SUFFIX = "oms_get_revenue_url_suffix_key";
	public static final String OMS_GET_LATEST_DD_APPROVED_VERSION = "oms_get_latest_dd_approved_version";
}
