package com.akamai.buyakamai.constants;

public class AzureConstants {

    public static final String AZURE_LOGIN_URL_PROPERTY_KEY = "azure_login_url";
    public static final String AZURE_AKAMAI_TENANT_ID_PROPERTY = "azure_akamai_tenant_id";
    public static final String AZURE_MP_BASE_URL_PROPERTY_KEY = "azure_mp_base_url";
 	public static final String AZURE_LIST_SUBS_API_PROPERTY_KEY = "azure_list_subs_api";
 	public static final String AZURE_UPDATE_SUBS_API_PROPERTY_KEY = "azure_update_subs_api";
 	public static final String AZURE_ACTIVATE_SUBS_API_PROPERTY_KEY = "azure_activate_subs_api";
 	public static final String AZURE_LIST_OPS_API_PROPERTY_KEY = "azure_list_operations_api";
 	public static final String AZURE_UPDATE_OPS_API_PROPERTY_KEY = "azure_update_operations_api";
 	public static final String AZURE_API_VERSION_PROPERTY_KEY = "azure_api_version_query_param_key";
 	public static final String AZURE_API_VERSION_PROPERTY_VALUE = "azure_api_version_query_param_value";
	public static final String AZURE_CLIENT_ID_KEY = "client_id";
	public static final String AZURE_CLIENT_SECRET_KEY = "client_secret";
	public static final String AZURE_CLIENT = "azure_mp_client_id";
	public static final String AZURE_CLIENT_SECRET = "azure_mp_client_secret";
 	public static final String AZURE_RESOURCE_KEY = "resource";
 	public static final String AZURE_SUBSCRIPTION_RESOURCE = "62d94f6c-d599-489b-a797-3e10e42fbe22";
 	public static final String AZURE_GRANT_TYPE_KEY = "grant_type";
 	public static final String AZURE_GRANT_TYPE_VALUE = "client_credentials";
}