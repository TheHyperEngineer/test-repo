/**
 * 
 */
package com.akamai.buyakamai.constants;

import java.util.Arrays;
import java.util.List;

/**
 * @author pguduthu
 * 
 */
public class SalesForceConstants {


    public static final String SF_VERSION_LINE = "/services/data/v30.0/";
    public static final String SOBJECTS = "sobjects/";
    public static final String INSTANCE_URL = "instance_url";
    public static final String ACCESS_TOKEN = "access_token";
    public static final String AUTHORIZATION = "Authorization";
    public static final String APPLICATION_JSON = "application/json";
    public static final String CONTENT_TYPE = "Content-Type";
    public static final String BEARER = "Bearer ";
    public static final String OPPORTUNITY_RESOURCE = "Opportunity/";
    public static final String SALESFORCE_PASSWORD = "salesforce_password";
    public static final String SALESFORCE_USER = "salesforce_user";
    public static final String SALESFORCE_CLIENT_SECRET = "salesforce_client_secret";
    public static final String SALESFORCE_CLIENT_ID = "salesforce_client_id";
    public static final String SALESFORCE_URL = "salesforce_url";
    public static final String CONTENT_ENCODING = "Content-Encoding";
    public static final String GZIP = "gzip";

    public static final String NO_ACCESS_TOKENS = "Access tokens could not be generated. The credentials provided maybe invalid.";

}