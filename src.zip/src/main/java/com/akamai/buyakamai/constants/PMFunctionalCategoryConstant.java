package com.akamai.buyakamai.constants;

public enum PMFunctionalCategoryConstant {

    BASE_PRODUCT_PRICING_ETLS_DEPENDENT("ETLS Billing Change"), CLOUDLET("Cloudlets - Base product dependency"), INTEGRATION("Integration");;

    private String value;

    PMFunctionalCategoryConstant(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

}
