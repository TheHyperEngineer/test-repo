package com.akamai.buyakamai.constants.enums;

public enum OMSServiceType {
	PURCHASE;
}
