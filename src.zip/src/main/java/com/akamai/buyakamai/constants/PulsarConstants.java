package com.akamai.buyakamai.constants;

public class PulsarConstants {
    
    public static final String ENV_KEY_HOST = "HOST";
    
    public static final String ENV_KEY_HOST_SCHEME = "HOST_SCHEME";
    
    public static final String ENV_KEY_HOST_PORT = "HOST_PORT";
    
    public static final String ENV_KEY_SERVICE_NAME = "SERVICE_NAME";
    
    public static final String ENV_KEY_APP_VERSION = "APP_VERSION";
    
    public static final String DEFAULT_HOST = "pulsar.extranet.akamai.com";
    
    public static final String DEFAULT_SCHEME = "http";
    
    public static final String DEFAULT_PORT = "80";

    public static final String LUNA_USERNAME = "LUNA_USERNAME";
    
    public static final String LUNA_PASSWORD = "LUNA_PASSWORD";

    public static final String TRUE = "true";
    
    public static final String FALSE = "false";
    
    public static final String ASYNC = "async";
    
    public static final String PULSAR_GRANT_TYPE_STRING = "grant_type";

    public static final String PULSAR_GRANT_TYPE_VALUE = "client_credentials";

    public static final String AKAMAI_ACCEPT ="Akamai-Accept";

    public static final String AKAMAI_BEARER_BODY = "akamai/bearer-body";

    public static final String ACCESS_TOKEN_URL_SUFFIX = "ACCESS_TOKEN_URL_SUFFIX";

    public static final String BEARER_TOKEN_STRING = "bearer ";

    public static final String NOTIFICATION_SERVICE_URL_SUFFIX = "notification_service_url_suffix";

    public static final String ENTERPRISE_EVENTS_URL_SUFFIX = "enterprise_events_url_suffix";
    
	public static final String EMAIL_STATUS_URL_SUFFIX = "email_status_url_suffix";

	public static final String RESEND_EMAIL_URL_SUFFIX = "resend_email_url_suffix";

    public static final String PULSAR_ADDRESS = "pulsar_server_addr";
    
}
