package com.akamai.buyakamai.constants;

public enum ValueConfirmationState {

    CREATED, RESULT_AVAILABLE, COMPLETED
}
