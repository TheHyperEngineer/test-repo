package com.akamai.buyakamai.constants;

public class EmailConstants {

	public static final String EXTENSION_APPROVAL_EMAIL_SUBJECT = "extension_approval_email_subject";

	public static final String EXTENSION_APPROVAL_EMAIL = "extension_approval_email";

	public static final String USER_FULL_NAME = "userFullName";

	public static final String ACCOUNT_NAME = "AccountName";

	public static final String PRODUCT_NAME = "ProductName";

}
