package com.akamai.buyakamai.constants;

public enum ApprovalTypeConstants {
    DealDesk,LEGAL,RSM
}
