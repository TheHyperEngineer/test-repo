package com.akamai.buyakamai.constants;

import com.akamai.buyakamai.service.events.*;

public enum UserEventAction {
    USER_LOGIN_SUCCESS(UserLoginEventDataGenerator.class, EventType.LOGIN),
    USER_LOGIN_FAILURE(UserLoginEventDataGenerator.class, EventType.LOGIN),
    NEW_TRIAL_SALESREP_SUCCESS(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    NEW_TRIAL_SALESREP_FAILURE(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    NEW_TRIAL_PARTNER_QUOTE_SUCCESS(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    NEW_TRIAL_PARTNER_QUOTE_FAILURE(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PARTNER_PROSPECT_TNC_ACCEPT_SUCCESS(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PARTNER_PROSPECT_TNC_ACCEPT_FAILURE(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    NEW_TRIAL_SDR_SUCCESS(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    NEW_TRIAL_SDR_FAILURE(NewTrialStartedEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    TRIAL_DETAILS_SUCCESS(UserViewsTrialPageEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    TRIAL_DETAILS_FAILURE(UserViewsTrialPageEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    ACTION_ON_ALERTS_SUCCESS(ActionOnAlertsEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    ACTION_ON_ALERTS_FAILURE(ActionOnAlertsEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    CREATE_OPPORTUNITY_SUCCESS(CreateOpportunityEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    CREATE_OPPORTUNITY_FAILURE(CreateOpportunityEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    TRIAL_ASSISTANCE_SUCCESS(TrialAssistanceEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    TRIAL_ASSISTANCE_FAILURE(TrialAssistanceEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    VALUE_CONFIRMATION_REQUEST_SUCCESS(ValueConfirmationRequestDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    VALUE_CONFIRMATION_REQUEST_FAILURE(ValueConfirmationRequestDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    DISPLAY_REPORTS(ValueConfirmationPivotalDataSetEventGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    EXTENSION_REQUESTED_SUCCESS(TrialExtensionSentDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    EXTENSION_REQUESTED_FAILURE(TrialExtensionSentDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PROD_RECOMMENDATION_SUCCESS(ProdRecommendationEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PROD_RECOMMENDATION_FAILURE(ProdRecommendationEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    CUSTOMER_QUOTE_CREATION_SUCCESS(ExistingCustomerTrialEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    CUSTOMER_QUOTE_CREATION_FAILURE(ExistingCustomerTrialEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PARTNER_QUOTE_CREATION_SUCCESS(ExistingCustomerTrialEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PARTNER_QUOTE_CREATION_FAILURE(ExistingCustomerTrialEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PARTNER_TNC_ACCEPT_SUCCESS(ExistingCustomerTrialEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION),
    PARTNER_TNC_ACCEPT_FAILURE(ExistingCustomerTrialEventDataGenerator.class, EventType.BUY_AKAMAI_USER_ACTION);

    private Class<? extends EventDataGenerator> eventDataGeneratorClass;
    private EventType eventType;


    UserEventAction(Class<? extends EventDataGenerator> eventDataGenerator, EventType eventType) {
        this.eventDataGeneratorClass = eventDataGenerator;
        this.eventType = eventType;
    }

    public Class<? extends EventDataGenerator> getEventDataGeneratorClass() {
        return eventDataGeneratorClass;
    }

    public EventType getEventType() {
        return eventType;
    }
}
