package com.akamai.buyakamai.constants;

public class DBLoggerConstants {

    public static final String OPPORTUNITY_ID = "OPPORTUNITY_ID";

    public static final String OPPORTUNITY_NAME = "OPPORTUNITY_NAME";

    public static final String ARL_FILE_NAME="ARL_FILE_NAME";

    public static final String ACCOUNT_ID = "ACCOUNT_ID";
    
    public static final String PARTNER_ACCOUNT_ID = "PARTNER_ACCOUNT_ID";

    public static final String ACCOUNT_NAME = "ACCOUNT_NAME";

    public static final String USER_ID = "USER_ID";

    public static final String ORDER_ID = "ORDER_ID";

    public static final String MESSAGE_ID = "EMAIl_MESSAGE_ID";

    public static final String EMAIl_ENTITY_ID = "EMAIl_ENTITY_ID";

    public static final String BUNDLE_ID = "BUNDLE_ID";

    public static final String PRODOPT_ID = "PRODUCT_OPTION_ID";

    public static final String LOCALE = "LOCALE";

    public static final String REQUEST_DATA = "REQUEST_DATA";

    public static final String CONTACT_ID = "CONTACT_ID";

    public static final String CONTRACT_ID = "CONTRACT_ID";

    public static final String CURRENCY = "CURRENCY";

    public static final String CATEGORY = "CATEGORY";

    public static final String ASSISTANCE_TEXT = "ASSISTANCE_TEXT";

    public static final String REQUEST_URL = "REQUEST_URL";

    public static final String VALUE_CONFIRMATION_ID = "VALUE_CONFIRMATION_ID";

    public static final String WEB_DELIVERY_TEST_SETUP_INFO_ID = "TEST_SETUP_INFO_ID";

    public static final String VALUE_CONFIRMATION_REPORT_TYPE = "REPORT_TYPE";

    public static final String WEB_DELIVERY_CASE_ID = "WEB_DELIVERY_CASE_ID";

    public static final String TENANT_NAME = "TENANT_NAME";

    public static final String LEAD_ID = "LEAD_ID";

    public static final String LEAD_NAME = "LEAD_NAME";

    public static final String SOURCE_ID = "SOURCE_ID";

    public static final String SOURCE_TYPE = "SOURCE_TYPE";

    public static final String PARTNER_ORDERS_REQUEST = "PARTNER_ORDERS_REQUEST";
    
    public static final String LOGGED_IN_CONTACT_ID = "LOOGED_IN_CONTACT_ID";
    
    public static final String ROLES = "ROLES";
    
    public static final String OPPORTUNITY_STAGES = "OPPORTUNITY_STAGES";
    
    public static final String EXCLUDE_STATUS = "EXCLUDE_STATUS";
    
    public static final String ALERT_KEY = "ALERT_KEY";
    
    public static final String REASON = "REASON";

	public static final String ORDER_VERSION_ID = "ORDER_VERSION_ID";

	public static final String DRAFT_ID = "DRAFT_ID";

    public static final String CHANNEL = "channel";

}
