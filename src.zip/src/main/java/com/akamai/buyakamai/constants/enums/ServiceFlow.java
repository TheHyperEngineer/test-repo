package com.akamai.buyakamai.constants.enums;

public enum  ServiceFlow {

    TRY_TO_BUY("try_to_buy");

    private String serviceType;

    ServiceFlow(String type) {
        this.serviceType = type;
    }

	public String getServiceType() {
		return serviceType;
	}

}
