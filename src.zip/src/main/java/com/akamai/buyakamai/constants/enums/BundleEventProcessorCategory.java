package com.akamai.buyakamai.constants.enums;

import com.akamai.buyakamai.constants.HistoryDefName;
import com.akamai.buyakamai.constants.OrderEventAction;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.HistoryEntity;
import com.akamai.buyakamai.service.alert.AlertStrategy;
import com.akamai.buyakamai.service.eventgenerators.EventGeneratorStrategy;
import com.akamai.buyakamai.service.history.HistoryStrategy;
import com.akamai.ids.commons.model.request.IdsRequest;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public enum BundleEventProcessorCategory {
    SOASTA("SoastaAlertStrategy", "SoastaHistoryStrategy", "SoastaEventGeneratorStrategy"), ARL_FILE("StagingPushAlertStrategy,ProdPushAlertStrategy", "", "ArlSummaryStrategy"),
    ENTERPRISE("EnterpriseAlertStrategy","EnterpriseHistoryStrategy","EnterpriseEventGeneratorStrategy"), DEFAULT;

    private List<AlertStrategy> alertStrategies = new ArrayList<>();
    private String alertStrategyClassName;

    private List<HistoryStrategy> historyStrategies = new ArrayList<>();
    private String historyStrategyClassName;

    private List<EventGeneratorStrategy> eventGeneratorStrategies = new ArrayList<>();
    private String eventGeneratorStrategyClassName;

    BundleEventProcessorCategory(String alertStrategyClassName, String historyStrategyClassName, String eventGeneratorStrategyClassName) {
        this.alertStrategyClassName = alertStrategyClassName;
        this.historyStrategyClassName = historyStrategyClassName;
        this.eventGeneratorStrategyClassName = eventGeneratorStrategyClassName;
    }

    BundleEventProcessorCategory() {
    }

    public void processAlerts(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        for (AlertStrategy strategy : alertStrategies)
            strategy.processAlertsForOrder(order, events, alerts);
    }

    public void processHistory(SelectOrderResponse order, List<EventData> events, List<HistoryEntity> historyEntities, OrderEventAction eventAction, HistoryDefName historyDefName) {
        for (HistoryStrategy strategy : historyStrategies)
            strategy.processHistoryForOrder(order, events, historyEntities, eventAction, historyDefName);
    }

    public void persistEvents(SelectOrderResponse order, List<EventData> events, IdsRequest idsRequest) {
        for (EventGeneratorStrategy strategy : eventGeneratorStrategies)
            strategy.persistEvents(order, events, idsRequest);
    }

    @Component
    private static class AlertProcessorBeanFetcher {
        @Autowired
        private ApplicationContext applicationContext;

        @PostConstruct
        public void initializeAlertProcessorBean() {
            for (BundleEventProcessorCategory processor : values()) {

                if (!StringUtils.isEmpty(processor.alertStrategyClassName)) {
                    List<String> alertStrategyList = Arrays.asList(processor.alertStrategyClassName.split("\\s*,\\s*"));
                    for (String alertStrategy : alertStrategyList)
                        processor.alertStrategies.add((AlertStrategy) applicationContext.getBean(alertStrategy));
                }

                if (!StringUtils.isEmpty(processor.historyStrategyClassName)) {
                    List<String> historyStrategyList = Arrays.asList(processor.historyStrategyClassName.split("\\s*,\\s*"));
                    for (String historyStrategy : historyStrategyList)
                        processor.historyStrategies.add((HistoryStrategy) applicationContext.getBean(historyStrategy));
                }

                if (!StringUtils.isEmpty(processor.eventGeneratorStrategyClassName)) {
                    List<String> eventGeneratorStrategyList = Arrays.asList(processor.eventGeneratorStrategyClassName.split("\\s*,\\s*"));
                    for (String eventStrategy : eventGeneratorStrategyList)
                        processor.eventGeneratorStrategies.add((EventGeneratorStrategy) applicationContext.getBean(eventStrategy));
                }
            }
        }
    }
}
