package com.akamai.buyakamai.constants;

public enum OrderSourceType {
	
	LEAD(EventDataPoint.LEAD_ID, UserEventAction.NEW_TRIAL_SDR_SUCCESS, UserEventAction.NEW_TRIAL_SDR_FAILURE, ActionType.QUOTE_CREATION_ATTEMPT_BY_SDR), 
	OPPORTUNITY(EventDataPoint.OPPORTUNITY_ID, UserEventAction.NEW_TRIAL_SALESREP_SUCCESS, UserEventAction.NEW_TRIAL_SALESREP_FAILURE, ActionType.QUOTE_CREATION_ATTEMPT_BY_SALES_REP),
	NONE(EventDataPoint.SOURCE_NOT_APPLICABLE, UserEventAction.NEW_TRIAL_SALESREP_SUCCESS, UserEventAction.NEW_TRIAL_SALESREP_FAILURE, ActionType.QUOTE_CREATION_ATTEMPT_BY_SALES_REP);
	
	private EventDataPoint eventDataPoint;
	private UserEventAction userSuccessEventAction;
	private UserEventAction userFailEventAction;
	private ActionType actionType;
	
	private OrderSourceType(EventDataPoint dataPoint, UserEventAction successEventAction,UserEventAction failEventAction, ActionType action) {
		this.eventDataPoint = dataPoint;
		this.userSuccessEventAction = successEventAction;
		this.userFailEventAction = failEventAction;
		this.actionType = action;
	}

	public EventDataPoint getEventDataPoint() {
		return eventDataPoint;
	}

	public UserEventAction getUserSuccessEventAction() {
		return userSuccessEventAction;
	}

	public UserEventAction getUserFailEventAction() {
		return userFailEventAction;
	}

	public ActionType getActionType() {
		return actionType;
	}

}
