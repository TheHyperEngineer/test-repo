package com.akamai.buyakamai.constants;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

public enum HappinessIndexType {
    GREY(0), RED(25), YELLOW(50), GREEN(100);

    private final Integer happinessScore;

    HappinessIndexType(Integer happinessScore) {
        this.happinessScore = happinessScore;
    }

    private static Map<Integer, HappinessIndexType> INDEX_LOOKUP = Arrays.stream(values())
            .collect(Collectors.toMap(e->e.happinessScore,e->e));

    public Integer getHappinessScore() {
        return happinessScore;
    }

    public static Integer getNextHigherScore(Integer oldHappinessScore){
        HappinessIndexType oldIndexType= INDEX_LOOKUP.get(oldHappinessScore);
      switch (oldIndexType){
          case RED: return YELLOW.happinessScore;
          case YELLOW:
          case GREEN: return GREEN.happinessScore;
          default: return RED.happinessScore;
      }
    }


    public static Integer getNextLowerScore(Integer oldHappinessScore){
        HappinessIndexType oldIndexType= INDEX_LOOKUP.get(oldHappinessScore);
        switch (oldIndexType){
            case GREEN: return YELLOW.happinessScore;
            case YELLOW:
            case RED: return RED.happinessScore;
            default: return RED.happinessScore;
        }
    }

}
