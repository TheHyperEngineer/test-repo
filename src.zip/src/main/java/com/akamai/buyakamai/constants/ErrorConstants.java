package com.akamai.buyakamai.constants;

public class ErrorConstants {

	public static final String GET_ALL_ORDERS_FAILED_KEY = "get.orders.failed";

	public static final String GET_ORDER_DETAILS_FAILED_KEY = "get.order.details.failed";
	
	public static final String SEND_EXTENSION_APPROVAL_EMAIL_FAILED_KEY = "send.extension.approval.email.failed";
	
	public static final String GET_ORDER_STATUS_FAILED_KEY = "get.order.status.failed";
	
	public static final String GET_TRAFFIC_FOR_CPCODE_DETAILS_FAILED_KEY = "get.traffic.for.cpcode.failed";
	
	public static final String DATA_HANDLING_FAILED = "buyakamai.data.handling.failed";
	
	public static final String INVALID_ALERT_STATE = "alert.state.invalid";
	
	public static final String INVALID_ALERT_ID = "alert.id.invalid";
	
	public static final String INVALID_ORDER_ID = "order.id.invalid";
	
	public static final String ALERT_UPDATE_FAILED = "alert.update.failed";

	public static final String ALERTS_FETCH_FAILED = "alert.fetch.failed";
	
	public static final String ACCOUNT_FETCH_FAILED = "account.fetch.failed";

	public static final String USER_SEARCH_FAILED = "user.search.failed";
	
	public static final String GET_BUNDLES_FAILED_KEY = "get.bundles.failed";

	public static final String OPPORTUNITY_CREATION_VALIDATION_FAILURE_KEY = "opportunity.creation.validation.failed";
	
	public static final String QUOTE_CREATION_FAILED = "quote.creation.failed";

	public static final String QUOTE_ACCEPTANCE_FAILED = "quote.acceptance.failed";

	public static final String GET_OPPORTUNITY_DETAILS_FAILED_KEY = "get.opportunity.details.failed";

	public static final String SEARCH_LEADS_FAILED_KEY = "search.leads.failed";

	public static final String INVALID_ASSISTANCE_TEXT = "assistance.text.invalid";
	
	public static final String INVALID_ASSISTANCE_CATEGORY = "assistance.category.invalid";
	public static final String EMPTY_ASSISTANCE_PAGE = "assistance.page.empty";
	public static final String ORDER_EVENT_FETCH_FAILED = "orders.events.fetch.failed";
	public static final String GET_ALL_OPPORTUNITIES_FAILED_KEY = "opportunity.getall.failed";
	
	public static final String OPPORTUNITY_LOOKUP_FAILED_KEY = "opportunity.lookup.failed";
	
	public static final String GET_USER_INFO_FAILED_KEY = "get.user.info.failed";
	
	public static final String GET_ACCOUNT_DETAILS_FAILED_KEY = "get.account.details.failed";
	
	public static final String GET_ACCOUNT_LIST_FAILED_KEY = "get.account.list.failed";
	
	public static final String ACCOUNT_SEARCH_FAILED_KEY = "account.search.failed";
	
	public static final String GET_MP_USERS_FAILED_KEY = "get.mpusers.failed";
	
	public static final String GET_ACCOUNTS_FAILED_KEY = "get.accounts.failed";
	
	public static final String GET_PRODUCTS_FAILED_KEY = "get.product.failed";
	
	public static final String GET_CONTRACTS_FAILED_KEY = "get.contract.failed";

	public static final String GET_PRICING_FOR_PRODUCT_FAILED_KEY = "get.pricing.failed";
	
	public static final String RECOMMEND_PRODUCT_FAILED_KEY = "recommend.product.failed";
	
	public static final String OPPORTUNITY_CREATION_FAILURE_KEY = "opportunity.creation.failed";

	public static final String OPPORTUNITY_CREATION_CONFLICT_KEY = "opportunity.creation.conflict";

	public static final String GET_ORDER_HAPPINESS_SCORE_FAILED = "get.order.happiness.score.failed";
	
	public static final String SEND_TRIAL_ASSISTANCE_EMAIL_FAILED = "send.trial.assistance.email.failed";

	public static final String GET_ORDER_CONTACTS_FAILED_KEY = "get.order.contacts.failed";

	public static final String RESEND_CREDETIAL_FAILED_KEY = "resend.credetial.failed";

	public static final String PARTNER_ORDERS_FETCH_FAILED = "get.partner.orders.failed";

	public static final String PARTNER_BASIC_ORDERS_FETCH_FAILED = "get.basic.partner.orders.failed";

	public static final String CUSTOMER_QUOTE_CREATION_FAILED = "customer.quote.creation.failed";

	public static final String EXTEND_TRIAL_FAILED_KEY = "order.extension.failed";

	public static final String CONTACT_CREATION_FAILED = "create.contact.failed";
	
	public static final String EXTEND_TRIAL_TNC_ACCEPTANCE_FAILED_KEY = "order.extension.tnc.acceptance.failed";

	public static final String REGISTER_CONTACT_FAILED = "register.contact.failed";

    public static final String VALUE_CONFIRMATION_REPORT_REQUEST_FAILED = "valueConfirmation.reportRequest.failed";

	public static final String VALUE_CONFIRMATION_FETCH_REPORT_FAILED = "valueConfirmation.fetchReport.failed";
	
	public static final String GET_ALL_LEADS_FAILED_KEY = "lead.getall.failed";
	
	public static final String GET_LEAD_DETAILS_FAILED_KEY = "get.lead.details.failed";
	public static final String GET_OPPORTUNITIES_FAILED = "get.opportunities.failed";
	public static final String OMS_GET_ORDERS_FAILED = "get.orders.failed.oms";
	public static final String OMS_GET_VERSION_HISTORY_FAILED = "get.version.history.failed.oms";	
	public static final String GET_RECOMMENDED_PRODUCTS_FROM_BRE_FAILED = "get recommended products from BRE at 'buyAkamai/recommendedProducts' failed.";

	public static final String OMS_GET_VERSION_DETAILS_FAILED = "get.order.version.details.failed.oms";

	public static final String OMS_GET_SELECT_ORDER_FAILED = "get.select.order.failed";

	public static final String GET_TITLE_DETAILS_FAILED = "get.order.titles.failed";


	public static final String OMS_CREATE_VERSION_FAILED = "create.order.version.failed";

	public static final String OMS_CREATE_NEW_ORDER_FAILED = "create.new.order.failed";

	public static final String OMS_GET_DRAFT_DETAILS_FAILED = "get.draft.details.failed.oms";

	public static final String GET_QUOTE_APPROVAL_FROM_BRE_FAILED = "get quote approvals from BRE at 'buyAkamai/quote' failed.";
	public static final String GET_PRODUCT_APPROVAL_FROM_BRE_FAILED = "get product approval from BRE at 'buyAkamai/product' failed.";
	public static final String GET_SSL_CERTIFICATE_FOR_PRODUCTS_FROM_BRE_FAILED = "get SslDetails for products from BRE at 'buyAkamai/productCertificateDetail' failed.";


	public static final String OMS_CREATE_DRAFT_FAILED = "create.draft.failed.oms";
	public static final String OMS_UPDATE_DRAFT_FAILED = "update.draft.failed.oms";
	
	public static final String OMS_GET_SBT = "get.sbt.failed.oms";
	
	public static final String OMS_SBT_RULE_RESPONSE_EMPTY = "get.bre.sbt.failed.oms";
	public static final String OMS_UPDATE_VERSION_FAILED = "update.version.failed.oms";
	
	public static final String OMS_RESTRICTION_ON_IMPERSONATION = "oms.impersonation.access.restricted";
	
	public static final String NO_ACTIVE_OPPORTUNITY_FOUND = "active.opportunity.not.found";
	
	public static final String BILLING_EFFECTIVE_DATE_INVALID_INPUT = "billing.effective.date.invalid.input";

}
