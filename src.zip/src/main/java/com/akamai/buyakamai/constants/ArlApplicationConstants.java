package com.akamai.buyakamai.constants;

public class ArlApplicationConstants {
	/**
	 * Timeout value used for DNS resolutions by HttpConfigurationService and BasicPropertyService 
	 */
	public static final String DNS_LOOKUP_TIMEOUT = "dns_lookup_timeout";
	
	/**
	 * Core API pagination value used by HttpConfigurationService and BasicPropertyService 
	 */
	public static final String CORE_API_PAGINATION = "core_api_pagination";

	public static final String MAX_THREADS = "dns_max_threads";
	
	public static final String LUNA_ADDRESS = "luna_server_addr";
	
	public static final String LUNA_IDENTITY = "luna_identity";
}
