package com.akamai.buyakamai.constants;

public enum AlertState {
	
	ACTIVE, SNOOZED, COMPLETE, ACKNOWLEDGED;
}
