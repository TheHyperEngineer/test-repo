package com.akamai.buyakamai.constants.enums;

public enum RequestorType {
	PAE, PARTNER, INT_OPS
}
