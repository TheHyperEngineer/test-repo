package com.akamai.buyakamai.constants;

import java.util.Arrays;
import java.util.List;

public class BAConstants {

	public static final String DEFAULT_LOCALE_KEY = "default_locale";

	public static final String MEDIATYPE_PROBLEM_JSON = "application/problem+json";

	public static final String PROBLEM_INSTANCE_PREFIX = "/error-instances/";

	//TODO - temp value. Should be replace once buy akamai has its own client id and secret
    public static final String BUY_AKAMAI_CLIENT = "buy-akamai";

    public static final String MARKETPLACE_URL = "marketplaceUrl";

    public static final String ENV_KEY_HOST_SCHEME = "HOST_SCHEME";

    public static final String ENV_KEY_HOST = "HOST";

    public static final String ENV_KEY_HOST_PORT = "HOST_PORT";

    public static final String DEFAULT_SCHEME = "http";

    public static final String DEFAULT_HOST = "localhost";

    public static final String DEFAULT_PORT = "80";

    public static final String ORDER_TYPE = "OrderType";

    public static final String ORDER_STATUS = "OrderStatus";

    public static final String STATE = "STATE";

    public static final String REQUEST_ID_LIST = "ID-List";

    public static final String ORDER_FILTER_TYPE = "OrderFilterType";

    public static final String USER_NAME = "X-IDS-IDENTITY-ID";

    public static final String IMP_USER_ID = "X-IDS-IMPERSONATOR-ID";

    public static final String DETAIL_MISSING_SCOPES = "Missing scopes";

    public static final String SCOPE_FRIEND = "FRIEND";

    public static final String DATE_FORMAT_FOR_GET_EVENTS = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    public static final String DATE_FORMAT_FOR_GET_EVENTS_END_DATE = "yyyy-MM-dd'T'23:59:59'Z'";

    public static final String DATE_FORMAT_FOR_TIME_STAMP = "yyyy-MM-dd HH:mm:ss.SSSSSSSSS";

    public static final String DATE_FORMAT_FOR_MPULSE_LOGIN= "yyyy-MM-dd'T'HH:mm:ss.SSSSSSSSS";

    public static final String DATE_FORMAT_FOR_SST_REPORT = "yyyy-MM-dd HH:mm:ss";

    public static final String DATE_FORMAT_FOR_SELECT_ORDERS = "yyyy-MM-dd'T'HH:mm:ssXXX";

    public static final String DATE_FORMAT_ORDER = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    public static final String DATE_FORMAT_OPPORTUNITY = "yyyy-MM-dd'T'HH:mm:ss";

    public static final String DATE_FORMAT_LEAD = "yyyy-MM-dd'T'HH:mm:ss";

    public static final String DATE_FORMAT_LEO_INTERNAL = "yyyy-MM-dd'T'HH:mm:ss.SSSZ";

	public static final String UI_METADATA_CACHE_MAXIMUM_SIZE = "metadata_cache_maximum_size";

	public static final String UI_METADATA_CACHE_EXPIRY_PERIOD = "metadata_cache_expiry_period";

	public static final String ACCOUNTID_CACHE_MAXIMUM_SIZE = "accountId_cache_maximum_size";

	public static final String ACCOUNTID_CACHE_EXPIRY_PERIOD = "accountId_cache_expiry_period";

	public static final String ACCEPT_LANGUAGE = "accept-language";

    public static final String DEFAULT_LOCALE = "en_US";

	public static final String METADATA_JSON_DOUBLE_QUOTES="\"";
    public static final String METADATA_TAG_VALUE_SEPARATOR=":";
    public static final String METADATA_LOCALE_REGEX="\"(localized_(.+?))\"";
    public static final String METADATA_OBJECT_NODE_KEY = "metadata";

	public static final String CONTEXT = "marketplace";

	public static final String BUNDLE = "marketplace3";
    public static final String GET_BASIC_PROPS_URL = "get_basic_props_for_account_url";

    public static final String DATE_FORMAT_WITHOUT_TIME = "yyyy-MM-dd";

    public static final String GOMEZ_DATE_FORMAT = "MM/dd/yyyy";


    public static final String SUPPORTED_CURRENCIES="opportunity_supported_currencies";
    public static final String SUPPORTED_DEAL_TYPES="opportunity_supported_deal_types";
    public static final String SUPPORTED_STAGES="opportunity_supported_stages";
    public static final String CREATION_SUPPORTED_STAGES="opportunity_creation_supported_stages";
    public static final String OPPORTUNITY_CAMPAIGN_OFFER_TYPE = "opportunity_campaign_offer_type";
    public static final String SUPPORTED_COMPETITORS="opportunity_supported_competitors";
    public static final String OPPORTUNITY_CLOSE_DATE_INTERVAL ="opportunity_close_date_interval";
    public static final String SALES_FORCE_BASE_URL ="sales_force_base_url";
	public static final String SEPERATOR = "/";
	public static final String MP_APP_RELATIVE_URL_KEY = "mp_app_url";


	public static final String GET_USER_REGISTRATION_URL = "/v1/users/{contactId}/status";

	public static final String V1_ORDERS_ORDER_ID_API = "/v1/orders/{orderId}";
	
	public static final String V1_PARTNER_ORDER_STATUS_API = "/v1/partner-orders/{orderId}/status";

	public static final String ALERTS_DESC_ARGS_SEPARATOR = "###";

    public static final String OPPORTUNITY_LOOKUP_STAGES="opportunity_lookup_stages";

	public static final String ASSISTANCE_FROM_EMAIL_KEY = "assistance_email_from";
	public static final String ASSISTANCE_TO_LIST_KEY = "assistance_email_to_list";
	public static final String ASSISTANCE_CC_LIST_KEY = "assistance_email_cc_list";

    public static final String VALUE_CONFIRMATION_FROM_EMAIL_KEY = "valueConfirmation_email_from";
    public static final String VALUE_CONFIRMATION_TO_LIST_KEY = "valueConfirmation_email_to_list";
    public static final String VALUE_CONFIRMATION_CC_LIST_KEY = "valueConfirmation_email_cc_list";

	public static final String PROD_REC_FROM_EMAIL_KEY = "product_rec_email_from";
	public static final String PROD_REC_CC_LIST_KEY = "product_rec_cc_list";

	public  static  final String ACCOUNT_LOOKUP_STATUS="account_lookup_status";
    public static final String EVENT_REQUEST = "EVENT_REQUEST";
    public static final String EVENT_START_DATE = "EVENT_START_DATE";
    public static final String BUYAKAM_USER = "BUYAKAM-USER";

	public static final String QUOTEACCEPTED_ORDER_SOURCE="get_ordersource_quoteacepted";

	public static final String EXTEND_TRIAL_URL = "extend_trial_url";

	public static final String EXTEND_PARTNER_TRIAL_URL = "extend_partner_trial_url";

	public static final String CONTACT_REGISTER_URL = "contact_register_url";

	public static final String GET_ASSOCIATED_ACTIVE_ORDER_URL = "get_associated_active_url";
	
	public static final String GET_ACCOUNT_CONTACTS_URL = "get_account_contacts_url";

	public static final String ASSISTANCE_DEF_EMAIl_TEMPLATE = "ASSISTANCE_DEF_EMAIl_TEMPLATE";

	public static final String ASSISTANCE_DEF_EMAIl_TEMPLATE_SUB = "ASSISTANCE_DEF_EMAIl_TEMPLATE_SUB";

    public static final String VALUE_CONFIRMATION_DEF_EMAIl_TEMPLATE = "VALUE_CONFIRMATION_DEF_EMAIl_TEMPLATE";

    public static final String VALUE_CONFIRMATION_DEF_EMAIl_TEMPLATE_SUB = "VALUE_CONFIRMATION_DEF_EMAIl_TEMPLATE_SUB";

	public static final String PROD_REC_SALES_REP_EMAIl_TEMPLATE = "PROD_REC_SALES_REP_EMAIl_TEMPLATE";

	public static final String PROD_REC_SALES_REP_EMAIl_SUBJECT = "PROD_REC_SALES_REP_EMAIl_SUBJECT";

	public static final String PROD_REC_CUSTOMER_EMAIl_TEMPLATE = "PROD_REC_CUSTOMER_EMAIl_TEMPLATE";

	public static final String PROD_REC_CUSTOMER_EMAIl_SUBJECT = "PROD_REC_CUSTOMER_EMAIl_SUBJECT";

	public static final String HIERARCHY_FILTERING_LEVEL="hierarchy_filtering_level";

    public static final String OPPORTUNITY_CACHE_KEY = "OPPORTUNITY_CACHE_KEY";

    public static final String LEAD_CACHE_KEY = "LEAD_CACHE_KEY";

    public static final String OPPORTUNITIES_CACHE_MAXIMUM_SIZE = "opportunities_cache_maximum_size";
    public static final String LEADS_CACHE_MAXIMUM_SIZE = "leads_cache_maximum_size";
    public static final String OPPORTUNITIES_CACHE_EXPIRY_PERIOD = "opportunities_cache_expiry_period";
    public static final String LEADS_CACHE_EXPIRY_PERIOD ="leads_cache_expiry_period";


    public static final String CONTACTS_UI_METADATA_CACHE_SIZE= "contacts_ui_metadata_cache_size";
    public static final String CONTACTS_UI_METADATA_CACHE_EXPIRY_PERIOD_IN_MIN = "contacts_ui_metadata_cache_expiry_period_in_min";

    public static final String ALERTS_CACHE_MAXIMUM_SIZE = "alerts_cache_maximum_size";
    public static final String ALERTS_CACHE_EXPIRY_PERIOD = "alerts_cache_expiry_period_in_minutes";

	public static final String DEFAULT_ROLE = "DEFAULT";

	public static final String SALES_REP_ROLE = "SALES_REP";
	public static final String SDR_ROLE = "SDR";
    public static final String SALES_ANALYST_ROLE = "SALES_ANALYST";
    public static final String SALES_HIGHER_MGMT_ROLE = "SALES_HIGHER_MGMT";

    public static final String PAE_ROLE = "PAE";
    public static final String ALL_PARTNERS_ADMIN = "ALL_PARTNERS_ADMIN";
    public static final String TRIAL_CATEGORY_TYPE = "TRIAL";
    public static final String PURCHASE_CATEGORY_TYPE = "PURCHASE";
    public static final String CREATING_QUOTE_OR_ORDER = "Creating a quote or order";


    public static final String SOLUTION_ENG_ROLE = "SOLUTION_ENGINEER";

    public static final String INTEGRATED_OPS_ROLE = "INTEGRATED_OPS";

    public static final String PARTNER_ADMIN_ROLE = "PARTNER_ADMIN";

    public static final List<String> SALES_RELATED_ROLES = Arrays.asList(SALES_REP_ROLE,SALES_ANALYST_ROLE,SALES_HIGHER_MGMT_ROLE);

    public static final String FALLBACK_LOCALE="en_US";

    public static final String TECHNICAL_SALES_PRIMARY ="Technical Sales - Primary";

    public static final String PRODUCTS_WITHOUT_CONFIG_KEY ="products_without_config";

    public static final String ACTIVE_ORDER_LIST_CACHE_KEY = "ACTIVE_ORDER_LIST_CACHE_KEY";
    public static final String ACTIVE_ORDER_LIST_CACHE_MAXIMUM_SIZE = "activeOrderId_cache_maximum_size";
    public static final String ACTIVE_ORDER_LIST_CACHE_EXPIRY_PERIOD = "activeOrderId_cache_expiry_period";

    public static final String XLSX_MEDIA_TYPE = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    public static final String CSV_MEDIA_TYPE = "text/csv";
    public static final String ACCEPT_HEADER = "Accept";
    public static final String CONTENT_DISPOSITION_HEADER = "Content-Disposition";

    public static final String KEY_PROPERTY_NAME = "PROPERTY_NAME";

    public static final String AQL_STAGE="0.5 AQL";

    public static final String DEFAULT_INTERVAL_SST_REPORT_DAYS = "default_interval_sst_reports_days";

    public static final String MAX_INTERVAL_SST_REPORT_DAYS = "max_interval_supported_sst_reports_days";
    
    public static final String ALERT_ACK_DURATION = "alert.ack.duration";

    public static  final  String ALERT_ACK_ACTION = "Acknowledge";

    public static final String ORDER_ID = "order_id";

    public static final String HAPPINESS_INDEX_TNC_INTERVAL_HOURS="happiness_index_tnc_interval_hours";

    public static final String ROOT_ORDER_ID="ROOT_ORDER_ID";

    public static final String REQUEST_SUPPORT_ACTION = "Request support";

    public static final String EXTEND_TRIAL_ACTION = "Extend trial";

    public static final String AWAITING_EXTENSION_NOTIFICATION_TIME_HOURS = "awaiting_extension_time_interval_hours";

    public static final String SALES_REP_MAX_EXTENSION_SUPPORTED_DAYS = "sales_rep_max_extension_days";

    public static final String COMMA_SEPERATOR = ",";

    public static final String MPULSE_INSIGHT_URL = "mpluse_insight_url";

    public static final String EVENT_SEPERATOR = "##";

    public static final String NEGATIVE_EVENT_APPEND_TEXT = "_NEGATIVE";

    public static final String CASE_CREATION_FLAG = "poc.trial.enabled";

    public static final String URL_GET_MP_IDENTITIES = "get_mp_users_url";

    public static final String TRIAL_TYPE_POC = "POC";

    public static final String TRIAL_TYPE_SELF_SERVICE = "Self Service";

    public static final String PRODUCT_MAX_TRAIL_DETAILS = "bundle.trial.extension.max.days";

    public static final String DEFAULT_PRODUCT_ID = "default";

    public static final String POC_FAILURE_ALERT_HISTORY_TEXT = "case_creation_failed";
    public static final String ADDON_TYPE = "ADDON";
    public static final String BASE_PRODUCT_TYPE = "BASE_PRODUCT";

    public static final String SOURCE_TYPE_LEAD = "LEAD";
    public static final String SOURCE_TYPE_OPPORTUNITY = "OPPORTUNITY";

    public static final String ORDER_SOURCE_QUOTE_ACCEPTED = "quoteAccepted";

    public static final String LEAD_OWNER_CACHE_MAXIMUM_SIZE="lead_owner_cache_maximum_size";
    public static final String LEAD_OWNER_CACHE_EXPIRY_PERIOD_IN_MINUTES="lead_owner_cache_expiry_period_in_minutes";

    public static final String TRIAL_REC_TYPE = "trial";

    public static final String TNC_VIEW_QUERY_PARAM = "contractType";
    public static final String PARTNER_CONSTANT = "Partner";
    public static final String DIRECT_CUSTOMER = "DirectCustomer";

    public static final String PARTNER_FEATURE_ENABLE_FLAG ="partner_feature_enable_flag";
    public static final String PRODUCT_RECOMMENDATION_QUERY_PARAM="select";
    public static final String MARKETING_PRODUCT_ID = "marketingProductId";
    public static final String PARTNER_ACCOUNT_ID_QUERY_PARAM="partnerAccountId";
    public static final String INDIRECT_CUSTOMER_ACCOUNT_ID="indirectAccountId";
    public static final String INDIRECT_CUSTOMER_ACCOUNT="inDirectAccountId";
    public static final String USER_TYPE = "userType";
    public static final String RECOMMENDATION="recommendation";
    public static final String USER_ID = "userId";

    public static final String CURRENCY = "currency";
    public static final String SERVICE_TYPE = "serviceType";
    public static final String EXISTING_ACCOUNT_NEW_CONTRACT = "existingAccountNewContract";

    public static final String BUNDLE_ID = "bundleId";
    public static final String IS_PARTNER = "isPartner";
    public static final String LOCALE = "locale";
    
    public static final String APPLICATION_DOWN_TIME_CONSTANT = "is_downtime";
    public static final String APPLICATION_DOWN_TIME_MESSAGE = "downtime_message";
    public static final String APPLICATION_DOWN_ALLOWED_URLS = "down_time_allowed_api";

	public static final String INTERNAL_USER = "internal";
	public static final String EXTERNAL_USER = "external";
    public static final String PARTNER_ACCOUNT_STATUS = "Tier 1 Reseller.*";

    public static final String UI_PROPERTY_KEY = "ui_property_keys";
    
    public static final String BLOCKED_PARTNERS_PROPERTY_KEY = "blocked_partners";
    
    public static final String PROSPECT = "prospect";
    public static final String CUSTOMER = "customer";

    public static final String UPDATED_BY_QUERY_PARAM = "updatedBy";
    
    public static final String ATNT_PARTNER_ACCOUNTS_KEY = "atnt_partner_accounts";
    
    public static final String ORDER_STATUS_ONGOING = "Ongoing";
    
    public static final String ORDER_TYPE_TRIAL = "trial";
    
    public static final String ORDER_FILTER_ACCOUNT = "account";
    
    public static final String ORDER_TYPE_PROSPECT = "Prospect";

    public static final String WEB_DELIVERY = "WEB_DELIVERY";
    
    public static final String DEPRECATED_BUNDLES = "deprecated_bundles";

    public static final String BILLING_EFFECTIVE_DATE = "billingEffectiveDate"; 
    public static final String INTEGRATION_TYPE_MANAGED = "MANAGED";
    public static final String PRODUCT_WITH_MANAGED_INTEGRATION_BED = "product_with_managed_integration_bed";
    public static final String DEFAULT_BED = "default_billing_effective_days";
    public static final String SPECIAL_BUSINESS_TERM_JSON = "special_business_term_response";
    public static final String SPECIAL_BUSINESS_TERM_KEYS = "special_business_term_keys";
    public static final String SPECIAL_BUSINESS_TERM_TOOL_TIP_KEYS = "special_business_term_tool_tip_keys";
    public static final String BUY_AKAMAI_CONTEXT = "buy-akamai";
    public static final String SBT_BUNDLE = "business-term";
    
    public static final String ENTERPRISE_PRODUCTS_KEY = "enterprise_products";
    
    public static final String ENTERPRISE_TEAM_EMAIL_KEY = "enterprise_team_email";
    
    public static final String INTEGRATION_TYPE_PRODUCT_ID_EXCLUSION_FOR_BED = "integration_type_productid_exclusion_for_bed";

    public static final String BUY_AKAMAI_APP = "/apps/mpcc";

    public static final String VERSION_REDIRECTION_PATH_APPENDER = "type=ORDERS&serviceType=PURCHASE&apiVersion=4";
    public static final String BUY_AKAMAI_HOME_PAGE = "buy_akamai_home_page";

    public static final String EAA_CERT_PATH = "eaa_cert_path";
    public static final String EAA_PRIVATE_KEY_PATH = "eaa_private_key_path";
}