package com.akamai.buyakamai.constants;

import java.util.HashMap;
import java.util.Map;

import com.akamai.buydata.kpieventlogging.KpiEventDataKeys;



public enum EventDataPoint {
    USER_NAME, ROLE, USER_EMAIL_ID, USER_CONTACT_ID, ACCOUNT_NAME, ACCOUNT_OWNER_NAME, ACCOUNT_ID, CONTACT_NAME, CONTACT_EMAIL, CONTACT_ID, ORDER_ID, ROOT_ORDER_ID,
    CONTRACT_ID, PRODUCT_NAME, PRODUCT_DETAILS, TRIAL_START_DATE, TRIAL_END_DATE, ALERT_ID, ALERT_TYPE, ALERT_ACTION_TYPE, OPPORTUNITY_ID,
    OPPORTUNITY_NAME, STAGE, CLOSE_DATE, OPPORTUNITY_CURRENCY, DEAL_TYPE, COMPETITOR_PRIMARY, BUNDLE_ID, ORDER_STATUS, BUNDLE_NAME, TRIAL_DURATION,
    BASE_PROD_QUANTITY, BASE_PRODUCT_ID, BASE_PROD_OVERAGE_PRICE, SELECTED_OPTIONS, BASE_PRODUCT_LIST_ITEM, QUOTE_CREATION_REQUEST,CUSTOMER_QUOTE_CREATION_REQUEST,
    CATEGORY, CATEGORY_ID, ASSISTANCE_TEXT, VALUE_CONFIRMATION_FORM_DATA, TIME_STAMP, SALES_REP_FULL_NAME, VALUE_CONFIRMATION_REPORT_TYPE, MARKET_PLACE_OPPORTUNITY_ID, EVENT_ACTION, DATE_REPORT_DISPLAYED,
    EXTENSION_REASON, EXTENSION_DAYS, INTEGRATION_TYPE,LEAD_ID,PROD_OPT_ID, PARTNER_ACCOUNT_ID, PARTNER_ACCOUNT_NAME, PARTNER_CONTACT_ID, ACCEPT_TNC_REQUEST, CUSTOMER_ACCEPT_TNC_REQUEST, SOURCE_NOT_APPLICABLE;

	private static Map<String, String> kpiDataPointsMap = new HashMap<>();

	static {
		kpiDataPointsMap.put(EventDataPoint.ACCOUNT_ID.name(), KpiEventDataKeys.ACCOUNT_ID);
		kpiDataPointsMap.put(EventDataPoint.USER_EMAIL_ID.name(), KpiEventDataKeys.USER_EMAIL);
		kpiDataPointsMap.put(EventDataPoint.ROLE.name(), "role");

		kpiDataPointsMap.put(EventDataPoint.ACCOUNT_NAME.name(), "account_name");
		kpiDataPointsMap.put(EventDataPoint.ACCOUNT_OWNER_NAME.name(), "account_owner_name");
		kpiDataPointsMap.put(EventDataPoint.CONTACT_NAME.name(), "contact_name");
		kpiDataPointsMap.put(EventDataPoint.CONTACT_EMAIL.name(), "contact_email");
		kpiDataPointsMap.put(EventDataPoint.PRODUCT_DETAILS.name(), "product_details");
		kpiDataPointsMap.put(EventDataPoint.TRIAL_END_DATE.name(), "trial_end_date");
		kpiDataPointsMap.put(EventDataPoint.TRIAL_START_DATE.name(), "trial_start_date");
		kpiDataPointsMap.put(EventDataPoint.ROOT_ORDER_ID.name(), "root_order_id");
		kpiDataPointsMap.put(EventDataPoint.ALERT_ID.name(), "alert_id");
		kpiDataPointsMap.put(EventDataPoint.ALERT_TYPE.name(), "alert_type");
		kpiDataPointsMap.put(EventDataPoint.ALERT_ACTION_TYPE.name(), "alert_action_type");
		kpiDataPointsMap.put(EventDataPoint.OPPORTUNITY_ID.name(), KpiEventDataKeys.OPPORTUNITY_ID);
		kpiDataPointsMap.put(EventDataPoint.OPPORTUNITY_NAME.name(), "opportunity_name");
		kpiDataPointsMap.put(EventDataPoint.STAGE.name(), "stage");
		kpiDataPointsMap.put(EventDataPoint.CLOSE_DATE.name(), "close_date");
		kpiDataPointsMap.put(EventDataPoint.OPPORTUNITY_CURRENCY.name(), "opportunity_currency");
		kpiDataPointsMap.put(EventDataPoint.DEAL_TYPE.name(), "deal_type");
		kpiDataPointsMap.put(EventDataPoint.COMPETITOR_PRIMARY.name(), "competitor_primary");
		kpiDataPointsMap.put(EventDataPoint.ORDER_STATUS.name(), "order_status");
		kpiDataPointsMap.put(EventDataPoint.COMPETITOR_PRIMARY.name(), "competitor_primary");
		kpiDataPointsMap.put(EventDataPoint.BUNDLE_NAME.name(), "bundle_name");
		kpiDataPointsMap.put(EventDataPoint.TRIAL_DURATION.name(), "trial_duration");
		kpiDataPointsMap.put(EventDataPoint.BASE_PROD_QUANTITY.name(), "base_product_quantity");
		kpiDataPointsMap.put(EventDataPoint.BASE_PRODUCT_ID.name(), "base_product_id");
		kpiDataPointsMap.put(EventDataPoint.BASE_PROD_OVERAGE_PRICE.name(), "base_product_overage_price");
		kpiDataPointsMap.put(EventDataPoint.BASE_PRODUCT_LIST_ITEM.name(), "base_product_list_item");
		kpiDataPointsMap.put(EventDataPoint.SELECTED_OPTIONS.name(), "selected_options");
		kpiDataPointsMap.put(EventDataPoint.QUOTE_CREATION_REQUEST.name(), "quote_creation_request");
		kpiDataPointsMap.put(EventDataPoint.CUSTOMER_QUOTE_CREATION_REQUEST.name(), "customer_quote_creation_request");
		kpiDataPointsMap.put(EventDataPoint.CATEGORY.name(), "category");
		kpiDataPointsMap.put(EventDataPoint.CATEGORY_ID.name(), "category_id");
		kpiDataPointsMap.put(EventDataPoint.ASSISTANCE_TEXT.name(), "assistance_text");
		kpiDataPointsMap.put(EventDataPoint.VALUE_CONFIRMATION_FORM_DATA.name(), "value_confirmation_form_data");
		kpiDataPointsMap.put(EventDataPoint.VALUE_CONFIRMATION_REPORT_TYPE.name(), "value_confirmation_report_type");
		kpiDataPointsMap.put(EventDataPoint.TIME_STAMP.name(), "timestamp");
		kpiDataPointsMap.put(EventDataPoint.SALES_REP_FULL_NAME.name(), "sales_rep_full_name");
		kpiDataPointsMap.put(EventDataPoint.MARKET_PLACE_OPPORTUNITY_ID.name(), "marketplace_opportunity_id");
		kpiDataPointsMap.put(EventDataPoint.EVENT_ACTION.name(), "event_action");
		kpiDataPointsMap.put(EventDataPoint.DATE_REPORT_DISPLAYED.name(), "date_report_displayed");
		kpiDataPointsMap.put(EventDataPoint.EXTENSION_DAYS.name(), "extension_days");
		kpiDataPointsMap.put(EventDataPoint.INTEGRATION_TYPE.name(), "integration_type");
		kpiDataPointsMap.put(EventDataPoint.LEAD_ID.name(), KpiEventDataKeys.LEAD_ID);
		kpiDataPointsMap.put(EventDataPoint.PROD_OPT_ID.name(), "prod_opt_id");
		kpiDataPointsMap.put(EventDataPoint.PARTNER_ACCOUNT_NAME.name(), "partner_account_name");
		kpiDataPointsMap.put(EventDataPoint.ACCEPT_TNC_REQUEST.name(), "accept_tnc_request");
		kpiDataPointsMap.put(EventDataPoint.CUSTOMER_ACCEPT_TNC_REQUEST.name(), "customer_accept_tnc_request");

		kpiDataPointsMap.put(EventDataPoint.CONTRACT_ID.name(), KpiEventDataKeys.CONTRACT_ID);
		
		kpiDataPointsMap.put(EventDataPoint.BUNDLE_ID.name(), "bundle_id");
	
		kpiDataPointsMap.put(EventDataPoint.PARTNER_ACCOUNT_ID.name(), KpiEventDataKeys.PARTNER_ACCOUNT_ID);
		kpiDataPointsMap.put(EventDataPoint.EXTENSION_REASON.name(), "extension_reason");
		kpiDataPointsMap.put(EventDataPoint.BUNDLE_NAME.name(), "bundle_name");
		

		kpiDataPointsMap.put(EventDataPoint.CONTACT_ID.name(), KpiEventDataKeys.CONTACT_ID);
		kpiDataPointsMap.put(EventDataPoint.USER_CONTACT_ID.name(), "user_contact_id");
		kpiDataPointsMap.put(EventDataPoint.PARTNER_CONTACT_ID.name(), "partner_contact_id");

		kpiDataPointsMap.put(EventDataPoint.PRODUCT_NAME.name(), KpiEventDataKeys.PRODUCT_NAME);
		
		kpiDataPointsMap.put(EventDataPoint.ORDER_ID.name(), KpiEventDataKeys.ORDER_ID);
		kpiDataPointsMap.put(EventDataPoint.USER_NAME.name(), KpiEventDataKeys.USERNAME);
		

	}

	public static String getKpiEventDataPoint(String eventDataPoint) {
		return kpiDataPointsMap.get(eventDataPoint);
	}
    public static String getEventLoggerName(String name) {
        return EventConstants.eventLogMapper.getOrDefault(name, name);
    }
}