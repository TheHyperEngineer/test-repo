package com.akamai.buyakamai.constants;

import com.akamai.buyakamai.service.alert.AlertActionFetcher;
import com.akamai.buyakamai.service.alert.TrialExpiringActionFetcher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.PostConstruct;
import java.util.Arrays;
import java.util.List;

public enum AlertDefName {

    TNC_NOT_ACCEPTED(1),
    TNC_ACCEPTED(2),
    STAGING_CONFIG_NOT_PUSHED(3),
    STAGING_CONFIG_PUSHED(4),
    PROD_CONFIG_NOT_PUSHED(5),
    PROD_CONFIG_PUSHED(6),
    CUSTOMER_LIVE(7),
    TRIAL_EXPIRING(8, TrialExpiringActionFetcher.class.getSimpleName()),
    TRIAL_EXPIRED(9),
    REQUEST_VALUE_CONF_REPORT(10),
    VALUE_CONF_REPORT_AVAILABLE(11),
    EXTENSION_REQUEST_NOT_ACCEPTED(12),
    MPULSE_APP_NOT_CREATED(13),
    INSIGHT_EDGE_INJECTION(14),
    BEACON_NOT_PUSHED(15),
    MPULSE_DASHBOARD_LOGIN(16),
    MPULSE_SITE_LOGIN(17),
    PRODUCT_RECOMMENDED(100),
    CONTRACT_ENDING(101),
    CONTRACT_ENDING_SHORTLY(102),
    DOMAIN_PRESENT_AT_COMPETITOR(103),
    PRODUCT_NOT_IMPLEMENTED(104),
    ENTERPRISE_DOMAIN_NOT_CREATED_ETP(200),
    ENTERPRISE_ENTITIES_NOT_CONFIGURED_ETP(201),
    ENTERPRISE_CONFIG_NOT_PUSHED_ETP(202),
    ENTERPRISE_TRAFFIC_NOT_PUSHED_ETP(203),
    ENTERPRISE_DOMAIN_NOT_CREATED_EAA(204),
    ENTERPRISE_ENTITIES_NOT_CONFIGURED_EAA(205),
    ENTERPRISE_CONFIG_NOT_PUSHED_EAA(206),
    ENTERPRISE_TRAFFIC_NOT_PUSHED_EAA(207);

    private int sequence;

    private AlertActionFetcher alertActionFunction;

    private String alertActionFetcherClassName;


    AlertDefName(int sequence, String alertActionFetcherClass) {
        this.sequence = sequence;
        this.alertActionFetcherClassName = alertActionFetcherClass;
    }

    AlertDefName(int sequence) {
        this.sequence = sequence;
        this.alertActionFunction = (id, role, actions) -> Arrays.asList(actions.split(("[,]")));
    }

    public int getSequence() {
        return sequence;
    }


    public List<String> determineAction(int alertId, List<String> baRoles, String actions) {

        if(CollectionUtils.isEmpty(baRoles)){
            return Arrays.asList(actions.split(("[,]")));
        }

        return this.alertActionFunction.evaluateAction(alertId, baRoles, actions);
    }

    @Component
    private static class AlertFunctionBeanFetcher {

        @Autowired
        private ApplicationContext applicationContext;

        @PostConstruct
        public void initializeAlertFunction() {

            for (AlertDefName alertDefName : values())
                if (alertDefName.alertActionFetcherClassName != null) {
                    alertDefName.alertActionFunction = ((AlertActionFetcher) applicationContext.getBean(alertDefName.alertActionFetcherClassName));
                }
        }

    }


}
