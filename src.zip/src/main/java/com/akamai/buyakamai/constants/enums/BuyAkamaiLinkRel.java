package com.akamai.buyakamai.constants.enums;

public enum BuyAkamaiLinkRel {
    SELF("self"), GET_ORDERS("getOrders"),
    GET_ORDER_VERSION_DETAILS("getOrderVersionDetails"),
    GET_DRAFT_DETAILS("getDraftDetails"),
    GET_ORDER_VERSION_HISTORY("getOrderVersionHistory"),
    DUPLICATE_QUOTE("duplicateQuote"),
    GENERATE_ORDER("generateOrder"),
    GENERATE_ORDER_WITHOUT_APPROVAL("generateOrderWithNoDDApproval"),
    SUBMIT_FOR_APPROVAL("submitOrderForApproval"),
    APPROVE_VERSION("versionApprovalLink"),
    REJECT_VERSION("versionRejectionLink"),
    APPROVE_WITH_EDITS("versionApproveWithEditLink"),
    DD_VERSION_FOR_CONSIDERATION("activeDealDeskVersion"),
    OA_VERSION_FOR_CONSIDERATION("activeOrderAnalystVersion"),
    CREATE_NEW_ORDER("createNewOrder"),
    CREATE_NEW_VERSION("createNewVersion"),
    UPDATE_DRAFT("updateDraft"),
    CREATE_DRAFT("createDraft"),
    GET_LATEST_ORDER_VERSION_DETAILS("getLatestVersionDetails"),
    GET_USER_CONTACTS("getUserContacts");

    private String value;

    public String getValue() {
        return value;
    }

    BuyAkamaiLinkRel(String value) {
        this.value = value;
    }

}
