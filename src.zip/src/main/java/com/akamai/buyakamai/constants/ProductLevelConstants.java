package com.akamai.buyakamai.constants;

import java.util.Arrays;
import java.util.List;

public enum ProductLevelConstants {
    BASE, CERT, INTEGRATION, ADDON, INCLUDED, QUOTE, OPTION;

    private static List<ProductLevelConstants> ASSOCIATED_PRODUCT_LEVELS =
            Arrays.asList(ProductLevelConstants.ADDON, ProductLevelConstants.INCLUDED, ProductLevelConstants.CERT, ProductLevelConstants.OPTION);

    public static List<ProductLevelConstants> getAssociatedProductLevels() {
        return ASSOCIATED_PRODUCT_LEVELS;
    }
}
