package com.akamai.buyakamai.constants;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum  OpportunityStage {
    IDENTIFY_NEED("1. Identify Need"),EXPLORE_OPTIONS("2. Explore Options"),VERIFY_OPTIONS("3. Verify Options"),SELECT_OPTION("4. Select Option");

    private String stageName;

    public static final List<String> STAGES_WITH_COMPETITOR =
            Arrays.asList(OpportunityStage.VERIFY_OPTIONS.getStageName(), OpportunityStage.SELECT_OPTION.getStageName());

    OpportunityStage(String stageName) {
        this.stageName = stageName;
    }

    public String getStageName() {
        return stageName;
    }

    public static List<String> getAllStages(){
        return Arrays.stream(values()).map(OpportunityStage::getStageName).collect(Collectors.toList());
    }

}
