package com.akamai.buyakamai.constants;

public class ProductMasterConstants {

		private ProductMasterConstants() {
		}
		
		public static final String BUNDLE_ID_LOCALE_SEPARATOR_REGEX = "\\Q.\\E";
		public static final String METADATA_LOCALE_REGEX="\"(localized_(.+?))\""; 
		public static final String METADATA_JSON_DOUBLE_QUOTES="\"";
	    public static final String METADATA_TAG_VALUE_SEPARATOR=":";
	    public static final String METADATA_OBJECT_NODE_KEY = "metadata";
		public static final String PRODUCT_MASTER_GET_BUNDLE_URL_SUFFIX_KEY = "product_master_get_bundle_url_suffix";
		public static final String PRODUCT_MASTER_GET_TRIAL_DETAILS_URL_SUFFIX_KEY = "product_master_get_trial_details_url_suffix";
		public static final String PRODUCT_MASTER_GET_TNC_URL_SUFFIX_KEY = "product_master_get_tnc_url_suffix";
		public static final String QUERY_PARAM_LOCALE_KEY = "locale";
		public static final String QUERY_PARAM_CHANNEL_VALUE = "marketplace";	
		public static final String QUERY_PARAM_CHANNEL_KEY = "marketChannel";	
		public static final String QUERY_PARAM_CURRENCY_KEY = "currency";
		public static final String QUERY_PARAM_ACTION_KEY = "action";
		public static final String FALLBACK_LOCALE="en_US";
		public static final String QUERY_PARAM_CUSTOMER_TYPE = "customerType";
		public static final String QUERY_PARAM_ORDER_TYPE = "orderType";
		public static final String QUERY_PARAM_ACCOUNT_REGION = "region";

		public static final String TRIAL = "trial";
		
		public static final int DEFAULT_PRICING_ROUND_OFF = 4;

		public static final String WAP_ION_POC_BUNDLE_ID = "wap_ion_poc_bundle_id";
		public static final String WAP_POC_BUNDLE_ID = "wap_poc_bundle_id";
		public static final String DEVELOPER_KIT_BUNDLE_ID = "developer_kit_bundle_id";

		public static final String WAP_ION_MKT_ID = "M-LC-162043";
		public static final String WAP_MKT_ID = "M-LC-162042";
		public static final String ION_MKT_ID = "M-LC-84827";

		public static final String WAP_POC_OPTIONS_MKT_IDS = "wap_poc_options_mkt_ids";
		public static final String WAP_ION_POC_OPTIONS_MKT_IDS = "wap_ion_poc_options_mkt_ids";
		public static final String DEVELOPER_KIT_OPTIONS_MKT_IDS = "developer_kit_options_mkt_ids";
		
		public static final String INCLUDED_OPTIONS_GROUP_NAME = "Included";
		public static final String INCLUDED_OPTIONS_GROUP_ALTERNATE_NAME = "Included Options";
		public static final String WAP_POC_BUNDLE_IDS = "wap_poc_bundle_ids";

		public static final String BLOCKED_BUNDLEIDS_FOR_PARTNER_EVENT_GENERATION = "bundleids_blocked_for_event_generation";
		
		/*
		 * At&t constants
		 */
		public static final String QUERY_PARAM_USER_TYPE_KEY = "userType";
		public static final String CUSTOMER_USER_TYPE = "CUSTOMER";
		public static final String ATNT_USER_TYPE= "ATNT";
		public static final String DEFAULT_USER_TYPE = "DEFAULT";

		public static final String PLATFORM_UOM = "Platform Fee";

		public static final String INTEGRATION_FUNCTIONAL_CATEGORY = "Integration";
		
		public static final String CONFLICTING_TRAFFIC_PRODUCT_IDS_KEY = "conflicting_traffic_product_ids";

	}

