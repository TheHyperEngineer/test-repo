package com.akamai.buyakamai.constants;

public class TrafficConstants {

    public static final String CONTRACT_HEADER = "X-AWS-Customer";

    // Error message text
    public static final String GET_TRAFFIC_API_FAILURE = "Get traffic for CpCodes failure";
    public static final String GET_TRAFFIC_API_FAILURE_DETAILS = "Error while attempting to get traffic for CpCodes because ";
    public static final String REPORT_DATE_FORMAT = "yyyy-MM-dd";
    public static final String TRAFFIC_REPORT_API_SUFFIX = "traffic_report_api_url_suffix";
    public static final String TRAFFIC_REPORT_NAME_PROPERTY_KEY = "traffic_report_name";
    public static final String TRAFFIC_METRICS_LIST = "traffic_metrics_list";
    public static final String TRAFFIC_METRICS_CONSIDERED = "traffic_metric_considered";
}
