package com.akamai.buyakamai.constants.enums;

public enum ReportType {

	DELIVERY_METRIC("DELIVERY METRIC"),
	GEOGRAPHICAL_REGIONS("GEOGRAPHICAL_REGIONS"),
	HISTOGRAM("HISTOGRAM"),
	SST("SST");
	
	String type;
	
	private ReportType(String type) {
		this.type = type;
	}

	public String getType() {
		return type;
	}
}
