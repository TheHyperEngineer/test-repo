package com.akamai.buyakamai.constants.enums;

public enum PulsarAuthZHeader {
	USERNAME("X-IDS-IDENTITY-ID"), CONTRACT_TYPE_ID("X-IDS-CONTRACT-TYPE-ID"), CONTRACT_TYPE("X-IDS-CONTRACT-TYPE"),CONTRACT_ID("X-IDS-CONTRACT-ID"),
	ACCEPT_LANGUAGE("Accept-Language"), IMPERSONATOR("X-IDS-IMPERSONATOR-ID"), DEFAULT_ACCOUNT_ID("X-IDS-DEFAULT-ACCOUNT-ID"), CURRENT_ACCOUNT_ID("X-IDS-CURRENT-ACCOUNT-ID");

	private String headerName;

	PulsarAuthZHeader(String headerName) {
		this.headerName = headerName;
	}

	public String getHeaderName() {
		return headerName;
	}
}