package com.akamai.buyakamai.constants;

/**
 * Used to categorize the email state.
 * @author vineek
 */
public enum NotificationEmailStatus {
	
	SENT , FAILED, QUEUED

}
