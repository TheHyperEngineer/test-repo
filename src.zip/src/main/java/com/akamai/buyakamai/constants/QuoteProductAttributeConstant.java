package com.akamai.buyakamai.constants;

public enum QuoteProductAttributeConstant {
    ID_PRODUCT_ATTRIBUTES("id"), TLS_SELECTED_ATTRIBUTE("enhanced-TLS-question");

    private String value;


    QuoteProductAttributeConstant(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
