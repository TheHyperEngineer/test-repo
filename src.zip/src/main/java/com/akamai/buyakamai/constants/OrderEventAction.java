package com.akamai.buyakamai.constants;

import java.util.Arrays;
import java.util.List;

public enum OrderEventAction {

    //used for happiness events. any changes in sequence will affect happiness logic.

    TEMP_CREDENTIAL_SENT(1), USER_CLICKS_SIGN_UP_SUCCESS(2), STAGING_CONFIG_COMPLETED(3), PRODUCTION_CONFIG_COMPLETED(4),
    CUSTOMER_CNAMED(5), CUSTOMER_LIVE(6), VALUE_CONFIRMATION_REQUESTED(7), VALUE_CONFIRMATION_REPORT_AVAILABLE(8),
    MPULSE_APP_CREATED(9), MPULSE_BEACON_RECEIVED(10), MPULSE_USER_LOGIN(11), MPULSE_DASHBOARD_LOGIN(12), MPULSE_APP_ENABLED(13),
    TRIAL_EXTENSION_REQUEST_SENT_SUCCESS(14), USER_ACCEPTS_TRIAL_EXTENSION_TNC_SUCCESS(15), ENTERPRISE_DOMAIN_CREATED(16), ENTERPRISE_CONFIGURED_ETITIES(17), ENTERPRISE_CONFIG_PUSHED(18), ENTERPRISE_SERVICE_USAGE(19),
    ADD_ON_TRIAL_EXTENSION_REQUEST_SENT_SUCCESS(20),USER_ACCEPTS_ADD_ON_TRIAL_EXTENSION_TNC_SUCCESS(21);


    private int sequenceNumber;
    private static List<String> trackedSequencedEvents = Arrays.asList(TEMP_CREDENTIAL_SENT.name(), USER_CLICKS_SIGN_UP_SUCCESS.name(), STAGING_CONFIG_COMPLETED.name(),
            PRODUCTION_CONFIG_COMPLETED.name(), CUSTOMER_CNAMED.name(), CUSTOMER_LIVE.name());


    private static List<String> configurationProdTrackedEvents =
            Arrays.asList(USER_CLICKS_SIGN_UP_SUCCESS.name(), STAGING_CONFIG_COMPLETED.name(),
                    PRODUCTION_CONFIG_COMPLETED.name(), CUSTOMER_CNAMED.name(), CUSTOMER_LIVE.name());


    private static List<String> extensionEvents = Arrays.asList(TRIAL_EXTENSION_REQUEST_SENT_SUCCESS.name(), USER_ACCEPTS_TRIAL_EXTENSION_TNC_SUCCESS.name(),
            ADD_ON_TRIAL_EXTENSION_REQUEST_SENT_SUCCESS.name(), USER_ACCEPTS_ADD_ON_TRIAL_EXTENSION_TNC_SUCCESS.name());


    private static List<String> extensionRequestEvents = Arrays.asList(TRIAL_EXTENSION_REQUEST_SENT_SUCCESS.name(),
            ADD_ON_TRIAL_EXTENSION_REQUEST_SENT_SUCCESS.name());

    private static List<String> extensionSuccessEvents = Arrays.asList(USER_ACCEPTS_TRIAL_EXTENSION_TNC_SUCCESS.name(),
            USER_ACCEPTS_ADD_ON_TRIAL_EXTENSION_TNC_SUCCESS.name());


    private static List<String> tncEvents = Arrays.asList(TEMP_CREDENTIAL_SENT.name(),USER_CLICKS_SIGN_UP_SUCCESS.name());


    OrderEventAction(int sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    public int getSequenceNumber() {
        return sequenceNumber;
    }

    public static List<String> getTrackedSequencedEvents() {
        return trackedSequencedEvents;
    }

    public static List<String> getConfigurationProdTrackedEvents() {
        return configurationProdTrackedEvents;
    }

    public static List<String> getExtensionEvents() {
        return extensionEvents;
    }

    public static List<String> getExtensionSuccessEvents() {
        return extensionSuccessEvents;
    }

    public static List<String> getExtensionRequestEvents() {
        return extensionRequestEvents;
    }

    public static List<String> getTncEvents() {
        return tncEvents;
    }
}