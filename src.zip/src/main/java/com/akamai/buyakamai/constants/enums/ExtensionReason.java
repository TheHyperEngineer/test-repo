package com.akamai.buyakamai.constants.enums;

import java.util.Arrays;
import java.util.List;

public enum ExtensionReason {

    DELAY_IN_SETUP("Akamai delay in configuration/technical issues during set-up"),
    AKAM_PERFORMANCE_ISSUE("Akamai performance issues"),
    AKAM_DELAY_IN_VALUE_CONFIRMATION("Akamai needs more time to optimize and provide value confirmation"),
    INSUFFICIENT_TIME_FOR_EVALUATION("Customer hasn’t had sufficient time to evaluate Akamai product"),
    CHALLENGE_IN_INTEGRATION("Customer experienced challenges with integration"),
    CUSTOMER_INTERNAL_DELAY("Customer needs more time for internal approvals");

    private String reason;
    private static List<String> happinessImpactingReasons;

    static {
        happinessImpactingReasons = Arrays.asList(DELAY_IN_SETUP.name(),AKAM_PERFORMANCE_ISSUE.name(),
                AKAM_DELAY_IN_VALUE_CONFIRMATION.name(),INSUFFICIENT_TIME_FOR_EVALUATION.name(), CHALLENGE_IN_INTEGRATION.name() );
    }

    ExtensionReason(String reason) {
        this.reason = reason;
    }

    public String getReason() {
        return reason;
    }

    public static List<String> getHappinessImpactingReasons(){
        return happinessImpactingReasons;
    }

}
