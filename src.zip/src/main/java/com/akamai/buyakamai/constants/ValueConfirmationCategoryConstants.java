package com.akamai.buyakamai.constants;

public class ValueConfirmationCategoryConstants {

    public static final String WEB_DELIVERY_CATEGORY = "WebDelivery";
}
