package com.akamai.buyakamai.constants;

public class BACoreConstants {

    public static final String GET_OPPORTUNITIES_URL = "get_opportunities_url";
    public static final String GET_CONTACTS_FOR_ACCOUNT = "get_contacts_for_account_url";
    public static final String GET_TEAM_MEMBERS_FOR_ACCOUNT = "get_team_members_for_account_url";
    public static final String SEARCH_ACCOUNTS = "search_accounts_url";
    public static final String GET_OPPORTUNITY_DETAILS_URL = "get_opportunity_details_url";
    public static final String GET_OPPORTUNITY_BASIC_DETAILS_URL = "get_opportunity_basic_details_url";
    public static final String GET_COMPETITORS_LIST="get_competitors_url";
    public static final String SEARCH_OPPORTUNITIES_URL = "search_opportunities_url";
    public static final String GET_ACCOUNTIDS_WITH_REPORTEES_URL="get_accountids_with_reportees_url";
    public static final String GET_LEADID_OWNER_URL = "get_leadid_owner_url";
    public static final String GET_LIST_OF_ACCOUNTS_URL = "get_list_of_accounts_url";
    public static final String GET_LIST_OF_USERS_URL = "get_list_Of_users_url";
    public static final String GET_PRODUCT_PRICING_URL = "get_product_pricing_url";
    public static final String GET_PRICING_FOR_LIST_OF_PRODUCTS_URL = "get_pricing_for_list_of_products";
    public static final String GET_ALL_PRODUCT_PRICING_URL = "get_all_product_pricing_url";
    public static final String MARKETPLACE_USER = "activeMarketplaceUsers";
    public static final String ENTERPRISE_USER = "enterpriseUser";

    public static final String INACTIVE_PORTAL_USER = "inactivePortalUsers";
    public static final String ACTIVE_PORTAL_USER = "activePortalUsers";
    public static final String INACTIVE_USER = "inactivePortalUser";
    public static final String ACTIVE_MARKETPLACE_USER = "activeMarketplaceUser";
    public static final String GET_ACCOUNT_DETAILS_USER="user";
    public static final String PAE_USER_QUERY_PARAM="paeUserId";
    public static final String GET_ACCOUNT_LIST_URL = "account_list_url";
    public static final String QUERY_PARAM_USER_ID = "userId";
    public static final String QUERY_PARAM_ATTRIBUTE_CONSTANT = "attribute";
    public static final String QUERY_PARAM_LEVEL = "level";
    public static final String DEFUALT_LEVEL_VALUE = "1";
    public static final String SEARCH_LEADS_URL = "search_leads_url";
    public static final String ACCOUNT_ID_QUERY_PARAM = "accountId";
    public static final String URL_GET_CONTACTS_BASIC_INFO = "get_contacts_basic_url";
    public static final String GET_LEAD_DETAILS_URL = "get_lead_details_url";
    public static final String GET_LEADS_URL = "get_leads_url";
    public static final String GET_LIST_OF_CONTACTS_URL = "get_list_of_contacts_url";
    public static final String LEAD_DETAILS_URL = "get_basic_details_for_leads_url";
    public static final String GET_PARTNER_SF_ROLES_URL = "get_sf_roles_partner_key";
    public static final String GET_PARTNER_OPPORTUNITIES_URL = "get_partner_opportunities_url";
    public static final String GET_PARTNER_TEAM_MEMBER_API = "get_partner_team_member_api";
    public static final String GET_DIRECT_ACCOUNT_OPPORTUNITIES_URL = "get_direct_account_opportunities_url";
    public static final String GET_PARTNER_FOR_PAE_USER = "get_parter_for_pae_user";
    public static final String PARTNER_ACCOUNTS = "partner-accounts";
    public static final String PARTNER_OPPORTUNITY_EXCLUDE_STATUS = "partner_opportunity_exclude_status";
	public static final String GET_OPP_FOR_USER_SUFFIX_KEY = "get_opp_for_user";
	public static final String MARKETCHANNEL_QUERY_PARAM = "marketChannel";
	public static final String CURRENCY_QUERY_PARAM = "currency";
	public static final String USER_TYPE_QUERY_PARAM = "userType";
	public static final String LIST_ITEM_TYPE_QUERY_PARAM = "listItemType";
	public static final String FUNCTIONAL_CATEGORY_QUERY_PARAM = "functionalCategory";
	public static final String LIST_ITEM_TYPE_PURCHASE = "purchase";
	public static final String DIRECT_CHANNEL_VALUE = "direct";	
	public static final String DEFAULT_CURRENCY = "USD";
	public static final String SUPPORT_PRODUCTS = "get_all_products";
}
