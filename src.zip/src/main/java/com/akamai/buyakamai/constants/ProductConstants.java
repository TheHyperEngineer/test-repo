package com.akamai.buyakamai.constants;

public class ProductConstants {

    public static final String PRODUCT_LIST_TO_SKIP_BRE_SMALL_DEAL = "product_list_to_skip_bre_small_deal";

    public static final String USAGE_BILLING_MODEL_ID = "usage_billing_model_id";

    public static final String EXCLUSIVITY_BUSINESS_TERM_ID = "exclusivity_business_term_id";
    public static final Integer EXCLUSIVITY_PERCENTAGE_TO_CONSIDER = 100;

    public static final String PRODUCT_BUSINESS_UNIT = "businessUnit";
}
