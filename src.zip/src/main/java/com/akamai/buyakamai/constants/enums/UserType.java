package com.akamai.buyakamai.constants.enums;

public enum UserType {

	INDIRECT_PROSPECT(true), INDIRECT_CUSTOMER(true), DIRECT_CUSTOMER(false);

	private boolean showTnC;

	UserType(boolean showTnC) {
		this.showTnC = showTnC;
	}

	public boolean getShowTnc() {
		return showTnC;
	}
}