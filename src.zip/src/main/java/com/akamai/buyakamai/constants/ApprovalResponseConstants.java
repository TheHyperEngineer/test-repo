package com.akamai.buyakamai.constants;

public class ApprovalResponseConstants {

    public static final String GENERIC_APPROVAL_PRODUCT_REMOVAL = "productRemoved";

    public static final String GENERIC_APPROVAL_PRODUCT_REMOVAL_REASON = "Adding the approval as there were some products removed from previous approved version";

    public static final String GENERIC_APPROVAL_STRUCTURAL_CHANGE = "structurallyDifferent";

    public static final String GENERIC_APPROVAL_STRUCTURAL_CHANGE_REASON = "Adding this approval as there was some structural changes like billing model change or commit quantity change has happened from previous approved version";

    public static final String UNIT_PRICE_FE_FIELD_NAME = "unitPrice";

    public static final String OVERAGE_PRICE_FE_FIELD_NAME = "overagePrice";

    public static final String PLATFORM_FEE_FE_FIELD_NAME = "platformFee";

    public static final String EXCLUSIVITY_BUSINESS_TERM_USAGE_MODEL_REASON = "Approval is needed as Usage Model is selected and either the exclusivity business term is not selected or exclusivity is less than 100 percent";

    public static final String SNI_CERT_QUANTITY_RANGE = "RSM approval is required, because SNI certificate quantity is between 5 and 50 for price 0";

    public static final String DEAL_DESK_UNIT_PRICE_FE_CERT = "Deal Desk approval is required for product. Unit price selected by sales rep is less than fe.";

    public static final String STANDARD_INTEGRATION_FEE_WAVIER_DD = "Deal Desk approval is required for integration fee waiver. Unit price selected by sales rep for Standard integration product is less than fe.";

    public static final String STANDARD_INTEGRATION_FEE_WAVIER_RSM = "RSM approval is required for integration fee waiver. Unit price selected by sales rep for Standard integration product is less than fe.";

    public static final String DEAL_DESK_UNIT_PRICE_FE = "Deal Desk approval is required for product. Unit price selected by sales rep is less than fe.";
}
