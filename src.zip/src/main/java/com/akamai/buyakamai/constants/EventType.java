package com.akamai.buyakamai.constants;

public enum EventType {
    LOGIN, BUY_AKAMAI_USER_ACTION;
}
