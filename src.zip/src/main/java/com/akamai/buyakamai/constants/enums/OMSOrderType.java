package com.akamai.buyakamai.constants.enums;

public enum OMSOrderType {
	QUOTE, DRAFT;
}
