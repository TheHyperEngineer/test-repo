package com.akamai.buyakamai.constants.enums;

import com.akamai.buyakamai.constants.OrderEventAction;

public enum EnterpriseEventType {
    CONFIG_DEPLOYED(OrderEventAction.ENTERPRISE_CONFIG_PUSHED),SERVICE_USAGE(OrderEventAction.ENTERPRISE_SERVICE_USAGE),
    CUSTOMER_ONBOARD(OrderEventAction.ENTERPRISE_DOMAIN_CREATED),CONFIGURED_ENTITIES(OrderEventAction.ENTERPRISE_CONFIGURED_ETITIES);

    private OrderEventAction orderEventAction;

    EnterpriseEventType(OrderEventAction orderEventAction) {
        this.orderEventAction = orderEventAction;
    }

    public OrderEventAction getOrderEventAction(){
        return this.orderEventAction;
    }
}
