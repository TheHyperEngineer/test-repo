package com.akamai.buyakamai.constants;

public class EnterpriseConstants {
    public static final String DOMAIN_CREATED_ALERT_INTERVAL = "domain_created_alert_interval";
    public static final String CONFIGURED_ENTITIES_ALERT_INTERVAL = "configured_entites_alert_interval";
    public static final String CONFIG_PUSHED_ALERT_INTERVAL = "config_pushed_alert_interval";
    public static final String TRAFFIC_PUSHED_ALERT_INTERVAL = "traffic_pushed_alert_interval";
    public static final String ETP_RELATED_BUNDLE_ID = "etp_related_bundle_id";
    public static final String ETP_BUNDLE_ID = "etp_bundle_id";
    public static final String EAA_BUNDLE_ID = "eaa_bundle_id";
    public static final String EAA_MKT_PROD_ID = "eaa_mkt_prod_id";
    public static final String ETP_MKT_PROD_ID = "etp_mkt_prod_id";
    public static final String ETP_ADVANCED_MKT_PROD_ID = "etp_advanced_mkt_prod_id";
}
