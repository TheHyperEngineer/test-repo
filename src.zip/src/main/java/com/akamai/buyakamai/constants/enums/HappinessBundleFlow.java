package com.akamai.buyakamai.constants.enums;

import com.akamai.buyakamai.service.impl.AbstractHappinessCalculator;
import com.akamai.buyakamai.service.impl.ConfigurationBundleHappinessCalculator;
import com.akamai.buyakamai.service.impl.DefaultHappinessCalculator;
import com.akamai.buyakamai.service.impl.MpulseBundleHappinessCalculator;

public enum HappinessBundleFlow {

    ARL_FILE(ConfigurationBundleHappinessCalculator.class),
    SOASTA(MpulseBundleHappinessCalculator.class),
    DEFAULT(DefaultHappinessCalculator.class),
    ENTERPRISE(DefaultHappinessCalculator.class);


    private Class<? extends AbstractHappinessCalculator> happinessCalculatorClass;

    HappinessBundleFlow(Class<? extends AbstractHappinessCalculator> happinessCalculatorClass) {
        this.happinessCalculatorClass = happinessCalculatorClass;
    }

    public Class<? extends AbstractHappinessCalculator> getHappinessCalculatorClass() {
        return happinessCalculatorClass;
    }
}
