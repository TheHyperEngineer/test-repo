package com.akamai.buyakamai.constants.enums;

public enum LoggedInContextType {

	SALES_REP_CUSTOMER("SALES_REP_CUSTOMER"), 
	SALES_REP_PROSPECT("SALES_REP_PROSPECT"), 
	PARTNER_CUSTOMER("PARTNER_CUSTOMER"), 
	PARTNER_PROSPECT("PARTNER_PROSPECT"), 
	PAE_CUSTOMER("PAE_CUSTOMER"),
	PAE_PROSPECT("PAE_PROSPECT");
	
	private String type;
	
	LoggedInContextType(String contextType){
		type = contextType;
	}

	public String getType() {
		return type;
	}

}
