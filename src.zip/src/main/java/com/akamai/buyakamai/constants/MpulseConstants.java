package com.akamai.buyakamai.constants;

public class MpulseConstants {

    public static final String SOASTA_API_TOKEN = "mpulse_api_token";
    public static final String SOASTA_BASE_URL = "soasta_base_url";
    public static final String SOASTA_REPOSITORY_DOMAIN_URL = "soasta_repository_domain_url";
    public static final String SOASTA_REPOSITORY_USER_URL = "soasta_repository_user_url";
    public static final String SOASTA_AUDIT_TOKEN_URL = "soasta_audit_token_url";
    public static final String SOASTA_AUDIT_RECORD_URL = "soasta_audit_record_url";
    public static final String SOASTA_TENANT_DETAIL_URL = "soasta_tenant_detail_url";

    public static final String DASHBOARD_LOGIN_TIMESTAMP_KEY = "LatestDashBoardLoginTime";
    public static final String MPULSE_APP_LOGIN_TIMESTAMP_KEY = "LatestMPulseLoginTime";

    public static final String SOASTA_APP_ALERT_INTERVAL = "soasta_app_alert_interval";
    public static final String SOASTA_BEACON_ALERT_INTERVAL = "soasta_beacon_alert_interval";
    public static final String SOASTA_DASHBOARD_LOGIN_INTERVAL = "soasta_dashboard_login_alert_interval";
    public static final String SOASTA_APP_LOGIN_INTERVAL = "soasta_app_login_alert_interval";
    public static final String MPULSE_APP_ENABLED_ALERT_INTERVAL = "mpulse_app_enabled_alert_interval";

    public static final String SOASTA_AUTHORIZATION_HEADER = "Authorization";
    public static final String SOASTA_TENANT_NAME_HEADER = "X-Tenant-Name";
    public static final String SOASTA_USER_ID_HEADER = "X-User-Name";

    public static final String SOASTA_ACCOUNTID_QUERY_PARAM="SAMLId";
    public static final String SOASTA_OBJECT_TYPE_QUERY_PARAM="objectType";
    public static final String SOASTA_CATEGORY_QUERY_PARAM="category";
    public static final String SOASTA_TENANT_QUERY_PARAM="tenant";

}
