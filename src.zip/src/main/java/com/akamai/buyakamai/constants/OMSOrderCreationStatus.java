package com.akamai.buyakamai.constants;

import com.akamai.buyakamai.constants.enums.BuyOrderRoles;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum OMSOrderCreationStatus {
    PENDING_APPROVAL,
    REJECTED,
    APPROVED,
    NO_APPROVAL,
    APPROVED_WITH_EDIT,
    SUBMIT_TO_ORDER_MGMT;

    private static Map<String, List<OMSOrderCreationStatus>> roleToActionMap = new HashMap<>();

    static {
        roleToActionMap.put(BuyOrderRoles.SALES_REP_PURCHASE.name(), Arrays.asList(PENDING_APPROVAL, NO_APPROVAL, SUBMIT_TO_ORDER_MGMT));
        roleToActionMap.put(BuyOrderRoles.DEAL_DESK_APPROVER.name(), Arrays.asList(APPROVED, REJECTED, APPROVED_WITH_EDIT));
    }

    public static Map<String, List<OMSOrderCreationStatus>> getRoleToActionMap() {
        return new HashMap<>(roleToActionMap);
    }
}