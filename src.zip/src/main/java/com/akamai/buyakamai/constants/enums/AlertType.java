package com.akamai.buyakamai.constants.enums;

public enum AlertType {
   
	TRIAL_EXTENSION("trial_extension_alert_priority","trial_extension_alert_key_template"),
	REQUEST_REPORT("request_report_alert_priority", "request_report_alert_key_template"),
	REQUEST_SUPPORT("request_support_alert_priority", "request_support_alert_key_template"),
	PARTNER_PRODUCT_RECOMMENDATION("partner_product_recommendation_alert_priority", "partner_product_recommendation_alert_key_template"),
	PRODUCT_RECOMMENDATION("product_recommendation_alert_priority", "product_recommendation_alert_key_template"),
	TRIALS_LOAD("trials_load_alert_priority", "trials_load_alert_key_template"),
	OPPORTUNITIES_LOAD("opportunities_load_alert_priority", "opportunities_load_alert_key_template"),
	TRIAL_DETAILS_LOAD("trial_details_load_alert_priority", "trial_details_load_alert_key_template"),
	ALERTS_LOAD_FAIL("alerts_load_fail_alert_priority", "alerts_load_fail_alert_key_template"),
	TRAFFIC_FETCH("traffic_fetch_alert_priority", "traffic_fetch_alert_key_template"),
	CONFIG_FETCH("config_fetch_alert_priority", "config_fetch_alert_key_template"),
	REPORTS_FETCH("reports_fetch_alert_priority", "reports_fetch_alert_key_template"),
	LEAD_LOAD("lead_load_alert_priority","lead_load_alert_key_template"),
	SST_REPORT("sst_report_alert_priority","sst_report_alert_key_template"),
	INSIGNT_SERVICE("insight_service_alert_priority","insight_service_alert_key_template"),
	HAPPYNESS_CALCULATION("happyness_calculation_alert_priority","happyness_calculation_alert_key_template"),
	LEAD_DETAILS_FETCH("lead_details_alert_priority","lead_details_alert_key_template"),
	OMS_ORDER_DETAILS_FETCH("oms_order_details_alert_priority","oms_order_details_alert_key_template"), 
	OMS_ORDER_VERSION_HISTORY_FETCH("oms_order_version_history_alert_priority","oms_order_version_history_alert_key_template"), 
	OMS_ORDER_VERSION_DETAILS_FETCH("oms_order_version_details_alert_priority","oms_order_version_details_alert_key_template"),
	OMS_DRAFT_DETAILS_FETCH("oms_draft_details_alert_priority","oms_draft_details_alert_key_template"),
	BRE_APPROVAL_RULE_EXECUTION("bre_approval_rule_execution_priority", "bre_approval_rule_execution_key_template"),
	EXTENSION_APPROVAL_EMAIL("extension_approval_email_alert_priority","extension_approval_email_alert_key_template");
	String priorityKey;
	String alertIdTemplateKey;
	
	private AlertType(String priorityKey, String alertIdTemplateKey) {
		this.priorityKey = priorityKey;
		this.alertIdTemplateKey = alertIdTemplateKey;
	}

	public String getPriorityKey() {
		return priorityKey;
	}

	public String getAlertIdTemplateKey() {
		return alertIdTemplateKey;
	}
}


