package com.akamai.buyakamai.constants;

public class ConfigConstants {
    
    public static final String SOURCE_ASAPMSTR = "asapSource";
    
    public static final String SOURCE_EXTAPI = "extapiSource";

    public static final String SOURCE_BUY_AKAMAI = "buyAkamaiSource";
    
    public static final String ENTITIES_ASAPMSTR = "asapEntityManager";
    
    public static final String ENTITIES_BUY_AKAMAI = "buyAkamaiEntityManager";
    
    /**
     * Transaction Manager for asapmstr data source
     */
    public static final String TXM_ASAP = "asapTxManager";
    
    /**
     * Transaction Manager for contract data source
     */
    public static final String TXM_BUY_AKAMAI = "buyAkamaiTxManager";
    
    /**
     * Transaction Manager for all data source
     */
    public static final String TXM_ALL = "allTxManager";
    
    /* OTHER CONFIG !!! */
    
    public static final String DEFAULT_APP_VERSION = "1.0";
    
    public static final String DEFAULT_APP_NAME = "buy-akamai-api";
    
}
