package com.akamai.buyakamai.constants.enums;

import com.akamai.buyakamai.constants.ApprovalTypeConstants;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;

public enum BuyOrderRoles {
    SALES_REP_PURCHASE(StringUtils.EMPTY), DEAL_DESK_APPROVER(ApprovalTypeConstants.DealDesk.name()), PURCHASE_ORDER_MANAGEMENT(StringUtils.EMPTY);

    private String approvalValue;

    BuyOrderRoles(String approvalValue) {
        this.approvalValue = approvalValue;
    }

    public static List<BuyOrderRoles> getBuyMotionSpecificRoles() {
        return Arrays.asList(SALES_REP_PURCHASE, DEAL_DESK_APPROVER, PURCHASE_ORDER_MANAGEMENT);
    }

    public static boolean isBuyMotionRole(String roleName) {
        List<String> roles = Arrays.asList(SALES_REP_PURCHASE.name(), DEAL_DESK_APPROVER.name(), PURCHASE_ORDER_MANAGEMENT.name());
        return roles.contains(roleName.toUpperCase());
    }

    public static boolean isSalesRepRole(List<String> roles) {
        return roles.contains(SALES_REP_PURCHASE.name());
    }

    public String getApprovalValue() {
        return approvalValue;
    }

    public static String getApprovalTypeToFilter(List<String> roles) {
        for (String role : roles) {
            if (isBuyMotionRole(role)) {
                return BuyOrderRoles.valueOf(role).getApprovalValue();
            }
        }
        return StringUtils.EMPTY;
    }
}
