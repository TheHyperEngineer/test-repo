package com.akamai.buyakamai.constants;

public class WebDeliveryHttpConstants {

    public static final String RR_DETAIL_URL = "trialInfoURL";
    public static final String TEST_SET_UP_INFO_URL = "testSetUpInfoURL";
    public static final String HISTOGRAM_URL = "histogramURL";
    public static final String METRIC_AGGREGATION_URL = "metricAggregationURL";
    public static final String PERFORMANCE_URL = "performanceURL";
    public static final String BASE_URL = "pst-url";

    public static final String HISTOGRAM_METHOD = "histogramMethod";
    public static final String PERFORMANCE_METHOD = "performanceMethod";
    public static final String METRIC_AGGREGATION_METHOD = "metricAggregationMethod";

    public static final String VALIDATE_RRID_URL = "validate_rrid_url";
    public static final String ADD_TRIAL_REQUEST_URL = "add_trial_request_url";
    public static final String EXPECTED_PST_TICKET_COMPLETION_DAYS= "expected_pst_ticket_completion_date";

    public static final String UNIT_DEFAULT_VALUE = "12h";
    public static final String AGGREGATE_DEFAULT_VALUE = "median";
    public static final String START_DATE_DEFAULT_VALUE = "actualStartDate";
    public static final String END_DATE_DEFAULT_VALUE = "actualEndDate";
    public static final String HISTOGRAM_GOOD_EXPERIENCE_DEFAULT_VALUE = "2";
    public static final String HISTOGRAM_BAD_EXPERIENCE_DEFAULT_VALUE = "4";
    public static final String HISTOGRAM_MIN_DEFAULT_VALUE = "1";
    public static final String HISTOGRAM_MAX_DEFAULT_VALUE = "20";
    public static final String HISTOGRAM_STEP_DEFAULT_VALUE = "1";
    public static final String COUNTRY_LIST_DEFAULT_VALUE = "all";
    public static final String GEO_LIST_DEFAULT_VALUE = "all";
    public static final String AGGREGATION_REFRESH_DEFAULT_VALUE = "refresh";


    public static final String METRIC_PARAMETER_KEY = "metric";
    public static final String AGGREGATE_PARAMETER_KEY = "aggregate";
    public static final String TEST_SETUP_INFO_PARAMETER_KEY = "test_setup_info_id";
    public static final String START_TIME_PARAMETER_KEY = "start_time";
    public static final String END_TIME_PARAMETER_KEY = "end_time";
    public static final String METHOD_PARAMETER_KEY = "method";
    public static final String COUNTRY_LIST_PARAMETER_KEY = "country_list";
    public static final String GEO_LIST_PARAMETER_KEY = "geo_list";
    public static final String UNIT_PARAMETER_KEY = "unit";
    public static final String GOOD_EXPERIENCE_PARAMETER_KEY = "good_experience";
    public static final String BAD_EXPERIENCE_PARAMETER_KEY = "bad_experience";
    public static final String MIN_PARAMETER_KEY = "min";
    public static final String MAX_PARAMETER_KEY = "max";
    public static final String STEP_PARAMETER_KEY = "step";
    public static final String AGGREGATE_REFRESH_PARAMETER_KEY = "overall";

    public static final String ENCRYPTED_STRING = "encrypted_password";
    public static final String PFX_FILE_LOCATION = "key_file_location";

    public static final String EAA_ROOT_CERTIFICATE = "eaa_root_cert_file_location";

    public static final String PST_TRIAL_REQUEST_TYPE = "pst_trial_request_type";

}
