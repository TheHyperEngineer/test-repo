package com.akamai.buyakamai.constants;

public class ValueConfirmationConstants {

    public static final String WEB_DELIVERY_PURGE_INTERVAL = "web_delivery_purge_interval";

    public static final String WEB_DELIVERY_REPORT_PROCESS_INTERVAL = "web_delivery_report_process_duration_hours";

    public static final String WEB_DELIVERY_HOST="WEB_DELIVERY_HOST";
}