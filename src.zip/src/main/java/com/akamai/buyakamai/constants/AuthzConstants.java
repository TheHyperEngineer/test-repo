package com.akamai.buyakamai.constants;

public class AuthzConstants {

    public static final String IDENTITY_SERVICE_URL_SUFFIX = "identity_service_url_suffix";
    
    public static final String BASIC_CONTRACT_SERVICE_URL_SUFFIX = "basic_contract_service_url_suffix";
}
