package com.akamai.buyakamai.constants.enums;

public enum OMSLinkRel {
    SELF("self"), GET_ORDERS("getOrders"), GET_ORDER_DETAILS("getOrderDetails"), GET_DRAFT_DETAILS(
            "getOrderVersionResponseForDraftId"), GET_ORDER_VERSION_HISTORY("getOrderVersionHistory"), GET_LATEST_VERSION_DETAILS(
            "getLatestVersionDetails"), GET_VERSION_DETAILS("getVersionDetails"), APPROVE_VERSION("versionApprovalLink"),
    REJECT_VERSION("versionRejectionLink"), APPROVE_WITH_EDITS("versionApproveWithEditLink"),
    DD_VERSION_FOR_CONSIDERATION("activeDealDeskVersion"),OA_VERSION_FOR_CONSIDERATION("activeOrderAnalystVersion"),CREATE_NEW_ORDER("createNewOrder"), CREATE_NEW_VERSION("createNewVersion"),
    UPDATE_DRAFT("updateDraft"), GENERATE_ORDER("generateOrder"),   CREATE_DRAFT("createDraft"),;

    private String value;

    public String getValue() {
        return value;
    }

    OMSLinkRel(String value) {
        this.value = value;
    }

    public static OMSLinkRel getOMSLinkRel(String value) {
        for (OMSLinkRel omsLinkRel : values()) {
            if (omsLinkRel.getValue().equalsIgnoreCase(value)) {
                return omsLinkRel;
            }
        }
        return null;
    }
}
