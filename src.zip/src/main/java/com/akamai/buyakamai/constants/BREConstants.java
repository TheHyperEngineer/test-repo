package com.akamai.buyakamai.constants;

public class BREConstants {

    public static final String RECOMMENDATION_URI_SUFFIX = "recommendedProduct";
    public static final String SERVER_ADDRESS = "bre_server_address";
	public static final String BASE_PRODUCT_LIST = "baseProductList";

    public static final String ENCRYPTED_STRING = "bre_encrypted_string";
    public static final String PFX_FILE_LOCATION = "bre_certificate_location";

    public static final String QUOTE_APPROVAL_URI_SUFFIX = "quoteApproval";
    public static final String INDEPENDENT_PRODUCTS_APPROVAL_URI_SUFFIX = "independentProductApproval";
    public static final String DEPENDENT_PRODUCTS_APPROVAL_URL_SUFFIX = "dependentProductApproval";
    
    public static final String SBT_RULE_URL = "special_business_terms_rule_url";

    public static final String PRODUCT_SSL_CERTIFICATE_URI_SUFFIX = "productSslCertificateDetail";

    public static final String APP_TYPE_UNIT_PRICE_FIELD_NAME = "unitPrice";

    public static final String APP_TYPE_OVERAGE_PRICE_FIELD_NAME = "overagePrice";

    public static final String APP_TYPE_PLATFORM_PRICE_FIELD_NAME = "platformFee";

    public static final String CONNECTION_TIMEOUT = "bre.connection.timeout";
}