package com.akamai.buyakamai.constants;

public enum AlertSeverity {
	
	LOW, MEDIUM, HIGH;
}
