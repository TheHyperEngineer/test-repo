package com.akamai.buyakamai.constants;

import java.util.HashMap;
import java.util.Map;

public class DashConstants {

    public static final String DASH_CLIENT_ID_PROPERTY_STRING = "dash_client_id";

    public static final String DASH_CLIENT_SECRET_PROPERTY_STRING = "dash_client_secret";

    public static final String DASH_OAUTH_URL_PROPERTY_STRING = "dash_oauth_token_url";

    public static final String DASH_GRANT_TYPE_PROPERTY_STRING = "dash_grant_type";

    public static final String DASH_SCOPE_PROPERTY_STRING = "dash_scope";

    public static final String DASH_SCOPE_FOR_METIS = "dash_metis_scope";


    public static final String DASH_CASE_CREATION_SCOPE_PROPERTY_STRING = "dash_create_case_scope";

    public static final String DASH_GRANT_TYPE_STRING = "grant_type";

    public static final String DASH_SCOPE_STRING = "scope";

    public static final String DASH_ACCESS_TOKEN = "access_token";

    public static final String DASH_SERVER_ADDRESS = "dash_server_address";


    public static final String DASH_API_SERVER_ADDRESS = "dash_api_server_address";

    public static final String DASH_ACCESS_TOKEN_URL_SUFFIX = "dash_access_token_url_suffix";


    public static final String DASH_CREATE_OPPORTUNITY_URL_SUFFIX = "dash_create_opportunity_url_suffix";

    public static final String DASH_OPPORTUNITY_COMEPITITOR_URL_SUFFIX = "dash_opportunity_competitor_url_suffix";

    public static final String DASH_GET_STATES_URL_SUFFIX = "dash_get_states_url_suffix";

    public static final String DASH_GET_COUNTRIES_URL_SUFFIX = "dash_get_countries_url_suffix";

    public static final String PRIMARY = "PRIMARY";

    public static final String OPPORTUNITY_SOURCE = "Buy Akamai";
    public static final String OPPORTUNITY_DEAL_TYPE_DIRECT = "Direct";
    public static final String OPPORTUNITY_ORDER_TYPE_NEW = "Trial Order";
    public static final String OPPORTUNITY_ORDER_TYPE_NEW_PURCHASE = "New Service Order";

    public static final String OPPORTUNITY_DATE_FMT = "yyyy-MM-dd";

    public static final String COMPETITOR_LIST_KEY = "pickList";

    public static final String PS_CASE_TASK_LOE = "ps_case_task_loe";

    public static final String PS_CASE_DEFAULT_STATUS = "ps_case_default_status";

    public static final String PS_CASE_DEFAULT_SEVERITY = "ps_case_default_severity";

    public static final String PS_CASE_DEFAULT_SERVICE = "ps_case_default_service";

    public static final String POC_CASE_DEFAULT_VISIBILITY = "poc_case_default_visibility";

    public static final String PS_CASE_DEFAULT_RECORD_TYPE = "ps_case_default_record_type";

    public static final String PS_CASE_DEFAULT_REQUEST_TYPE="ps_case_default_request_type";

    public static final String PS_CASE_DEFAULT_SERVICE_CATEGORY = "ps_case_default_service_category";

    public static final String DASH_CREATE_CASE_URL_SUFFIX = "dash_create_case_url_suffix";

    public static final Map<String, String> PLAT_FORM_PRODUCT_MAPPING = new HashMap<>();
    
    public static final String OPPORTUNITY_TYPE_ADD_ON = "Add-on";

    public static final String OPPORTUNITY_TYPE_NEW_LOGO = "New Logo";
    public static final String DASH_ENVIRONMENT_KEY = "dash_calls_env";

    static {

        PLAT_FORM_PRODUCT_MAPPING.put("MPULMP3", "mPulse");
        PLAT_FORM_PRODUCT_MAPPING.put("ION", "Web Performance");
        PLAT_FORM_PRODUCT_MAPPING.put("DSA", "Web Performance");
        PLAT_FORM_PRODUCT_MAPPING.put("WAPION", "Web Application Protector");
        PLAT_FORM_PRODUCT_MAPPING.put("WAPDSA", "Web Application Protector");
    }
}
