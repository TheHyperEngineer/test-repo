package com.akamai.buyakamai.constants;

public enum AlertLevel {

	INFO, WARNING, ERROR;
}
