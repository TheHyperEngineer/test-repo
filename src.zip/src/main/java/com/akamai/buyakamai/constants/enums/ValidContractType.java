package com.akamai.buyakamai.constants.enums;


import java.util.Map;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toMap;

public enum ValidContractType {

    MARKETPLACE_PROSPECT("M-PRSPT", "Marketplace Prospect"), DIRECT_CUSTOMER("1-2RBL", "Direct Customer") , INDIRECT_CUSTOMER("1-5G3LB","Indirect Customer"),
    INTERNAL_CUSTOMER("1-8BYUX","Akamai Internal"),PARTNER("1-2RBC","Akamai Partner"), TIER_1_RESELLER("1-9OGH","Tier 1 Reseller");


    private String contractTypeId;
    private String contractType;

    ValidContractType(String contractTypeId, String contractType) {
        this.contractTypeId = contractTypeId;
        this.contractType = contractType;
    }

    private static final Map<String, String> MAP = stream(ValidContractType.values()).collect(
            toMap(contract -> contract.contractTypeId, contract -> contract.contractType));
    private static final Map<String, String> contractTypeToIdMap = stream(ValidContractType.values()).collect(
            toMap(contract -> contract.contractType, contract -> contract.contractTypeId));


    public static String getContractTypeToContractTypeId(String contractType){
        return contractTypeToIdMap.get(contractType);
    }

    public static String getContractType(String contractTypeId) {
        return MAP.get(contractTypeId);
    }

    public String getContractTypeId() {
        return contractTypeId;
    }

    public String getContractType() {
        return contractType;
    }
}
