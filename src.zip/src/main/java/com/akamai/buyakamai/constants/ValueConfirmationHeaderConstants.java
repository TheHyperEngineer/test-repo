package com.akamai.buyakamai.constants;

public class ValueConfirmationHeaderConstants {

    public static final String WEB_DELIVERY_REPORT_REQUEST = "Product-Type=WebDelivery";
}
