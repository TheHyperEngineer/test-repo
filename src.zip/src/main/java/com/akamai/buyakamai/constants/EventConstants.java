package com.akamai.buyakamai.constants;

import java.util.HashMap;
import java.util.Map;

public class EventConstants {

    public static Map<String, String> eventLogMapper = new HashMap<>();

    static {
        eventLogMapper.put(EventDataPoint.ACCOUNT_NAME.name(), "portal_accountName");
        eventLogMapper.put(EventDataPoint.ACCOUNT_ID.name(), "_accountid");
        eventLogMapper.put(EventDataPoint.USER_NAME.name(), "portal_username");
    }
}
