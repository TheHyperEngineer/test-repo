package com.akamai.buyakamai.constants;

public class Portal3Constants {

	public static final String PRICING_HELP_TEXT_KEY_FOR_ = "pricing_help_text_key_for_";
	
	public static final String DEFAULT_LOCALE = "en_US";
	
	public static final String PRODUCT_INFO= "product-info";
	
	
}
