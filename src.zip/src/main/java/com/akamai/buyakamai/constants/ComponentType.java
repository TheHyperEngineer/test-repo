package com.akamai.buyakamai.constants;

/**
 * Used for DB Logging to log the failed component name.
 *
 * @author jdixit
 */
public enum ComponentType {

    BUY_AKAMAI_CACHE_SERVICE, ORDER_APPLICATION_SERVICE, BUY_AKAMAI_CORE_SERVICE, DASH_SERVICE, PRODUCT_MASTER_SERVICE,
    BUY_AKAMAI_SERVICE, SOASTA_SERVICE, INSIGHT_EXPOSURE_SERVICE, BASIC_PROPERTY_SERVICE, INSIGHT_ALERT_SERVICE, OMS, BRE_SERVICE

}
