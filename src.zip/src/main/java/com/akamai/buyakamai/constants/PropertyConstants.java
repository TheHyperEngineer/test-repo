package com.akamai.buyakamai.constants;

public class PropertyConstants {

    public static final String BUY_COMPETITORS = "buy_orders_competitors";
}
