package com.akamai.buyakamai.constants.enums;

public enum  DealType {

    DIRECT("Direct"), INDIRECT("Indirect");

    private String dealName;

    DealType(String name) {
        this.dealName = name;
    }

    public String getDealName() {
        return dealName;
    }
}
