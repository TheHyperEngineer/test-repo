package com.akamai.buyakamai.orchestrator.rule.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BREAggregateProductModel {

    private List<BREProductModel> breProductModel;
    private String identifier;
}
