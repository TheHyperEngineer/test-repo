package com.akamai.buyakamai.orchestrator.rule;

import com.akamai.buyakamai.constants.BREConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.impl.rule.BreHttpClient;
import com.akamai.buyakamai.integration.clients.impl.rule.BreHttpRequestObject;
import com.akamai.buyakamai.integration.clients.impl.rule.BreHttpRequestObjectBuilder;
import com.akamai.buyakamai.model.oms.BusinessTermBRERequest;
import com.akamai.buyakamai.model.quote.ProductSslDetail;
import com.akamai.buyakamai.model.quote.approval.QuoteApproval;
import com.akamai.buyakamai.model.recommendation.ProductRecommendation;
import com.akamai.buyakamai.orchestrator.rule.model.BREAggregateProductModel;
import com.akamai.buyakamai.orchestrator.rule.model.BREProductModel;
import com.akamai.buyakamai.orchestrator.rule.model.BREQuoteModel;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

@Component
public class BREClient {
    private static final Logger logger = LoggerFactory.getLogger(BREClient.class);

    @Autowired
    private PropertyManager propertyManager;

    @Autowired
    private BreHttpClient breHttpClient;

    public ProductRecommendation getRecommendationsFromBRE(
            ProductRecommendation recommendedProduct) {
        String contactURL = propertyManager.getProperty(BREConstants.RECOMMENDATION_URI_SUFFIX);
        BreHttpRequestObject requestBuilder = getHttpRequestObject(contactURL, Arrays.asList(recommendedProduct));
        String response = execute(requestBuilder);
        List<ProductRecommendation> productRecommendations = CommonUtils.jsonArrayToObjectList(response, ProductRecommendation.class);
        if (productRecommendations == null && productRecommendations.size() == 0) {
            return (ProductRecommendation) CollectionUtils.EMPTY_COLLECTION;
        }
        return productRecommendations.get(0);
    }


    public QuoteApproval getQuoteLevelApprovals(
            BREQuoteModel breQuoteModel) throws BuyAkamaiApplicationException {
        String contactURL = propertyManager.getProperty(BREConstants.QUOTE_APPROVAL_URI_SUFFIX);
        BreHttpRequestObject requestBuilder = getHttpRequestObject(contactURL, Arrays.asList(breQuoteModel));
        String response = execute(requestBuilder);
        List<BREQuoteModel> breQuoteModels = CommonUtils.jsonArrayToObjectList(response, BREQuoteModel.class);

        if (breQuoteModels == null && breQuoteModels.size() == 0) {
            QuoteApproval quoteApproval = new QuoteApproval();
            quoteApproval.setOpportunityId(breQuoteModel.getOpportunityId());
            quoteApproval.setTitle(breQuoteModel.getTitle());
            return quoteApproval;
        }

        BREQuoteModel quoteModel = breQuoteModels.get(0);
        return getApprovalsForQuote(quoteModel);
    }

    public List<ProductSslDetail> getSslDetailsForProducts(List<String> products) throws BuyAkamaiApplicationException {
        String contactURL = propertyManager.getProperty(BREConstants.PRODUCT_SSL_CERTIFICATE_URI_SUFFIX);
        List<ProductSslDetail> productSslDetails = getRequestObject(products);
        BreHttpRequestObject requestBuilder = getHttpRequestObject(contactURL, productSslDetails);
        String response = execute(requestBuilder);
        List<ProductSslDetail> productSslDetailList = CommonUtils.jsonArrayToObjectList(response, ProductSslDetail.class);
        if (CollectionUtils.isEmpty(productSslDetailList)) {
            return (List<ProductSslDetail>) CollectionUtils.EMPTY_COLLECTION;
        }
        return productSslDetailList;

    }

    private QuoteApproval getApprovalsForQuote(BREQuoteModel quoteModel) {
        QuoteApproval quoteApproval = new QuoteApproval();
        quoteApproval.setOpportunityId(quoteModel.getOpportunityId());
        quoteApproval.setTitle(quoteModel.getTitle());
        if (quoteModel.getQuoteApproval() != null) {
            quoteApproval.setContractTermsApproval(quoteModel.getQuoteApproval().getContractTermsApproval());
            quoteApproval.setBusinessJustificationInfoApprovals(quoteModel.getQuoteApproval().getBusinessJustificationInfoApprovals());
        }
        return quoteApproval;
    }


    public List<BREProductModel> getIndependentProductApprovals(
            List<BREProductModel> breProductModels) throws BuyAkamaiApplicationException {
        String independentApprovalSuffix = propertyManager.getProperty(BREConstants.INDEPENDENT_PRODUCTS_APPROVAL_URI_SUFFIX);
        BreHttpRequestObject requestBuilder = getHttpRequestObject(independentApprovalSuffix, breProductModels);
        String response = execute(requestBuilder);
        return CommonUtils.jsonArrayToObjectList(response, BREProductModel.class);
    }

    public List<BREAggregateProductModel> getDependentProductApprovals(
            List<BREAggregateProductModel> breAggregateProductModelList) {

        String dependentApprovalSuffix = propertyManager.getProperty(BREConstants.DEPENDENT_PRODUCTS_APPROVAL_URL_SUFFIX);

        BreHttpRequestObject requestBuilder = getHttpRequestObject(dependentApprovalSuffix, breAggregateProductModelList);
        String response = execute(requestBuilder);
        return CommonUtils.jsonArrayToObjectList(response, BREAggregateProductModel.class);
    }

    public String getBusinessTerms(BusinessTermBRERequest businessTermBRERequest) throws BuyAkamaiApplicationException {
        String sbtUrl = propertyManager.getProperty(BREConstants.SBT_RULE_URL);
        BreHttpRequestObject requestBuilder = getHttpRequestObject(sbtUrl, Arrays.asList(businessTermBRERequest));
        return execute(requestBuilder);
    }

    public String execute(BreHttpRequestObject requestBuilder) {
        String response = breHttpClient.call(requestBuilder);
        logger.debug("Response is {}", response);
        return response;
    }


    private <T> BreHttpRequestObject getHttpRequestObject(String url, T object) {
        return new
                BreHttpRequestObjectBuilder()
                .urlSuffix(url).method(HttpMethod.POST)
                .requestObject(object).headers(new HashMap<String, String>()).build();
    }

    private List<ProductSslDetail> getRequestObject(List<String> products) {
        List<ProductSslDetail> productSslDetails = new ArrayList<>();
        for (String product : products) {
            ProductSslDetail productSslDetail = new ProductSslDetail();
            productSslDetail.setMarketingProductId(product);
            productSslDetails.add(productSslDetail);
        }
        return productSslDetails;
    }
}
