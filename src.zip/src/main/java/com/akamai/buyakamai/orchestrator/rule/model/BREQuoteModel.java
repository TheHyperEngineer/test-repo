package com.akamai.buyakamai.orchestrator.rule.model;

import com.akamai.buyakamai.model.oms.*;
import com.akamai.buyakamai.model.quote.approval.Approval;
import com.akamai.buyakamai.model.quote.approval.ContractTermApproval;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
public class BREQuoteModel {

    private String opportunityId;
    private String accountId;
    private String currency;
    private String title;
    private String status;
    private String serviceType;
    private ContractTerms contractTerms;
    private BusinessJustificationInfo businessJustificationInfo;
    private String createdBy;
    private ParentDetails parentDetails;
    private BigDecimal mrr;
    private BREQuoteApproval quoteApproval;

    public BREQuoteModel(BuyOrderRequestDto quote) {
        this.opportunityId = quote.getOpportunityId();
        this.accountId = quote.getAccountId();
        this.currency = quote.getCurrency();
        this.title = quote.getTitle();
        this.status = quote.getStatus();
        this.serviceType = quote.getServiceType();
        this.contractTerms = quote.getContractTerms();
        this.businessJustificationInfo = quote.getBusinessJustificationInfo();
        this.createdBy = quote.getCreatedBy();
        this.mrr = BigDecimal.valueOf(0);
        this.quoteApproval = getEmptyBREQuoteApproval();
    }

    private BREQuoteApproval getEmptyBREQuoteApproval() {
        BREQuoteApproval breQuoteApproval = new BREQuoteApproval();
        breQuoteApproval.setTitle("");
        breQuoteApproval.setOpportunityId("");
        ContractTermApproval contractTermApproval = new ContractTermApproval();
        contractTermApproval.setApprovalsForBusinessTerms(Collections.emptyList());
        contractTermApproval.setApprovalsForContractTerm(Collections.emptyList());
        breQuoteApproval.setContractTermsApproval(contractTermApproval);
        breQuoteApproval.setBusinessJustificationInfoApprovals(Collections.emptyList());
        breQuoteApproval.setMrrApproval(new Approval());
        return breQuoteApproval;
    }
}
