package com.akamai.buyakamai.orchestrator.rule.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BAIntermediateProductBreModel {

    private List<BREAggregateProductModel> breAggregateProductModelList;
    private List<BREProductModel> breProductModelList;
}
