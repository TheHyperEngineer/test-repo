package com.akamai.buyakamai.orchestrator.rule;

import com.akamai.buyakamai.constants.BREConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.model.recommendation.Product;
import com.akamai.buyakamai.model.recommendation.ProductRecommendation;
import com.akamai.buyakamai.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Component
public class ProductRecommendationOrchestrator {

    private static final Logger logger = LoggerFactory.getLogger(ProductRecommendationOrchestrator.class.getName());

    @Autowired
    private PropertyManager propertyManager;

    @Autowired
    private BREClient breClient;

    public ProductRecommendation getProductRecommendations() {
        logger.info("Entering getProductRecommendations ");
        return getRecommendationsFromBRE(getBaseProductsFromProperties());
    }

    private ProductRecommendation getBaseProductsFromProperties() {
        List<String> productList = Arrays
                .asList(propertyManager.getProperty(BREConstants.BASE_PRODUCT_LIST).split(","));

        List<Product> products = new ArrayList<>();

        productList.stream().forEach(product -> {
            Product baseProduct = new Product();
            String[] productInfo = product.split("##");
            baseProduct.setProductId(productInfo[0]);
            baseProduct.setProductName(productInfo[1]);
            baseProduct.setAddOnProducts(new ArrayList<Product>());
            products.add(baseProduct);
        });

        ProductRecommendation recommendations = new ProductRecommendation();
        recommendations.setProducts(products);
        return recommendations;
    }

    private ProductRecommendation getRecommendationsFromBRE(
            ProductRecommendation recommendedProduct) {
        try {
            ProductRecommendation response = breClient.getRecommendationsFromBRE(recommendedProduct);
            logger.info("Response is {}", response);
            return response;
        } catch (Exception exception) {
            String title = "Failed to integrate with business rule engine.";
            logger.error(title + " Description : {}", exception.getMessage());
            throw new BuyAkamaiApplicationException(title, exception.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ErrorConstants.GET_RECOMMENDED_PRODUCTS_FROM_BRE_FAILED);
        }
    }
}
