package com.akamai.buyakamai.orchestrator.rule;


import com.akamai.buyakamai.constants.ApprovalTypeConstants;
import com.akamai.buyakamai.model.quote.approval.Approval;
import com.akamai.buyakamai.model.quote.approval.ContractTermApproval;
import com.akamai.buyakamai.model.quote.approval.ProductApproval;
import com.akamai.buyakamai.model.quote.approval.QuoteApproval;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class ApprovalServiceImpl {

    public Set<ApprovalTypeConstants> getDistinctTypeOfApprovals(QuoteApproval items) {
        Set<ApprovalTypeConstants> distinctApprovals = new HashSet<>();

        addDistinctTypeOfApprovalsForContractTerms(items.getContractTermsApproval(), distinctApprovals);

        setDistinctApprovalsType(items.getBusinessJustificationInfoApprovals(), distinctApprovals);

        setDistinctApprovalsType(items.getEventsApprovals(), distinctApprovals);

        addDistinctTypeOfApprovalForProducts(items.getBaseProducts(), distinctApprovals);

        addDistinctTypeOfApprovalForProducts(items.getMiscellaneousProducts(), distinctApprovals);

        setDistinctApprovalsType(items.getGenericApprovals(), distinctApprovals);

        return distinctApprovals;
    }

    public void addDistinctTypeOfApprovalForProducts(List<ProductApproval> products,
                                                      Set<ApprovalTypeConstants> distinctApprovals) {
        if (!CollectionUtils.isEmpty(products)) {
            for (ProductApproval unit : products) {
                addDistinctTypeOfApprovalPerProduct(unit, distinctApprovals);
            }
        }
    }

    private void addDistinctTypeOfApprovalPerProduct(ProductApproval productApproval, Set<ApprovalTypeConstants> distinctApprovals) {

        setDistinctApprovalsType(productApproval.getApprovals(), distinctApprovals);

        //check for integration
        if (productApproval.getIntegrationProduct() != null) {
            setDistinctApprovalsType(productApproval.getIntegrationProduct().getApprovals(), distinctApprovals);
        }

        if (!CollectionUtils.isEmpty(productApproval.getAssociatedProducts())) {
            for (ProductApproval unit : productApproval.getAssociatedProducts()) {
                addDistinctTypeOfApprovalPerProduct(unit, distinctApprovals);
            }
        }
    }

    private void setDistinctApprovalsType(List<Approval> approvals,
                                          Set<ApprovalTypeConstants> distinctApprovals) {
        if (!CollectionUtils.isEmpty(approvals)) {
            approvals.stream().forEach(V -> distinctApprovals.add(ApprovalTypeConstants.valueOf(V.getApprovalType())));
        }
    }


    private void addDistinctTypeOfApprovalsForContractTerms(ContractTermApproval contractTermsApproval,
                                                            Set<ApprovalTypeConstants> distinctApprovals) {
        if (contractTermsApproval != null) {
            if (!CollectionUtils.isEmpty(contractTermsApproval.getApprovalsForBusinessTerms())) {
                contractTermsApproval.getApprovalsForBusinessTerms().stream().forEach(V -> distinctApprovals.add(ApprovalTypeConstants.valueOf(V.getApprovalType())));
            }
            if (!CollectionUtils.isEmpty(contractTermsApproval.getApprovalsForContractTerm())) {
                contractTermsApproval.getApprovalsForContractTerm().stream().forEach(V -> distinctApprovals.add(ApprovalTypeConstants.valueOf(V.getApprovalType())));
            }
        }
    }
}
