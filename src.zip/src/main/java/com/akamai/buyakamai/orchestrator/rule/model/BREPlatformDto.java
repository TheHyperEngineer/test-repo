package com.akamai.buyakamai.orchestrator.rule.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BREPlatformDto {

    private static final BigDecimal DEFAULT_VALUE = new BigDecimal(-1);

    @Setter(AccessLevel.NONE)
    private BigDecimal platformFee = DEFAULT_VALUE;

    private String billingFrequency;
    private String usageMethod;
    private String uom;

    public void setPlatformFee(BigDecimal platformFee) {
        this.platformFee = platformFee == null ? DEFAULT_VALUE : platformFee;
    }
}
