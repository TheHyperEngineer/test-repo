package com.akamai.buyakamai.orchestrator.rule.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BREBillingDetails {

    private String contractDuration;
    private String billingModelName;
    private String billingModelId;
    private BREPlatformDto platform;
    private List<BREPriceList> priceList = new ArrayList<>();
}
