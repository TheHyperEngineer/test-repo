package com.akamai.buyakamai.orchestrator.rule.model;

import com.akamai.buyakamai.model.quote.approval.Approval;
import com.akamai.buyakamai.model.quote.approval.ContractTermApproval;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BREQuoteApproval {

    private String opportunityId;
    private String title;
    private ContractTermApproval contractTermsApproval;
    private List<Approval> businessJustificationInfoApprovals;
    private Approval mrrApproval;
}
