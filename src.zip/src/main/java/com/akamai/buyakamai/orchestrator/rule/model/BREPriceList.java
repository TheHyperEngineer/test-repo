package com.akamai.buyakamai.orchestrator.rule.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BREPriceList {

    private static final BigDecimal DEFAULT_VALUE = new BigDecimal(-1);

    private String uom;
    private Long includedQuantity;
    private Long quantity;

    @Setter(AccessLevel.NONE)
    private BigDecimal unitPrice = DEFAULT_VALUE;

    @Setter(AccessLevel.NONE)
    private BigDecimal overagePrice = DEFAULT_VALUE;

    private String commitPeriod;
    private String billingFrequency;
    private String usageMethod;
    private Integer sequence;

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice == null ? DEFAULT_VALUE : unitPrice;
    }

    public void setOveragePrice(BigDecimal overagePrice) {
        this.overagePrice = overagePrice == null ? DEFAULT_VALUE : overagePrice;
    }
}
