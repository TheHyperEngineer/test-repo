package com.akamai.buyakamai.orchestrator.rule;

import com.akamai.buyakamai.constants.*;
import com.akamai.buyakamai.constants.enums.BuyAkamaiLinkRel;
import com.akamai.buyakamai.controller.model.RevenueResponse;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.model.oms.*;
import com.akamai.buyakamai.model.productmaster.ProductPricingResponse;
import com.akamai.buyakamai.model.quote.BusinessTerms;
import com.akamai.buyakamai.model.quote.ProductSslDetail;
import com.akamai.buyakamai.model.quote.approval.*;
import com.akamai.buyakamai.orchestrator.rule.model.*;
import com.akamai.buyakamai.service.impl.BuyOrderServiceImpl;
import com.akamai.buyakamai.service.impl.LinkServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.akamai.se.com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.stream.Collectors;

@Component
public class RuleOrchestrator {
    private static final Logger logger = LoggerFactory.getLogger(RuleOrchestrator.class);

    @Autowired
    private BREClient breClient;

    @Autowired
    private BuyOrderServiceImpl buyOrderService;

    @Autowired
    private PropertyManager propertyManager;

    @Autowired
    private ApprovalServiceImpl approvalService;

    @Autowired
    private LinkServiceImpl linkService;

    public static final BigDecimal SMALL_DEAL_REVENUE = new BigDecimal(2000);


    public ApprovalDto getApprovalsForQuote(BuyOrderRequestDto quote) {

        boolean smallDealConditionSet = false;

        QuoteApproval quoteApproval = getQuoteLevelApprovals(quote);

        List<ProductApproval> productsApprovalList = getListOfApprovalsForProductsFromBRE(quote);

        if (!CollectionUtils.isEmpty(productsApprovalList)) {

            Set<ApprovalTypeConstants> distinctApprovals = new HashSet<>();
            approvalService.addDistinctTypeOfApprovalForProducts(productsApprovalList, distinctApprovals);

            if (!distinctApprovals.isEmpty() && distinctApprovals.contains(ApprovalTypeConstants.DealDesk)) {
                //compare approvals with previous dd
                if (quote.getParentDetails() != null) {
                    VersionComparisonResponse versionComparisonResponse = buyOrderService.getStructuralComparisonChangesComparingWithDDApprovedVersion(quote);
                    filterFEPricesApprovalListFromPreviousVersion(versionComparisonResponse, productsApprovalList);

                    //commented this code as it is out of MVP
                   /* List<Approval> genericApprovalList = buildApprovalsForVersionComparisonResponse(versionComparisonResponse);
                    if (!CollectionUtils.isEmpty(genericApprovalList)) {
                        quoteApproval.setGenericApprovals(genericApprovalList);
                    }*/
                }

                //validate rule 14 it depends on mrr
                smallDealConditionSet = filterFERelatedApprovalsForSmallDeal(productsApprovalList, quote.getRevenueInfo());
            }

            if (!distinctApprovals.isEmpty()) {
                buildQuoteStructureForProductsFromListOfApprovals(productsApprovalList, quoteApproval);
            }
        }
        //rule 16.2 where the rule fits for entire products selected and business terms hence handling it here
        Set<String> uniqueBillingModelsSelected = buyOrderService.getUniqueBillingModelsSelected(quote);

        //if usage model is selected set approvals for exclusivity accordingly
        setExclusivityBusinessTerm(uniqueBillingModelsSelected, quote, quoteApproval);

        return constructApprovalResponse(quoteApproval, quote, smallDealConditionSet);
    }

    private void setExclusivityBusinessTerm(Set<String> uniqueBillingModelsSelected,
                                            BuyOrderRequestDto requestDto, QuoteApproval quoteApproval) {
        String usageBillingModelId = propertyManager.getProperty(ProductConstants.USAGE_BILLING_MODEL_ID);
        String exclusivitySbtId = propertyManager.getProperty(ProductConstants.EXCLUSIVITY_BUSINESS_TERM_ID);

        if (!uniqueBillingModelsSelected.isEmpty() && uniqueBillingModelsSelected.contains(usageBillingModelId)) {

            Approval exclusivityApproval;
            if (CollectionUtils.isEmpty(requestDto.getContractTerms().getBusinessTerms())) {
                exclusivityApproval = createApprovalForExclusivity();
                addExclusivityInGenericApproval(quoteApproval, exclusivityApproval);
                return;
            }

            Optional<BusinessTerms> requiredSbt = requestDto.getContractTerms().getBusinessTerms().stream().
                    filter(V -> V.getId().equalsIgnoreCase(exclusivitySbtId)).findFirst();

            if (!requiredSbt.isPresent()) {
                exclusivityApproval = createApprovalForExclusivity();
                addExclusivityInGenericApproval(quoteApproval, exclusivityApproval);
                return;
            }

            String selectedValue = requiredSbt.get().getArguments().get(0).getValue();
            if (Integer.valueOf(selectedValue) < ProductConstants.EXCLUSIVITY_PERCENTAGE_TO_CONSIDER) {
                exclusivityApproval = createApprovalForExclusivity();
                addExclusivityInSBTTerms(quoteApproval, exclusivityApproval);
            }
        }
    }

    private void addExclusivityInSBTTerms(QuoteApproval quoteApproval, Approval exclusivityApproval) {
        if (quoteApproval.getContractTermsApproval() == null) {
            ContractTermApproval contractTermApproval = new ContractTermApproval();
            contractTermApproval.setApprovalsForBusinessTerms(new ArrayList<>(Arrays.asList(exclusivityApproval)));
            quoteApproval.setContractTermsApproval(contractTermApproval);
        } else if (CollectionUtils.isEmpty(quoteApproval.getContractTermsApproval().getApprovalsForBusinessTerms())) {
            quoteApproval.getContractTermsApproval().setApprovalsForBusinessTerms(new ArrayList<>(Arrays.asList(exclusivityApproval)));
        } else {
            quoteApproval.getContractTermsApproval().getApprovalsForBusinessTerms().add(exclusivityApproval);
        }
    }

    private void addExclusivityInGenericApproval(QuoteApproval quoteApproval, Approval exclusivityApproval) {
        if (quoteApproval.getGenericApprovals() != null) {
            quoteApproval.getGenericApprovals().add(exclusivityApproval);
        } else {
            quoteApproval.setGenericApprovals(Arrays.asList(exclusivityApproval));
        }
    }

    private Approval createApprovalForExclusivity() {
        Approval approval = new Approval();
        approval.setApprovalType(ApprovalTypeConstants.DealDesk.name());
        approval.setFieldName(propertyManager.getProperty(ProductConstants.EXCLUSIVITY_BUSINESS_TERM_ID));
        approval.setFieldValue("true");
        approval.setReason(ApprovalResponseConstants.EXCLUSIVITY_BUSINESS_TERM_USAGE_MODEL_REASON);
        return approval;
    }

    private ApprovalDto constructApprovalResponse(QuoteApproval quoteApproval, BuyOrderRequestDto quote,
                                                  boolean smallDealConditionSet) {
        ApprovalDto approvalDto = new ApprovalDto();
        approvalDto.setItems(quoteApproval);

        Set<ApprovalTypeConstants> approvalTypeConstants = approvalService.getDistinctTypeOfApprovals(quoteApproval);

        if (!approvalTypeConstants.isEmpty()) {
            List<ApprovalStatus> approvalStatusList = new ArrayList<>();
            for (ApprovalTypeConstants unit : approvalTypeConstants) {
                ApprovalStatus approvalStatus = new ApprovalStatus();
                approvalStatus.setApprovalType(unit);
                approvalStatusList.add(approvalStatus);
            }

            approvalDto.setStatus(approvalStatusList);
        }

        if (smallDealConditionSet) {
            return approvalDto;
        }

        if (!approvalTypeConstants.isEmpty() && approvalTypeConstants.contains(ApprovalTypeConstants.DealDesk)) {
            approvalDto.add(getLinkForValidateQuote(quote, BuyAkamaiLinkRel.SUBMIT_FOR_APPROVAL.getValue()));
        } else {
            approvalDto.add(getLinkForValidateQuote(quote, BuyAkamaiLinkRel.GENERATE_ORDER_WITHOUT_APPROVAL.getValue()));
        }

        return approvalDto;
    }

    private Link getLinkForValidateQuote(BuyOrderRequestDto quote, String relName) {
        if (quote.getParentDetails() != null) {
            return linkService.getLinkForCreateNewVersion(quote.getParentDetails().getOrderId(), relName);
        } else {
            return linkService.getLinkForCreateQuote(relName);
        }
    }

    private boolean filterFERelatedApprovalsForSmallDeal(List<ProductApproval> productsApprovalList, RevenueResponse revenueInfo) {
        if (revenueInfo == null || revenueInfo.getTotalMrr() == null || CollectionUtils.isEmpty(productsApprovalList)) {
            return false;
        }

        //if deal size grater than revenue then return
        if (revenueInfo.getTotalMrr().compareTo(SMALL_DEAL_REVENUE) >= 0) {
            return false;
        }

        List<String> productIds = new ArrayList<>();
        productsApprovalList.stream().forEach(V -> productIds.add(V.getProductId()));

        String enterpriseCategory = propertyManager.getProperty(ProductConstants.PRODUCT_LIST_TO_SKIP_BRE_SMALL_DEAL);
        List<String> enterpriseProductList = CommonUtils.convertCommaSeparatedStringToList(enterpriseCategory);

        //if selected product contains enterprise product list return
        if (org.springframework.util.CollectionUtils.containsAny(productIds, enterpriseProductList)) {
            return false;
        }

        //iterate the product approval list and remove deal desk approvals of type fe for overage,unit and platform
        // other type of deal desk approvals needs to be sent to dd
        List<String> fieldNamesToConsider = Arrays.asList(ApprovalResponseConstants.OVERAGE_PRICE_FE_FIELD_NAME,
                ApprovalResponseConstants.PLATFORM_FEE_FE_FIELD_NAME, ApprovalResponseConstants.UNIT_PRICE_FE_FIELD_NAME);


        for (ProductApproval unit : productsApprovalList) {
            List<Approval> filteredApprovals = unit.getApprovals().stream().filter(V ->
                    !(ApprovalTypeConstants.DealDesk.name().equalsIgnoreCase(V.getApprovalType()) && fieldNamesToConsider.contains(V.getFieldName()))).
                    collect(Collectors.toList());
            unit.setApprovals(filteredApprovals);
        }

        return true;
    }

    private List<Approval> buildApprovalsForVersionComparisonResponse(VersionComparisonResponse versionComparisonResponse) {
        if (versionComparisonResponse == null) {
            return Collections.emptyList();
        }

        List<Approval> genericApprovals = new ArrayList<>();

        if (!CollectionUtils.isEmpty(versionComparisonResponse.getListOfProductsRemoved())) {
            Approval approval = new Approval();
            approval.setApprovalType(ApprovalTypeConstants.DealDesk.name());
            approval.setFieldName(ApprovalResponseConstants.GENERIC_APPROVAL_PRODUCT_REMOVAL);
            approval.setFieldValue(CommonUtils.convertToCommaSeperatedString(versionComparisonResponse.getListOfProductsRemoved()));
            approval.setReason(ApprovalResponseConstants.GENERIC_APPROVAL_PRODUCT_REMOVAL_REASON);
            genericApprovals.add(approval);
        }

        if (!versionComparisonResponse.isStructurallySame()) {
            Approval approval = new Approval();
            approval.setApprovalType(ApprovalTypeConstants.DealDesk.name());
            approval.setFieldName(ApprovalResponseConstants.GENERIC_APPROVAL_STRUCTURAL_CHANGE);
            approval.setFieldValue("true");
            approval.setReason(ApprovalResponseConstants.GENERIC_APPROVAL_STRUCTURAL_CHANGE_REASON);
            genericApprovals.add(approval);
        }

        return genericApprovals;
    }

    private void filterFEPricesApprovalListFromPreviousVersion(VersionComparisonResponse versionComparisonResponse,
                                                               List<ProductApproval> productsApprovalList) {

        if (CollectionUtils.isEmpty(productsApprovalList)) {
            return;
        }

        /*No filtering required if response is null
         * if list of products removed is not empty then no comparison needed
         * if no products are removed but they are not structurally same then no comparison needed*/
        if (versionComparisonResponse == null || !CollectionUtils.isEmpty(versionComparisonResponse.getListOfProductsRemoved())
                || (CollectionUtils.isEmpty(versionComparisonResponse.getListOfProductsRemoved()) && !versionComparisonResponse.isStructurallySame())) {

            return;
        }

        try {
            HashMap<BuyProductHashKey, BuyProduct> approvedVersionHash = versionComparisonResponse.getApprovedVersionHash();
            HashMap<BuyProductHashKey, BuyProduct> requestDtoHash = versionComparisonResponse.getRequestDtoHash();

            for (ProductApproval productApproval : productsApprovalList) {

                if (!CollectionUtils.isEmpty(productApproval.getApprovals())) {

                    BuyProductHashKey hashKey = buyOrderService.buildBuyProductHashKey(productApproval.getProductId(),
                            productApproval.getParentProductId(), productApproval.getBaseMarketingProductId(),
                            productApproval.getAttributes(), productApproval.getProductLevel(),
                            productApproval.getProductMasterIdToConsider(), productApproval.getProductName());

                    BuyProduct approvedVersion = approvedVersionHash.get(hashKey);
                    BuyProduct requestedVersion = requestDtoHash.get(hashKey);

                    productApproval.setApprovals(removeFeApprovalsFromProductApproval(productApproval,
                            approvedVersion, requestedVersion));
                }
            }
        } catch (Exception e) {
            //Ignore this exception as it shouldn't cause any blocker
            logger.error("Exception occurred while filtering product approvals when comparing it with previous dd version {}", e);
        }
    }

    private List<Approval> removeFeApprovalsFromProductApproval(ProductApproval productApproval, BuyProduct approvedVersion,
                                                                BuyProduct requestedVersion) {
        if (CollectionUtils.isEmpty(productApproval.getApprovals())) {
            return Collections.emptyList();
        }

        if (ProductLevelConstants.CERT.name().equalsIgnoreCase(productApproval.getProductLevel())) {
            return productApproval.getApprovals();
        }

        List<PriceList> approvedPriceLists = approvedVersion.getBillingDetails().getPriceList();
        List<PriceList> requestPriceLists = requestedVersion.getBillingDetails().getPriceList();

        List<Approval> modifiableApprovals = new ArrayList<>(productApproval.getApprovals());

        List<Approval> approvalsToRemove = new ArrayList<>();


        PlatformDto approvedPlatform = approvedVersion.getBillingDetails().getPlatform();
        PlatformDto requestedPlatform = requestedVersion.getBillingDetails().getPlatform();

        if (approvedPlatform != null && requestedPlatform != null) {
            List<Approval> platformFeeRelatedApprovals = modifiableApprovals.stream().
                    filter(V -> BREConstants.APP_TYPE_PLATFORM_PRICE_FIELD_NAME.equalsIgnoreCase(V.getFieldName()) &&
                            ApprovalTypeConstants.DealDesk.name().equalsIgnoreCase(V.getApprovalType())).
                    collect(Collectors.toList());

            if (approvedPlatform.getPlatformFee().compareTo(requestedPlatform.getPlatformFee()) <= 0) {
                approvalsToRemove.addAll(platformFeeRelatedApprovals);
            }
        }

        for (Approval unit : modifiableApprovals) {

            PriceList approvedList = filterPriceListForApproval(unit, approvedPriceLists);
            PriceList requestedList = filterPriceListForApproval(unit, requestPriceLists);

            if (approvedList == null || requestedList == null) {
                continue;
            }

            if (ApprovalTypeConstants.DealDesk.name().equalsIgnoreCase(unit.getApprovalType()) &&
                    BREConstants.APP_TYPE_UNIT_PRICE_FIELD_NAME.equalsIgnoreCase(unit.getFieldName())) {

                if (approvedList.getUnitPrice().compareTo(requestedList.getUnitPrice()) <= 0) {
                    approvalsToRemove.add(unit);
                }
            } else if (ApprovalTypeConstants.DealDesk.name().equalsIgnoreCase(unit.getApprovalType()) &&
                    BREConstants.APP_TYPE_OVERAGE_PRICE_FIELD_NAME.equalsIgnoreCase(unit.getFieldName())) {
                if (approvedList.getOveragePrice().compareTo(requestedList.getOveragePrice()) <= 0) {
                    approvalsToRemove.add(unit);
                }
            }
        }

        modifiableApprovals.removeAll(approvalsToRemove);

        return modifiableApprovals;
    }

    /*
     * This method filters the priceList based on approval, criteria for filtering are
     * UOM
     * Sequence if present*/
    private PriceList filterPriceListForApproval(Approval unit, List<PriceList> productPriceLists) {

        List<PriceList> approvedLists = productPriceLists.stream().filter(V -> StringUtils.isNotEmpty(V.getUom())).
                filter(V -> V.getUom().equalsIgnoreCase(unit.getUom())).collect(Collectors.toList());

        if (CollectionUtils.isEmpty(approvedLists)) {
            return null;
        }

        if (unit.getSequence() != null) {
            return approvedLists.stream().filter(V -> unit.getSequence().equals(V.getSequence())).findFirst().orElse(null);
        } else {
            return approvedLists.get(0);
        }
    }


    public QuoteApproval getQuoteLevelApprovals(BuyOrderRequestDto quote) {
        BREQuoteModel breQuoteModel = new BREQuoteModel(quote);
        logger.info("Input quote JSON : " + getJson(breQuoteModel));
        try {
            return breClient.getQuoteLevelApprovals(breQuoteModel);
        } catch (Exception exception) {
            String title = "Failed to integrate with business rule engine.";
            logger.error(title + " Description : {}", exception.getMessage());
            throw new BuyAkamaiApplicationException(title, exception.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ErrorConstants.GET_QUOTE_APPROVAL_FROM_BRE_FAILED);
        }

    }


    public List<ProductApproval> getListOfApprovalsForProductsFromBRE(BuyOrderRequestDto buyOrderRequestDto) {
        BAIntermediateProductBreModel baIntermediateProductBreModel = transformQuoteRequestToBreInput(buyOrderRequestDto);
        if (baIntermediateProductBreModel == null) {
            return Collections.emptyList();
        }
        BAIntermediateProductBreModel breApprovalsResponse = getBreProductRelatedApprovals(baIntermediateProductBreModel);
        return buildListOfProductApprovalsFromBreResponse(breApprovalsResponse);
    }

    private List<ProductApproval> buildListOfProductApprovalsFromBreResponse(BAIntermediateProductBreModel breApprovalsResponse) {
        List<ProductApproval> productApprovalList = new ArrayList<>();

        List<BREProductModel> independentProductList = breApprovalsResponse.getBreProductModelList();
        independentProductList.stream().forEach(V -> filterMutuallyExclusiveIntegrationApproval(V));
        independentProductList.stream().forEach(V -> productApprovalList.add(new ProductApproval(V)));

        List<BREAggregateProductModel> dependentProducts = breApprovalsResponse.getBreAggregateProductModelList();

        if (!CollectionUtils.isEmpty(dependentProducts)) {
            for (BREAggregateProductModel unit : dependentProducts) {

                filterMutuallyExclusiveCertApprovals(unit);

                if (unit.getIdentifier().equalsIgnoreCase(ProductLevelConstants.CERT.name()) ||
                        unit.getIdentifier().equalsIgnoreCase(PMFunctionalCategoryConstant.BASE_PRODUCT_PRICING_ETLS_DEPENDENT.getValue())) {
                    productApprovalList.addAll(getApprovalsFromAllItemsInCollections(unit.getBreProductModel()));
                }
            }
        }
        return productApprovalList;
    }

    /*method to suppress FE rules if either 8.1 or 9.1 rules are triggered*/
    private void filterMutuallyExclusiveIntegrationApproval(BREProductModel independentProductList) {
        if (ProductLevelConstants.INTEGRATION.name().equalsIgnoreCase(independentProductList.getProductLevel())) {
            List<Approval> modifiableApprovals = new ArrayList<>(independentProductList.getApprovals());
            if (!CollectionUtils.isEmpty(modifiableApprovals)) {
                long count = modifiableApprovals.stream().filter(V -> ApprovalResponseConstants.STANDARD_INTEGRATION_FEE_WAVIER_DD.equalsIgnoreCase(V.getReason())
                        || ApprovalResponseConstants.STANDARD_INTEGRATION_FEE_WAVIER_RSM.equalsIgnoreCase(V.getReason())).count();

                if (count > 0) {
                    modifiableApprovals.removeAll(modifiableApprovals.stream().
                            filter(V -> ApprovalResponseConstants.DEAL_DESK_UNIT_PRICE_FE.equalsIgnoreCase(V.getReason())).collect(Collectors.toList()));
                }
                independentProductList.setApprovals(modifiableApprovals);
            }
        }
    }


    /*method to filter approvals for certs as rule 11.1 and 11.3 are mutually exclusive*/
    private void filterMutuallyExclusiveCertApprovals(BREAggregateProductModel aggregateProductModel) {
        if (aggregateProductModel.getIdentifier().equalsIgnoreCase(ProductLevelConstants.CERT.name())) {
            List<BREProductModel> breProductModelList = aggregateProductModel.getBreProductModel();

            if (!CollectionUtils.isEmpty(breProductModelList)) {
                for (BREProductModel unit : breProductModelList) {

                    List<Approval> modifiableApprovals = new ArrayList<>(unit.getApprovals());

                    List<Approval> filterableApprovals = unit.getApprovals().stream().filter(V -> ApprovalResponseConstants.SNI_CERT_QUANTITY_RANGE.equalsIgnoreCase(V.getReason())
                            || ApprovalResponseConstants.DEAL_DESK_UNIT_PRICE_FE_CERT.equalsIgnoreCase(V.getReason())).collect(Collectors.toList());

                    if (CollectionUtils.isNotEmpty(filterableApprovals)) {
                        Set<String> uniqueReasons = new HashSet<>();
                        filterableApprovals.stream().forEach(V -> uniqueReasons.add(V.getReason()));
                        if (uniqueReasons.size() > 1) {
                            modifiableApprovals.removeAll(filterableApprovals.stream().filter(V ->
                                    ApprovalResponseConstants.DEAL_DESK_UNIT_PRICE_FE_CERT.equalsIgnoreCase(V.getReason())).collect(Collectors.toList()));
                        }
                    }
                    unit.setApprovals(modifiableApprovals);
                }
            }
        }
    }

    private String getJson(BREQuoteModel breQuoteModel) {
        ObjectMapper Obj = new ObjectMapper();
        Obj.setSerializationInclusion(JsonInclude.Include.NON_NULL);
        String inputJsonString = "";
        try {
            inputJsonString = Obj.writeValueAsString(breQuoteModel);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return inputJsonString;
    }

    private BAIntermediateProductBreModel transformQuoteRequestToBreInput(BuyOrderRequestDto buyOrderRequestDto) {
        Map<String, ProductPricingResponse> baCoreResponse = buyOrderService.getPricingResponseForBuyOrderRequest(buyOrderRequestDto);
        List<BREProductModel> flattenResponse = flattenAndAppendPMResponse(buyOrderRequestDto, baCoreResponse);
        if (CollectionUtils.isEmpty(flattenResponse)) {
            return null;
        }
        return categorizeFlattenedObject(flattenResponse);
    }

    private BAIntermediateProductBreModel categorizeFlattenedObject(List<BREProductModel> flattenResponse) {

        List<BREProductModel> modifiableList = new ArrayList<>(flattenResponse);

        List<BREAggregateProductModel> aggregateProductList = new ArrayList<>();
        aggregateProductList.addAll(buildAndRemoveCerts(modifiableList));

        //keep this in end as it removes base product list
        aggregateProductList.addAll(buildAndRemoveEtlsCategory(modifiableList));

        BAIntermediateProductBreModel model = new BAIntermediateProductBreModel();
        model.setBreAggregateProductModelList(aggregateProductList);
        model.setBreProductModelList(modifiableList);
        return model;
    }

    private List<BREAggregateProductModel> buildAndRemoveEtlsCategory(List<BREProductModel> modifiableList) {
        List<BREAggregateProductModel> aggregatedEtlsProducts = new ArrayList<>();
        List<BREProductModel> etlsProduct = modifiableList.stream().filter(V -> V.getAttributes() != null && !V.getAttributes().isEmpty()).
                filter(V -> V.getAttributes().containsKey(QuoteProductAttributeConstant.ID_PRODUCT_ATTRIBUTES.getValue())).
                filter(V -> V.getAttributes().get(QuoteProductAttributeConstant.ID_PRODUCT_ATTRIBUTES.getValue()).
                        equalsIgnoreCase(QuoteProductAttributeConstant.TLS_SELECTED_ATTRIBUTE.getValue())).collect(Collectors.toList());

        if (CollectionUtils.isEmpty(etlsProduct)) {
            return Collections.emptyList();
        }


        for (BREProductModel unit : etlsProduct) {
            BREProductModel baseProduct = modifiableList.stream().filter(V -> V.getMarketingProductId().
                    equalsIgnoreCase(unit.getBaseMktProductId())).findFirst().get();

            //consider only etls product whose functional category is
            if (!PMFunctionalCategoryConstant.BASE_PRODUCT_PRICING_ETLS_DEPENDENT.getValue()
                    .equalsIgnoreCase(baseProduct.getProduct().getFunctionalCategory())) {
                continue;
            }
            BREAggregateProductModel aggregateProductModel = new BREAggregateProductModel();
            aggregateProductModel.setBreProductModel(Arrays.asList(unit, baseProduct));
            aggregateProductModel.setIdentifier(baseProduct.getProduct().getFunctionalCategory());
            aggregatedEtlsProducts.add(aggregateProductModel);
            modifiableList.remove(baseProduct);
            modifiableList.remove(unit);
        }
        return aggregatedEtlsProducts;
    }


    private List<BREAggregateProductModel> buildAndRemoveCerts(List<BREProductModel> modifiableList) {
        List<BREAggregateProductModel> aggregatedCertProductList = new ArrayList<>();
        List<BREProductModel> certList = modifiableList.stream().filter(V -> ProductLevelConstants.CERT.name().equalsIgnoreCase(V.getProductLevel())).
                collect(Collectors.toList());

        if (CollectionUtils.isEmpty(certList)) {
            return Collections.emptyList();
        }
        Map<String, List<BREProductModel>> certsGroupedWithBaseProductId = certList.stream().
                collect(Collectors.groupingBy(BREProductModel::getBaseMktProductId));

        if (!certsGroupedWithBaseProductId.isEmpty())
            for (Map.Entry<String, List<BREProductModel>> entry : certsGroupedWithBaseProductId.entrySet()) {
                List<BREProductModel> certs = entry.getValue();
                Map<String, List<BREProductModel>> certsGroupedByParentMktIds = certs.stream().
                        collect(Collectors.groupingBy(BREProductModel::getParentProductId));

                for (Map.Entry<String, List<BREProductModel>> unit : certsGroupedByParentMktIds.entrySet()) {
                    BREAggregateProductModel aggregateProductModel = new BREAggregateProductModel();
                    aggregateProductModel.setBreProductModel(unit.getValue());
                    aggregateProductModel.setIdentifier(ProductLevelConstants.CERT.name());
                    aggregatedCertProductList.add(aggregateProductModel);
                }
            }


        //remove cert products here
        modifiableList.removeAll(certList);

        return aggregatedCertProductList;
    }


    private List<BREProductModel> flattenAndAppendPMResponse(BuyOrderRequestDto buyOrderRequestDto,
                                                             Map<String, ProductPricingResponse> baCoreResponse) {


        HashMap<BuyProductHashKey, BuyProduct> productHashMap = buyOrderService.flattenBuyOrderRequest(buyOrderRequestDto);

        if (productHashMap.isEmpty()) {
            return Collections.EMPTY_LIST;
        }

        List<BREProductModel> breProductModels = new ArrayList<>();

        for (Map.Entry<BuyProductHashKey, BuyProduct> keyValuePair : productHashMap.entrySet()) {
            BREProductModel breProductModel = buildBreProductModel(buyOrderRequestDto, keyValuePair.getValue(), keyValuePair.getKey(), baCoreResponse);
            if (canAddBreProduct(breProductModel)) {
                breProductModels.add(breProductModel);
            }
        }
        return breProductModels;
    }

    private boolean canAddBreProduct(BREProductModel breProductModel) {
        if (StringUtils.isNotBlank(breProductModel.getMarketingProductId())
                && StringUtils.isNotBlank(breProductModel.getProductLevel())) {
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    private BREProductModel buildBreProductModel(BuyOrderRequestDto buyOrderRequestDto, BuyProduct buyProduct,
                                                 BuyProductHashKey hashKey, Map<String, ProductPricingResponse> baCoreResponse) {

        BREProductModel breProductModel = new BREProductModel();
        breProductModel.setOpportunityId(buyOrderRequestDto.getOpportunityId());
        breProductModel.setAccountId(buyOrderRequestDto.getAccountId());
        breProductModel.setCurrency(buyOrderRequestDto.getCurrency());
        breProductModel.setTitle(buyOrderRequestDto.getTitle());
        breProductModel.setStatus(buyOrderRequestDto.getStatus());
        breProductModel.setServiceType(buyOrderRequestDto.getServiceType());
        breProductModel.setCreatedBy(buyOrderRequestDto.getCreatedBy());
        breProductModel.setContractTerms(buyOrderRequestDto.getContractTerms());

        breProductModel.setParentProductId(hashKey.getParentProdId());
        breProductModel.setBaseMktProductId(hashKey.getBaseMktId());
        breProductModel.setMarketingProductId(buyProduct.getMarketingProductId());
        breProductModel.setProductLevel(buyProduct.getProductLevel());
        breProductModel.setMarketingProductName(buyProduct.getMarketingProductName());
        breProductModel.setProduct(baCoreResponse.get(hashKey.getProductMasterIdToConsider()));

        BREBillingDetails breBillingDetails = new BREBillingDetails();
        if (buyProduct.getBillingDetails() != null) {
            BeanUtils.copyProperties(buyProduct.getBillingDetails(), breBillingDetails);
            if (buyProduct.getBillingDetails().getPlatform() != null) {
                BREPlatformDto brePlatformDto = new BREPlatformDto();
                BeanUtils.copyProperties(buyProduct.getBillingDetails().getPlatform(), brePlatformDto);
                breBillingDetails.setPlatform(brePlatformDto);
            }
        }
        breProductModel.setBillingDetails(breBillingDetails);
        breProductModel.setAttributes(buyProduct.getAttributes());


        if (buyProduct.getAttributes() != null) {
            breProductModel.setAttributes(buyProduct.getAttributes());
        }

        breProductModel.setApprovals(new ArrayList<Approval>());
        return breProductModel;
    }


    private void buildQuoteStructureForProductsFromListOfApprovals(List<ProductApproval> productApprovalList, QuoteApproval quoteApproval) {

        List<ProductApproval> modifiableList = new ArrayList<>(productApprovalList);

        List<ProductApproval> quoteLevelApprovalList = productApprovalList.stream().filter(V -> V.getProductLevel().
                equalsIgnoreCase(ProductLevelConstants.QUOTE.name())).collect(Collectors.toList());

        Set<String> quoteMkIdList = new HashSet<>();
        quoteLevelApprovalList.stream().forEach(V -> quoteMkIdList.add(V.getProductId()));

        modifiableList.removeAll(quoteLevelApprovalList);

        //update the quote products with its associated products
        if (!quoteMkIdList.isEmpty()) {
            List<ProductApproval> quoteAssociatedProducts = modifiableList.stream().filter(V -> quoteMkIdList.contains(V.getParentProductId()) ||
                    quoteMkIdList.contains(V.getBaseMarketingProductId())).collect(Collectors.toList());
            modifiableList.removeAll(quoteAssociatedProducts);
            quoteLevelApprovalList.addAll(quoteAssociatedProducts);
        }

        List<ProductApproval> integrationApprovalList = productApprovalList.stream().filter(V -> V.getProductLevel().
                equalsIgnoreCase(ProductLevelConstants.INTEGRATION.name())).collect(Collectors.toList());
        modifiableList.removeAll(integrationApprovalList);

        List<ProductApproval> baseProductApprovalList = productApprovalList.stream().filter(V -> V.getProductLevel().
                equalsIgnoreCase(ProductLevelConstants.BASE.name())).collect(Collectors.toList());
        modifiableList.removeAll(baseProductApprovalList);

        Map<String, List<ProductApproval>> groupByBaseMarketingProductId = modifiableList.stream().
                collect(Collectors.groupingBy(ProductApproval::getBaseMarketingProductId));

        buildBaseProductsApprovalResponse(groupByBaseMarketingProductId, baseProductApprovalList, integrationApprovalList, quoteApproval);

        buildMiscellaneousProductApprovalResponse(new HashSet<>(quoteLevelApprovalList), quoteApproval);
    }

    private void buildBaseProductsApprovalResponse(Map<String, List<ProductApproval>> groupByBaseMarketingProductId,
                                                   List<ProductApproval> baseProductApprovalList, List<ProductApproval>
                                                           integrationApprovalList, QuoteApproval quoteApproval) {


        if (!groupByBaseMarketingProductId.isEmpty()) {
            for (Map.Entry<String, List<ProductApproval>> unit : groupByBaseMarketingProductId.entrySet()) {
                List<ProductApproval> assProductApprovals = unit.getValue();
                if (CollectionUtils.isNotEmpty(baseProductApprovalList)) {
                    ProductApproval baseProductApproval = baseProductApprovalList.stream().
                            filter(V -> V.getProductId().equalsIgnoreCase(unit.getKey())).findFirst().get();
                    baseProductApproval.setAssociatedProducts(buildProductsWithHierarchy(baseProductApproval.getProductId(), assProductApprovals));
                }
            }
        }

        Map<String, ProductApproval> groupByBaseMarketing = baseProductApprovalList.stream().
                collect(Collectors.toMap(ProductApproval::getProductId, V -> V));

        if (!CollectionUtils.isEmpty(integrationApprovalList)) {
            for (ProductApproval unit : integrationApprovalList) {
                ProductApproval baseProductToConsider = groupByBaseMarketing.get(unit.getBaseMarketingProductId());
                if (baseProductToConsider != null) {
                    if (unit.getParentProductId().equalsIgnoreCase(baseProductToConsider.getProductId())) {
                        baseProductToConsider.setIntegrationProduct(unit);
                    } else {
                        ProductApproval integrationToAttach = findProductInAssociatedProducts(baseProductToConsider, unit.getParentProductId());
                        integrationToAttach.setIntegrationProduct(unit);
                    }
                }
            }
        }

        quoteApproval.setBaseProducts(baseProductApprovalList);
    }

    private void buildMiscellaneousProductApprovalResponse(Set<ProductApproval> quoteLevelApprovalList, QuoteApproval quoteApproval) {
        List<ProductApproval> miscellaneousProductsTopLevel = quoteLevelApprovalList.stream().
                filter(V -> V.getParentProductId() == null).collect(Collectors.toList());

        quoteLevelApprovalList.removeAll(miscellaneousProductsTopLevel);

        Map<String, List<ProductApproval>> quoteHierarchyProducts = quoteLevelApprovalList.stream().
                collect(Collectors.groupingBy(ProductApproval::getParentProductId));

        if (!quoteHierarchyProducts.isEmpty()) {
            for (Map.Entry<String, List<ProductApproval>> unit : quoteHierarchyProducts.entrySet()) {
                List<ProductApproval> assProductApprovals = unit.getValue();
                if (CollectionUtils.isNotEmpty(miscellaneousProductsTopLevel)) {
                    ProductApproval miscellaneousBase = miscellaneousProductsTopLevel.stream().
                            filter(V -> V.getProductId().equalsIgnoreCase(unit.getKey())).findFirst().get();
                    miscellaneousBase.setAssociatedProducts(buildProductsWithHierarchy(miscellaneousBase.getProductId(), assProductApprovals));
                }
            }
        }

        quoteApproval.setMiscellaneousProducts(miscellaneousProductsTopLevel);
    }

    private ProductApproval findProductInAssociatedProducts(ProductApproval baseProductToConsider, String productId) {
        Optional<ProductApproval> selectFilter = baseProductToConsider.getAssociatedProducts().stream().filter(V -> V.getProductId().equalsIgnoreCase(productId)).findFirst();
        if (selectFilter.isPresent()) {
            return selectFilter.get();
        }
        for (ProductApproval unit : baseProductToConsider.getAssociatedProducts()) {
            ProductApproval test = findProductInAssociatedProducts(unit, productId);
            if (test == null) continue;
            else return test;
        }
        return null;
    }

    private List<ProductApproval> buildProductsWithHierarchy(String parentMktId, List<ProductApproval> assProductApprovals) {
        List<ProductApproval> currentHierarchyList = assProductApprovals.stream().filter(V -> V.getParentProductId().equalsIgnoreCase(parentMktId)).
                collect(Collectors.toList());

        assProductApprovals.removeAll(currentHierarchyList);

        if (!CollectionUtils.isEmpty(assProductApprovals)) {
            Map<String, List<ProductApproval>> groupByParentProductId = assProductApprovals.stream().
                    collect(Collectors.groupingBy(ProductApproval::getParentProductId));

            for (Map.Entry<String, List<ProductApproval>> unit : groupByParentProductId.entrySet()) {

                //find the parent product details from current hierarchy list
                ProductApproval productApprovalToConsider = currentHierarchyList.stream().
                        filter(V -> V.getProductId().equalsIgnoreCase(unit.getKey())).findFirst().get();

                productApprovalToConsider.setAssociatedProducts(buildProductsWithHierarchy(productApprovalToConsider.getProductId(), unit.getValue()));
            }
        }
        return currentHierarchyList;
    }


    private List<ProductApproval> getApprovalsFromAllItemsInCollections(List<BREProductModel> breProductModel) {
        List<ProductApproval> productApprovalList = new ArrayList<>();
        breProductModel.stream().forEach(V -> productApprovalList.add(new ProductApproval(V)));
        return productApprovalList;
    }

    private BAIntermediateProductBreModel getBreProductRelatedApprovals(BAIntermediateProductBreModel baIntermediateProductBreModel) {

        ThreadPoolExecutor executorService = (ThreadPoolExecutor) Executors.newFixedThreadPool(2);
        try {

            CompletableFuture<List<BREProductModel>> independentProductApprovals = CompletableFuture.supplyAsync(() ->
                    breClient.getIndependentProductApprovals(baIntermediateProductBreModel.getBreProductModelList()), executorService);

            CompletableFuture<List<BREAggregateProductModel>> dependentProductApprovals = null;
            List<BREAggregateProductModel> breAggregateProductModelList = baIntermediateProductBreModel.getBreAggregateProductModelList();
            if (!CollectionUtils.isEmpty(breAggregateProductModelList)) {
                dependentProductApprovals = CompletableFuture.supplyAsync(() ->
                        breClient.getDependentProductApprovals(breAggregateProductModelList), executorService);
            }

            Object rawDependentProductApprovals, rawIndependentProductApprovals;

            BAIntermediateProductBreModel breResponse = new BAIntermediateProductBreModel();

            logger.debug("getting response from independent product approval task");
            rawIndependentProductApprovals = getResponseFromTask(independentProductApprovals);
            logger.debug("response from core is {}", rawIndependentProductApprovals);
            breResponse.setBreProductModelList((List<BREProductModel>) rawIndependentProductApprovals);

            if (dependentProductApprovals != null) {
                logger.debug("getting response from dependent products approval task");
                rawDependentProductApprovals = getResponseFromTask(dependentProductApprovals);
                logger.debug("response from dependent products approval task is {}", rawDependentProductApprovals);
                breResponse.setBreAggregateProductModelList((List<BREAggregateProductModel>) rawDependentProductApprovals);
            }

            return breResponse;
        } catch (BuyAkamaiApplicationException baEx) {
            if (StringUtils.isEmpty(baEx.getErrorKey())) {
                baEx.setErrorKey(ErrorConstants.GET_PRODUCT_APPROVAL_FROM_BRE_FAILED);
            }
            throw baEx;
        } catch (Exception e) {
            logger.error("Exception is {}", e);
            throw new BuyAkamaiApplicationException("Exception communicating to Bre", "communication failed for product approvals",
                    HttpStatus.INTERNAL_SERVER_ERROR, ErrorConstants.GET_PRODUCT_APPROVAL_FROM_BRE_FAILED);
        } finally {
            executorService.shutdown();
        }
    }

    private Object getResponseFromTask(CompletableFuture task) {
        Object response = null;
        try {
            response = task.get();
        } catch (InterruptedException | ExecutionException ex) {
            logger.error("Exception occurred in executing approval task {}", ex);
            throw new BuyAkamaiApplicationException("Exception communicating to BRE", "communication failed for product approvals",
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (BuyAkamaiApplicationException ex) {
            logger.error("Buy akamai application exception caught", ex);
        }
        return response;
    }


    public List<ProductSslDetail> getSslDetailsForProducts(List<String> products) {
        logger.info("Input products : " + products);
        try {
            return breClient.getSslDetailsForProducts(products);
        } catch (Exception exception) {
            String title = "Failed to integrate with business rule engine.";
            logger.error(title + " Description : {}", exception.getMessage());
            throw new BuyAkamaiApplicationException(title, exception.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    ErrorConstants.GET_SSL_CERTIFICATE_FOR_PRODUCTS_FROM_BRE_FAILED);
        }
    }

}