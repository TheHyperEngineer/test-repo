package com.akamai.buyakamai.orchestrator.rule.model;


import com.akamai.buyakamai.model.oms.ContractTerms;
import com.akamai.buyakamai.model.productmaster.ProductPricingResponse;
import com.akamai.buyakamai.model.quote.approval.Approval;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BREProductModel {

    private String opportunityId;
    private String accountId;
    private String currency;
    private String title;
    private String status;
    private String serviceType;
    private String createdBy;
    private ContractTerms contractTerms;

    private String parentProductId;
    private String baseMktProductId;
    private String marketingProductId;
    private String productLevel;
    private String marketingProductName;
    private BREBillingDetails billingDetails;
    Map<String, String> attributes;


    private ProductPricingResponse product; //Product reference data from product Master

    private List<Approval> approvals;

}
