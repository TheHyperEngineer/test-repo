package com.akamai.buyakamai.config;

import com.akamai.buyakamai.constants.ConfigConstants;
import com.akamai.se.manager.CoreManagerFactory;
import com.akamai.se.manager.identity.IdentityServiceFactory;
import com.akamai.se.manager.identity.IdentityServiceResourceClient;
import com.akamai.se.manager.identity.service.impl.IdentityServiceFactoryImpl;
import com.akamai.se.manager.CoreManagerAuthzFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

@Configuration
public class AkamaiSEConfig {

    @Autowired
    @Qualifier(ConfigConstants.SOURCE_ASAPMSTR)
    private DataSource dataSource;
    
    @Autowired
    @Qualifier(ConfigConstants.SOURCE_EXTAPI)
    private DataSource extAPIDataSource;

    @Bean
    public CoreManagerFactory getCoreManagerFactory() {
        return new CoreManagerFactory(dataSource);
    }
    
    @Bean
    public CoreManagerFactory getCoreExtAPIManagerFactory() {
        return new CoreManagerFactory(extAPIDataSource);
    }
    
    @Bean
    public CoreManagerAuthzFactory getCoreExtAPIAuthzManagerFactory(IdentityServiceFactory identityServiceFactory) {
		return new CoreManagerAuthzFactory(identityServiceFactory, extAPIDataSource);
    }
    
    @Bean
    public CoreManagerAuthzFactory getCoreExtAPIAuthzManagerFactory() {
        IdentityServiceResourceClient client = new IdentityServiceResourceClient();
		IdentityServiceFactory factory = new IdentityServiceFactoryImpl(client );
		return new CoreManagerAuthzFactory(factory, extAPIDataSource);
    }
}
