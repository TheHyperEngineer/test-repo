package com.akamai.buyakamai.config;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.enums.PulsarAuthZHeader;
import com.akamai.buyakamai.controller.RESTExceptionHandler;
import com.akamai.buyakamai.integration.clients.model.AccountDto;
import com.akamai.buyakamai.service.impl.AccountServiceImpl;
import com.akamai.buyakamai.service.impl.AuthorizationServiceImpl;
import com.akamai.buyakamai.service.impl.PartnerService;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import com.akamai.buyakamai.util.RestScopeLoader;
import com.akamai.ids.commons.model.request.IdsRequest;
import com.akamai.se.dto.problem.Problem;
import com.akamai.se.dto.problem.ProblemBuilder;
import com.akamai.se.jackson.annotation.JsonInclude.Include;
import com.akamai.se.jackson.databind.ObjectMapper;
import com.akamai.se.manager.identity.IdentityServiceFactory;
import com.akamai.se.manager.identity.IdentityServiceResourceClient;
import com.akamai.se.manager.identity.service.impl.IdentityServiceFactoryImpl;
import com.google.common.collect.Lists;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;

import javax.servlet.*;
import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Configuration
public class AuthorizationFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(AuthorizationFilter.class);

    private static final String MISSING_SCOPES = "missingScopes";

    @Autowired
    private RestScopeLoader scopeLoader;

    @Autowired
    private AuthorizationServiceImpl authService;

    @Autowired
    private PartnerService partnerService;

    @Autowired
    private PropertyManager propertyManager;

    @Autowired
    private AccountServiceImpl accountService;



    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
            ServletException {
        logger.info("checking if client has required access");
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        IdsRequest idsRequest = IdsRequest.from(req);

        IdentityServiceResourceClient client = new IdentityServiceResourceClient();
		IdentityServiceFactory factory = new IdentityServiceFactoryImpl(client );
		boolean isAllowedPartnerUser = false;
		boolean isInternalUser = factory.getRequestIdentityService().isCurrentRequestInternal(idsRequest);
		if (!isInternalUser) {
            String accountId = req.getHeader(PulsarAuthZHeader.DEFAULT_ACCOUNT_ID.getHeaderName());
            List<String> blockedAccounts = CommonUtils.convertCommaSeparatedStringToList(propertyManager.getProperty(BAConstants.BLOCKED_PARTNERS_PROPERTY_KEY));
            if (!blockedAccounts.contains(accountId)) {
                isAllowedPartnerUser = partnerService.isPartnerUser(req.getHeader(PulsarAuthZHeader.USERNAME.getHeaderName()));
            }
            AccountDto accountDto = accountService.getAccountDetails(accountId);
            if (accountDto.getRestrictedCountry().equalsIgnoreCase("Y")) {
                logger.info("Blocking the login as user belong to restricted country account {}", accountId);
                isAllowedPartnerUser = false;
            }
        }

        if ( !(isInternalUser || isAllowedPartnerUser) ) {
            logger.error("Only internal/Tier-1-Resellers users are allowed to access this url");
            Problem problem = new ProblemBuilder().type(RESTExceptionHandler.statusCodeTypeMap.get(HttpStatus.FORBIDDEN)).status(
                    HttpStatus.FORBIDDEN.value()).title(HttpStatus.FORBIDDEN.getReasonPhrase()).detail(
                            "Only Internal/Tier-1-Resellers users are allowed to access this url").appendProblemIdToInstance(BAConstants.PROBLEM_INSTANCE_PREFIX).build();
            logger.info("problem instance id "+problem.getProblemId());
            sendProblem(res, problem);
        } else {

            //block api calls if system is under maintenance
            blockApiCallsForSystemDownTime(req, res);

	        Map<String, List<String>> scopesAndMethods = scopeLoader.getScopes(req.getRequestURI());
	        if (scopesAndMethods.isEmpty() || scopesAndMethods.get(req.getMethod()) == null) {
	            logger.error("scopes not available in db for requested method and uri. Blocking client");
	            Problem problem = new ProblemBuilder().type(RESTExceptionHandler.statusCodeTypeMap.get(HttpStatus.NOT_FOUND)).status(
	                    HttpStatus.NOT_FOUND.value()).title(HttpStatus.NOT_FOUND.getReasonPhrase()).detail(
	                            "Unknown URL").appendProblemIdToInstance(BAConstants.PROBLEM_INSTANCE_PREFIX).build();
	            logger.info("problem instance id "+problem.getProblemId());
	            sendProblem(res, problem);
	        } else {
                List<String> requiredScopes = scopesAndMethods.get(req.getMethod());
                List<String> matchingScopes = getMatchingScopes(requiredScopes, req, isAllowedPartnerUser);
                if (matchingScopes.isEmpty()) {
                    logger.warn("Authorization failed. Client does not have required scopes");
                    String detail = BAConstants.DETAIL_MISSING_SCOPES;
                    Problem problem = new ProblemBuilder().type(RESTExceptionHandler.statusCodeTypeMap.get(HttpStatus.FORBIDDEN)).status(
                            HttpStatus.FORBIDDEN.value()).title(HttpStatus.FORBIDDEN.getReasonPhrase()).detail(
                            detail).withExtension(MISSING_SCOPES, requiredScopes).appendProblemIdToInstance(BAConstants.PROBLEM_INSTANCE_PREFIX).build();
                    logger.info("problem instance id " + problem.getProblemId());
                    sendProblem(res, problem);
                } else {
                    logger.info("Client has required scopes to access url");
                    chain.doFilter(request, response);
                }
            }
        }
    }

    private void blockApiCallsForSystemDownTime(HttpServletRequest req, HttpServletResponse res) throws IOException {
        //block other API calls if system is down
        String isAppDown = propertyManager.getProperty(BAConstants.APPLICATION_DOWN_TIME_CONSTANT);
        if (Boolean.valueOf(isAppDown)) {
            logger.info("Found application is down, will allow only user info API");

            String allowedUrl = propertyManager.getProperty(BAConstants.APPLICATION_DOWN_ALLOWED_URLS);
            List<String> serviceDownTimeAllowedUrls = CommonUtils.convertCommaSeparatedStringToList(allowedUrl);
            if (!serviceDownTimeAllowedUrls.contains(req.getRequestURI())) {
                String detail = "Request not allowed as system is under maintenance";
                Problem problem = new ProblemBuilder().type(RESTExceptionHandler.statusCodeTypeMap.get(HttpStatus.SERVICE_UNAVAILABLE)).status(
                        HttpStatus.SERVICE_UNAVAILABLE.value()).title(HttpStatus.SERVICE_UNAVAILABLE.getReasonPhrase()).detail(
                        detail).appendProblemIdToInstance(BAConstants.PROBLEM_INSTANCE_PREFIX).build();
                logger.info("problem instance id " + problem.getProblemId());
                sendProblem(res, problem);
            }
        }
    }

	private void sendProblem(HttpServletResponse res, Problem problem) throws IOException {
       ObjectMapper objectMapper = new ObjectMapper();
       objectMapper.setSerializationInclusion(Include.NON_NULL);
        res.setStatus(problem.getStatus());
        res.setContentType(BAConstants.MEDIATYPE_PROBLEM_JSON);
        res.getWriter().write(objectMapper.writeValueAsString(problem));
        res.getWriter().flush();
        res.getWriter().close();
    }

    @SuppressWarnings({ "unchecked" })
    private List<String> getMatchingScopes(List<String> requiredScopes,
                                           HttpServletRequest httpRequest, boolean isPartnerUser) {
        if ( requiredScopes.contains(BAConstants.SCOPE_FRIEND) ) {
        	return Lists.newArrayList(BAConstants.SCOPE_FRIEND);
        }
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        String impUserName = httpRequest.getHeader(BAConstants.IMP_USER_ID);
        List<String> availableScopes = authService.getScopesForUser(userName, !StringUtils.isBlank(impUserName), isPartnerUser);

        return ListUtils.intersection(requiredScopes, availableScopes);
    }

    @Override
    public void destroy() {

    }
}
