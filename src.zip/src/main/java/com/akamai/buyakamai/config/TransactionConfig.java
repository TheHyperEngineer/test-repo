package com.akamai.buyakamai.config;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.transaction.ChainedTransactionManager;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import com.akamai.buyakamai.constants.ConfigConstants;

import javax.persistence.EntityManagerFactory;

/**
 * The idea Behind this class is to use Transaction chaining to provide Best Effort 1 PC. While it is possible to go for
 * XA 2 PC, the performance overhead is significant while our use case doesnt need such stringent gurantees. Current
 * req: Same DB, different schema calls. Only infra failures are likely to undermine BE 1 PC, which is rare.
 * 
 */
@Configuration
public class TransactionConfig {    
    
    @Primary
    @Bean(ConfigConstants.TXM_BUY_AKAMAI)
    public PlatformTransactionManager buyAkamaiTxManager(
            @Qualifier(ConfigConstants.ENTITIES_BUY_AKAMAI) EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
    
    @Bean(ConfigConstants.TXM_ASAP)
    public PlatformTransactionManager asapTxManager(
            @Qualifier(ConfigConstants.ENTITIES_ASAPMSTR) EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }
    

    @Bean(ConfigConstants.TXM_ALL)
    public ChainedTransactionManager allTxManager(
            @Qualifier(ConfigConstants.TXM_ASAP) PlatformTransactionManager asapTx,
            @Qualifier(ConfigConstants.TXM_BUY_AKAMAI) PlatformTransactionManager buyAkamaiTx) {

        return new ChainedTransactionManager(asapTx, buyAkamaiTx);
    }
}
