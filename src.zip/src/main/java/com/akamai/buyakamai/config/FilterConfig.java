package com.akamai.buyakamai.config;

import com.akamai.buyakamai.util.PropertyManager;
import com.akamai.ids.sdk.innergrid.web.InnerGridFilter;
import com.akamai.se.servlets.AdminServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;

@Configuration
public class FilterConfig {
    /*private static final String PATH_RESTRICTED = "/restricted/*";

    // TODO: Why is this done ? Refer prop manager code, hopefully it wont exist for long
    @Autowired
    PropertyManager propertyManager;

    @Autowired
    private AuthorizationFilter authorizatinFilter;

    @Autowired
    private HttpsEnforcerFilter httpsEnforcerFilter;


    @Bean
    public ServletRegistrationBean registerAdmin() {
        return new ServletRegistrationBean(new AdminServlet(), PATH_RESTRICTED);
    }

    @Bean
    public FilterRegistrationBean registerInnerGridFilter() {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(new InnerGridFilter());
        filterRegistrationBean.addUrlPatterns("/v1/*", "/v2/*","/v3/*","/v4/*");
        filterRegistrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE);
        return filterRegistrationBean;
    }

    @Bean
    public FilterRegistrationBean registerAuthorizationFilter() {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(authorizatinFilter);
        filterRegistrationBean.addUrlPatterns("/v1/*", "/v2/*","/v3/*","/v4/*");
        filterRegistrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE - 2);
        return filterRegistrationBean;
    }

    @Bean
    public FilterRegistrationBean registerHttpEnforcer() {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter(httpsEnforcerFilter);
        filterRegistrationBean.addUrlPatterns("/v1/*", "/v2/*","/v3/*","/v4/*");
        filterRegistrationBean.setOrder(Ordered.HIGHEST_PRECEDENCE - 3);
        return filterRegistrationBean;
    }
*/
}