package com.akamai.buyakamai.config;

import org.springframework.context.annotation.Configuration;

import javax.servlet.*;
import javax.servlet.FilterConfig;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.IOException;

@Configuration
public class HttpsEnforcerFilter implements Filter {
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain filterChain) throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) servletRequest;
        final HttpServletRequestWrapper wrapped = new HttpServletRequestWrapper(request) {
            @Override
            public StringBuffer getRequestURL() {
                final StringBuffer originalUrl = ((HttpServletRequest) getRequest()).getRequestURL();
                if (originalUrl.toString().startsWith("http://")) {
                    final String updatedUrl = originalUrl.toString().replace("http://", "https://");
                    return new StringBuffer(updatedUrl);
                }
                return originalUrl;
            }
        };
        filterChain.doFilter(wrapped, servletResponse);
    }

    @Override
    public void destroy() {

    }
}