package com.akamai.buyakamai.config;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import com.akamai.buyakamai.constants.ConfigConstants;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableJpaRepositories(basePackages = "com.akamai.buyakamai.dataaccess.asap", entityManagerFactoryRef = ConfigConstants.ENTITIES_ASAPMSTR, transactionManagerRef = ConfigConstants.TXM_ASAP)
public class AsapmstrDBConfig {

    private DataSource createDataSource(DataSourceProperties props) {
        if (props.getUrl() != null && !props.getUrl().isEmpty()) {
            return props.initializeDataSourceBuilder().build();
        }
        return new JndiDataSourceLookup().getDataSource(props.getJndiName());
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.asapmstr")
    public DataSourceProperties asapSourceProps() {
        return new DataSourceProperties();
    }

    @Bean(name = ConfigConstants.SOURCE_ASAPMSTR)
    @ConfigurationProperties(prefix = "spring.datasource.asapmstr")
    public DataSource asapSource() {
        return createDataSource(asapSourceProps());
    }
    
    public Map<String, String> asapEmProps() {
        Map<String, String> ceProps = new HashMap<>();        
        ceProps.put("hibernate.ejb.naming_strategy","org.springframework.boot.orm.jpa.hibernate.SpringNamingStrategy");
        return ceProps;
    }

    @Bean(ConfigConstants.ENTITIES_ASAPMSTR)
    public LocalContainerEntityManagerFactoryBean asapEntityManagerFactory(EntityManagerFactoryBuilder builder) {
        //@formatter:off
        return builder                
                .dataSource(asapSource())
                .persistenceUnit("asapEntityPersistence")
                .packages("com.akamai.buyakamai.dataaccess.asap.model")
                .properties(asapEmProps())
                .build();
       //@formatter:on
    }
}
