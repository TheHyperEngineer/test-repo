package com.akamai.buyakamai.config;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import com.akamai.buyakamai.constants.ConfigConstants;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = ConfigConstants.ENTITIES_BUY_AKAMAI, basePackages = "com.akamai.buyakamai.dataaccess.buyakamdb", transactionManagerRef = ConfigConstants.TXM_BUY_AKAMAI)
public class BuyAkamaiDBConfig {

    private DataSource createDataSource(DataSourceProperties props) {
        if (props.getUrl() != null && !props.getUrl().isEmpty()) {
            return props.initializeDataSourceBuilder().build();
        }
        return new JndiDataSourceLookup().getDataSource(props.getJndiName());
    }

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.buyakamai")
    public DataSourceProperties buyAkamaiSourceProps() {
        return new DataSourceProperties();
    }

    @Primary
    @Bean(name = ConfigConstants.SOURCE_BUY_AKAMAI)
    @ConfigurationProperties(prefix = "spring.datasource.buyakamai")
    public DataSource buyAkamaiSource() {
        return createDataSource(buyAkamaiSourceProps());
    }

    @Bean
    // @ConfigurationProperties(prefix = "spring.datasource.buyakamai.em")
    public Map<String, String> buyAkamaiEmProps() {
        Map<String, String> ceProps = new HashMap<>();
        ceProps.put("hibernate.ejb.naming_strategy", "org.springframework.boot.orm.jpa.hibernate.SpringNamingStrategy");
        return ceProps;
    }

    @Primary
    @Bean(ConfigConstants.ENTITIES_BUY_AKAMAI)
    public LocalContainerEntityManagerFactoryBean buyAkamaiEntityManagerFactory(EntityManagerFactoryBuilder builder) {
        //@formatter:off
        return builder
                .dataSource(buyAkamaiSource())
                .persistenceUnit("buyAkamaiEntityPersistence")                
                .packages("com.akamai.buyakamai.dataaccess.buyakamdb.model")
                .properties(buyAkamaiEmProps())
                .build();
       //@formatter:on
    }
}
