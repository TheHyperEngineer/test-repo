package com.akamai.buyakamai.config;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

import com.akamai.buyakamai.constants.ConfigConstants;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
//@EnableJpaRepositories(basePackages = "com.akamai.buyakamai.dataaccess.asap", entityManagerFactoryRef = ConfigConstants.ENTITIES_ASAPMSTR, transactionManagerRef = ConfigConstants.TXM_ASAP)
public class ExtAPIDBConfig {

    private DataSource createDataSource(DataSourceProperties props) {
        if (props.getUrl() != null && !props.getUrl().isEmpty()) {
            return props.initializeDataSourceBuilder().build();
        }
        return new JndiDataSourceLookup().getDataSource(props.getJndiName());
    }

    @Bean
    @ConfigurationProperties(prefix = "spring.datasource.extapi")
    public DataSourceProperties extapiSourceProps() {
        return new DataSourceProperties();
    }

    @Bean(name = ConfigConstants.SOURCE_EXTAPI)
    @ConfigurationProperties(prefix = "spring.datasource.extapi")
    public DataSource extapiSource() {
        return createDataSource(extapiSourceProps());
    }
}
