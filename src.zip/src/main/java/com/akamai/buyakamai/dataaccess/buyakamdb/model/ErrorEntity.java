package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.io.Serializable;
import java.sql.Date;
import java.util.Map;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKeyColumn;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.annotations.Type;

import com.akamai.buyakamai.constants.ActionType;
import com.akamai.buyakamai.constants.ComponentType;
import com.akamai.buyakamai.constants.enums.AlertType;

@Entity
@Table(name = "ERROR")
public class ErrorEntity implements Serializable{

	private static final long serialVersionUID = 6894215441786389820L;

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "error_seq")
	@SequenceGenerator(name = "error_seq", sequenceName = "ERROR_SEQ", initialValue = 1,allocationSize = 1)
	private Integer id;
	
	@Column(name = "USER_ID")
	private String userId;
	
	@Column(name = "ACTION")
	@Enumerated(EnumType.STRING)
	private AlertType action;
	
	@Column(name = "RESOLVED")
	@Type(type = "yes_no")
    private Boolean resolved;
	
	@ElementCollection
    @MapKeyColumn(name = "KEY")
    @Column(name = "VALUE")
    @CollectionTable(name = "ERROR_DATA", joinColumns = @JoinColumn(name = "ID"))
	private Map<String, String> requestData;
	
	@Column(name = "COMPONENT")
	@Enumerated(EnumType.STRING)
	private ComponentType component;
	
	@Column(name = "CREATED_TIME")
	private Date createdTime;
	
	@Column(name = "ALERT_ID")
	private String alertId;
	
	@Column(name = "PRIORITY")
	private String priority;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public AlertType getAction() {
		return action;
	}

	public void setAction(AlertType action) {
		this.action = action;
	}

	public boolean isResolved() {
		return resolved;
	}

	public void setResolved(boolean resolved) {
		this.resolved = resolved;
	}

	public Map<String, String> getRequestData() {
		return requestData;
	}

	public void setRequestData(Map<String, String> requestData) {
		this.requestData = requestData;
	}

	public ComponentType getComponent() {
		return component;
	}

	public void setComponent(ComponentType component) {
		this.component = component;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getAlertId() {
		return alertId;
	}

	public void setAlertId(String alertId) {
		this.alertId = alertId;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((action == null) ? 0 : action.hashCode());
		result = prime * result + ((alertId == null) ? 0 : alertId.hashCode());
		result = prime * result + ((component == null) ? 0 : component.hashCode());
		result = prime * result + ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((priority == null) ? 0 : priority.hashCode());
		result = prime * result + ((requestData == null) ? 0 : requestData.hashCode());
		result = prime * result + ((resolved == null) ? 0 : resolved.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ErrorEntity other = (ErrorEntity) obj;
		if (action != other.action)
			return false;
		if (alertId == null) {
			if (other.alertId != null)
				return false;
		} else if (!alertId.equals(other.alertId))
			return false;
		if (component != other.component)
			return false;
		if (createdTime == null) {
			if (other.createdTime != null)
				return false;
		} else if (!createdTime.equals(other.createdTime))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (priority == null) {
			if (other.priority != null)
				return false;
		} else if (!priority.equals(other.priority))
			return false;
		if (requestData == null) {
			if (other.requestData != null)
				return false;
		} else if (!requestData.equals(other.requestData))
			return false;
		if (resolved == null) {
			if (other.resolved != null)
				return false;
		} else if (!resolved.equals(other.resolved))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
