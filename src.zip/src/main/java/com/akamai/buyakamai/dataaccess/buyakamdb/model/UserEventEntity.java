package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import com.akamai.buyakamai.constants.UserEventAction;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "USER_EVENT")
public class UserEventEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "event_seq")
    @SequenceGenerator(name = "event_seq", sequenceName = "USER_EVENT_SEQ", initialValue = 1, allocationSize = 1)
    @Column(name = "event_id")
    private Integer eventId;

    @Column(name = "user_name")
    private String userName;

    @Column(name = "timestamp")
    private Date timestamp;

    @Column(name = "event_type")
    private String eventType;

    @Column(name = "event_action")
    @Enumerated(EnumType.STRING)
    private UserEventAction eventAction;

    @OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "eventId")
    private List<UserEventDataEntity> eventData;

    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public UserEventAction getEventAction() {
        return eventAction;
    }

    public void setEventAction(UserEventAction eventAction) {
        this.eventAction = eventAction;
    }

    public List<UserEventDataEntity> getEventData() {
        return eventData;
    }

    public void setEventData(List<UserEventDataEntity> eventData) {
        this.eventData = eventData;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserEventEntity that = (UserEventEntity) o;

        if (eventId != null ? !eventId.equals(that.eventId) : that.eventId != null) return false;
        if (userName != null ? !userName.equals(that.userName) : that.userName != null) return false;
        if (timestamp != null ? !timestamp.equals(that.timestamp) : that.timestamp != null) return false;
        if (eventType != null ? !eventType.equals(that.eventType) : that.eventType != null) return false;
        if (eventAction != that.eventAction) return false;
        return eventData != null ? eventData.equals(that.eventData) : that.eventData == null;
    }

    @Override
    public int hashCode() {
        int result = eventId != null ? eventId.hashCode() : 0;
        result = 31 * result + (userName != null ? userName.hashCode() : 0);
        result = 31 * result + (timestamp != null ? timestamp.hashCode() : 0);
        result = 31 * result + (eventType != null ? eventType.hashCode() : 0);
        result = 31 * result + (eventAction != null ? eventAction.hashCode() : 0);
        result = 31 * result + (eventData != null ? eventData.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UserEventEntity{" +
                "eventId=" + eventId +
                ", userName='" + userName + '\'' +
                ", timestamp=" + timestamp +
                ", eventType='" + eventType + '\'' +
                ", eventAction=" + eventAction +
                ", eventData=" + eventData +
                '}';
    }
}
