package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.HistoryEntity;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface HistoryRepository extends CrudRepository<HistoryEntity, Integer> {

	List<HistoryEntity> findByOrderId(Integer orderId);

	List<HistoryEntity> findByOrderIdAndHistoryDefinitionId(Integer orderId, Integer historyDefId);
}
