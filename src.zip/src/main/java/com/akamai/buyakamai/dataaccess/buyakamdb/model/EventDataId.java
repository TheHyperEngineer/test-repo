package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.io.Serializable;


public  class EventDataId implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer eventId;
	private String key;
	
	public EventDataId() {
	}

	public EventDataId(Integer eventId, String key) {
		super();
		this.eventId = eventId;
		this.key = key;
	}

	public Integer getEventId() {
		return eventId;
	}

	public String getKey() {
		return key;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EventDataId other = (EventDataId) obj;
		if (eventId == null) {
			if (other.eventId != null)
				return false;
		} else if (!eventId.equals(other.eventId))
			return false;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EventDataId [eventId=" + eventId + ", key=" + key + "]";
	}
	
	
	
}