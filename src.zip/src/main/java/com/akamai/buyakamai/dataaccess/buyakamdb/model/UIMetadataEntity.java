package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "UI_METADATA")
public class UIMetadataEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "ui_metadata_seq")
	@SequenceGenerator(name = "ui_metadata_seq", sequenceName = "UI_METADATA_SEQ")
	@Column(name = "ID")
	private int id;

	@Column(name = "BUNDLE_ID")
	private String bundleId;

	@Column(name = "METADATA_JSON")
	private String metaDataJson;
	
	@Column(name="PRODUCT_ID")
	private String productId;
	
	@Column(name="USER_TYPE")
	private String userType;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getMetaDataJson() {
		return metaDataJson;
	}

	public void setMetaDataJson(String metaDataJson) {
		this.metaDataJson = metaDataJson;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bundleId == null) ? 0 : bundleId.hashCode());
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + ((userType == null) ? 0 : userType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UIMetadataEntity other = (UIMetadataEntity) obj;
		if (bundleId == null) {
			if (other.bundleId != null)
				return false;
		} else if (!bundleId.equals(other.bundleId))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (userType == null) {
			if (other.userType != null)
				return false;
		} else if (!userType.equals(other.userType))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UIMetadataEntity [id=" + id + ", bundleId=" + bundleId + ", productId=" + productId + ", metaDataJson="
				+ metaDataJson + "]";
	}

}
