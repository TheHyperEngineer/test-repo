package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;

@Entity
@Table(name = "WEB_PST_MAPPING")
public class WebPSTMappingEntity {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "web_pst_mapping_seq")
    @SequenceGenerator(name = "web_pst_mapping_seq", sequenceName = "WB_REQ_MAP_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "CASE_ID")
    private String caseId;

    @Column(name = "PST_REQUEST_ID")
    private String pstRequestId;


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getPstRequestId() {
        return pstRequestId;
    }

    public void setPstRequestId(String pstRequestId) {
        this.pstRequestId = pstRequestId;
    }

    @Override
    public String toString() {
        return "WebPSTMappingEntity{" +
                "id=" + id +
                ", caseId='" + caseId + '\'' +
                ", pstRequestId='" + pstRequestId + '\'' +
                '}';
    }
}
