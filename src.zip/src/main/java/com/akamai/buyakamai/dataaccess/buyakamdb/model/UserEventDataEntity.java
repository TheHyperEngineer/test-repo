package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;

@Entity
@IdClass(EventDataId.class)
@Table(name = "USER_EVENT_DATA")
public class UserEventDataEntity {

    @Id
    @Column(name = "event_id")
    private Integer eventId;
    @Id
    @Column(name = "key")
    private String key;
    @Column(name = "value")
    private String value;


    public Integer getEventId() {
        return eventId;
    }

    public void setEventId(Integer eventId) {
        this.eventId = eventId;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserEventDataEntity that = (UserEventDataEntity) o;

        if (eventId != null ? !eventId.equals(that.eventId) : that.eventId != null) return false;
        if (key != null ? !key.equals(that.key) : that.key != null) return false;
        return value != null ? value.equals(that.value) : that.value == null;
    }

    @Override
    public int hashCode() {
        int result = eventId != null ? eventId.hashCode() : 0;
        result = 31 * result + (key != null ? key.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UserEventDataEntity{" +
                "eventId=" + eventId +
                ", key='" + key + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
