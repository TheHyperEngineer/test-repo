package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCT_BILLING_EFFECTIVE_DATE")
public class ProductBEDEntity {

	@Id
	@Column(name = "PRODUCT_ID")
	private String productId;
	
	@Column(name="FAMILY")
	private String family;
	
	@Column(name="RECOMMENDED_BED")
	private Integer recommendedBed;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getFamily() {
		return family;
	}

	public void setFamily(String family) {
		this.family = family;
	}

	public Integer getRecommendedBed() {
		return recommendedBed;
	}

	public void setRecommendedBed(Integer recommendedBed) {
		this.recommendedBed = recommendedBed;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((family == null) ? 0 : family.hashCode());
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		result = prime * result + recommendedBed;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductBEDEntity other = (ProductBEDEntity) obj;
		if (family == null) {
			if (other.family != null)
				return false;
		} else if (!family.equals(other.family))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		if (recommendedBed != other.recommendedBed)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProductBEDEntity [productId=" + productId + ", family=" + family + ", recommendedBed=" + recommendedBed
				+ "]";
	}
	
}
