package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;
import java.sql.Clob;
import java.util.Date;

@Entity
@Table(name = "Webdel_Aggregation")
public class WebDeliveryAggregationMetric {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "agg_report_seq")
    @SequenceGenerator(name = "agg_report_seq", sequenceName = "WB_AGGREGATION_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "TEST_SETUP_INFO_ID")
    private String testSetUpInfoId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    @Column(name = "REPORT")
    @Lob
    private String report;

    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

    public String getTestSetUpInfoId() {
        return testSetUpInfoId;
    }

    public void setTestSetUpInfoId(String testSetUpInfoId) {
        this.testSetUpInfoId = testSetUpInfoId;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryAggregationMetric that = (WebDeliveryAggregationMetric) o;

        return testSetUpInfoId != null ? testSetUpInfoId.equals(that.testSetUpInfoId) : that.testSetUpInfoId == null;
    }

    @Override
    public int hashCode() {
        return testSetUpInfoId != null ? testSetUpInfoId.hashCode() : 0;
    }

}
