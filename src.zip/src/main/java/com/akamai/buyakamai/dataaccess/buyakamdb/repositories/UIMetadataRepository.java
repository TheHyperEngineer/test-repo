package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.UIMetadataEntity;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface UIMetadataRepository extends CrudRepository<UIMetadataEntity, String> {
	
	    public UIMetadataEntity findByBundleId(String bundleId);
	    
	    public List<UIMetadataEntity> findByUserType(String userType);
	    
}
