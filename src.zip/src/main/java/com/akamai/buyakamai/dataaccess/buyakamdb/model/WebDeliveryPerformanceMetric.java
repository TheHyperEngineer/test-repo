package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;
import java.sql.Clob;
import java.util.Date;

@Entity
@Table(name = "Webdel_Performance")
public class WebDeliveryPerformanceMetric {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "perf_report_seq")
    @SequenceGenerator(name = "perf_report_seq", sequenceName = "WB_PERFORMANCE_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "Test_Setup_Info_Id")
    private String testSetupInfoId;

    @Column(name = "Report")
    @Lob
    private String report;

    @Column(name = "Updated_Time")
    private Date updatedTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTestSetupInfoId() {
        return testSetupInfoId;
    }

    public void setTestSetupInfoId(String testSetupInfoId) {
        this.testSetupInfoId = testSetupInfoId;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryPerformanceMetric that = (WebDeliveryPerformanceMetric) o;

        return testSetupInfoId != null ? testSetupInfoId.equals(that.testSetupInfoId) : that.testSetupInfoId == null;
    }

    @Override
    public int hashCode() {
        return testSetupInfoId != null ? testSetupInfoId.hashCode() : 0;
    }

}
