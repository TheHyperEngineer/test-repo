package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.EmailState;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.EmailEntity;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface EmailRepository extends CrudRepository<EmailEntity, Integer> {

	List<EmailEntity> findByStateIn(List<EmailState> states);
}
