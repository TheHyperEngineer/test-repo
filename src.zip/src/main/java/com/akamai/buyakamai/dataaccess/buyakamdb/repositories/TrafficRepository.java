package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.TrafficEntity;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface TrafficRepository extends CrudRepository<TrafficEntity, Integer> {

	TrafficEntity findByOrderId(Integer orderId);
}
