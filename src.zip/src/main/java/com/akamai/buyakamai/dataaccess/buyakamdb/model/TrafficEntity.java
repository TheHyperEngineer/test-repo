package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ORDER_TRAFFIC")
public class TrafficEntity {

	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_traffic_seq")
   	@SequenceGenerator(name = "order_traffic_seq", sequenceName = "ORDER_TRAFFIC_SEQ", initialValue = 1 ,allocationSize = 1)
	private Integer id;
	
	@Column(name = "ID_ORDER")
	private Integer orderId;

    @Column(name = "TRAFFIC_ALLOTTED")
	private double trafficAllotted;

    @Column(name = "TRAFFIC_CONSUMED")
	private double trafficConsumed;

	@Column(name = "UOM")
	private String uom;

	@Column(name = "ORDER_START_DATE")
	private Date orderStartDate;

	@Column(name = "ORDER_END_DATE")
	private Date orderEndDate;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}


	public double getTrafficAllotted() {
		return trafficAllotted;
	}

	public void setTrafficAllotted(double trafficAllotted) {
		this.trafficAllotted = trafficAllotted;
	}

	public double getTrafficConsumed() {
		return trafficConsumed;
	}

	public void setTrafficConsumed(double trafficConsumed) {
		this.trafficConsumed = trafficConsumed;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public Date getOrderStartDate() {
		return orderStartDate;
	}

	public void setOrderStartDate(Date orderStartDate) {
		this.orderStartDate = orderStartDate;
	}

	public Date getOrderEndDate() {
		return orderEndDate;
	}

	public void setOrderEndDate(Date orderEndDate) {
		this.orderEndDate = orderEndDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrafficEntity other = (TrafficEntity) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
