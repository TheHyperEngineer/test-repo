package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.OrderEventEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.UserEventEntity;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface UserEventRepository extends CrudRepository<UserEventEntity, Integer> {
}
