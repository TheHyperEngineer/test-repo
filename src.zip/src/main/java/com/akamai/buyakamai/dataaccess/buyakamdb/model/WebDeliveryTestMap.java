package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;

@Entity
@Table(name = "Webdel_Test_Map")
public class WebDeliveryTestMap {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "web_delivery_test_map_seq")
    @SequenceGenerator(name = "web_delivery_test_map_seq", sequenceName = "WB_TEST_MAP_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "Test_Setup_Info_Id")
    private String testSetupInfoId;

    @Column(name = "Case_Id")
    private String caseId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTestSetupInfoId() {
        return testSetupInfoId;
    }

    public void setTestSetupInfoId(String testSetupInfoId) {
        this.testSetupInfoId = testSetupInfoId;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryTestMap that = (WebDeliveryTestMap) o;

        return testSetupInfoId != null ? testSetupInfoId.equals(that.testSetupInfoId) : that.testSetupInfoId == null;
    }

    @Override
    public int hashCode() {
        return testSetupInfoId != null ? testSetupInfoId.hashCode() : 0;
    }
}
