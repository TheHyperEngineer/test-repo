package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.BundleEntity;

import java.util.List;


@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface BundleRepository extends CrudRepository<BundleEntity, String> {

    BundleEntity findByBundleId(String bundleId);

    @Query(value = "select bundleId from BundleEntity  where category= :category")
    List<String> findByCategory(@Param("category") String category);
}
