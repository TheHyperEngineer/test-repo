package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import com.akamai.buyakamai.constants.ValueConfirmationState;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "Order_Value_Confirmation")
public class OrderValueConfirmation {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_value_confirmation_report_seq")
    @SequenceGenerator(name = "order_value_confirmation_report_seq", sequenceName = "VALUE_CONFIRMATION_REPORT_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "ID_Order")
    private Integer orderId;

    @Column(name = "User_Id")
    private String userId;

    @Column(name = "Bundle_Id")
    private String bundleId;

    @Column(name = "Created_Time")
    private Date createdTime;

    @Column(name = "Updated_Time")
    private Date updatedTime;

    @Column(name = "State")
    @Enumerated(EnumType.STRING)
    private ValueConfirmationState state;

    public ValueConfirmationState getState() {
        return state;
    }

    public void setState(ValueConfirmationState state) {
        this.state = state;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderValueConfirmation that = (OrderValueConfirmation) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
        if (userId != null ? !userId.equals(that.userId) : that.userId != null) return false;
        if (bundleId != null ? !bundleId.equals(that.bundleId) : that.bundleId != null) return false;
        if (createdTime != null ? !createdTime.equals(that.createdTime) : that.createdTime != null) return false;
        return updatedTime != null ? updatedTime.equals(that.updatedTime) : that.updatedTime == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (orderId != null ? orderId.hashCode() : 0);
        result = 31 * result + (userId != null ? userId.hashCode() : 0);
        result = 31 * result + (bundleId != null ? bundleId.hashCode() : 0);
        result = 31 * result + (createdTime != null ? createdTime.hashCode() : 0);
        result = 31 * result + (updatedTime != null ? updatedTime.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OrderValueConfirmation{" +
                "id=" + id +
                ", orderId=" + orderId +
                ", userId='" + userId + '\'' +
                ", bundleId='" + bundleId + '\'' +
                ", createdTime=" + createdTime +
                ", updatedTime=" + updatedTime +
                '}';
    }
}
