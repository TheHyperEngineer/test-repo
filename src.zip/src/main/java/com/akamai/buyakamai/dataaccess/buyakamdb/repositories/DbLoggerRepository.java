package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.ErrorEntity;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface DbLoggerRepository extends CrudRepository<ErrorEntity, Integer> {

	List<ErrorEntity> findByAlertIdAndResolved(String alertId, Boolean resolved);
}
