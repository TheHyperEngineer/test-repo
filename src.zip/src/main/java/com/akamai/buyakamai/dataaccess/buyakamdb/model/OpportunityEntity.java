package com.akamai.buyakamai.dataaccess.buyakamdb.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;


@Entity
@Table(name = "OPPORTUNITY")
public class OpportunityEntity {


    @Id
    @Column(name = "akam_opportunity_id")
    private String akamOpportunityId;

    @Column(name = "opportunity_src_id")
    private String opportunitySrcId;

    @Column(name = "name")
    private String opportunityName;

    @Column(name = "created_date")
    private Date createdDate;

    @Column(name = "account_id")
    private String accountId;

    @Column(name = "account_name")
    private String accountName;

    @Column(name = "account_src_id")
    private String accountSrcId;

    @Column(name = "owner_contact_id")
    private String ownerContactId;

    @Column(name = "owner_user_id")
    private String ownerUserId;

    @Column(name = "owner_src_id")
    private String ownerSrcId;

    @Column(name = "owner_name")
    private String ownerName;

    @Column(name = "bundle_id")
    private String bundleId;

    @Column(name = "stage")
    private String stage;

    @Column(name = "currency")
    private String currency;

    @Column(name = "competitor")
    private String competitor;

    @Column(name = "deal_type")
    private String dealType;

    @Column(name = "account_type")
    private String accountType;

    @Column(name = "account_country")
    private String accountCountry;
    
    @Column(name = "customer_contact_id")
    private String customerContactId;

    @Column(name = "partner_account_id")
    private String partnerAccountId;

    @Column(name = "partner_contact_id")
    private String partnerContactId;
    

    public String getCustomerContactId() {
		return customerContactId;
	}

	public void setCustomerContactId(String customerContactId) {
		this.customerContactId = customerContactId;
	}

	public String getOpportunitySrcId() {
        return opportunitySrcId;
    }

    public void setOpportunitySrcId(String opportunitySrcId) {
        this.opportunitySrcId = opportunitySrcId;
    }

    public String getAkamOpportunityId() {
        return akamOpportunityId;
    }

    public void setAkamOpportunityId(String akamOpportunityId) {
        this.akamOpportunityId = akamOpportunityId;
    }

    public String getOpportunityName() {
        return opportunityName;
    }

    public void setOpportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getOwnerContactId() {
        return ownerContactId;
    }

    public void setOwnerContactId(String ownerContactId) {
        this.ownerContactId = ownerContactId;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getCompetitor() {
        return competitor;
    }

    public void setCompetitor(String competitor) {
        this.competitor = competitor;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getDealType() {
        return dealType;
    }

    public void setDealType(String dealType) {
        this.dealType = dealType;
    }

    public String getOwnerUserId() {
        return ownerUserId;
    }

    public void setOwnerUserId(String ownerUserId) {
        this.ownerUserId = ownerUserId;
    }

    public String getAccountSrcId() {
        return accountSrcId;
    }

    public void setAccountSrcId(String accountSrcId) {
        this.accountSrcId = accountSrcId;
    }

    public String getOwnerSrcId() {
        return ownerSrcId;
    }

    public void setOwnerSrcId(String ownerSrcId) {
        this.ownerSrcId = ownerSrcId;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountCountry() {
        return accountCountry;
    }

    public void setAccountCountry(String accountCountry) {
        this.accountCountry = accountCountry;
    }

    public String getPartnerAccountId() {
        return partnerAccountId;
    }

    public void setPartnerAccountId(String partnerAccountId) {
        this.partnerAccountId = partnerAccountId;
    }

    public String getPartnerContactId() {
        return partnerContactId;
    }

    public void setPartnerContactId(String partnerContactId) {
        this.partnerContactId = partnerContactId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OpportunityEntity that = (OpportunityEntity) o;

        if (akamOpportunityId != null ? !akamOpportunityId.equals(that.akamOpportunityId) : that.akamOpportunityId != null)
            return false;
        return opportunityName != null ? opportunityName.equals(that.opportunityName) : that.opportunityName == null;
    }

    @Override
    public int hashCode() {
        int result = akamOpportunityId != null ? akamOpportunityId.hashCode() : 0;
        result = 31 * result + (opportunityName != null ? opportunityName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OpportunityEntity{" +
                "akamOpportunityId='" + akamOpportunityId + '\'' +
                ", opportunitySrcId='" + opportunitySrcId + '\'' +
                ", opportunityName='" + opportunityName + '\'' +
                ", createdDate=" + createdDate +
                ", accountId='" + accountId + '\'' +
                ", accountName='" + accountName + '\'' +
                ", accountSrcId='" + accountSrcId + '\'' +
                ", ownerContactId='" + ownerContactId + '\'' +
                ", ownerUserId='" + ownerUserId + '\'' +
                ", ownerSrcId='" + ownerSrcId + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", bundleId='" + bundleId + '\'' +
                ", stage='" + stage + '\'' +
                ", currency='" + currency + '\'' +
                ", competitor='" + competitor + '\'' +
                ", dealType='" + dealType + '\'' +
                ", accountType='" + accountType + '\'' +
                ", accountCountry='" + accountCountry + '\'' +
                '}';
    }
}
