package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.WebDeliveryAggregationMetric;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface WebDeliveryAggregationMetricRepository extends CrudRepository<WebDeliveryAggregationMetric, Integer> {

    WebDeliveryAggregationMetric findByTestSetUpInfoId(String testSetUpInfoId);

    void deleteByTestSetUpInfoIdIn(List<String> testSetUpInfoId);
}
