package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.akamai.buyakamai.constants.EmailState;

@Entity
@Table(name = "EMAIL")
public class EmailEntity {

	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "email_seq")
   	@SequenceGenerator(name = "email_seq", sequenceName = "EMAIL_SEQ", initialValue = 1 ,allocationSize = 1)
	private Integer id;
	
	@Column(name = "MESSAGE_ID")
	private String messageId;

	@Column(name = "SUBJECT")
	private String subject;

	@Column(name = "BODY")
	private String body;

	@Column(name = "STATE")
	@Enumerated(EnumType.STRING)
	private EmailState state;

	@Column(name = "SENT_BY_USER_ID")
	private String sentByUserId;

	@Column(name = "FROM_EMAIL")
	private String from;

	@Column(name = "TO_RECIPIENTS")
	private String to;

	@Column(name = "CC_RECIPIENTS")
	private String cc;

	@Column(name = "BCC_RECIPIENTS")
	private String bcc;

	@Column(name = "ATTACHMENT")
	private byte[] attachment;

	@Column(name = "SENT_TIME")
	private Date sentTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public EmailState getState() {
		return state;
	}

	public void setState(EmailState state) {
		this.state = state;
	}

	public String getSentByUserId() {
		return sentByUserId;
	}

	public void setSentByUserId(String sentByUserId) {
		this.sentByUserId = sentByUserId;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getBcc() {
		return bcc;
	}

	public void setBcc(String bcc) {
		this.bcc = bcc;
	}

	public byte[] getAttachment() {
		return attachment;
	}

	public void setAttachment(byte[] attachment) {
		this.attachment = attachment;
	}

	public Date getSentTime() {
		return sentTime;
	}

	public void setSentTime(Date sentTime) {
		this.sentTime = sentTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmailEntity other = (EmailEntity) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EmailEntity [id=" + id + ", messageId=" + messageId + ", subject=" + subject + ", body=" + body
				+ ", state=" + state + ", sentByUserId=" + sentByUserId + ", from=" + from + ", to=" + to + ", cc=" + cc
				+ ", bcc=" + bcc + ", createdTime=" + sentTime + "]";
	}
}
