package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ERROR_MESSAGE")
public class ErrorMessageEntity {

	 @Id
	 @Column(name = "ID")
	 @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "error_msg_seq")
	 @SequenceGenerator(name = "error_msg_seq", sequenceName = "ERROR_MSG_SEQ", initialValue = 1 ,allocationSize = 1)
	 private Integer id;
	 
	 @Column(name = "ERROR_ID")
	 private Integer errorId;
	 
	 @Column(name = "MESSAGE")
	 private String message;
	 
	 @Column(name = "CREATED_TIME")
	 private Date createdTime;
		
	public Integer getId() {
		return id;
	}

	public Integer getErrorId() {
		return errorId;
	}

	public void setErrorId(Integer errorId) {
		this.errorId = errorId;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result + ((errorId == null) ? 0 : errorId.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((message == null) ? 0 : message.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ErrorMessageEntity other = (ErrorMessageEntity) obj;
		if (createdTime == null) {
			if (other.createdTime != null)
				return false;
		} else if (!createdTime.equals(other.createdTime))
			return false;
		if (errorId == null) {
			if (other.errorId != null)
				return false;
		} else if (!errorId.equals(other.errorId))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (message == null) {
			if (other.message != null)
				return false;
		} else if (!message.equals(other.message))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ErrorMessageEntity [id=" + id + ", errorId=" + errorId + ", message=" + message + ", createdTime="
				+ createdTime + "]";
	}

}
