package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.CurrencyEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface CurrencyRepository extends CrudRepository<CurrencyEntity,Integer> {

    @Query("select DISTINCT currency from CurrencyEntity where currency is not null order by currency asc")
    List<String> findDistinctCurrencyCode();
}
