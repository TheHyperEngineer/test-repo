package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.WebDeliveryHistogramMetric;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface WebDeliveryHistogramMetricRepository extends CrudRepository<WebDeliveryHistogramMetric, Integer> {

    WebDeliveryHistogramMetric findByTestSetUpInfoId(String testSetupInfoId);

    void deleteByTestSetUpInfoIdIn(List<String> testSetupInfoIdList);
}
