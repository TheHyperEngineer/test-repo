package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

@Entity
@Table(name = "ORDER_ARL_SUMMARY")
public class OrderARLSummary {

	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_arl_seq")
   	@SequenceGenerator(name = "order_arl_seq", sequenceName = "ORDER_ARL_SEQ" ,allocationSize = 1)
	private Integer id;

	@Column(name = "ORDER_ID")
	private Integer orderId;

    @Column(name = "ARL_FILE_ID")
	private Integer arlFileId;

    @Column(name = "ARL_FILE_NAME")
	private String arlFileName;

	@Column(name = "ARL_STAGING_VERSION")
	private Integer arlStagingVersion = 0;

	@Column(name = "ARL_PROD_VERSION")
	private Integer arlProdVersion = 0;

	@Column(name = "AKAMAIZED")
    @Type(type = "yes_no")
	private Boolean akamaized = false;

	@Column(name = "LAST_MODIFIED_TIME")
	private Date lastModifiedTime;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getArlFileId() {
		return arlFileId;
	}

	public void setArlFileId(Integer arlFileId) {
		this.arlFileId = arlFileId;
	}

	public String getArlFileName() {
		return arlFileName;
	}

	public void setArlFileName(String arlFileName) {
		this.arlFileName = arlFileName;
	}

	public Integer getArlStagingVersion() {
		return arlStagingVersion;
	}

	public void setArlStagingVersion(Integer arlStagingVersion) {
		this.arlStagingVersion = arlStagingVersion;
	}

	public Integer getArlProdVersion() {
		return arlProdVersion;
	}

	public void setArlProdVersion(Integer arlProdVersion) {
		this.arlProdVersion = arlProdVersion;
	}

	public Boolean isAkamaized() {
		return akamaized;
	}

	public void setAkamaized(Boolean akamaized) {
		this.akamaized = akamaized;
	}

	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderARLSummary other = (OrderARLSummary) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		return true;
	}
}
