package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;


import com.akamai.buyakamai.dataaccess.buyakamdb.model.WebDeliveryEvaluationRequest;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface WebDeliveryEvaluationRequestRepository extends CrudRepository<WebDeliveryEvaluationRequest, Integer> {

    @Query("select caseId from WebDeliveryEvaluationRequest where resumable='Y' and isPurged='N' and caseId Is NOT NULL ")
    List<String> getAllActiveIds();

    WebDeliveryEvaluationRequest findByCaseId(String caseId);

    WebDeliveryEvaluationRequest findByValueConfirmationId(Integer valueConfirmationId);

    @Query(value = "SELECT DISTINCT ID_ORDER FROM ORDER_VALUE_CONFIRMATION valueConfirmation,Web_Evaluation_Request evaluation where valueConfirmation.ID = evaluation.Value_Conf_ID and evaluation.Is_Purged='Y' ", nativeQuery = true)
    Set<Integer> getPurgedOrderIdSet();

    @Query(value = "SELECT caseId FROM  WebDeliveryEvaluationRequest  where valueConfirmationId IN (:valueConfId)")
    List<String> getCaseIdsForValueConfirmationId(@Param("valueConfId") List<Integer> valueConfId);
}
