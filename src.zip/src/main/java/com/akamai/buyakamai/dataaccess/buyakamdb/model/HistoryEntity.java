package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name = "ORDER_HISTORY")
public class HistoryEntity {

	@Id
	@Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_history_seq")
   	@SequenceGenerator(name = "order_history_seq", sequenceName = "ORDER_HISTORY_SEQ", initialValue = 1 ,allocationSize = 1)
	private Integer id;
	
	@Column(name = "ID_ORDER")
	private Integer orderId;

    @Column(name = "ID_HISTORY_DEFINITION")
	private Integer historyDefinitionId;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "EVENT_TIME")
	private Date eventTime;

	@Column(name = "CREATED_TIME")
	private Date createdTime;
	
	@Column(name = "DESCRIPTION_ARGS")
	private String descriptionArgs;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getHistoryDefinitionId() {
		return historyDefinitionId;
	}

	public void setHistoryDefinitionId(Integer historyDefinitionId) {
		this.historyDefinitionId = historyDefinitionId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getEventTime() {
		return eventTime;
	}

	public void setEventTime(Date eventTime) {
		this.eventTime = eventTime;
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(Date createdTime) {
		this.createdTime = createdTime;
	}

	public String getDescriptionArgs() {
		return descriptionArgs;
	}

	public void setDescriptionArgs(String descriptionArgs) {
		this.descriptionArgs = descriptionArgs;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HistoryEntity other = (HistoryEntity) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
