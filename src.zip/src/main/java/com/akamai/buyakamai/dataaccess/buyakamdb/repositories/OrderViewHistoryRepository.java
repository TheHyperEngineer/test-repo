package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.OrderViewHistory;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface OrderViewHistoryRepository extends CrudRepository<OrderViewHistory, Integer> {

    OrderViewHistory findByOrderIdAndUserId(Integer orderId, String userId);

    List<OrderViewHistory> findByUserId(String userId);
}
