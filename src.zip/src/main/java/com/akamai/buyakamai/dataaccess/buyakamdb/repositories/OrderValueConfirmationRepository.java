package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.OrderValueConfirmation;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface OrderValueConfirmationRepository extends CrudRepository<OrderValueConfirmation, Integer> {

    List<OrderValueConfirmation> findByOrderId(Integer orderId);

    @Query(value = "select distinct orderId from OrderValueConfirmation where bundleId in (:bundleId)")
    Set<Integer> getOrderIdForBundleId(@Param("bundleId") List<String> bundleId);

    @Query(value = "select id from OrderValueConfirmation  where orderId in (:orderIdList)")
    List<Integer> getValueConfirmationIdsForOrderId(@Param("orderIdList") List<Integer> orderIdList);
}
