package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.OpportunityEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;


@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface OpportunityRepository extends CrudRepository<OpportunityEntity, String> {

    @Query("select akamOpportunityId from OpportunityEntity ")
    Set<String> findAllOpportunityId();

    @Query(value = "select opp.AKAM_OPPORTUNITY_ID ,opp.NAME ,opp.STAGE ,opp.DEAL_TYPE , opp.ACCOUNT_ID, opp.OWNER_USER_ID, opp.CURRENCY, opp.CREATED_DATE from OPPORTUNITY opp where\n" +
            " opp.AKAM_OPPORTUNITY_ID IN (:IDS) and REGEXP_LIKE(upper(opp.NAME), upper(:name)) or REGEXP_LIKE(upper (opp.AKAM_OPPORTUNITY_ID), upper(:id))", nativeQuery = true)
    List<Object[]> findOpportunitiesCustom(@Param("IDS") Set<String> opportunityIds, @Param("id") String id, @Param("name") String name);

}
