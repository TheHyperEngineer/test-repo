package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;


import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.OrderARLSummary;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface OrderARLRepository extends CrudRepository<OrderARLSummary, Integer> {
	
	List<OrderARLSummary> findByOrderId(Integer orderId);
}
