package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import com.akamai.buyakamai.constants.AlertState;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ALERT")
public class AlertEntity {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_alert_seq")
    @SequenceGenerator(name = "order_alert_seq", sequenceName = "ORDER_ALERT_SEQ", initialValue = 1000000, allocationSize = 1)
    private Integer id;

    @Column(name = "ID_ALERT_DEFINITION")
    private Integer alertDefinitionId;

    @Column(name = "STATE")
    @Enumerated(EnumType.STRING)
    private AlertState state;

    @Column(name = "SNOOZE_DURATION")
    private Integer snoozeDuration;

    @Column(name = "SNOOZED_TIME")
    private Date snoozedTime;

    @Column(name = "CREATED_TIME")
    private Date createdTime;

    @Column(name = "LONG_DESCRIPTION_ARGS")
    private String longDescriptionArgs;

    @Column(name = "ID_ORDER")
    private Integer orderId;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAlertDefinitionId() {
        return alertDefinitionId;
    }

    public void setAlertDefinitionId(Integer alertDefinitionId) {
        this.alertDefinitionId = alertDefinitionId;
    }

    public AlertState getState() {
        return state;
    }

    public void setState(AlertState state) {
        this.state = state;
    }

    public Integer getSnoozeDuration() {
        return snoozeDuration;
    }

    public void setSnoozeDuration(Integer snoozeDuration) {
        this.snoozeDuration = snoozeDuration;
    }

    public Date getSnoozedTime() {
        return snoozedTime;
    }

    public void setSnoozedTime(Date snoozedTime) {
        this.snoozedTime = snoozedTime;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    public String getDescriptionArgs() {
        return longDescriptionArgs;
    }

    public void setDescriptionArgs(String longDescriptionArgs) {
        this.longDescriptionArgs = longDescriptionArgs;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        AlertEntity other = (AlertEntity) obj;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        return true;
    }
}
