package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Type;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertLevel;
import com.akamai.buyakamai.constants.AlertSeverity;

@Entity
@Table(name = "ALERT_DEFINITION")
public class AlertDefinition {

	@Id
	@Column(name = "ID")
	private Integer id;
	
	@Column(name = "NAME")
	@Enumerated(EnumType.STRING)
	private AlertDefName name;

	@Column(name = "SEVERITY")
	@Enumerated(EnumType.STRING)
	private AlertSeverity severity;

	@Column(name = "ALERT_LEVEL")
	@Enumerated(EnumType.STRING)
	private AlertLevel level;

	@Column(name = "SHORT_DESCRIPTION")
	private String shortDescription;

	@Column(name = "LONG_DESCRIPTION")
	private String longDescription;

	@Column(name = "ACTIONS")
	private String actions;

	@Column(name = "IS_SNOOZABLE")
    @Type(type = "yes_no")
	private Boolean snoozable;

	@Column(name = "DEFAULT_SNOOZE_DURATION")
	private Integer defaultSnoozeDuration;
	
	@Column(name = "TYPE")
	private String type;

	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public AlertDefName getName() {
		return name;
	}

	public void setName(AlertDefName name) {
		this.name = name;
	}

	public AlertSeverity getSeverity() {
		return severity;
	}

	public void setSeverity(AlertSeverity severity) {
		this.severity = severity;
	}

	public AlertLevel getLevel() {
		return level;
	}

	public void setLevel(AlertLevel type) {
		this.level = type;
	}

	public String getShortDescription() {
		return shortDescription;
	}

	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}

	public String getLongDescription() {
		return longDescription;
	}

	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}

	public String getActions() {
		return actions;
	}

	public void setActions(String actions) {
		this.actions = actions;
	}

	public Boolean getSnoozable() {
		return snoozable;
	}

	public void setSnoozable(Boolean snoozable) {
		this.snoozable = snoozable;
	}

	public Integer getDefaultSnoozeDuration() {
		return defaultSnoozeDuration;
	}

	public void setDefaultSnoozeDuration(Integer defaultSnoozeDuration) {
		this.defaultSnoozeDuration = defaultSnoozeDuration;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AlertDefinition other = (AlertDefinition) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
}
