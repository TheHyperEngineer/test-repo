package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Entity
@IdClass(EventDataId.class)
@Table(name = "ORDER_EVENT_DATA")
public class OrderEventDataEntity {
	@Id
	@Column(name = "event_id")
	private Integer eventId;
	@Id
	@Column(name = "key")
	private String key;
	@Column(name = "value")
	private String value;
	
	public OrderEventDataEntity() {
	}

	public OrderEventDataEntity(Integer eventId, String key, String value) {
		this.eventId = eventId;
		this.key = key;
		this.value = value;
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
		result = prime * result + ((key == null) ? 0 : key.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderEventDataEntity other = (OrderEventDataEntity) obj;
		if (eventId == null) {
			if (other.eventId != null)
				return false;
		} else if (!eventId.equals(other.eventId))
			return false;
		if (key == null) {
			if (other.key != null)
				return false;
		} else if (!key.equals(other.key))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderEventDataEntity [eventId=" + eventId + ", key=" + key + ", value=" + value + "]";
	}
	
}