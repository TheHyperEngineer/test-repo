package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Date;

@Entity
@Table(name = "HAPPINESS_STAGE")
public class HappinessStageEntity {

    @Id
    @Column(name = "order_id")
    private Integer orderId;

    @Column(name = "last_occurred_event")
    private String lastOccuredEvent;

    @Column(name = "event_occurred_time")
    private Date eventOccuredTime;

    @Column(name = "last_reset_time")
    private Date lastResetTime;

    @Column(name = "happiness_index")
    private Integer happinessIndex;

    @Column(name = "processed_events")
    private String processedEvents;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getLastOccuredEvent() {
        return lastOccuredEvent;
    }

    public void setLastOccuredEvent(String lastOccuredEvent) {
        this.lastOccuredEvent = lastOccuredEvent;
    }

    public Date getEventOccuredTime() {
        return eventOccuredTime;
    }

    public void setEventOccuredTime(Date eventOccuredTime) {
        this.eventOccuredTime = eventOccuredTime;
    }

    public Date getLastResetTime() {
        return lastResetTime;
    }

    public void setLastResetTime(Date lastResetTime) {
        this.lastResetTime = lastResetTime;
    }

    public Integer getHappinessIndex() {
        return happinessIndex;
    }

    public void setHappinessIndex(Integer happinessIndex) {
        this.happinessIndex = happinessIndex;
    }

    public String getProcessedEvents() {
        return processedEvents;
    }

    public void setProcessedEvents(String processedEvents) {
        this.processedEvents = processedEvents;
    }

    @Override
    public String toString() {
        return "HappinessStageEntity{" +
                "orderId=" + orderId +
                ", lastOccuredEvent='" + lastOccuredEvent + '\'' +
                ", eventOccuredTime=" + eventOccuredTime +
                ", lastResetTime=" + lastResetTime +
                ", happinessIndex=" + happinessIndex +
                ", processedEvents='" + processedEvents + '\'' +
                '}';
    }
}
