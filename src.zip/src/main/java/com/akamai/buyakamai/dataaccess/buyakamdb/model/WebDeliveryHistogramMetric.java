package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.*;
import java.sql.Clob;
import java.util.Date;

@Entity
@Table(name = "Webdel_Histogram")
public class WebDeliveryHistogramMetric {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "histo_report_seq")
    @SequenceGenerator(name = "histo_report_seq", sequenceName = "WB_HISTOGRAM_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "Test_Setup_Info_Id")
    private String testSetUpInfoId;

    @Column(name = "Report")
    @Lob
    private String report;

    @Column(name = "Updated_Time")
    private Date updatedTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTestSetUpInfoId() {
        return testSetUpInfoId;
    }

    public void setTestSetUpInfoId(String testSetUpInfoId) {
        this.testSetUpInfoId = testSetUpInfoId;
    }

    public String getReport() {
        return report;
    }

    public void setReport(String report) {
        this.report = report;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryHistogramMetric that = (WebDeliveryHistogramMetric) o;

        return testSetUpInfoId != null ? testSetUpInfoId.equals(that.testSetUpInfoId) : that.testSetUpInfoId == null;
    }

    @Override
    public int hashCode() {
        return testSetUpInfoId != null ? testSetUpInfoId.hashCode() : 0;
    }

}
