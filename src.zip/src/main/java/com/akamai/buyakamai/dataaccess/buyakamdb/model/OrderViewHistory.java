package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "ORDER_VIEW_HISTORY")
@Data
public class OrderViewHistory {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_view_history_seq")
    @SequenceGenerator(name = "order_view_history_seq", sequenceName = "ORDER_VIEW_HISTORY_SEQ", allocationSize = 1)
    private Integer id;

    @Column(name = "ID_ORDER")
    private Integer orderId;

    @Column(name = "USER_ID")
    private String userId;

    @Column(name = "UPDATED_TIME")
    private Date updatedTime;

}
