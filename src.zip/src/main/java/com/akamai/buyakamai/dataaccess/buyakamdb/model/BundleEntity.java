package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "BUNDLE")
public class BundleEntity {
	@Id
	@Column(name = "id")
	private int id;
	
	@Column(name = "BUNDLE_ID")
	private String bundleId;

	@Column(name = "BUNDLE_NAME")
	private String bundleName;

	@Column(name = "Category")
	private String category;

	@Column(name = "EVENT_PROCESSOR_CATEGORY")
	private String eventProcessorCategory;

	public String getEventProcessorCategory() {
		return eventProcessorCategory;
	}

	public void setEventProcessorCategory(String eventProcessorCategory) {
		this.eventProcessorCategory = eventProcessorCategory;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getBundleName() {
		return bundleName;
	}

	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		BundleEntity that = (BundleEntity) o;

		return bundleId != null ? bundleId.equals(that.bundleId) : that.bundleId == null;
	}

	@Override
	public int hashCode() {
		return bundleId != null ? bundleId.hashCode() : 0;
	}

	@Override
	public String toString() {
		return "BundleEntity{" +
				"id=" + id +
				", bundleId='" + bundleId + '\'' +
				", bundleName='" + bundleName + '\'' +
				", category='" + category + '\'' +
				", eventProcessorCategory='" + eventProcessorCategory + '\'' +
				'}';
	}
}
