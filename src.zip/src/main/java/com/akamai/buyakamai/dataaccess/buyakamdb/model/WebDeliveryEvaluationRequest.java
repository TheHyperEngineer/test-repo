package com.akamai.buyakamai.dataaccess.buyakamdb.model;


import javax.persistence.*;
import java.util.Date;


@Entity
@Table(name = "WEB_Evaluation_Request")
public class WebDeliveryEvaluationRequest {

    @Id
    @Column(name = "ID")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "evaluation_req_seq")
    @SequenceGenerator(name = "evaluation_req_seq", sequenceName = "WB_REQ_MAP_SEQ" ,allocationSize = 1)
    private Integer id;

    @Column(name = "Case_Id")
    private String caseId;

    @Column(name = "Host")
    private String host;

    @Column(name = "TestURL")
    private String testUrl;

    @Column(name = "Agents")
    private String agents;

    @Column(name = "Specific_Region")
    private String specificRegion;

    @Column(name = "Platform")
    private String platform;

    @Column(name = "Success_Criteria")
    private String successCriteria;

    @Column(name = "Resumable")
    private Character resumable;

    @Column(name = "Updated_Time")
    private Date updatedTime;

    @Column(name = "Is_Purged")
    private Character isPurged;

    @Column(name = "Value_Conf_ID")
    private Integer valueConfirmationId;

    @Column(name = "Pivotal_Data_Time")
    private Date pivotalDataTime;

    @Column(name = "state")
    private String  currentCompletedState;

    @Column(name = "COUNTRIES")
    private String countries;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getValueConfirmationId() {
        return valueConfirmationId;
    }

    public void setValueConfirmationId(Integer valueConfirmationId) {
        this.valueConfirmationId = valueConfirmationId;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getTestUrl() {
        return testUrl;
    }

    public void setTestUrl(String testUrl) {
        this.testUrl = testUrl;
    }

    public String getAgents() {
        return agents;
    }

    public void setAgents(String agents) {
        this.agents = agents;
    }

    public String getSpecificRegion() {
        return specificRegion;
    }

    public void setSpecificRegion(String specificRegion) {
        this.specificRegion = specificRegion;
    }

    public String getPlatform() {
        return platform;
    }

    public void setPlatform(String platform) {
        this.platform = platform;
    }

    public String getSuccessCriteria() {
        return successCriteria;
    }

    public void setSuccessCriteria(String successCriteria) {
        this.successCriteria = successCriteria;
    }

    public Character getResumable() {
        return resumable;
    }

    public void setResumable(Character resumable) {
        this.resumable = resumable;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Character getIsPurged() {
        return isPurged;
    }

    public void setIsPurged(Character isPurged) {
        this.isPurged = isPurged;
    }

    public Date getPivotalDataTime() {
        return pivotalDataTime;
    }

    public void setPivotalDataTime(Date pivotalDataTime) {
        this.pivotalDataTime = pivotalDataTime;
    }

    public String getCurrentCompletedState() {
        return currentCompletedState;
    }

    public void setCurrentCompletedState(String currentCompletedState) {
        this.currentCompletedState = currentCompletedState;
    }

    public String getCountries() {
        return countries;
    }

    public void setCountries(String countries) {
        this.countries = countries;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryEvaluationRequest that = (WebDeliveryEvaluationRequest) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (caseId != null ? !caseId.equals(that.caseId) : that.caseId != null) return false;
        if (host != null ? !host.equals(that.host) : that.host != null) return false;
        if (testUrl != null ? !testUrl.equals(that.testUrl) : that.testUrl != null) return false;
        if (agents != null ? !agents.equals(that.agents) : that.agents != null) return false;
        if (specificRegion != null ? !specificRegion.equals(that.specificRegion) : that.specificRegion != null)
            return false;
        if (platform != null ? !platform.equals(that.platform) : that.platform != null) return false;
        if (successCriteria != null ? !successCriteria.equals(that.successCriteria) : that.successCriteria != null)
            return false;
        if (resumable != null ? !resumable.equals(that.resumable) : that.resumable != null) return false;
        if (updatedTime != null ? !updatedTime.equals(that.updatedTime) : that.updatedTime != null) return false;
        if (isPurged != null ? !isPurged.equals(that.isPurged) : that.isPurged != null) return false;
        if (valueConfirmationId != null ? !valueConfirmationId.equals(that.valueConfirmationId) : that.valueConfirmationId != null)
            return false;
        return pivotalDataTime != null ? pivotalDataTime.equals(that.pivotalDataTime) : that.pivotalDataTime == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (caseId != null ? caseId.hashCode() : 0);
        result = 31 * result + (host != null ? host.hashCode() : 0);
        result = 31 * result + (testUrl != null ? testUrl.hashCode() : 0);
        result = 31 * result + (agents != null ? agents.hashCode() : 0);
        result = 31 * result + (specificRegion != null ? specificRegion.hashCode() : 0);
        result = 31 * result + (platform != null ? platform.hashCode() : 0);
        result = 31 * result + (successCriteria != null ? successCriteria.hashCode() : 0);
        result = 31 * result + (resumable != null ? resumable.hashCode() : 0);
        result = 31 * result + (updatedTime != null ? updatedTime.hashCode() : 0);
        result = 31 * result + (isPurged != null ? isPurged.hashCode() : 0);
        result = 31 * result + (valueConfirmationId != null ? valueConfirmationId.hashCode() : 0);
        result = 31 * result + (pivotalDataTime != null ? pivotalDataTime.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "WebDeliveryEvaluationRequest{" +
                "id=" + id +
                ", caseId='" + caseId + '\'' +
                ", host='" + host + '\'' +
                ", testUrl='" + testUrl + '\'' +
                ", agents='" + agents + '\'' +
                ", specificRegion='" + specificRegion + '\'' +
                ", platform='" + platform + '\'' +
                ", successCriteria='" + successCriteria + '\'' +
                ", resumable=" + resumable +
                ", updatedTime=" + updatedTime +
                ", isPurged=" + isPurged +
                ", valueConfirmationId=" + valueConfirmationId +
                ", pivotalDataTime=" + pivotalDataTime +
                '}';
    }
}
