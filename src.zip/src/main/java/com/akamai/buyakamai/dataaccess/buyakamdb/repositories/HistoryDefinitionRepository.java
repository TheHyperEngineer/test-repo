package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.HistoryDefinition;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface HistoryDefinitionRepository extends CrudRepository<HistoryDefinition, Integer> {

}
