package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import java.util.List;
import java.util.Set;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.ProductBEDEntity;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface ProductBEDRepository extends CrudRepository<ProductBEDEntity, Integer>{
	
	List<ProductBEDEntity> findByProductIdIn(Set<String> productId);

}
