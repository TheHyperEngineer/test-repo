package com.akamai.buyakamai.dataaccess.buyakamdb.model;

import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.akamai.buyakamai.constants.OrderEventAction;

@Entity
@Table(name = "ORDER_EVENT")
public class OrderEventEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "order_event_seq")
	@SequenceGenerator(name = "order_event_seq", sequenceName = "ORDER_EVENT_SEQ", initialValue = 1, allocationSize = 1)
	@Column(name = "event_id")
	private Integer eventId;

	@Column(name = "order_id")
	private Integer orderId;
	
	@Column(name = "timestamp")
	private Date timestamp;

	@Column(name = "event_type")
	private String eventType;

	@Column(name = "event_action")
	@Enumerated(EnumType.STRING)
	private OrderEventAction eventAction;

	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "eventId")
	private List<OrderEventDataEntity> eventData;

	public OrderEventEntity() {
	}

	public Integer getEventId() {
		return eventId;
	}

	public void setEventId(Integer eventId) {
		this.eventId = eventId;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public String getEventType() {
		return eventType;
	}

	public void setEventType(String eventType) {
		this.eventType = eventType;
	}

	public OrderEventAction getEventAction() {
		return eventAction;
	}

	public void setEventAction(OrderEventAction eventAction) {
		this.eventAction = eventAction;
	}

	public List<OrderEventDataEntity> getEventData() {
		return eventData;
	}

	public void setEventData(List<OrderEventDataEntity> eventData) {
		this.eventData = eventData;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((eventId == null) ? 0 : eventId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderEventEntity other = (OrderEventEntity) obj;
		if (eventId == null) {
			if (other.eventId != null)
				return false;
		} 
		return true;
	}

	@Override
	public String toString() {
		return "OrderEventEntity [eventId=" + eventId + ", orderId=" + orderId + ", timestamp=" + timestamp + ", eventType="
				+ eventType + ", eventAction=" + eventAction + "]";
	}
}