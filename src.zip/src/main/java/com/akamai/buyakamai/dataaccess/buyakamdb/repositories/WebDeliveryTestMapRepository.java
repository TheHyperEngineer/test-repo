package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.WebDeliveryTestMap;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface WebDeliveryTestMapRepository extends CrudRepository<WebDeliveryTestMap, Integer> {

    WebDeliveryTestMap findByTestSetupInfoId(String testSetUpInfoId);

    void deleteByTestSetupInfoIdIn(List<String> testSetUpInfoId);

    @Query("select testSetupInfoId from WebDeliveryTestMap where caseId= :caseId")
    List<String> getAllTestSetUpForCaseId(@Param("caseId") String caseId);
}
