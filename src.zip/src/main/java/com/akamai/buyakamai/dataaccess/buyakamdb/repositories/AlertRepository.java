package com.akamai.buyakamai.dataaccess.buyakamdb.repositories;

import java.util.List;

import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional(propagation = Propagation.MANDATORY)
public interface AlertRepository extends org.springframework.data.repository.CrudRepository<AlertEntity, Integer> {

    List<AlertEntity> findByOrderId(Integer orderId);

    List<AlertEntity> findByStateInAndOrderIdIn(List<AlertState> state, List<Integer> orderId);

    @Query(value = "SELECT ID_ORDER, LISTAGG(ad.NAME, ',') WITHIN GROUP (ORDER BY CREATED_TIME desc) states FROM ALERT a,ALERT_DEFINITION ad where a.STATE in (:states) and a.ID_ALERT_DEFINITION = ad.id GROUP BY ID_ORDER", nativeQuery = true)
    List<Object[]> getAlertsByOrderGroup(@Param("states") List<String> states);
}