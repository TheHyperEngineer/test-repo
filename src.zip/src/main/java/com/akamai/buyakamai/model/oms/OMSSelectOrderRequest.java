package com.akamai.buyakamai.model.oms;

import com.akamai.buyakamai.constants.enums.OMSServiceType;

import java.util.List;

public class OMSSelectOrderRequest {

	private List<String> opportunityIds;
	private String serviceType;
	private List<String> orderStatus;
	private String salesRepContactId;
	private List<String> attributes;
	
	public OMSSelectOrderRequest(List<String> opportunities, OMSServiceType serviceType, List<String> orderStatus, String salesRepContactId) {
		this.opportunityIds = opportunities;
		this.serviceType=serviceType.name();
		this.orderStatus=orderStatus;
		this.salesRepContactId=salesRepContactId;
	}

	public OMSSelectOrderRequest() {
	}

	public List<String> getOpportunityIds() {
		return opportunityIds;
	}
	
	public String getServiceType() {
		return serviceType;
	}
	public List<String> getOrderStatus() {
		return orderStatus;
	}
	
	public String getSalesRepContactId() {
		return salesRepContactId;
	}

	public List<String> getAttributes() {
		return attributes;
	}

	public void setAttributes(List<String> attributes) {
		this.attributes = attributes;
	}

	public void setOpportunityIds(List<String> opportunityIds) {
		this.opportunityIds = opportunityIds;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public void setOrderStatus(List<String> orderStatus) {
		this.orderStatus = orderStatus;
	}

	public void setSalesRepContactId(String salesRepContactId) {
		this.salesRepContactId = salesRepContactId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((opportunityIds == null) ? 0 : opportunityIds.hashCode());
		result = prime * result + ((orderStatus == null) ? 0 : orderStatus.hashCode());
		result = prime * result + ((salesRepContactId == null) ? 0 : salesRepContactId.hashCode());
		result = prime * result + ((serviceType == null) ? 0 : serviceType.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OMSSelectOrderRequest other = (OMSSelectOrderRequest) obj;
		if (opportunityIds == null) {
			if (other.opportunityIds != null)
				return false;
		} else if (!opportunityIds.equals(other.opportunityIds))
			return false;
		if (orderStatus == null) {
			if (other.orderStatus != null)
				return false;
		} else if (!orderStatus.equals(other.orderStatus))
			return false;
		if (salesRepContactId == null) {
			if (other.salesRepContactId != null)
				return false;
		} else if (!salesRepContactId.equals(other.salesRepContactId))
			return false;
		if (serviceType == null) {
			if (other.serviceType != null)
				return false;
		} else if (!serviceType.equals(other.serviceType))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OMSSelectOrderRequest [opportunityIds=" + opportunityIds + ", serviceType=" + serviceType
				+ ", orderStatus=" + orderStatus + ", salesRepContactId=" + salesRepContactId + "]";
	}
}
