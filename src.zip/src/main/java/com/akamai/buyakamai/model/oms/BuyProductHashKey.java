package com.akamai.buyakamai.model.oms;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;

@Data
@Slf4j
public class BuyProductHashKey {

    private String marketingProdId;
    private String marketingProdName;
    private String parentProdId;
    private String baseMktId;
    private Map<String, String> attributes;
    private String productMasterIdToConsider;
}
