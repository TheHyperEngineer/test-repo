package com.akamai.buyakamai.model.quote.approval;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class Approval {
    private String uom;
    private String fieldName;
    private String fieldValue;
    private String approvalType;
    private String reason;
    private Integer sequence;
}
