package com.akamai.buyakamai.model.productmaster;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class TierInfoDTO {
	private Long tierStart;
	private Long tierEnd;
	private PriceInfoDTO price;
	private PriceInfoDTO overagePrice;
	public Long getTierStart() {
		return tierStart;
	}
	public void setTierStart(Long tierStart) {
		this.tierStart = tierStart;
	}
	public Long getTierEnd() {
		return tierEnd;
	}
	public void setTierEnd(Long tierEnd) {
		this.tierEnd = tierEnd;
	}
	public PriceInfoDTO getPrice() {
		return price;
	}
	public void setPrice(PriceInfoDTO price) {
		this.price = price;
	}
	public PriceInfoDTO getOveragePrice() {
		return overagePrice;
	}
	public void setOveragePrice(PriceInfoDTO overagePrice) {
		this.overagePrice = overagePrice;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((overagePrice == null) ? 0 : overagePrice.hashCode());
		result = prime * result + ((price == null) ? 0 : price.hashCode());
		result = prime * result + ((tierEnd == null) ? 0 : tierEnd.hashCode());
		result = prime * result + ((tierStart == null) ? 0 : tierStart.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TierInfoDTO other = (TierInfoDTO) obj;
		if (overagePrice == null) {
			if (other.overagePrice != null)
				return false;
		} else if (!overagePrice.equals(other.overagePrice))
			return false;
		if (price == null) {
			if (other.price != null)
				return false;
		} else if (!price.equals(other.price))
			return false;
		if (tierEnd == null) {
			if (other.tierEnd != null)
				return false;
		} else if (!tierEnd.equals(other.tierEnd))
			return false;
		if (tierStart == null) {
			if (other.tierStart != null)
				return false;
		} else if (!tierStart.equals(other.tierStart))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TierInfoDTO [tierStart=" + tierStart + ", tierEnd=" + tierEnd + ", price=" + price + ", overagePrice="
				+ overagePrice + "]";
	}
	
}
