package com.akamai.buyakamai.model.quote;

import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BusinessTermArgument {

    private String argumentName;
    private String inputType;
    private String defaultValue;
    private String minValue;
    private String maxValue;
    private String value;

}
