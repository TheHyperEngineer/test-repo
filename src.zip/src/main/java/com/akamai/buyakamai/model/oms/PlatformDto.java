package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class PlatformDto {

    private BigDecimal platformFee;
    private String billingFrequency;
    private String usageMethod;
    private String uom;
}
