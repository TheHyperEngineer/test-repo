package com.akamai.buyakamai.model.oms;

import java.util.List;
import java.util.Map;

import org.springframework.hateoas.Link;
import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VersionResponse extends ResourceSupport {
	private Integer versionId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer draftId;

	@JsonProperty("isLatest")
	private boolean latest;

	@JsonProperty("isDraft")
	private boolean draft;

	private String status;

	private String createdBy;

	private String userFullName;

	private String createdTime;

	private List<QuoteEvent> events;
	
	@JsonProperty("_links")
	public void setLinks(final Map<String, Link> links) {
		links.forEach((label, link) -> add(link.withRel(label)));
	}

	public Integer getVersionId() {
		return versionId;
	}

	public void setVersionId(Integer versionId) {
		this.versionId = versionId;
	}

	public Integer getDraftId() {
		return draftId;
	}

	public void setDraftId(Integer draftId) {
		this.draftId = draftId;
	}

	@JsonProperty("isLatest")
	public boolean isLatest() {
		return latest;
	}

	@JsonProperty("isLatest")
	public void setLatest(boolean latest) {
		this.latest = latest;
	}

	@JsonProperty("isDraft")
	public boolean isDraft() {
		return draft;
	}

	@JsonProperty("isDraft")
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	public List<QuoteEvent> getEvents() {
		return events;
	}

	public void setEvents(List<QuoteEvent> events) {
		this.events = events;
	}

	public String getUserFullName() {
		return userFullName;
	}

	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((createdTime == null) ? 0 : createdTime.hashCode());
		result = prime * result + (draft ? 1231 : 1237);
		result = prime * result + ((draftId == null) ? 0 : draftId.hashCode());
		result = prime * result + ((events == null) ? 0 : events.hashCode());
		result = prime * result + (latest ? 1231 : 1237);
		result = prime * result + ((userFullName == null) ? 0 : userFullName.hashCode());
		result = prime * result + ((versionId == null) ? 0 : versionId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		VersionResponse other = (VersionResponse) obj;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (createdTime == null) {
			if (other.createdTime != null)
				return false;
		} else if (!createdTime.equals(other.createdTime))
			return false;
		if (draft != other.draft)
			return false;
		if (draftId == null) {
			if (other.draftId != null)
				return false;
		} else if (!draftId.equals(other.draftId))
			return false;
		if (events == null) {
			if (other.events != null)
				return false;
		} else if (!events.equals(other.events))
			return false;
		if (latest != other.latest)
			return false;
		if (userFullName == null) {
			if (other.userFullName != null)
				return false;
		} else if (!userFullName.equals(other.userFullName))
			return false;
		if (versionId == null) {
			if (other.versionId != null)
				return false;
		} else if (!versionId.equals(other.versionId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "VersionResponse [versionId=" + versionId + ", draftId=" + draftId + ", latest=" + latest + ", draft="
		        + draft + ", status=" + status + ", createdBy=" + createdBy + ", userFullName=" + userFullName
		        + ", createdTime=" + createdTime + ", events=" + events + "]";
	}
}