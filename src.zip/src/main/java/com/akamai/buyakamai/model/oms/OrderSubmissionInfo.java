package com.akamai.buyakamai.model.oms;

import lombok.Data;

import java.util.List;

@Data
public class OrderSubmissionInfo {
    private List<CustomerContactInfo> customerContact;
    private PreviousConfigurationInfo previousConfiguration;

}
