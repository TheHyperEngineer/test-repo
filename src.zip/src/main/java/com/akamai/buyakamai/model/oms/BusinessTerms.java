package com.akamai.buyakamai.model.oms;

import java.util.List;

import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessTerms {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String name;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String id;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String tooltipIcon;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<BusinessTermResponse> includedBusinessTerms;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<BusinessTermArgument> arguments;
	
}
