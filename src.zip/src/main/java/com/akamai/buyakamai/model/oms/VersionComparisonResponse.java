package com.akamai.buyakamai.model.oms;

import lombok.Data;

import java.util.HashMap;
import java.util.List;

@Data
public class VersionComparisonResponse {

    private HashMap<BuyProductHashKey, BuyProduct> requestDtoHash;
    private HashMap<BuyProductHashKey, BuyProduct> approvedVersionHash;
    private List<String> listOfProductsRemoved;
    private boolean structurallySame;

    public VersionComparisonResponse() {
    }

    public VersionComparisonResponse(HashMap<BuyProductHashKey, BuyProduct> requestDtoHash,
                                     HashMap<BuyProductHashKey, BuyProduct> approvedVersionHash,
                                     List<String> listOfProductsRemoved, boolean structurallySame) {
        this.requestDtoHash = requestDtoHash;
        this.approvedVersionHash = approvedVersionHash;
        this.listOfProductsRemoved = listOfProductsRemoved;
        this.structurallySame = structurallySame;
    }
}
