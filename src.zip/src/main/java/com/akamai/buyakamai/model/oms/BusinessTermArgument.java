package com.akamai.buyakamai.model.oms;

import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessTermArgument {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String argumentName;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String inputType;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String defaultValue;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String minValue;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String maxVavlue;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String value;

}
