package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuoteEvent {

    private String role;
    private String action;
    private String createdBy;
    private String createdTime;
    private String note;
    private String userFullName;

}
