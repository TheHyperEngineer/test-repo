package com.akamai.buyakamai.model.productmaster;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
public class OptionDTO {
	private String optionId;
	private String optionName;
	private boolean mandatory;
	@JsonInclude(Include.NON_NULL)
	private String parentId;
	private List<ListItem> listItems;
	private String selectionCriteria;
	private String category;
	private String businessUnit;
	private String originalMarketingProductId;
	@JsonInclude(Include.NON_NULL)
	private Boolean usageBillingModelApplicable;
	private String shortDescription;
	private String longDescription;
	@JsonInclude(Include.NON_NULL)
	private Boolean useBaseProductBillingModel;
	
	public String getOptionId() {
		return optionId;
	}
	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}
	public String getOptionName() {
		return optionName;
	}
	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}
	public boolean isMandatory() {
		return mandatory;
	}
	public void setMandatory(boolean mandatory) {
		this.mandatory = mandatory;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public List<ListItem> getListItems() {
		return listItems;
	}
	public void setListItems(List<ListItem> listItems) {
		this.listItems = listItems;
	}
	
	public String getSelectionCriteria() {
		return selectionCriteria;
	}
	public void setSelectionCriteria(String selectionCriteria) {
		this.selectionCriteria = selectionCriteria;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	public String getOriginalMarketingProductId() {
		return originalMarketingProductId;
	}
	public void setOriginalMarketingProductId(String originalMarketingProductId) {
		this.originalMarketingProductId = originalMarketingProductId;
	}
	
	public Boolean getUsageBillingModelApplicable() {
		return usageBillingModelApplicable;
	}
	public void setUsageBillingModelApplicable(Boolean usageBillingModelApplicable) {
		this.usageBillingModelApplicable = usageBillingModelApplicable;
	}
	
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	public Boolean getUseBaseProductBillingModel() {
		return useBaseProductBillingModel;
	}
	public void setUseBaseProductBillingModel(Boolean useBaseProductBillingModel) {
		this.useBaseProductBillingModel = useBaseProductBillingModel;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((businessUnit == null) ? 0 : businessUnit.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((listItems == null) ? 0 : listItems.hashCode());
		result = prime * result + ((longDescription == null) ? 0 : longDescription.hashCode());
		result = prime * result + (mandatory ? 1231 : 1237);
		result = prime * result + ((optionId == null) ? 0 : optionId.hashCode());
		result = prime * result + ((optionName == null) ? 0 : optionName.hashCode());
		result = prime * result + ((originalMarketingProductId == null) ? 0 : originalMarketingProductId.hashCode());
		result = prime * result + ((parentId == null) ? 0 : parentId.hashCode());
		result = prime * result + ((selectionCriteria == null) ? 0 : selectionCriteria.hashCode());
		result = prime * result + ((shortDescription == null) ? 0 : shortDescription.hashCode());
		result = prime * result + ((usageBillingModelApplicable == null) ? 0 : usageBillingModelApplicable.hashCode());
		result = prime * result + ((useBaseProductBillingModel == null) ? 0 : useBaseProductBillingModel.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OptionDTO other = (OptionDTO) obj;
		if (businessUnit == null) {
			if (other.businessUnit != null)
				return false;
		} else if (!businessUnit.equals(other.businessUnit))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (listItems == null) {
			if (other.listItems != null)
				return false;
		} else if (!listItems.equals(other.listItems))
			return false;
		if (longDescription == null) {
			if (other.longDescription != null)
				return false;
		} else if (!longDescription.equals(other.longDescription))
			return false;
		if (mandatory != other.mandatory)
			return false;
		if (optionId == null) {
			if (other.optionId != null)
				return false;
		} else if (!optionId.equals(other.optionId))
			return false;
		if (optionName == null) {
			if (other.optionName != null)
				return false;
		} else if (!optionName.equals(other.optionName))
			return false;
		if (originalMarketingProductId == null) {
			if (other.originalMarketingProductId != null)
				return false;
		} else if (!originalMarketingProductId.equals(other.originalMarketingProductId))
			return false;
		if (parentId == null) {
			if (other.parentId != null)
				return false;
		} else if (!parentId.equals(other.parentId))
			return false;
		if (selectionCriteria == null) {
			if (other.selectionCriteria != null)
				return false;
		} else if (!selectionCriteria.equals(other.selectionCriteria))
			return false;
		if (shortDescription == null) {
			if (other.shortDescription != null)
				return false;
		} else if (!shortDescription.equals(other.shortDescription))
			return false;
		if (usageBillingModelApplicable == null) {
			if (other.usageBillingModelApplicable != null)
				return false;
		} else if (!usageBillingModelApplicable.equals(other.usageBillingModelApplicable))
			return false;
		if (useBaseProductBillingModel == null) {
			if (other.useBaseProductBillingModel != null)
				return false;
		} else if (!useBaseProductBillingModel.equals(other.useBaseProductBillingModel))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OptionDTO [optionId=" + optionId + ", optionName=" + optionName + ", mandatory=" + mandatory
				+ ", parentId=" + parentId + ", listItems=" + listItems + ", selectionCriteria=" + selectionCriteria
				+ ", category=" + category + ", businessUnit=" + businessUnit + ", originalMarketingProductId="
				+ originalMarketingProductId + ", usageBillingModelApplicable=" + usageBillingModelApplicable
				+ ", shortDescription=" + shortDescription + ", longDescription=" + longDescription
				+ ", useBaseProductBillingModel=" + useBaseProductBillingModel + "]";
	}

}
