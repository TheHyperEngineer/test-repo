
package com.akamai.buyakamai.model.oms;

import com.akamai.buyakamai.controller.model.RevenueResponse;
import com.akamai.buyakamai.model.quote.approval.ApprovalDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class BuyOrderRequestDto extends ResourceSupport {

	private String opportunityId;

	private String accountId;

	private String currency;

	private String title;

	private String status;

	private String serviceType;

	private ContractTerms contractTerms;

	private BusinessJustificationInfo businessJustificationInfo;

	private String createdBy;

	private List<BuyProduct> products = null;

	private List<BuyProduct> miscellaneousProducts = null;

	private ParentDetails parentDetails;

	private List<QuoteEvent> events;

	private OrderSubmissionInfo orderSubmissionInfo;

	private RevenueResponse revenueInfo;

	private ApprovalDto approvals;

	private String note;
}
