package com.akamai.buyakamai.model.quote.approval;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class QuoteApproval {

    private String opportunityId;
    private String title;
    private ContractTermApproval contractTermsApproval;
    private List<Approval> businessJustificationInfoApprovals;
    private List<ProductApproval> baseProducts;
    private List<ProductApproval> miscellaneousProducts;
    private List<Approval> eventsApprovals;
    private List<Approval> genericApprovals;
}
