package com.akamai.buyakamai.model.productmaster;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
public class OptionGroupDTO {
	private String optionGroupId;
	private String functionalCategory;
	private List<OptionDTO> options;
	public String getOptionGroupId() {
		return optionGroupId;
	}
	public void setOptionGroupId(String optionGroupId) {
		this.optionGroupId = optionGroupId;
	}
	public String getFunctionalCategory() {
		return functionalCategory;
	}
	public void setFunctionalCategory(String functionalCategory) {
		this.functionalCategory = functionalCategory;
	}
	public List<OptionDTO> getOptions() {
		return options;
	}
	public void setOptions(List<OptionDTO> options) {
		this.options = options;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((functionalCategory == null) ? 0 : functionalCategory.hashCode());
		result = prime * result + ((optionGroupId == null) ? 0 : optionGroupId.hashCode());
		result = prime * result + ((options == null) ? 0 : options.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OptionGroupDTO other = (OptionGroupDTO) obj;
		if (functionalCategory == null) {
			if (other.functionalCategory != null)
				return false;
		} else if (!functionalCategory.equals(other.functionalCategory))
			return false;
		if (optionGroupId == null) {
			if (other.optionGroupId != null)
				return false;
		} else if (!optionGroupId.equals(other.optionGroupId))
			return false;
		if (options == null) {
			if (other.options != null)
				return false;
		} else if (!options.equals(other.options))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OptionGroupDTO [optionGroupId=" + optionGroupId + ", functionalCategory=" + functionalCategory
				+ ", options=" + options + "]";
	} 
	
}
