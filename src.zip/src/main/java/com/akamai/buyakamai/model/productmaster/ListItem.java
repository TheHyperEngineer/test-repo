package com.akamai.buyakamai.model.productmaster;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ListItem {
	private String listItemId;
	private String name;
	@JsonInclude(Include.NON_NULL)
	private Integer quantity;
	@JsonProperty("isImplicit")
	private boolean implicit;
	private UOMInfo uom;
	private String billingFrequency;
	private String billingModel;
	private String usageMethod;
	private String pricingMethod;
	private String chargeType;
	private List<TierInfoDTO> tiers;
	private boolean splitOnPeriodCommit;
	private Tag tag;

	public String getListItemId() {
		return listItemId;
	}

	public void setListItemId(String listItemId) {
		this.listItemId = listItemId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	public boolean isImplicit() {
		return implicit;
	}

	public void setImplicit(boolean implicit) {
		this.implicit = implicit;
	}

	public UOMInfo getUom() {
		return uom;
	}

	public void setUom(UOMInfo uom) {
		this.uom = uom;
	}

	public String getBillingFrequency() {
		return billingFrequency;
	}

	public void setBillingFrequency(String billingFrequency) {
		this.billingFrequency = billingFrequency;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public List<TierInfoDTO> getTiers() {
		return tiers;
	}

	public void setTiers(List<TierInfoDTO> tiers) {
		this.tiers = tiers;
	}

	public String getBillingModel() {
		return billingModel;
	}

	public void setBillingModel(String billingModel) {
		this.billingModel = billingModel;
	}

	public String getUsageMethod() {
		return usageMethod;
	}

	public void setUsageMethod(String usageMethod) {
		this.usageMethod = usageMethod;
	}

	public String getPricingMethod() {
		return pricingMethod;
	}

	public void setPricingMethod(String pricingMethod) {
		this.pricingMethod = pricingMethod;
	}

	
	public boolean isSplitOnPeriodCommit() {
		return splitOnPeriodCommit;
	}

	public void setSplitOnPeriodCommit(boolean splitOnUsageCommit) {
		this.splitOnPeriodCommit = splitOnUsageCommit;
	}
	
	public Tag getTag() {
		return tag;
	}

	public void setTag(Tag tag) {
		this.tag = tag;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((billingFrequency == null) ? 0 : billingFrequency.hashCode());
		result = prime * result + ((chargeType == null) ? 0 : chargeType.hashCode());
		result = prime * result + (implicit ? 1231 : 1237);
		result = prime * result + ((listItemId == null) ? 0 : listItemId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result + ((tiers == null) ? 0 : tiers.hashCode());
		result = prime * result + ((uom == null) ? 0 : uom.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ListItem other = (ListItem) obj;
		if (billingFrequency == null) {
			if (other.billingFrequency != null)
				return false;
		} else if (!billingFrequency.equals(other.billingFrequency))
			return false;
		if (chargeType == null) {
			if (other.chargeType != null)
				return false;
		} else if (!chargeType.equals(other.chargeType))
			return false;
		if (implicit != other.implicit)
			return false;
		if (listItemId == null) {
			if (other.listItemId != null)
				return false;
		} else if (!listItemId.equals(other.listItemId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (tiers == null) {
			if (other.tiers != null)
				return false;
		} else if (!tiers.equals(other.tiers))
			return false;
		if (uom == null) {
			if (other.uom != null)
				return false;
		} else if (!uom.equals(other.uom))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ListItem [listItemId=" + listItemId + ", name=" + name + ", quantity=" + quantity + ", implicit="
				+ implicit + ", uom=" + uom + ", billingFrequency=" + billingFrequency + ", billingModel="
				+ billingModel + ", usageMethod=" + usageMethod + ", pricingMethod=" + pricingMethod + ", chargeType="
				+ chargeType + ", tiers=" + tiers + ", splitOnPeriodCommit=" + splitOnPeriodCommit + ", tag=" + tag
				+ "]";
	}

}
