package com.akamai.buyakamai.model.oms;

import java.util.List;

import com.akamai.buyakamai.integration.model.productmaster.ProductFamily;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessTermBRERequest {
	
	private String serviceFlow;
	private List<ProductFamily> products;
	private List<BusinessTermResponse> businessTerms;
	
}
