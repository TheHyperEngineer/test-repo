package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderVersionHistoryResponse extends ResourceSupport{
	private Integer orderId;
	private List<VersionResponse> versions;
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public List<VersionResponse> getVersions() {
		return versions;
	}
	public void setVersions(List<VersionResponse> versions) {
		this.versions = versions;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result + ((versions == null) ? 0 : versions.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderVersionHistoryResponse other = (OrderVersionHistoryResponse) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (versions == null) {
			if (other.versions != null)
				return false;
		} else if (!versions.equals(other.versions))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OrderVersionHistoryResponse [orderId=" + orderId + ", versions=" + versions + "]";
	}
	
}
