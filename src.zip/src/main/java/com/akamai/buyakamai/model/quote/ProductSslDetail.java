package com.akamai.buyakamai.model.quote;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProductSslDetail {

    private String marketingProductId;
    private int totalCertificateCount;
    private List<SslCertificateDetail> certificates;

}
