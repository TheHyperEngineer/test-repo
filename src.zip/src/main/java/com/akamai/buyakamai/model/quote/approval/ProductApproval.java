package com.akamai.buyakamai.model.quote.approval;

import com.akamai.buyakamai.orchestrator.rule.model.BREProductModel;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@NoArgsConstructor
public class ProductApproval {

    private String productId;
    private String productName;
    private String parentProductId;
    private String baseMarketingProductId;
    private String productLevel;
    private String productMasterIdToConsider;
    private Map<String, String> attributes;
    private List<Approval> approvals;
    private List<ProductApproval> associatedProducts;
    private ProductApproval integrationProduct;

    public ProductApproval(BREProductModel breProductModel) {
        this.productId = breProductModel.getMarketingProductId();
        this.productName = breProductModel.getMarketingProductName();
        this.parentProductId = breProductModel.getParentProductId();
        this.baseMarketingProductId = breProductModel.getBaseMktProductId();
        this.productLevel = breProductModel.getProductLevel();
        this.productMasterIdToConsider = breProductModel.getProduct().getMarketingProductId();
        this.approvals = breProductModel.getApprovals();
        this.attributes = breProductModel.getAttributes();
    }
}
