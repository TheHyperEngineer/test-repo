package com.akamai.buyakamai.model.oms;

import java.util.List;

import org.springframework.hateoas.Link;

import com.akamai.buyakamai.controller.model.Note;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OMSOrder {
	@JsonProperty("orderId")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String orderId;

	@JsonProperty("draftId")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String draftId;

	@JsonProperty("draftOrderId")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String draftOrderId;

	@JsonProperty("title")
	private String title;

	@JsonProperty("accountId")
	private String accountId;

	@JsonProperty("opportunityId")
	private String opportunityId;

	@JsonProperty("status")
	private String status;

	@JsonProperty("version")
	private Integer version;

	@JsonProperty("isLatest")
	private Boolean latest;

	@JsonProperty("isDraft")
	private Boolean draft;

	@JsonProperty("lastModifiedTime")
	private String lastModifiedTime;

	private String lastModifiedBy;

	@JsonProperty("notes")
	private List<Note> notes;

	@JsonProperty("links")
	private List<Link> links;

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public String getDraftId() {
		return draftId;
	}

	public void setDraftId(String draftId) {
		this.draftId = draftId;
	}

	public String getDraftOrderId() {
		return draftOrderId;
	}

	public void setDraftOrderId(String draftOrderId) {
		this.draftOrderId = draftOrderId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Integer getVersion() {
		return version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}

	@JsonProperty("isLatest")
	public Boolean getLatest() {
		return latest;
	}

	@JsonProperty("isLatest")
	public void setLatest(Boolean latest) {
		this.latest = latest;
	}

	@JsonProperty("isDraft")
	public Boolean getDraft() {
		return draft;
	}

	@JsonProperty("isDraft")
	public void setDraft(Boolean draft) {
		this.draft = draft;
	}

	public String getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(String lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public List<Note> getNotes() {
		return notes;
	}

	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}

	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((draft == null) ? 0 : draft.hashCode());
		result = prime * result + ((draftId == null) ? 0 : draftId.hashCode());
		result = prime * result + ((draftOrderId == null) ? 0 : draftOrderId.hashCode());
		result = prime * result + ((lastModifiedBy == null) ? 0 : lastModifiedBy.hashCode());
		result = prime * result + ((lastModifiedTime == null) ? 0 : lastModifiedTime.hashCode());
		result = prime * result + ((latest == null) ? 0 : latest.hashCode());
		result = prime * result + ((links == null) ? 0 : links.hashCode());
		result = prime * result + ((notes == null) ? 0 : notes.hashCode());
		result = prime * result + ((opportunityId == null) ? 0 : opportunityId.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((title == null) ? 0 : title.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OMSOrder other = (OMSOrder) obj;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (draft == null) {
			if (other.draft != null)
				return false;
		} else if (!draft.equals(other.draft))
			return false;
		if (draftId == null) {
			if (other.draftId != null)
				return false;
		} else if (!draftId.equals(other.draftId))
			return false;
		if (draftOrderId == null) {
			if (other.draftOrderId != null)
				return false;
		} else if (!draftOrderId.equals(other.draftOrderId))
			return false;
		if (lastModifiedBy == null) {
			if (other.lastModifiedBy != null)
				return false;
		} else if (!lastModifiedBy.equals(other.lastModifiedBy))
			return false;
		if (lastModifiedTime == null) {
			if (other.lastModifiedTime != null)
				return false;
		} else if (!lastModifiedTime.equals(other.lastModifiedTime))
			return false;
		if (latest == null) {
			if (other.latest != null)
				return false;
		} else if (!latest.equals(other.latest))
			return false;
		if (links == null) {
			if (other.links != null)
				return false;
		} else if (!links.equals(other.links))
			return false;
		if (notes == null) {
			if (other.notes != null)
				return false;
		} else if (!notes.equals(other.notes))
			return false;
		if (opportunityId == null) {
			if (other.opportunityId != null)
				return false;
		} else if (!opportunityId.equals(other.opportunityId))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (title == null) {
			if (other.title != null)
				return false;
		} else if (!title.equals(other.title))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OMSOrder [orderId=" + orderId + ", draftId=" + draftId + ", draftOrderId=" + draftOrderId + ", title="
		        + title + ", accountId=" + accountId + ", opportunityId=" + opportunityId + ", status=" + status
		        + ", version=" + version + ", latest=" + latest + ", draft=" + draft + ", lastModifiedTime="
		        + lastModifiedTime + ", lastModifiedBy=" + lastModifiedBy + ", notes=" + notes + ", links=" + links
		        + "]";
	}
}
