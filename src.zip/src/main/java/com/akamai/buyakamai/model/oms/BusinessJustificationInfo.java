
package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class BusinessJustificationInfo {

    private Integer budgetPerMonth;
    private String justification;
    private List<String> competitor;

}
