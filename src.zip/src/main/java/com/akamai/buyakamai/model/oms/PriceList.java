package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PriceList {

    private String uom;
    private Long includedQuantity;
    private Long quantity;
    private BigDecimal unitPrice;
    private BigDecimal overagePrice;
    private String commitPeriod;
    private String billingFrequency;
    private String usageMethod;
    private Integer sequence;
}
