package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.hateoas.Link;

import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderVersionResponse extends BuyOrderRequestDto{
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer orderId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer draftId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer versionId;

	@JsonProperty("isLatest")
	private Boolean latest =false;

	@JsonProperty("isDraft")
	private Boolean draft =false;

	@JsonProperty("isTransactionSuccess")
	private Boolean isTransactionSuccess;

	@JsonProperty("_links")
	public void setLinks(final Map<String, Link> links) {
		links.forEach((label, link) -> add(link.withRel(label)));
	}

	private String createdTime;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getDraftId() {
		return draftId;
	}

	public void setDraftId(Integer draftId) {
		this.draftId = draftId;
	}

	public Integer getVersionId() {
		return versionId;
	}

	public void setVersionId(Integer versionId) {
		this.versionId = versionId;
	}

	@JsonProperty("isLatest")
	public boolean isLatest() {
		return latest;
	}

	@JsonProperty("isLatest")
	public void setLatest(boolean latest) {
		this.latest = latest;
	}

	@JsonProperty("isDraft")
	public boolean isDraft() {
		return draft;
	}

	@JsonProperty("isTransactionSuccess")
	public Boolean getTransactionSuccess() {
		return isTransactionSuccess;
	}

	@JsonProperty("isDraft")
	public void setDraft(boolean draft) {
		this.draft = draft;
	}

	public String getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(String createdTime) {
		this.createdTime = createdTime;
	}

	@Override
	public String toString() {
		return "OrderVersionResponse{" +
				"orderId=" + orderId +
				", draftId=" + draftId +
				", versionId=" + versionId +
				", latest=" + latest +
				", draft=" + draft +
				", createdTime='" + createdTime + '\'' +
				'}';
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		if (!super.equals(o)) return false;

		OrderVersionResponse that = (OrderVersionResponse) o;

		if (latest != that.latest) return false;
		if (draft != that.draft) return false;
		if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
		if (draftId != null ? !draftId.equals(that.draftId) : that.draftId != null) return false;
		if (versionId != null ? !versionId.equals(that.versionId) : that.versionId != null) return false;
		return createdTime != null ? createdTime.equals(that.createdTime) : that.createdTime == null;
	}

	@Override
	public int hashCode() {
		int result = super.hashCode();
		result = 31 * result + (orderId != null ? orderId.hashCode() : 0);
		result = 31 * result + (draftId != null ? draftId.hashCode() : 0);
		result = 31 * result + (versionId != null ? versionId.hashCode() : 0);
		result = 31 * result + (latest ? 1 : 0);
		result = 31 * result + (draft ? 1 : 0);
		result = 31 * result + (createdTime != null ? createdTime.hashCode() : 0);
		return result;
	}
}
