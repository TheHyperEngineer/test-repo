package com.akamai.buyakamai.model.quote;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SslCertificateDetail {

    private String certificateId;
    private String certificateName;
    private int count;
}
