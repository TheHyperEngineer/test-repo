package com.akamai.buyakamai.model.oms;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class CustomerContactInfo {

    private String contactId;

    public CustomerContactInfo(String contactId) {
        this.contactId = contactId;
    }
}


