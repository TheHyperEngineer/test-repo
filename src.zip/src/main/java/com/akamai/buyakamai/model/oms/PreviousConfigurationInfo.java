package com.akamai.buyakamai.model.oms;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class PreviousConfigurationInfo {

    private String retain;
    private List<String> contractIds;

    public PreviousConfigurationInfo(String retain, List<String> contractIds) {
        this.retain = retain;
        this.contractIds = contractIds;
    }
}
