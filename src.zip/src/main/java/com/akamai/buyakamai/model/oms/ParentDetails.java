package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ParentDetails {
    private Integer orderId;
    private Integer versionId;
}
