package com.akamai.buyakamai.model.oms;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.List;

@Data
@Slf4j
public class BuyProductStructureHashKey {
    private String billingModelId;
    private List<PriceList> priceList;
}
