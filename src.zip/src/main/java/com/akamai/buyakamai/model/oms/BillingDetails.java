package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BillingDetails {

    private String contractDuration;
    private String billingModelName;
    private String billingModelId;
    private PlatformDto platform;
    private List<PriceList> priceList = new ArrayList<>();
}
