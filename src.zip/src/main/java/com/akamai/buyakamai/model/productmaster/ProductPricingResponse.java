package com.akamai.buyakamai.model.productmaster;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown=true)
public class ProductPricingResponse {
	private String marketingProductId;
	private String marketingProductName;
	private String functionalCategory;
	private String currency;
	private String selectionCriteria;
	private List<ListItem> listItems;
	private List<OptionGroupDTO> optionGroups;
	private String businessUnit;
	@JsonProperty("isBaseProduct")
	private Boolean baseProduct;
	private String category;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean usageBillingModelApplicable;
	private String shortDescription;
	private String longDescription;
	private String pricingHelpText;
	
	public String getMarketingProductId() {
		return marketingProductId;
	}
	public void setMarketingProductId(String marketingProductId) {
		this.marketingProductId = marketingProductId;
	}
	public String getMarketingProductName() {
		return marketingProductName;
	}
	public void setMarketingProductName(String marketingProductName) {
		this.marketingProductName = marketingProductName;
	}
	public String getFunctionalCategory() {
		return functionalCategory;
	}
	public void setFunctionalCategory(String functionalCategory) {
		this.functionalCategory = functionalCategory;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSelectionCriteria() {
		return selectionCriteria;
	}
	public void setSelectionCriteria(String selectionCriteria) {
		this.selectionCriteria = selectionCriteria;
	}
	public List<ListItem> getListItems() {
		return listItems;
	}
	public void setListItems(List<ListItem> listItem) {
		this.listItems = listItem;
	}
	public List<OptionGroupDTO> getOptionGroups() {
		return optionGroups;
	}
	public void setOptionGroups(List<OptionGroupDTO> optionGroups) {
		this.optionGroups = optionGroups;
	}
	
	public String getBusinessUnit() {
		return businessUnit;
	}
	public void setBusinessUnit(String businessUnit) {
		this.businessUnit = businessUnit;
	}
	
	public Boolean isBaseProduct() {
		return baseProduct;
	}
	public void setBaseProduct(Boolean baseProduct) {
		this.baseProduct = baseProduct;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public Boolean getUsageBillingModelApplicable() {
		return usageBillingModelApplicable;
	}
	public void setUsageBillingModelApplicable(Boolean usageBillingModelApplicable) {
		this.usageBillingModelApplicable = usageBillingModelApplicable;
	}
	
	public String getShortDescription() {
		return shortDescription;
	}
	public void setShortDescription(String shortDescription) {
		this.shortDescription = shortDescription;
	}
	public String getLongDescription() {
		return longDescription;
	}
	public void setLongDescription(String longDescription) {
		this.longDescription = longDescription;
	}
	
	public String getPricingHelpText() {
		return pricingHelpText;
	}
	public void setPricingHelpText(String pricingHelpText) {
		this.pricingHelpText = pricingHelpText;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((baseProduct == null) ? 0 : baseProduct.hashCode());
		result = prime * result + ((businessUnit == null) ? 0 : businessUnit.hashCode());
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + ((functionalCategory == null) ? 0 : functionalCategory.hashCode());
		result = prime * result + ((listItems == null) ? 0 : listItems.hashCode());
		result = prime * result + ((longDescription == null) ? 0 : longDescription.hashCode());
		result = prime * result + ((marketingProductId == null) ? 0 : marketingProductId.hashCode());
		result = prime * result + ((marketingProductName == null) ? 0 : marketingProductName.hashCode());
		result = prime * result + ((optionGroups == null) ? 0 : optionGroups.hashCode());
		result = prime * result + ((pricingHelpText == null) ? 0 : pricingHelpText.hashCode());
		result = prime * result + ((selectionCriteria == null) ? 0 : selectionCriteria.hashCode());
		result = prime * result + ((shortDescription == null) ? 0 : shortDescription.hashCode());
		result = prime * result + ((usageBillingModelApplicable == null) ? 0 : usageBillingModelApplicable.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductPricingResponse other = (ProductPricingResponse) obj;
		if (baseProduct == null) {
			if (other.baseProduct != null)
				return false;
		} else if (!baseProduct.equals(other.baseProduct))
			return false;
		if (businessUnit == null) {
			if (other.businessUnit != null)
				return false;
		} else if (!businessUnit.equals(other.businessUnit))
			return false;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (functionalCategory == null) {
			if (other.functionalCategory != null)
				return false;
		} else if (!functionalCategory.equals(other.functionalCategory))
			return false;
		if (listItems == null) {
			if (other.listItems != null)
				return false;
		} else if (!listItems.equals(other.listItems))
			return false;
		if (longDescription == null) {
			if (other.longDescription != null)
				return false;
		} else if (!longDescription.equals(other.longDescription))
			return false;
		if (marketingProductId == null) {
			if (other.marketingProductId != null)
				return false;
		} else if (!marketingProductId.equals(other.marketingProductId))
			return false;
		if (marketingProductName == null) {
			if (other.marketingProductName != null)
				return false;
		} else if (!marketingProductName.equals(other.marketingProductName))
			return false;
		if (optionGroups == null) {
			if (other.optionGroups != null)
				return false;
		} else if (!optionGroups.equals(other.optionGroups))
			return false;
		if (pricingHelpText == null) {
			if (other.pricingHelpText != null)
				return false;
		} else if (!pricingHelpText.equals(other.pricingHelpText))
			return false;
		if (selectionCriteria == null) {
			if (other.selectionCriteria != null)
				return false;
		} else if (!selectionCriteria.equals(other.selectionCriteria))
			return false;
		if (shortDescription == null) {
			if (other.shortDescription != null)
				return false;
		} else if (!shortDescription.equals(other.shortDescription))
			return false;
		if (usageBillingModelApplicable == null) {
			if (other.usageBillingModelApplicable != null)
				return false;
		} else if (!usageBillingModelApplicable.equals(other.usageBillingModelApplicable))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "ProductPricingResponse [marketingProductId=" + marketingProductId + ", marketingProductName="
				+ marketingProductName + ", functionalCategory=" + functionalCategory + ", currency=" + currency
				+ ", selectionCriteria=" + selectionCriteria + ", listItems=" + listItems + ", optionGroups="
				+ optionGroups + ", businessUnit=" + businessUnit + ", baseProduct=" + baseProduct + ", category="
				+ category + ", usageBillingModelApplicable=" + usageBillingModelApplicable + ", shortDescription="
				+ shortDescription + ", longDescription=" + longDescription + ", pricingHelpText=" + pricingHelpText
				+ "]";
	}
	
}
