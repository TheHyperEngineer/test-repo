package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.hateoas.Link;

import java.util.List;
@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectOrderResponse {
	@JsonProperty("orders")
	private List<OMSOrder> orders;
	private List<Link> links;

	public List<OMSOrder> getOrders() {
		return orders;
	}

	public void setOrders(List<OMSOrder> orders) {
		this.orders = orders;
	}
	

	public List<Link> getLinks() {
		return links;
	}

	public void setLinks(List<Link> links) {
		this.links = links;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((links == null) ? 0 : links.hashCode());
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelectOrderResponse other = (SelectOrderResponse) obj;
		if (links == null) {
			if (other.links != null)
				return false;
		} else if (!links.equals(other.links))
			return false;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SelectOrderResponse [orders=" + orders + ", links=" + links + "]";
	}
	
}
