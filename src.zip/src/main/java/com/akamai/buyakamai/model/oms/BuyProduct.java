package com.akamai.buyakamai.model.oms;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;
import java.util.Map;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BuyProduct {
    private String marketingProductId;
    private String productLevel;
    private String marketingProductName;
    private BillingDetails billingDetails;
    private Map<String, String> attributes;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<BuyProduct> associatedProducts = null;
    private BuyProduct integration;

}
