package com.akamai.buyakamai.model.quote;

import java.util.List;

import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BusinessTerms {

	private String name;
	private String id;
	private String tooltipIcon;
	private List<BusinessTermArgument> arguments;
	private List<BusinessTermResponse> includedChildTerms;

}
