package com.akamai.buyakamai.model.oms;


import com.akamai.se.com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.ResourceSupport;

import java.util.Map;


@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class CreatedResourceResponse extends ResourceSupport {

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer draftId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer orderId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer versionId;

    @JsonProperty("_links")
    public void setLinks(final Map<String, Link> links) {
        links.forEach((label, link) -> add(link.withRel(label)));
    }
}
