package com.akamai.buyakamai.model.productmaster;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown=true)
public class PriceInfoDTO {
	private BigDecimal fe;
	private BigDecimal target;
	private BigDecimal srp;
	private BigDecimal list;
	
	public PriceInfoDTO() {

	}
	public PriceInfoDTO(BigDecimal fe, BigDecimal list, BigDecimal srp,
                        BigDecimal target) {
		this.fe=fe;
		this.target=target;
		this.srp=srp;
		this.list=list;
		
	}
	public BigDecimal getFe() {
		return fe;
	}
	public void setFe(BigDecimal fe) {
		this.fe = fe;
	}
	public BigDecimal getTarget() {
		return target;
	}
	public void setTarget(BigDecimal target) {
		this.target = target;
	}
	public BigDecimal getSrp() {
		return srp;
	}
	public void setSrp(BigDecimal srp) {
		this.srp = srp;
	}
	public BigDecimal getList() {
		return list;
	}
	public void setList(BigDecimal list) {
		this.list = list;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fe == null) ? 0 : fe.hashCode());
		result = prime * result + ((list == null) ? 0 : list.hashCode());
		result = prime * result + ((srp == null) ? 0 : srp.hashCode());
		result = prime * result + ((target == null) ? 0 : target.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PriceInfoDTO other = (PriceInfoDTO) obj;
		if (fe == null) {
			if (other.fe != null)
				return false;
		} else if (!fe.equals(other.fe))
			return false;
		if (list == null) {
			if (other.list != null)
				return false;
		} else if (!list.equals(other.list))
			return false;
		if (srp == null) {
			if (other.srp != null)
				return false;
		} else if (!srp.equals(other.srp))
			return false;
		if (target == null) {
			if (other.target != null)
				return false;
		} else if (!target.equals(other.target))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "PriceInfoDTO [fe=" + fe + ", target=" + target + ", srp=" + srp + ", list=" + list + "]";
	}
	
}
