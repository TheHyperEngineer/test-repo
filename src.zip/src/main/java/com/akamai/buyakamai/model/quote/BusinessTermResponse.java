package com.akamai.buyakamai.model.quote;

import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class BusinessTermResponse {

    private String inputType;
    private List<BusinessTerms> terms;

}
