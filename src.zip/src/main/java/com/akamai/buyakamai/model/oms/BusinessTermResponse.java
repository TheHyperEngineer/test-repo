package com.akamai.buyakamai.model.oms;

import java.util.List;

import com.akamai.buyakamai.integration.model.productmaster.ProductDTO;
import com.akamai.se.com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessTermResponse {

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String inputType;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<BusinessTerms> businessTerms;
	
}
