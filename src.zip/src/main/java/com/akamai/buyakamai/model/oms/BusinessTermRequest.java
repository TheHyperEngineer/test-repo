
package com.akamai.buyakamai.model.oms;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BusinessTermRequest{
	
	private String serviceFlow;
	private String orderSourceId;
	private List<String> productIds;
	
	public String getServiceFlow() {
		return serviceFlow;
	}
	public void setServiceFlow(String serviceFlow) {
		this.serviceFlow = serviceFlow;
	}
	public String getOrderSourceId() {
		return orderSourceId;
	}
	public void setOrderSourceId(String orderSourceId) {
		this.orderSourceId = orderSourceId;
	}
	public List<String> getProductIds() {
		return productIds;
	}
	public void setProductIds(List<String> productIds) {
		this.productIds = productIds;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderSourceId == null) ? 0 : orderSourceId.hashCode());
		result = prime * result + ((productIds == null) ? 0 : productIds.hashCode());
		result = prime * result + ((serviceFlow == null) ? 0 : serviceFlow.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BusinessTermRequest other = (BusinessTermRequest) obj;
		if (orderSourceId == null) {
			if (other.orderSourceId != null)
				return false;
		} else if (!orderSourceId.equals(other.orderSourceId))
			return false;
		if (productIds == null) {
			if (other.productIds != null)
				return false;
		} else if (!productIds.equals(other.productIds))
			return false;
		if (serviceFlow == null) {
			if (other.serviceFlow != null)
				return false;
		} else if (!serviceFlow.equals(other.serviceFlow))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "BusinessTermsRequest [serviceFlow=" + serviceFlow + ", orderSourceId=" + orderSourceId + ", productIds="
				+ productIds + "]";
	}
	
}
