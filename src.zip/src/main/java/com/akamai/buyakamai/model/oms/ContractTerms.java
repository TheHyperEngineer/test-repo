package com.akamai.buyakamai.model.oms;

import com.akamai.buyakamai.model.quote.BusinessTerms;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ContractTerms {

    private String contractDuration;
    private String anticipatedSignedDate;
    private String billingEffectiveDate;
    private String expirationDate;
    private List<BusinessTerms> businessTerms;
}
