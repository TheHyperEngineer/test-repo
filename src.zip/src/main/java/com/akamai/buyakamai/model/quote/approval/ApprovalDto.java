package com.akamai.buyakamai.model.quote.approval;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ApprovalDto extends ResourceSupport {
    private QuoteApproval items;
    private List<ApprovalStatus> status;
}
