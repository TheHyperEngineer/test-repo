package com.akamai.buyakamai.model.quote.approval;


import com.akamai.buyakamai.constants.ApprovalTypeConstants;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ApprovalStatus {

    private ApprovalTypeConstants approvalType;

    @JsonProperty("isApproved")
    private Boolean approved;
}