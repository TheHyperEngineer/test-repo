package com.akamai.buyakamai.service.common.cache;

public class AccountIdCacheKey {

    private String userName;
    private String level;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccountIdCacheKey that = (AccountIdCacheKey) o;

        if (userName != null ? !userName.equals(that.userName) : that.userName != null) return false;
        return level != null ? level.equals(that.level) : that.level == null;
    }

    @Override
    public int hashCode() {
        int result = userName != null ? userName.hashCode() : 0;
        result = 31 * result + (level != null ? level.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AccountIdCacheKey{" +
                "userName='" + userName + '\'' +
                ", level='" + level + '\'' +
                '}';
    }
}
