package com.akamai.buyakamai.service.alert;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.OrderEventAction;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.util.CommonUtils;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class TnCAlertStrategy extends AlertStrategy {

	private static Logger logger = LoggerFactory.getLogger(TnCAlertStrategy.class);
	
	@Override
	public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		if ( refreshAlertIfPresent(alerts, AlertDefName.TNC_ACCEPTED) ) {
			logger.info("Alert already processed: TNC_ACCEPTED for order id: " + order.getOrderId());
			return;
		} else {
			handleNewEventIfAny(order, events, alerts);
		}
	}

	private void handleNewEventIfAny(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		logger.info("Alert being processed: TNC_ACCEPTED for order id: " + order.getOrderId());
		
		Optional<EventData> tncEvent = events.stream().filter(event -> {
			return OrderEventAction.USER_CLICKS_SIGN_UP_SUCCESS.name().equalsIgnoreCase(event.getEventAction());
		}).findFirst();
		
		if ( tncEvent.isPresent() || (order.getStartDate() != null) ) {
			logger.info("Found TNC_ACCEPTED event for order: " +order.getOrderId());
			Date eventDate = CommonUtils.formatOrderDate(order.getStartDate()).toDate();
			AlertEntity alert = addNewAlert(order, AlertDefName.TNC_ACCEPTED, eventDate, AlertState.COMPLETE, getDirectAccountOrPartnerName(order));
			alerts.add(alert);
			clearAlertsIfPresent(alerts, Arrays.asList(AlertDefName.TNC_NOT_ACCEPTED));
		} else {
			addOrRefreshNotOccurredAlert(alerts, order, events, AlertDefName.TNC_NOT_ACCEPTED, 1);
		}
	}


	@Override
	protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		Optional<EventData> tempCredSentEvent = events.stream().filter(event -> {
			return OrderEventAction.TEMP_CREDENTIAL_SENT.name().equalsIgnoreCase(event.getEventAction());
		}).findFirst();
		if ( tempCredSentEvent.isPresent() ) {
			return new LocalDate(CommonUtils.formatEventDate(tempCredSentEvent.get()));
		} else {
			return new LocalDate(CommonUtils.formatOrderDate(order.getCreatedDate()));
		}
	}	
}