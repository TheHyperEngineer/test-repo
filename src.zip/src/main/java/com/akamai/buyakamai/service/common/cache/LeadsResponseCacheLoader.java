package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.constants.*;
import com.akamai.buyakamai.controller.model.LeadDto;
import com.akamai.buyakamai.controller.model.QuoteAcceptedOrderSourceDTO;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.AlertLogger;
import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.akamai.buyakamai.service.impl.MarketplaceAPIServiceImpl;
import com.google.common.cache.CacheLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;
import java.util.*;
import java.util.stream.Collectors;


@Component
public class LeadsResponseCacheLoader extends CacheLoader<String, List<LeadDto>> {

    private static final Logger logger = LoggerFactory.getLogger(LeadsResponseCacheLoader.class);

    @Autowired
    private BACoreAPIServiceImpl baCoreService;

    @Autowired
    private AlertLogger alertLogger;
    
    @Autowired
    private MarketplaceAPIServiceImpl marketplaceAPIService;


    @Override
    public List<LeadDto> load(String leadsKey) throws BuyAkamaiApplicationException {
        logger.info("Lead cache getting loaded with new value",
        		leadsKey);

        return getLeadsResponseOnCacheMiss();
    }

    private List<LeadDto> getLeadsResponseOnCacheMiss() {
        List<LeadDto> coreResponse;
        try {
            StopWatch timer = new StopWatch();
            timer.start("CoreAPIResponse");
            coreResponse = baCoreService.getLeads();
            timer.stop();
            logger.info("Got leads from Core. Time taken in milliseconds before sort {}.", timer.prettyPrint());
            return removeLeadsIfQuoteIsAccepted(coreResponse);
        } catch (Exception ex) {
            logger.error("Exception occurred while fetching leads : {}", ex);
            Map<String, String> requestData = new HashMap<>();
            requestData.put(DBLoggerConstants.USER_ID, BAConstants.BUYAKAM_USER);
            alertLogger.logAlertForLeadLoadFail(requestData, ex);
            String title = "Exception occurred while fetching all leads.";
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.INTERNAL_SERVER_ERROR,
                    ErrorConstants.GET_ALL_LEADS_FAILED_KEY);
        }
    }

    public List<LeadDto> removeLeadsIfQuoteIsAccepted(List<LeadDto> coreList) {
        QuoteAcceptedOrderSourceDTO marketplaceResponse = marketplaceAPIService.getOrderSourceListWithQuoteAccepted();
        Set<String> idSet = marketplaceResponse.getSourceIdList();
        return coreList.stream().filter(LeadDto -> !idSet.contains(LeadDto.getId())).collect(Collectors.toList());
    }

}