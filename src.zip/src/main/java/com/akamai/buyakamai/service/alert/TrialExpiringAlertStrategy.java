package com.akamai.buyakamai.service.alert;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.akamai.buyakamai.constants.OrderApplicationConstants;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class TrialExpiringAlertStrategy extends AlertStrategy {

	private static Logger logger = LoggerFactory.getLogger(TrialExpiringAlertStrategy.class);
	
	private static final String TRIAL_EXPIRY_NOTICE_DAYS = "trial_expiry_alert_notice_days";

	@Autowired
	private OrderServiceImpl orderService;

	@Autowired
	private PropertyManager propertyManager;
	
	@Override
	public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		if ( order.getEndDate() == null ) {
			logger.info("Skipping TRIAL_EXPIRING for order id: {} since its a quote", order.getOrderId());
			return;
		}
		if ( orderService.isOrderExpired(order) ) {
			logger.info("Skipping TRIAL_EXPIRING for order id: {} since order is already expired.", order.getOrderId());
			return;
		}
		
		DateTime orderEndDate = CommonUtils.formatOrderDate(order.getEndDate());

		int noticeDays = Integer.valueOf(propertyManager.getPropertyWithDeafultValue(TRIAL_EXPIRY_NOTICE_DAYS, "5"));
		int trialDaysRem = Days.daysBetween(LocalDate.now(), new LocalDate(orderEndDate)).getDays();
		
		boolean hasTrialExpiringEventOccurred =  !orderService.isOrderExpired(order) && !isOrderCancelled(order)
				&& (trialDaysRem <= noticeDays);
		if ( hasTrialExpiringEventOccurred ) {
			logger.info("Alert being processed: TRIAL_EXPIRING for order id: " + order.getOrderId());
			handleTrialExpiringEvent(order, events, alerts, trialDaysRem);
		} else {
			deleteAlertIfPresent(alerts, AlertDefName.TRIAL_EXPIRING);
		}
	}

	private boolean isOrderCancelled(SelectOrderResponse order) {
		return OrderApplicationConstants.ORDER_CANCELLED_STATUS.equalsIgnoreCase(order.getStatus());
	}

	private void handleTrialExpiringEvent(SelectOrderResponse order, List<EventData> events,
			List<AlertEntity> alerts, Integer trialDaysRem) {
		logger.info("Alert being processed: TRIAL_EXPIRING for order id: " + order.getOrderId());

		Optional<AlertEntity> expiringEvent = fetchAlertForDefinition(alerts, AlertDefName.TRIAL_EXPIRING);

		if ( !expiringEvent.isPresent() ) {
			logger.info("Found TRIAL_EXPIRING event for order: " +order.getOrderId());
			AlertEntity alert = addNewAlert(order, AlertDefName.TRIAL_EXPIRING, new Date(), AlertState.ACTIVE,order.getAccount().getAccountName() + 
					BAConstants.ALERTS_DESC_ARGS_SEPARATOR + trialDaysRem.toString());
			alerts.add(alert);
		} else {
			String longDesc = order.getAccount().getAccountName() +
					BAConstants.ALERTS_DESC_ARGS_SEPARATOR + trialDaysRem.toString();
			refreshRecurringEventSnoozableAlert(alerts, order, AlertDefName.TRIAL_EXPIRING, longDesc);
		}
	}

	@Override
	protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		AlertEntity previousAlert = findAlertByName(alerts, AlertDefName.TRIAL_EXPIRING).get();
		return new LocalDate(previousAlert.getCreatedTime());
	}

}