package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.google.common.cache.CacheLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class AccountIdCacheLoader extends CacheLoader<AccountIdCacheKey, List<String>> {

    private static final Logger logger = LoggerFactory.getLogger(AccountIdCacheLoader.class.getName());

    @Autowired
    private BACoreAPIServiceImpl baCoreService;

    @Override
    public List<String> load(AccountIdCacheKey key) throws Exception {
        logger.info("AccountId cache for user {} doesn't exist", key);
        return getAccountIdsOnCacheMiss(key);
    }

    private List<String> getAccountIdsOnCacheMiss(AccountIdCacheKey key) {
        return baCoreService.getAccountIdsWithReporteesIncluded(key.getUserName(), key.getLevel());
    }
}
