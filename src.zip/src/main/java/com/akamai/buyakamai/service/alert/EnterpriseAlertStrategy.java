package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.constants.*;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.HistoryEntity;
import com.akamai.buyakamai.service.history.HistoryActionsImpl;
import com.akamai.buyakamai.util.CommonUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component("EnterpriseAlertStrategy")
@Transactional(propagation = Propagation.REQUIRED)
public class EnterpriseAlertStrategy extends AlertStrategy {

    private static final Logger logger = LoggerFactory.getLogger(EnterpriseAlertStrategy.class);

    @Autowired
    private HistoryActionsImpl historyActions;

    @Override
    public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        logger.info("Processing alert for ENTERPRISE category with order id {}", order.getOrderId());
        processDomainCreatedAlert(order, events, alerts);
        processEntitiesConfiguredAlert(order, events, alerts);
        processConfigPushedAlert(order, events, alerts);
        processServiceUsageAlert(order, events, alerts);
    }

    private void processServiceUsageAlert(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {

        /*AlertDefName alertDefName =
                order.getBundleId().equalsIgnoreCase(propertyManager.getProperty(EnterpriseConstants.EAA_BUNDLE_ID)) ?
                        AlertDefName.ENTERPRISE_TRAFFIC_NOT_PUSHED_EAA : AlertDefName.ENTERPRISE_TRAFFIC_NOT_PUSHED_ETP;*/

        if(isETPRelatedBundle(order.getBundleId())){
            AlertDefName alertDefName = AlertDefName.ENTERPRISE_TRAFFIC_NOT_PUSHED_ETP;
            if (orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_SERVICE_USAGE, events)) {
                clearAlertsIfPresent(alerts, Collections.singletonList(alertDefName));
            }
            if (!orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_SERVICE_USAGE, events)
                    && !refreshAlertIfPresent(alerts, alertDefName)) {
                List<EventData> enterpriseEntitiesConfiguredEvent = orderEventsService
                        .filterEventDataForEventType(OrderEventAction.ENTERPRISE_CONFIG_PUSHED, events);
                if (!enterpriseEntitiesConfiguredEvent.isEmpty()) {
                    DateTime eventCreatedate = CommonUtils.formatEventDate(enterpriseEntitiesConfiguredEvent.get(0));
                    if (CommonUtils.calculateDaysBetweenDate(eventCreatedate.toLocalDate(), LocalDate.now()) >= Integer
                            .parseInt(propertyManager.getProperty(EnterpriseConstants.TRAFFIC_PUSHED_ALERT_INTERVAL))) {
                        String longDescription = order.getAccount().getAccountName();
                        addNewAlert(order, alertDefName, new Date(), AlertState.ACTIVE, longDescription);
                        logger.info("Added alert for entites not configured with order Id {}", order.getOrderId());
                    }
                }
            }
        }
    }

    private void processConfigPushedAlert(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {

        /*AlertDefName alertDefName =
                order.getBundleId().equalsIgnoreCase(propertyManager.getProperty(EnterpriseConstants.EAA_BUNDLE_ID)) ?
                        AlertDefName.ENTERPRISE_CONFIG_NOT_PUSHED_EAA : AlertDefName.ENTERPRISE_CONFIG_NOT_PUSHED_ETP;*/
        if(isETPRelatedBundle(order.getBundleId())){
            AlertDefName alertDefName = AlertDefName.ENTERPRISE_CONFIG_NOT_PUSHED_ETP;
            if (orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_CONFIG_PUSHED, events)) {
                clearAlertsIfPresent(alerts, Collections.singletonList(alertDefName));
            }
            if (!orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_CONFIG_PUSHED, events)
                    && !refreshAlertIfPresent(alerts, alertDefName)) {
                List<EventData> enterpriseEntitiesConfiguredEvent = orderEventsService
                        .filterEventDataForEventType(OrderEventAction.ENTERPRISE_CONFIGURED_ETITIES, events);
                if (!enterpriseEntitiesConfiguredEvent.isEmpty()) {
                    DateTime eventCreatedate = CommonUtils.formatEventDate(enterpriseEntitiesConfiguredEvent.get(0));
                    if (CommonUtils.calculateDaysBetweenDate(eventCreatedate.toLocalDate(), LocalDate.now()) >= Integer
                            .parseInt(propertyManager.getProperty(EnterpriseConstants.CONFIG_PUSHED_ALERT_INTERVAL))) {
                        String longDescription = order.getAccount().getAccountName();
                        addNewAlert(order, alertDefName, new Date(), AlertState.ACTIVE, longDescription);
                        logger.info("Added alert for entites not configured with order Id {}", order.getOrderId());
                    }
                }
            }
        }


    }

    private void processEntitiesConfiguredAlert(SelectOrderResponse order, List<EventData> events,
            List<AlertEntity> alerts) {
        /*AlertDefName alertDefName =
                order.getBundleId().equalsIgnoreCase(propertyManager.getProperty(EnterpriseConstants.EAA_BUNDLE_ID)) ?
                        AlertDefName.ENTERPRISE_ENTITIES_NOT_CONFIGURED_EAA :
                        AlertDefName.ENTERPRISE_ENTITIES_NOT_CONFIGURED_ETP;*/
            if(isETPRelatedBundle(order.getBundleId())) {
                AlertDefName alertDefName = AlertDefName.ENTERPRISE_CONFIG_NOT_PUSHED_ETP;
                if (orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_CONFIGURED_ETITIES, events)) {
                    clearAlertsIfPresent(alerts, Collections.singletonList(alertDefName));
                }
                if (!orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_CONFIGURED_ETITIES, events)
                        && !refreshAlertIfPresent(alerts, alertDefName)) {
                    List<EventData> enterpriseEntitiesConfiguredEvent = orderEventsService
                            .filterEventDataForEventType(OrderEventAction.ENTERPRISE_DOMAIN_CREATED, events);
                    if (!enterpriseEntitiesConfiguredEvent.isEmpty()) {
                        DateTime eventCreatedate = CommonUtils.formatEventDate(enterpriseEntitiesConfiguredEvent.get(0));
                        if (CommonUtils.calculateDaysBetweenDate(eventCreatedate.toLocalDate(), LocalDate.now()) >= Integer
                                .parseInt(propertyManager
                                        .getProperty(EnterpriseConstants.CONFIGURED_ENTITIES_ALERT_INTERVAL))) {
                            String longDescription = order.getAccount().getAccountName();
                            addNewAlert(order, alertDefName, new Date(), AlertState.ACTIVE, longDescription);
                            logger.info("Added alert for entites not configured with order Id {}", order.getOrderId());
                        }
                    }
                }
            }
    }

    private void processDomainCreatedAlert(SelectOrderResponse order, List<EventData> events,
            List<AlertEntity> alerts) {
        AlertDefName alertDefName =
                order.getBundleId().equalsIgnoreCase(propertyManager.getProperty(EnterpriseConstants.EAA_BUNDLE_ID)) ?
                        AlertDefName.ENTERPRISE_DOMAIN_NOT_CREATED_EAA : AlertDefName.ENTERPRISE_DOMAIN_NOT_CREATED_ETP;
        if (orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_DOMAIN_CREATED, events)) {
            clearAlertsIfPresent(alerts, Collections.singletonList(alertDefName));
            logger.info("cleared alert for domain not yet created with order Id {}", order.getOrderId());
        }
        if (!orderEventsService.isEventAlreadyLogged(OrderEventAction.ENTERPRISE_DOMAIN_CREATED, events)
                && !refreshAlertIfPresent(alerts, alertDefName)) {
            Optional<HistoryEntity> historyEntity = historyActions
                    .getHistoryEntityByName(HistoryDefName.TNC_ACCEPTED, order);
            if (historyEntity.isPresent()) {
                Date eventDate = historyEntity.get().getEventTime();
                int days = CommonUtils.calculateDaysBetweenDate(new LocalDate(eventDate), new LocalDate()) + 1;
                if (days > Integer
                        .parseInt(propertyManager.getProperty(EnterpriseConstants.DOMAIN_CREATED_ALERT_INTERVAL))) {
                    String longDescription = order.getAccount().getAccountName();
                    addNewAlert(order, alertDefName, new Date(), AlertState.ACTIVE, longDescription);
                    logger.info("Added alert for domain not yet created with order Id {}", order.getOrderId());
                }
            }
        }
    }

    @Override
    protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events,
            List<AlertEntity> alerts) {
        return null;
    }

    private boolean isETPRelatedBundle(String bundleId) {
        List<String> etpRelatedBundleIds = CommonUtils.convertCommaSeparatedStringToList
                (propertyManager.getProperty(EnterpriseConstants.ETP_RELATED_BUNDLE_ID));
        return etpRelatedBundleIds.contains(bundleId);
    }
}
