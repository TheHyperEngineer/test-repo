package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.constants.*;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.util.CommonUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class TrialExtensionAlertStrategy extends AlertStrategy {


    private static Logger logger = LoggerFactory.getLogger(TrialExtensionAlertStrategy.class);

    @Override
    public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {

        logger.info("Processing extension notification current status: {}", order.getStatus());

        if (order.getStatus().equalsIgnoreCase(OrderApplicationConstants.AWAITING_EXTENSION)) {
            Optional<EventData> extensionRequestEvent = events.stream().filter(evnt -> OrderEventAction.getExtensionRequestEvents().
                    contains(evnt.getEventAction().toUpperCase()))
                    .max(Comparator.comparing(EventData::getTimestamp));
            if(extensionRequestEvent.isPresent()) {
                handleExtensionNotAcceptedAlert(extensionRequestEvent, alerts, order);
            }
        } else {
            deleteAlertIfPresent(alerts, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED);
        }
    }

    private void handleExtensionNotAcceptedAlert(Optional<EventData> extensionRequestEvent, List<AlertEntity> alerts,
                                                 SelectOrderResponse order) {

        Date eventTime = CommonUtils.formatEventDate(extensionRequestEvent.get()).toDate();
        double intervalHours = CommonUtils.findHoursBetweenDate(new Date(), eventTime);

        String HOURS = propertyManager.getProperty(BAConstants.AWAITING_EXTENSION_NOTIFICATION_TIME_HOURS);

        if (intervalHours > Integer.valueOf(HOURS)) {
            if (extensionRequestEvent.isPresent() && !containsAlert(alerts, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED)) {
                String freeDays = extensionRequestEvent.get().getData().get(OrderApplicationConstants.EXTENSION_DAYS_EVENT_DATA_KEY);
                String longDesc = getDirectAccountOrPartnerName(order) + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + order.getProducts().get(0) + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + freeDays;
                addNewAlert(order, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED, new Date(), AlertState.ACTIVE, longDesc);
            }
        } else {
            deleteAlertIfPresent(alerts, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED);
        }
    }

    @Override
    protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        return null;
    }
}
