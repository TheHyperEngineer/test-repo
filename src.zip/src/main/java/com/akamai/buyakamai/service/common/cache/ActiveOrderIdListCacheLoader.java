package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.controller.model.SelectOrderRequest;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import com.google.common.cache.CacheLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class ActiveOrderIdListCacheLoader extends CacheLoader<String, List<Integer>> {

    @Autowired
    private OrderServiceImpl orderService;

    private static final Logger logger = LoggerFactory.getLogger(ActiveOrderIdListCacheLoader.class.getName());

    @Override
    public List<Integer> load(String key) throws Exception {
        logger.info("Active order list doesn't exist", key);
        return getActiveOrderListOnCacheMiss();
    }

    private List<Integer> getActiveOrderListOnCacheMiss() {

        SelectOrderRequest selectOrderRequest = new SelectOrderRequest();
        selectOrderRequest.setOrderType("trial");
        selectOrderRequest.setOrderStatus("ongoing");

        List<SelectOrderResponse> responseList = orderService.fetchOrdersBasedOnRequest(selectOrderRequest);
        List orderIdList = new ArrayList();
        responseList.stream().map(unit -> orderIdList.add(unit.getOrderId())).count();
        return orderIdList;
    }
}
