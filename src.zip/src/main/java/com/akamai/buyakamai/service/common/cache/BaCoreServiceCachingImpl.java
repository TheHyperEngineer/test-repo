package com.akamai.buyakamai.service.common.cache;


import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.util.PropertyManager;
import com.google.common.cache.LoadingCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Service
public class BaCoreServiceCachingImpl {

    private static final Logger logger = LoggerFactory.getLogger(BaCoreServiceCachingImpl.class.getName());

    @Autowired
    private CacheInitializerService cachingService;

    @Autowired
    private PropertyManager propertyManager;

    public List<String> getAccountIdsIncludingReportees(String userName) throws ExecutionException {

        logger.debug("Inside Getting AccountIds from Cache");
        List<String> accountIds;
        try {
            LoadingCache<AccountIdCacheKey, List<String>> cache = cachingService.getAccountIdCache();
            String level = propertyManager.getProperty(BAConstants.HIERARCHY_FILTERING_LEVEL);

            AccountIdCacheKey key = new AccountIdCacheKey();
            key.setLevel(level);
            key.setUserName(userName);

            accountIds = cache.get(key);

        } catch (Exception e) {
            logger.error("Exception occurred during fetching cache {}", e);
            throw e;
        }
        return accountIds;
    }

    public List<String> getLeadIdsForUser(String userName) throws Exception {
        logger.debug("Inside getting leads for user {}", userName);
        List<String> leadIds;
        try {
            LoadingCache<String, List<String>> cache = cachingService.getLeadOwnerCache();
            leadIds = cache.get(userName.toUpperCase());
        } catch (Exception e) {
            logger.error("Exception occurred during getting lead detail for user {}", userName);
            throw e;
        }

        return leadIds;
    }

}
