package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.controller.model.OrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.AlertRepository;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Transactional
@Component("TrialExpiringActionFetcher")
public class TrialExpiringActionFetcher implements AlertActionFetcher {


    @Autowired
    private OrderServiceImpl orderService;

    @Autowired
    private AlertRepository alertRepository;

    @Autowired
    private PropertyManager propertyManager;

    @Override
    public List<String> evaluateAction(int alertId, List<String> baRole, String actions) {


        if (baRole.contains(BAConstants.INTEGRATED_OPS_ROLE)) {
            return Arrays.asList(actions.split(("[,]")));
        } else if (!Collections.disjoint(baRole, BAConstants.SALES_RELATED_ROLES)) {
            Integer orderId = alertRepository.findOne(alertId).getOrderId();
            try {
                OrderResponse orderResponse = orderService.getOrderResponseForOrderId(orderId);

                Date startDate = CommonUtils.parseTimestamp(orderResponse.getStartDate(), BAConstants.DATE_FORMAT_FOR_SELECT_ORDERS);
                Date endDate = CommonUtils.parseTimestamp(orderResponse.getEndDate(), BAConstants.DATE_FORMAT_FOR_SELECT_ORDERS);

                int days = CommonUtils.calculateDaysBetweenDate(new LocalDate(startDate),
                        new LocalDate(endDate)) + 1;
                String MAX_DAYS = propertyManager.getProperty(BAConstants.SALES_REP_MAX_EXTENSION_SUPPORTED_DAYS);
                if (days >= Integer.valueOf(MAX_DAYS)) {
                    return Collections.singletonList(BAConstants.REQUEST_SUPPORT_ACTION);
                } else {
                    return Collections.singletonList(BAConstants.EXTEND_TRIAL_ACTION);
                }

            } catch (BuyAkamaiApplicationException ex) {
                ex.setErrorKey(ErrorConstants.ALERTS_FETCH_FAILED);
                throw ex;
            }
        }
        return Collections.emptyList();
    }
}
