package com.akamai.buyakamai.service.alert;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.OrderEventAction;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertDefinition;
import com.akamai.buyakamai.util.CommonUtils;

@Component("ProdPushAlertStrategy")
@Transactional(propagation = Propagation.REQUIRED)
public class ProdPushAlertStrategy extends AlertStrategy {

	private static Logger logger = LoggerFactory.getLogger(ProdPushAlertStrategy.class);
	
	@Override
	public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		logger.info("Alert being processed: PROD_CONFIG_PUSHED for order id: " + order.getOrderId());
		
		List<EventData> stagePushEvents = events.stream().filter(event -> {
			return OrderEventAction.STAGING_CONFIG_COMPLETED.name().equalsIgnoreCase(event.getEventAction());
		}).collect(Collectors.toList());

		List<EventData> prodPushEvents = events.stream().filter(event -> {
			return OrderEventAction.PRODUCTION_CONFIG_COMPLETED.name().equalsIgnoreCase(event.getEventAction());
		}).collect(Collectors.toList());
		
		for ( EventData stagePushEvent : stagePushEvents ) {
			String propertyName = stagePushEvent.getData().get(BAConstants.KEY_PROPERTY_NAME);
			EventData prodPushEvent = getMatchingProdPushEvent(stagePushEvent, prodPushEvents);
			if ( (prodPushEvent != null) && !containsAlert(alerts, AlertDefName.PROD_CONFIG_PUSHED, propertyName) ) {
				logger.info("Found PROD_CONFIG_PUSHED event for order: {} and arl file: {} ", order.getOrderId(), propertyName);
				Date eventDate = CommonUtils.formatEventDate(prodPushEvent).toDate();
				String longDiscription = order.getAccount().getAccountName() + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + propertyName;
				AlertEntity alert = addNewAlert(order, AlertDefName.PROD_CONFIG_PUSHED, eventDate, AlertState.COMPLETE,longDiscription);
				alerts.add(alert);
				clearAlertsIfPresent(alerts, Arrays.asList(
						AlertDefName.STAGING_CONFIG_NOT_PUSHED, AlertDefName.TNC_NOT_ACCEPTED));
				clearAlertIfPresent(alerts, AlertDefName.PROD_CONFIG_NOT_PUSHED, propertyName);
			} else if ( prodPushEvent == null  ) {
				addOrRefreshNotOccurredAlert(alerts, order, stagePushEvent, AlertDefName.PROD_CONFIG_NOT_PUSHED, 2, propertyName);
			}
		}
	}

	private EventData getMatchingProdPushEvent(EventData stagePushEvent, List<EventData> prodPushEvents) {
		String stageARLFileName = stagePushEvent.getData().get(BAConstants.KEY_PROPERTY_NAME);
		for ( EventData prodEventData : prodPushEvents) {
			if ( stageARLFileName.equalsIgnoreCase(prodEventData.getData().get(BAConstants.KEY_PROPERTY_NAME)) ) {
				return prodEventData;
			}
		}
		return null;
	}
	
	protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events,
			List<AlertEntity> alerts, String arlFileName) {
		AlertEntity previousAlert = findAlertByName(alerts, AlertDefName.STAGING_CONFIG_PUSHED, arlFileName).get();
		return new LocalDate(previousAlert.getCreatedTime());
	}
	
	protected void clearAlertIfPresent(List<AlertEntity> alerts, AlertDefName alertDefName, String propertyName) {
		logger.debug("Clearing alerts ...");
		alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			if ( (alertDef.getName() == alertDefName) && (alert.getState() != AlertState.COMPLETE) ) {
				List<String> argList = Arrays.asList(alert.getDescriptionArgs().split(BAConstants.ALERTS_DESC_ARGS_SEPARATOR));
				if ( argList.contains(propertyName) ) {
					alert.setState(AlertState.COMPLETE);
					alertRepo.save(alert);
					return true;
				}
			}
			return false;
		}).collect(Collectors.toList());
	}
	
	protected void addOrRefreshNotOccurredAlert(List<AlertEntity> alerts, SelectOrderResponse order,
			EventData stagePushEvent, AlertDefName alertDefName, int waitDaysForAlert, String propertyName) {
		LocalDate eventDate = new LocalDate(CommonUtils.formatEventDate(stagePushEvent));
		if (containsAlert(alerts, alertDefName, propertyName)) {
			refreshAlert(alerts, order, alertDefName, propertyName);
		} else if (Days.daysBetween(eventDate, LocalDate.now()).getDays() >= waitDaysForAlert) {
			String longDescription;
			if (BAConstants.TRIAL_TYPE_POC.equalsIgnoreCase(order.getTrialType())) {
				longDescription = propertyName;
			} else {
				longDescription = order.getAccount().getAccountName() + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + propertyName;
			}
			AlertEntity alert = addNewAlert(order, alertDefName, eventDate.plusDays(waitDaysForAlert).toDate(), AlertState.ACTIVE, longDescription);
			alerts.add(alert);
		}
	}

	protected void refreshAlert(List<AlertEntity> alerts, SelectOrderResponse order,
			AlertDefName alertDefName, String propertyName) {
		logger.info("Refreshing alert for order {} and alert {} and property: {}", order.getOrderId(), alertDefName.name(), propertyName);
		AlertEntity alert = findAlertByName(alerts, alertDefName, propertyName).get();
		performRefreshActionOnAlert(alert);
	}

	protected Optional<AlertEntity> findAlertByName(List<AlertEntity> alerts, AlertDefName alertDefName, String propertyName) {
		
		return alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			if ( alertDef.getName() == alertDefName ) {
				List<String> argList = Arrays.asList(alert.getDescriptionArgs().split(BAConstants.ALERTS_DESC_ARGS_SEPARATOR));
				if ( argList.contains(propertyName) ) {
					return true;
				}
			}
			return false;
		}).findAny();
	}

	protected boolean containsAlert(List<AlertEntity> alerts, AlertDefName alertDefName, String propertyName) {
		
		return alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			if ( alertDef.getName() == alertDefName ) {
				List<String> argList = Arrays.asList(alert.getDescriptionArgs().split(BAConstants.ALERTS_DESC_ARGS_SEPARATOR));
				if ( argList.contains(propertyName) ) {
					return true;
				}
			}
			return false;
		}).findAny().isPresent();
	}

	@Override
	protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events,
			List<AlertEntity> alerts) {
		return null;
	}
}
