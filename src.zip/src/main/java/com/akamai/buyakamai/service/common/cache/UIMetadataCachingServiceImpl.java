package com.akamai.buyakamai.service.common.cache;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.integration.model.productmaster.ProductMasterKey;
import com.akamai.buyakamai.integration.model.productmaster.UIMetadataDTO;
import com.google.common.cache.LoadingCache;

@Service
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class UIMetadataCachingServiceImpl  {

	private static final Logger logger = LoggerFactory.getLogger(UIMetadataCachingServiceImpl.class.getName());

	@Autowired
	private CacheInitializerService cachingService;

	public UIMetadataDTO getUiMetadata(String bundleId, String locale) throws ExecutionException {
		logger.debug("Getting metadat from UI Metadata Cache");
		UIMetadataDTO metaData = new UIMetadataDTO();
		ProductMasterKey productMasterKey = new ProductMasterKey(bundleId, locale);
		try{
			LoadingCache<ProductMasterKey, UIMetadataDTO> cache = cachingService.getUIMetadataCache();
			metaData = cache.get(productMasterKey);
		}
		catch(ExecutionException exception){
			logger.error("Exception occurred while getting UiMetadata {} ",exception);
			throw exception;
		}

		return metaData;
	}

}