package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.constants.BAConstants;
import com.google.common.cache.LoadingCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MarketplaceCachingServiceImpl {
    private static final Logger logger = LoggerFactory.getLogger(MarketplaceCachingServiceImpl.class.getName());

    @Autowired
    private CacheInitializerService cachingService;

    public List<Integer> getActiveOrderIdList() throws Exception {
        List<Integer> activeOrderList;
        try {
            LoadingCache<String, List<Integer>> cache = cachingService.getActiveOrderIdListCache();
            String key = BAConstants.ACTIVE_ORDER_LIST_CACHE_KEY;
            activeOrderList = cache.get(key);

        } catch (Exception e) {
            logger.error("Exception occurred during fetching cache {}", e);
            throw e;
        }
        return activeOrderList;
    }
}
