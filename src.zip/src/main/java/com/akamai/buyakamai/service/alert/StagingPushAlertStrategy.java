package com.akamai.buyakamai.service.alert;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.OrderEventAction;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.util.CommonUtils;

@Component("StagingPushAlertStrategy")
@Transactional(propagation = Propagation.REQUIRED)
public class StagingPushAlertStrategy extends AlertStrategy {

	private static Logger logger = LoggerFactory.getLogger(StagingPushAlertStrategy.class);
	
	@Override
	public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		if ( refreshAlertIfPresent(alerts, AlertDefName.STAGING_CONFIG_PUSHED) ) {
			logger.info("Alert already processed: STAGING_CONFIG_PUSHED for order id: " + order.getOrderId());
			return;
		} else {
			handleNewEventIfAny(order, events, alerts);
		}
	}

	private void handleNewEventIfAny(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		logger.info("Alert being processed: STAGING_CONFIG_PUSHED for order id: " + order.getOrderId());
		
		Optional<EventData> stagePushEvent = events.stream().filter(event -> {
			return OrderEventAction.STAGING_CONFIG_COMPLETED.name().equalsIgnoreCase(event.getEventAction());
		}).findFirst();
		
		if ( stagePushEvent.isPresent() ) {
			logger.info("Found STAGING_CONFIG_PUSHED event for order: " +order.getOrderId());
			Date eventDate = CommonUtils.formatEventDate(stagePushEvent.get()).toDate();
			AlertEntity alert = addNewAlert(order, AlertDefName.STAGING_CONFIG_PUSHED, eventDate, AlertState.COMPLETE,order.getAccount().getAccountName());
			alerts.add(alert);
			clearAlertsIfPresent(alerts, Arrays.asList(
					AlertDefName.STAGING_CONFIG_NOT_PUSHED, AlertDefName.TNC_NOT_ACCEPTED));
		} else if ( containsAlert(alerts, AlertDefName.TNC_ACCEPTED) ) {
			String longDiscription = order.getAccount().getAccountName();
			addOrRefreshNotOccurredAlert(alerts, order, events, AlertDefName.STAGING_CONFIG_NOT_PUSHED, 2, longDiscription);
		} else {
			logger.info("Previous event yet to occur. Alert can't be processed: STAGING_CONFIG_PUSHED for order id: " + order.getOrderId());
		}
	}

	@Override
	protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		AlertEntity previousAlert = findAlertByName(alerts, AlertDefName.TNC_ACCEPTED).get();
		return new LocalDate(previousAlert.getCreatedTime());
	}	
}
