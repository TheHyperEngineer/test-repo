package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.controller.model.*;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AlertProcessor {

    @Autowired
    private AlertStrategySelector alertStrategySelector;

    @Autowired
    private PartnerAlertStrategySelector partnerAlertStrategySelector;

    private static Logger logger = LoggerFactory.getLogger(AlertProcessor.class);

    @Async("asyncProcessExecutor")
    public void processAllAlerts(List<SelectOrderResponse> orderList, Map<Integer, List<EventData>> orderVsEventMap) {

        logger.info("Processing Alerts...");

        for (SelectOrderResponse order : orderList) {
            try {
                if (order.getPartnerAccount() == null) {
                    alertStrategySelector.processAlertsForOrder(order, orderVsEventMap);
                } else {
                    partnerAlertStrategySelector.processAlertsForOrder(order, orderVsEventMap);
                }
            } catch (Exception ex) {
                // log the error and continue for next order
                logger.error("Alert processing failed for order: " + order.getOrderId(), ex);
            }
        }

        logger.info("Processed all alerts successfully");
    }
}