package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.integration.model.dash.ContactUiMetaDataResponse;
import com.akamai.buyakamai.integration.service.impl.DashServiceImpl;
import com.google.common.cache.CacheLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ContactUiMetaDataCacheLoader extends CacheLoader<String, ContactUiMetaDataResponse> {

    private static final Logger logger = LoggerFactory.getLogger(ContactUiMetaDataCacheLoader.class);

    @Autowired
    private DashServiceImpl dashService;

    @Override
    public ContactUiMetaDataResponse load(String key) throws Exception {
        logger.info("Refreshing alerts cache with key {}", key);
        return getUiMetaDataOnCacheMiss();
    }

    private ContactUiMetaDataResponse getUiMetaDataOnCacheMiss() {
        return dashService.fetchContactsUIMetaData();
    }

}
