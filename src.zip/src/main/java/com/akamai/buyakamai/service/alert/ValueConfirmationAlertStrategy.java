package com.akamai.buyakamai.service.alert;


import com.akamai.buyakamai.constants.*;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.*;
import com.akamai.buyakamai.service.impl.BundleServiceImpl;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.Date;
import java.util.List;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class ValueConfirmationAlertStrategy extends AlertStrategy {

    private static Logger logger = LoggerFactory.getLogger(ValueConfirmationAlertStrategy.class);

    @Autowired
    private BundleServiceImpl bundleService;

    @Override
    public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {

        String valueConfirmationCategory = bundleService.getValueConfirmationCategory(order.getBundleId());

        if(StringUtils.isEmpty(valueConfirmationCategory))
            return;

        switch (valueConfirmationCategory) {
            case ValueConfirmationCategoryConstants.WEB_DELIVERY_CATEGORY:
                generateAlertForWebDelivery(order, events, alerts);
                break;

            default:
                break;
        }
    }

    @Override
    protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        return null;
    }

    private void generateAlertForWebDelivery(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        boolean isCustomerAlive = events.stream().anyMatch(eventData -> eventData.getEventAction().equalsIgnoreCase(OrderEventAction.CUSTOMER_LIVE.toString()));
        if (isCustomerAlive) {
            boolean isValueConfirmationRequested = refreshAlertIfPresent(alerts, AlertDefName.REQUEST_VALUE_CONF_REPORT);
            if (!isValueConfirmationRequested) {
                String longDesc = order.getAccount().getAccountName() + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + order.getProducts().get(0);
                AlertEntity alertEntity = addNewAlert(order, AlertDefName.REQUEST_VALUE_CONF_REPORT, new Date(), AlertState.ACTIVE, longDesc);
                alerts.add(alertEntity);
            }
        }
    }
}
