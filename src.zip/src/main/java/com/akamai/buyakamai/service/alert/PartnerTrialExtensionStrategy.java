package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.OrderApplicationConstants;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.controller.model.TrialExtensionDetail;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.util.CommonUtils;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class PartnerTrialExtensionStrategy extends AlertStrategy {


    private static Logger logger = LoggerFactory.getLogger(PartnerTrialExtensionStrategy.class);

    @Override
    public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {

        logger.info("Processing partner extension notification current status: {}", order.getStatus());

        TrialExtensionDetail currentChild = order.getChildOrderHierarchy();

        boolean extensionRequestFound = false;

        while (currentChild != null) {
            if (currentChild.getStatus().equalsIgnoreCase(OrderApplicationConstants.AWAITING_EXTENSION)) {
                handleExtensionNotAcceptedAlert(alerts, currentChild, order);
                extensionRequestFound = true;
            }
            currentChild = currentChild.getChildOrder();
        }

        if (!extensionRequestFound) {
            deleteAlertIfPresent(alerts, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED);
        }


    }

    private void handleExtensionNotAcceptedAlert(List<AlertEntity> alerts,
                                                 TrialExtensionDetail extensionDetail, SelectOrderResponse orderResponse) {

        Date eventTime = CommonUtils.formatOrderDate(extensionDetail.getCreatedDate()).toDate();
        double intervalHours = CommonUtils.findHoursBetweenDate(new Date(), eventTime);

        String HOURS = propertyManager.getProperty(BAConstants.AWAITING_EXTENSION_NOTIFICATION_TIME_HOURS);

        if (intervalHours > Integer.valueOf(HOURS)) {
            if (!containsAlert(alerts, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED)) {
                String freeDays = extensionDetail.getDuration();
                String longDesc = getDirectAccountOrPartnerName(orderResponse) + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + orderResponse.getProducts().get(0) + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + freeDays;
                addNewAlert(orderResponse, AlertDefName.EXTENSION_REQUEST_NOT_ACCEPTED, new Date(), AlertState.ACTIVE, longDesc);
            }
        }
    }

    @Override
    protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        return null;
    }

    private boolean createdByInternalRole(SelectOrderResponse order) {
        return false;
    }
}



