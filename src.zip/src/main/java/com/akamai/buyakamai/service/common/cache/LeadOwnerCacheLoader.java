package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.google.common.cache.CacheLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class LeadOwnerCacheLoader extends CacheLoader<String, List<String>> {

    private static final Logger logger = LoggerFactory.getLogger(LeadOwnerCacheLoader.class.getName());

    @Autowired
    private BACoreAPIServiceImpl baCoreService;


    @Override
    public List<String> load(String key) throws Exception {
        logger.info("Refreshing the lead owner cache for key {}", key);
        return getLeadIdsOnCacheMiss(key.toUpperCase());
    }

    private List<String> getLeadIdsOnCacheMiss(String userId) {
        return baCoreService.getLeadIdsForUser(userId);
    }
}
