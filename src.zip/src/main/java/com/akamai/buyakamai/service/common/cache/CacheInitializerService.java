package com.akamai.buyakamai.service.common.cache;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;

import com.akamai.buyakamai.controller.model.OrderAlertsDto;
import com.akamai.buyakamai.integration.model.dash.ContactUiMetaDataResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.controller.model.LeadDto;
import com.akamai.buyakamai.integration.clients.model.OpportunityDto;
import com.akamai.buyakamai.integration.model.productmaster.ProductMasterKey;
import com.akamai.buyakamai.integration.model.productmaster.UIMetadataDTO;
import com.akamai.buyakamai.util.PropertyManager;
import com.google.common.cache.CacheBuilder;
import com.google.common.cache.LoadingCache;


@Component
public class CacheInitializerService {
	
	private static final Logger logger = LoggerFactory.getLogger(CacheInitializerService.class.getName());
	
	@Autowired
	private LeadsResponseCacheLoader leadsResponseCacheLoader;
	
	@Autowired
	private UIMetadataCacheLoader metadataCacheLoader;

	@Autowired
	private AccountIdCacheLoader accountIdCacheLoader;

	@Autowired
	private LeadOwnerCacheLoader leadOwnerCacheLoader;

    @Autowired
    private ActiveOrderIdListCacheLoader activeOrderIdListCacheLoader;

    @Autowired
	private AlertsCacheLoader alertsCacheLoader;

    @Autowired
	private ContactUiMetaDataCacheLoader contactUiMetaDataCacheLoader;

	@Autowired
	private PropertyManager propertyManager;

	private LoadingCache<String, List<OpportunityDto>> opportunitiesCache;
	
	private LoadingCache<String, List<LeadDto>> leadsCache;

	private LoadingCache<ProductMasterKey, UIMetadataDTO> metadataCache;

    private LoadingCache<AccountIdCacheKey,List<String>>  accountIdsCache;

    private LoadingCache<String, List<String>> leadOwnerCache;

    private LoadingCache<String,List<Integer>> activeOrderIdListCache;

    private LoadingCache<String,List<OrderAlertsDto>> alertsCache;

    private LoadingCache<String,ContactUiMetaDataResponse> contactsMetaDataCache;

	public LoadingCache<String, List<OpportunityDto>> getOpportunitiesCache() {
		return opportunitiesCache;
	}

	public LoadingCache<ProductMasterKey, UIMetadataDTO> getUIMetadataCache() {
		return metadataCache;
	}

	public LoadingCache<AccountIdCacheKey, List<String>> getAccountIdCache() {
		return accountIdsCache;
	}

    public LoadingCache<String, List<Integer>> getActiveOrderIdListCache() {
        return activeOrderIdListCache;
    }

	public LoadingCache<String, List<LeadDto>> getLeadsCache() {
		return leadsCache;
	}

	public LoadingCache<String, List<String>> getLeadOwnerCache() {
		return leadOwnerCache;
	}

	public LoadingCache<String, List<OrderAlertsDto>> getAlertsCache() {
		return alertsCache;
	}

	public LoadingCache<String, ContactUiMetaDataResponse> getContactsMetaDataCache() {
		return contactsMetaDataCache;
	}

	private CacheBuilder<Object, Object> createCacheBuilder(Integer cacheSize, Integer expiryPeriod) {
		return CacheBuilder.newBuilder().maximumSize(cacheSize).expireAfterWrite(expiryPeriod, TimeUnit.MINUTES);
	}


	@PostConstruct
	private void buildCaches() {	
		createleadsCache();
		createUIMetadataCache();
		createAccountIdsCache();
		createActiveOrderIdListCache();
		createLeadOwnerCache();
		createAlertsCache();
		createContactsMetaDataCache();
	}


	private void createContactsMetaDataCache(){
		String cacheMaxSize = propertyManager.getProperty(BAConstants.CONTACTS_UI_METADATA_CACHE_SIZE);
		int maxSize;
		try{
			maxSize = Integer.parseInt(cacheMaxSize);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting cacheMaxSize {} {} ",cacheMaxSize , e);
			maxSize = 1;
		}

		String expiryTime = propertyManager.getProperty(BAConstants.CONTACTS_UI_METADATA_CACHE_EXPIRY_PERIOD_IN_MIN);
		int expiryTimeVal;
		try{
			expiryTimeVal = Integer.parseInt(expiryTime);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting expiryTimeVal {} {} ",expiryTime , e);
			expiryTimeVal = 600;
		}

		logger.info("Building cache in create contact metadata maxSize {}",maxSize);
		contactsMetaDataCache = createCacheBuilder(maxSize,expiryTimeVal).build(contactUiMetaDataCacheLoader);

	}

    private void createActiveOrderIdListCache() {
        String cacheMaxSize = propertyManager.getProperty(BAConstants.ACTIVE_ORDER_LIST_CACHE_MAXIMUM_SIZE);
        int maxSize;
        try {
            maxSize = Integer.parseInt(cacheMaxSize);
        } catch (NumberFormatException e) {
            logger.info("Number Format Exception while getting cacheMaxSize {} {} ", cacheMaxSize, e);
            maxSize = 1;
        }

        String expiryTime = propertyManager.getProperty(BAConstants.ACTIVE_ORDER_LIST_CACHE_EXPIRY_PERIOD);
        int expiryTimeVal;
        try {
            expiryTimeVal = Integer.parseInt(expiryTime);
        } catch (NumberFormatException e) {
            logger.info("Number Format Exception while getting expiryTimeVal {} {} ", expiryTime, e);
            expiryTimeVal = 5;
        }


        logger.info("Building cache in createOpportunitiesCache maxSize {}", maxSize);

        activeOrderIdListCache = createCacheBuilder(maxSize, expiryTimeVal)
                .build(activeOrderIdListCacheLoader);
    }

	private void createAlertsCache() {
		String cacheMaxSize = propertyManager.getProperty(BAConstants.ALERTS_CACHE_MAXIMUM_SIZE);
		int maxSize;
		try {
			maxSize = Integer.parseInt(cacheMaxSize);
		} catch (NumberFormatException e) {
			logger.info("Number Format Exception while getting cacheMaxSize {} {} ", cacheMaxSize, e);
			maxSize = 1;
		}

		String expiryTime = propertyManager.getProperty(BAConstants.ALERTS_CACHE_EXPIRY_PERIOD);
		int expiryTimeVal;
		try {
			expiryTimeVal = Integer.parseInt(expiryTime);
		} catch (NumberFormatException e) {
			logger.info("Number Format Exception while getting expiryTimeVal {} {} ", expiryTime, e);
			expiryTimeVal = 20;
		}


		logger.info("Building cache for all alerts maxSize {}", maxSize);

		alertsCache = createCacheBuilder(maxSize, expiryTimeVal).build(alertsCacheLoader);
	}

	private void createUIMetadataCache() {
		String cacheMaxSize = propertyManager.getProperty(BAConstants.UI_METADATA_CACHE_MAXIMUM_SIZE);
		int maxSize;
		try{
		 maxSize = Integer.parseInt(cacheMaxSize);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting cacheMaxSize {} {} ",cacheMaxSize , e);
			maxSize = 50;
		}
		
		String expiryTime = propertyManager.getProperty(BAConstants.UI_METADATA_CACHE_EXPIRY_PERIOD);
		int expiryTimeVal;
		try{
			expiryTimeVal = Integer.parseInt(expiryTime);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting expiryTimeVal {} {} ",expiryTime , e);
			expiryTimeVal = 1;
		}
		
		
		logger.info("Building cache in createOpportunitiesCache maxSize {}",maxSize);
		
		metadataCache =  CacheBuilder.newBuilder().maximumSize(maxSize).expireAfterWrite(expiryTimeVal, TimeUnit.DAYS)
						.build(metadataCacheLoader);
	}

	private void createLeadOwnerCache(){
		String cacheMaxSize = propertyManager.getProperty(BAConstants.LEAD_OWNER_CACHE_MAXIMUM_SIZE);
		int maxSize;
		try{
			maxSize = Integer.parseInt(cacheMaxSize);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting cacheMaxSize {} {} ",cacheMaxSize , e);
			maxSize = 1000;
		}

		String expiryTime = propertyManager.getProperty(BAConstants.LEAD_OWNER_CACHE_EXPIRY_PERIOD_IN_MINUTES);
		int expiryTimeVal;
		try{
			expiryTimeVal = Integer.parseInt(expiryTime);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting expiryTimeVal {} {} ",expiryTime , e);
			expiryTimeVal = 1;
		}


		logger.info("Building cache for lead owner with maxSize {}",maxSize);

		leadOwnerCache = CacheBuilder.newBuilder().maximumSize(maxSize).expireAfterWrite(expiryTimeVal,TimeUnit.MINUTES).build(leadOwnerCacheLoader);
	}

	private void createAccountIdsCache(){
		String cacheMaxSize = propertyManager.getProperty(BAConstants.ACCOUNTID_CACHE_MAXIMUM_SIZE);
		int maxSize;
		try{
			maxSize = Integer.parseInt(cacheMaxSize);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting cacheMaxSize {} {} ",cacheMaxSize , e);
			maxSize = 1000;
		}

		String expiryTime = propertyManager.getProperty(BAConstants.ACCOUNTID_CACHE_EXPIRY_PERIOD);
		int expiryTimeVal;
		try{
			expiryTimeVal = Integer.parseInt(expiryTime);
		}
		catch(NumberFormatException e){
			logger.info("Number Format Exception while getting expiryTimeVal {} {} ",expiryTime , e);
			expiryTimeVal = 12;
		}


		logger.info("Building cache for accountIds with maxSize {}",maxSize);

		accountIdsCache = CacheBuilder.newBuilder().maximumSize(maxSize).expireAfterWrite(expiryTimeVal,TimeUnit.HOURS).build(accountIdCacheLoader);
	}

    private void createleadsCache() {
        String cacheMaxSize = propertyManager.getProperty(BAConstants.LEADS_CACHE_MAXIMUM_SIZE);
        int maxSize;
        try{
            maxSize = Integer.parseInt(cacheMaxSize);
        }
        catch(NumberFormatException e){
            logger.info("Number Format Exception while getting cacheMaxSize {} {} ",cacheMaxSize , e);
            maxSize = 1;
        }

        String expiryTime = propertyManager.getProperty(BAConstants.LEADS_CACHE_EXPIRY_PERIOD);
        int expiryTimeVal;
        try{
            expiryTimeVal = Integer.parseInt(expiryTime);
        }
        catch(NumberFormatException e){
            logger.info("Number Format Exception while getting expiryTimeVal {} {} ",expiryTime , e);
            expiryTimeVal = 5;
        }


        logger.info("Building cache in createleadsCache maxSize {}",maxSize);

        leadsCache = createCacheBuilder(maxSize,expiryTimeVal).build(leadsResponseCacheLoader);
        
        logger.info("Cache in createleadsCache. {} .",leadsCache);
    }

}
