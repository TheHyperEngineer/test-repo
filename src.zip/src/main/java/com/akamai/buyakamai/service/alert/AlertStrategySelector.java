package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.enums.BundleEventProcessorCategory;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertDefinition;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.AlertRepository;
import com.akamai.buyakamai.service.common.cache.DBEntitiesCache;
import com.akamai.buyakamai.service.impl.BundleServiceImpl;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import org.apache.commons.lang3.EnumUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
public class AlertStrategySelector {
	
    private static Logger logger = LoggerFactory.getLogger(AlertStrategySelector.class);

    @Autowired
    private AlertRepository alertRepository;
    
	@Autowired
	protected DBEntitiesCache dbEntitiesCache;

	@Autowired
	private TnCAlertStrategy tncAlertStrategy;

	@Autowired
	private TrialExpiringAlertStrategy trialExpiringAlertStrategy;

	@Autowired
	private TrialExpiredAlertStrategy trialExpiredAlertStrategy;

	@Autowired
	private ValueConfirmationAlertStrategy valueConfirmationAlertStrategy;

	@Autowired
	private TrialExtensionAlertStrategy trialExtensionAlertStrategy;

	@Autowired
	private BundleServiceImpl bundleService;

	@Autowired
	private OrderServiceImpl orderService;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void processAlertsForOrder(SelectOrderResponse order, Map<Integer, List<EventData>> eventMap) {

		Integer orderId = order.getOrderId();
		logger.info("Processing alerts for orderId: {}", orderId);

		List<AlertEntity> alerts = alertRepository.findByOrderId(orderId);
		List<EventData> events = (eventMap.get(order.getOrderId()) != null) ?
				eventMap.get(order.getOrderId()) : new ArrayList<>();


		//need to run this strategy out side
		trialExpiredAlertStrategy.processAlertsForOrder(order, events, alerts);

		if (!(hasOrderAlreadyReachedLastStage(alerts) || orderService.isOrderCancelled(order))) {

			tncAlertStrategy.processAlertsForOrder(order, events, alerts);
			if (order.getBundleId() != null) {

				//product specific alert processing starts here
				String processorCategory = bundleService.getEventProcessorCategory(order.getBundleId());
				if (processorCategory != null && EnumUtils.isValidEnum(BundleEventProcessorCategory.class,
						processorCategory.toUpperCase())) {
					BundleEventProcessorCategory.valueOf(processorCategory.toUpperCase()).processAlerts(order, events, alerts);
				}
				valueConfirmationAlertStrategy.processAlertsForOrder(order, events, alerts);
			}
				//run following strategies for add on product type
			handleTrialExtensionAlertStrategy(order, alerts, events);
			trialExpiringAlertStrategy.processAlertsForOrder(order, events, alerts);
		}

		logger.info("Processed alerts for orderId: {} successfully", orderId);
	}

	private void handleTrialExtensionAlertStrategy(SelectOrderResponse order, List<AlertEntity> alerts, List<EventData> events) {
			trialExtensionAlertStrategy.processAlertsForOrder(order, events, alerts);
	}


    private boolean hasOrderAlreadyReachedLastStage(List<AlertEntity> alerts) {
		return alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			return ( alertDef.getName() == AlertDefName.TRIAL_EXPIRED );
		}).findAny().isPresent();
    }
}
