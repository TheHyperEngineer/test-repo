package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.controller.model.OrderAlertsDto;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.service.common.AlertServiceImpl;
import com.akamai.buyakamai.service.impl.EntityHelper;
import com.google.common.cache.CacheLoader;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

@Component
public class AlertsCacheLoader extends CacheLoader<String, List<OrderAlertsDto>> {

    private static final Logger logger = LoggerFactory.getLogger(AlertsCacheLoader.class);

    @Autowired
    private EntityHelper entityHelper;

    @Autowired
    private AlertServiceImpl alertService;

    @Override
    public List<OrderAlertsDto> load(String state) throws Exception {
        logger.info("Refreshing alerts cache with key {}", state);
        return getAlertsOnCacheMiss(state);
    }

    private List<OrderAlertsDto> getAlertsOnCacheMiss(String state) {

        StopWatch timer = new StopWatch();

        timer.start("databaseResponse");
        List<AlertEntity> alertList = entityHelper.getAlertsForActiveOrders(state);
        timer.stop();

        timer.start("building response");
        List<OrderAlertsDto> responseList = alertService.buildAlertResponseForAlertEntities(alertList);
        timer.stop();

        logger.info("Performance for loading alerts cache is {}", timer.prettyPrint());
        return responseList;
    }



}
