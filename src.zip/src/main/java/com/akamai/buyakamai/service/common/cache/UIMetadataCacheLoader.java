package com.akamai.buyakamai.service.common.cache;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.UIMetadataEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.UIMetadataRepository;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.model.productmaster.ProductMasterKey;
import com.akamai.buyakamai.integration.model.productmaster.UIMetadataDTO;
import com.akamai.buyakamai.service.common.LocalizationServiceImpl;
import com.google.common.cache.CacheLoader;
import com.google.common.util.concurrent.UncheckedExecutionException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

@Component
@Transactional(propagation = Propagation.REQUIRES_NEW)
public class UIMetadataCacheLoader extends CacheLoader<ProductMasterKey, UIMetadataDTO> {
	
	private final static String EXCEPTION_MSG_PREFIX = "Localization text cannot be updated in metadata for  : ";
	
	@Autowired
	public UIMetadataRepository metadataRepository;

	@Autowired
	private LocalizationServiceImpl localizationService;


	private UIMetadataDTO emptyMetadataDTO = new UIMetadataDTO();

	private static final Logger logger = LoggerFactory.getLogger(UIMetadataCacheLoader.class.getName());

	@Override
	public UIMetadataDTO load(ProductMasterKey productMasterKey) throws BuyAkamaiApplicationException {
		logger.info("Metadata cache entry for key:{}  does not exist. Need to retrieve Metadata from DB",
				productMasterKey);
		return getMetadataOnCacheMiss(productMasterKey).orElse(emptyMetadataDTO);
	}

	private Optional<UIMetadataDTO> getMetadataOnCacheMiss(ProductMasterKey productMasterKey) throws BuyAkamaiApplicationException 
	{
		UIMetadataDTO uiMetadataDTO = null;
		uiMetadataDTO = getUIMetadata(productMasterKey.getBundleId(), productMasterKey.getLocale());

		return Optional.of(uiMetadataDTO);
	}

	private UIMetadataDTO getUIMetadata(String bundleId, String locale) throws BuyAkamaiApplicationException {
		// get metadata from database
		UIMetadataEntity metadataEntity = null;
		metadataEntity = metadataRepository.findByBundleId(bundleId);

		if(null == metadataEntity){
			throw new BuyAkamaiApplicationException("Error while fetching metadata","Metadata does not exist for "+bundleId,HttpStatus.BAD_REQUEST);
		}
		
		try {

			// construct responseJson
			logger.info("fetched  metadata from db for bundle id {}", bundleId);
			String metadataJson = metadataEntity.getMetaDataJson();
			logger.info("fetched  metadata from db {}", metadataJson);
			JsonParser gsonParser = new JsonParser();
			JsonElement metadataJsonElement = gsonParser.parse(metadataJson);
			logger.info("converted to jsonElement {}", metadataJsonElement);
			//List<String> tagValues = getTagValues(metadataJson);
			//logger.info("tagValues {}", tagValues);

		/*	for (String tagValue : tagValues) {
				String localisationKey = tagValue.replace(BAConstants.METADATA_JSON_DOUBLE_QUOTES, "")
						.trim();
				String localizationText = getLocalizedMetadataContent(locale, localisationKey);
				if (StringUtils.isBlank(localizationText)) {
					throw new BuyAkamaiApplicationException("Error while fetching metadata",EXCEPTION_MSG_PREFIX+bundleId+" "+localisationKey+" "+locale,HttpStatus.INTERNAL_SERVER_ERROR);
				}
				putJsonValue(localisationKey, localizationText,
						metadataJsonElement);
			}*/
			Gson gson = new GsonBuilder().disableHtmlEscaping().create();
			String updatedMetadataJson =  gson.toJson(metadataJsonElement);
			logger.info("updatedMetadataJson {}", updatedMetadataJson);
			return new UIMetadataDTO(updatedMetadataJson, locale);
		} catch (Exception exception) {
			logger.error("Unable to retrieve ui-metadata since {} {} ", exception.getMessage(), exception);
			Map<String, String> excData = new HashMap<>();
			excData.put("bundleId", bundleId);
			excData.put("Locale", locale);
			//TODO DB Logging
			throw new BuyAkamaiApplicationException("Unable to retrieve ui-metadata since "+exception.getClass().getSimpleName(),"Error while fetching metadata", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	private void putJsonValue(String key, String localisationText, JsonElement jsonElement) {
		if (jsonElement.isJsonArray()) {
			for (JsonElement jsonArrayElement : jsonElement.getAsJsonArray()) {
				 putJsonValue(key, localisationText, jsonArrayElement);
			}
		} else {
			if (jsonElement.isJsonObject()) {
				Set<Map.Entry<String, JsonElement>> entrySet = jsonElement.getAsJsonObject().entrySet();
				for (Map.Entry<String, JsonElement> entry : entrySet) {
					String key1 = entry.getKey();
					if (key1.equals(key)) {
						entry.setValue(new JsonPrimitive(localisationText));
						logger.debug("new entry made {}:{}", entry.getKey(), entry.getValue().toString());
					}
					putJsonValue(key, localisationText, entry.getValue());
				}
			}
		}
	}

	private String getLocalizedMetadataContent(String locale, String key) {
		String localizationText = "";
		try {
			logger.debug("key{} locale{}", key, locale);
			localizationText = localizationService.getLocalizedContent(key, locale);
		} catch (BuyAkamaiApplicationException e) {
			logger.error("localization not found for key:{} for locale {} since {} ", key, locale, e);
		}
		return localizationText;
	}

	private List<String> getTagValues(final String str) {
		final Pattern TAG_REGEX = Pattern.compile(BAConstants.METADATA_LOCALE_REGEX);
		final List<String> tagValues = new ArrayList<>();
		final Matcher matcher = TAG_REGEX.matcher(str);
		while (matcher.find()) {
			tagValues.add(matcher.group(1));
		}
		return tagValues;
	}
}
