package com.akamai.buyakamai.service.alert;

import java.util.List;

public interface AlertActionFetcher {

    List<String> evaluateAction(int alertId, List<String> baRole, String actions);
}
