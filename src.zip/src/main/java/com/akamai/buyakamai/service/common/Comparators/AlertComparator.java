package com.akamai.buyakamai.service.common.Comparators;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.controller.model.Alert;
import com.akamai.buyakamai.util.CommonUtils;

import java.util.Comparator;
import java.util.Date;

public class AlertComparator implements Comparator<Alert> {

    @Override
    public int compare(Alert a, Alert b) {
        Date aDate ,bDate;
        aDate = CommonUtils.parseTimestamp(a.getDate(), BAConstants.DATE_FORMAT_FOR_GET_EVENTS);
        bDate = CommonUtils.parseTimestamp(b.getDate(), BAConstants.DATE_FORMAT_FOR_GET_EVENTS);
        return aDate.compareTo(bDate);
    }
}
