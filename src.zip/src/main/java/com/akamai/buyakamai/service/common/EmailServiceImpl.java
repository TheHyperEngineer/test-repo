package com.akamai.buyakamai.service.common;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.EmailState;
import com.akamai.buyakamai.constants.NotificationEmailStatus;
import com.akamai.buyakamai.constants.PulsarConstants;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.EmailEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.EmailRepository;
import com.akamai.buyakamai.integration.clients.impl.PulsarHttpClient;
import com.akamai.buyakamai.integration.clients.model.EmailDTO;
import com.akamai.buyakamai.integration.clients.model.EmailNotificationResponse;
import com.akamai.buyakamai.integration.clients.model.EmailStatusResponse;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObject;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObjectBuilder;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;


@Service
@Transactional(propagation = Propagation.REQUIRED)
public class EmailServiceImpl {

    @Autowired
    private PulsarHttpClient pulsarHttpClient;

    @Autowired
    private EmailRepository emailRepository;

    @Autowired
    private PropertyManager propertyManager;

    private static final Logger logger = LoggerFactory.getLogger(EmailServiceImpl.class);

    private static final String PERSISTENT = "persistent";
    private static final String TRUE = "true";

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void sendEmail( EmailDTO emailDTO, String userName) throws Exception {
        try {
	        String urlSuffix = propertyManager.getProperty(PulsarConstants.NOTIFICATION_SERVICE_URL_SUFFIX);
	        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
	        queryParams.add(PERSISTENT, TRUE);
	        HttpRequestObject<EmailNotificationResponse> requestBuilder = new HttpRequestObjectBuilder<EmailNotificationResponse>()
	                .responseClass(EmailNotificationResponse.class).urlSuffix(urlSuffix).method(HttpMethod.POST)
	                .requestObject(emailDTO).queryParams(queryParams).build();
	        EmailNotificationResponse emailNotification = pulsarHttpClient.call(requestBuilder);
            logger.debug("Response :  {}", emailNotification);
	        if ( (emailNotification != null) && StringUtils.isNotBlank(emailNotification.getMessageId()) ) {
	        	logger.info("Successfully queued email with message id: {}", emailNotification.getMessageId());
	        	this.persistEmail(emailDTO, emailNotification.getMessageId(), EmailState.QUEUED, userName);
	        } else {
	        	logger.info("Failed while sending email. Persisting to process later...");
	        	this.persistEmail(emailDTO, null, EmailState.FAILED, userName);
	        }

        } catch (Exception exception) {
            String msg = "Exception while sending Email";
        	logger.error(msg, exception);
        	this.persistEmail(emailDTO, null, EmailState.FAILED, userName);
			throw exception;
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void resendEmail(EmailEntity email) throws Exception {
        try {
            String urlSuffix = propertyManager.getProperty(PulsarConstants.RESEND_EMAIL_URL_SUFFIX);
            urlSuffix = urlSuffix.replace("{messageId}", email.getMessageId());
            HttpRequestObject<EmailNotificationResponse> builder = new HttpRequestObjectBuilder<EmailNotificationResponse>().
                    responseClass(EmailNotificationResponse.class).urlSuffix(urlSuffix)
                    .method(HttpMethod.POST).build();
            EmailNotificationResponse emailNotification = pulsarHttpClient.call(builder);
            logger.info("Resend done for messageId = " + emailNotification.getMessageId());
            email.setState(EmailState.QUEUED);
			emailRepository.save(email);
        } catch (Exception exception) {
            String msg = "Unable to resend email with messageid: " + email.getMessageId();
            logger.error(msg, exception);
        }
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
	public String checkEmailStatus(EmailEntity email) {
		logger.info("Checking email Status");
		try {
			String urlSuffix = propertyManager.getProperty(PulsarConstants.EMAIL_STATUS_URL_SUFFIX);
            urlSuffix = urlSuffix.replace("{messageId}", email.getMessageId());
			HttpRequestObject<EmailStatusResponse> builder = new HttpRequestObjectBuilder<EmailStatusResponse>()
			        .responseClass(EmailStatusResponse.class).urlSuffix(urlSuffix).method(HttpMethod.GET).build();
			EmailStatusResponse statusResponse =  pulsarHttpClient.call(builder);
			if ( statusResponse.getStatus() != null ) {
				return statusResponse.getStatus();
			}
		} catch (Exception exception) {
			String msg = "Unable to get status for email with messageId: " + email.getMessageId();
			logger.error(msg, exception);
		}
		return NotificationEmailStatus.QUEUED.name();
	}
    
    @Transactional(propagation = Propagation.REQUIRES_NEW)
	public List<EmailEntity> fetchEmailsToProcess() {
		 return emailRepository.findByStateIn(Arrays.asList(EmailState.FAILED, EmailState.QUEUED));
    }
	
    @Transactional(propagation = Propagation.REQUIRES_NEW)
	public void updateEmailEntityStatus(EmailEntity email, EmailState state) {
    	email.setState(state);
    	emailRepository.save(email);
	}

	private void persistEmail(EmailDTO emailDto, String messageId, EmailState state, String userName) {
	    EmailEntity email = new EmailEntity();
	    email.setBody(emailDto.getHtmlBody());
	    email.setSubject(emailDto.getSubject());
	    email.setTo(propertyManager.getProperty(BAConstants.ASSISTANCE_TO_LIST_KEY));
	    email.setCc(propertyManager.getProperty(BAConstants.ASSISTANCE_CC_LIST_KEY));
	    email.setFrom(emailDto.getFrom());
	    email.setMessageId(messageId);
	    email.setState(state);
	    email.setSentByUserId(userName);
	    email.setSentTime(new Date());
	    email.setMessageId(messageId);
	    emailRepository.save(email);
	}
	
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void resendBAFailedEmail(EmailEntity emailEntity) throws Exception {
        try {
        	EmailDTO emailDTO = this.buildEmailDTO(emailEntity);
	        String urlSuffix = propertyManager.getProperty(PulsarConstants.NOTIFICATION_SERVICE_URL_SUFFIX);
	        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
	        queryParams.add(PERSISTENT, TRUE);
	        HttpRequestObject<EmailNotificationResponse> requestBuilder = new HttpRequestObjectBuilder<EmailNotificationResponse>()
	                .responseClass(EmailNotificationResponse.class).urlSuffix(urlSuffix).method(HttpMethod.POST)
	                .requestObject(emailDTO).queryParams(queryParams).build();
	        EmailNotificationResponse emailNotification = pulsarHttpClient.call(requestBuilder);
            logger.debug("Response :  {}", emailNotification);
	        if ( (emailNotification != null) && StringUtils.isNotBlank(emailNotification.getMessageId()) ) {
	        	logger.info("Successfully queued email with message id: {}", emailNotification.getMessageId());
	        	emailEntity.setState(EmailState.QUEUED);
	        	emailEntity.setMessageId(emailNotification.getMessageId());
	        	emailRepository.save(emailEntity);
	        }
        } catch (Exception exception) {
            String msg = "Exception while sending Email";
        	logger.error(msg, exception);
        }
    }
    
    private EmailDTO buildEmailDTO(EmailEntity email) {
    	EmailDTO emailDTO = new EmailDTO();
    	emailDTO.setHtmlBody(email.getBody());
    	emailDTO.setTo(CommonUtils.convertCommaSeparatedStringToList(email.getTo()));
    	if ( !StringUtils.isBlank(email.getCc()) ) {
    		emailDTO.setCc(CommonUtils.convertCommaSeparatedStringToList(email.getCc()));
    	}
    	emailDTO.setSubject(email.getSubject());
    	emailDTO.setFrom(email.getFrom());
    	return emailDTO;
    }
    

}