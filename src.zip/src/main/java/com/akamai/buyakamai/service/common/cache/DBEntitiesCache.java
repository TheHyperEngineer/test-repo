package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.ConfigConstants;
import com.akamai.buyakamai.constants.HistoryDefName;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertDefinition;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.HistoryDefinition;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.AlertDefinitionRepository;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.HistoryDefinitionRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import javax.annotation.PostConstruct;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Component
@Scope("singleton")
@Transactional(propagation = Propagation.REQUIRED, transactionManager = ConfigConstants.TXM_BUY_AKAMAI)
public class DBEntitiesCache {

    private static final Logger logger = LoggerFactory.getLogger(DBEntitiesCache.class);

    private static Map<Integer, AlertDefinition> alertDefMap = null;

    private static Map<String, AlertDefinition> alertDefNameTypeMap = null;
    
    @Autowired
    private AlertDefinitionRepository alertDefinitionRepo;
    
    private static Map<Integer, HistoryDefinition> historyDefMap = null;

    private static Map<String, HistoryDefinition> historyDefNameTypeMap = null;
    
    @Autowired
    private HistoryDefinitionRepository historyDefinitionRepo;

    @PostConstruct
    public void loadAlertDefsFromDb() {
        logger.info("Loading alert definitions from ALERT_DEFINITION table");
        try {
            Iterator<AlertDefinition> alertDefs = alertDefinitionRepo.findAll().iterator();
            Map<Integer, AlertDefinition> tempAlertDefMap = new HashMap<>();
            Map<String, AlertDefinition> tempAlertDefNameTypeMap = new HashMap<>();
            while ( alertDefs.hasNext() ) {
            	AlertDefinition alertDef = alertDefs.next();
            	tempAlertDefMap.put(alertDef.getId(), alertDef);
            	tempAlertDefNameTypeMap.put(alertDef.getName() + alertDef.getType().toUpperCase(), alertDef);
            }
            alertDefMap = Collections.unmodifiableMap(tempAlertDefMap);
            alertDefNameTypeMap = Collections.unmodifiableMap(tempAlertDefNameTypeMap);
        } catch (Exception e) {
            logger.error("could not load alerts", e);
            throw e;
        }
    }

    @PostConstruct
    public void loadHistoryDefsFromDb() {
        logger.info("Loading history definitions from EVENT_HISTORY_DEFINITION table");
        try {
            Iterator<HistoryDefinition> historyDefs = historyDefinitionRepo.findAll().iterator();
            Map<Integer, HistoryDefinition> tempHistoryDefMap = new HashMap<>();
            Map<String, HistoryDefinition> tempHistoryDefNameTypeMap = new HashMap<>();
            while ( historyDefs.hasNext() ) {
            	HistoryDefinition historyDef = historyDefs.next();
            	tempHistoryDefMap.put(historyDef.getId(), historyDef);
            	tempHistoryDefNameTypeMap.put(historyDef.getName() + historyDef.getTrialType().toUpperCase(), historyDef);
            }
            historyDefMap = Collections.unmodifiableMap(tempHistoryDefMap);
            historyDefNameTypeMap = Collections.unmodifiableMap(tempHistoryDefNameTypeMap);
        } catch (Exception e) {
            logger.error("could not load history definitions", e);
            throw e;
        }
    }

    public AlertDefinition getAlertDefintion(Integer alertDefId) {
        return alertDefMap.get(alertDefId);
    }

    public AlertDefinition getAlertDefintion(AlertDefName alertDefName, String type) {
        return alertDefNameTypeMap.get(alertDefName.name() + type.toUpperCase());
    }
    
    public HistoryDefinition getHistoryDefintion(Integer historyDefId) {
        return historyDefMap.get(historyDefId);
    }

    public HistoryDefinition getHistoryDefintion(HistoryDefName historyDefName, String type) {
        return historyDefNameTypeMap.get(historyDefName.name() + type.toUpperCase());
    }
}
