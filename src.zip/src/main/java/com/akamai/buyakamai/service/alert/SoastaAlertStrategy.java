package com.akamai.buyakamai.service.alert;

import com.akamai.buyakamai.constants.*;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.HistoryEntity;
import com.akamai.buyakamai.service.history.HistoryActionsImpl;
import com.akamai.buyakamai.util.CommonUtils;
import org.joda.time.DateTime;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Component("SoastaAlertStrategy")
@Transactional(propagation = Propagation.REQUIRED)
public class SoastaAlertStrategy extends AlertStrategy {

    private static final Logger logger = LoggerFactory.getLogger(SoastaAlertStrategy.class);

    @Autowired
    private HistoryActionsImpl historyActions;

    @Override
    public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        logger.info("Processing alert for SOASTA category with order id {}", order.getOrderId());
        processAlertForAppCreation(order, events, alerts);
        processEdgeInjectionAlert(order, events, alerts);
        processAlertForBeaconNotReceived(order, events, alerts);
        processAlertForDashboardLogin(order, events, alerts);
        processAlertForMpulseAppLogin(order, events, alerts);
    }

    private void processAlertForAppCreation(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        //check if order event doesn't exist and alert is not yet created
        if (!orderEventsService.isMpulseAppCreated(events) && !refreshAlertIfPresent(alerts, AlertDefName.MPULSE_APP_NOT_CREATED)) {

            //should be processed only if sign up success is happened
            Optional<HistoryEntity> historyEntity = historyActions.getHistoryEntityByName(HistoryDefName.TNC_ACCEPTED, order);

            if (historyEntity.isPresent()) {
                Date eventDate = historyEntity.get().getEventTime();
                int days = CommonUtils.calculateDaysBetweenDate(new LocalDate(eventDate), new LocalDate()) + 1;
                if (days > Integer.parseInt(propertyManager.getProperty(MpulseConstants.SOASTA_APP_ALERT_INTERVAL))) {
                    String longDescription = order.getAccount().getAccountName();
                    addNewAlert(order, AlertDefName.MPULSE_APP_NOT_CREATED, new Date(), AlertState.ACTIVE, longDescription);
                    logger.info("Added alert for mpulse not yet created with order Id {}", order.getOrderId());
                }
            }
        }
        //clear the alert if present
        if (orderEventsService.isMpulseAppCreated(events)) {
            clearAlertsIfPresent(alerts, Collections.singletonList(AlertDefName.MPULSE_APP_NOT_CREATED));
            logger.info("cleared alert for mpulse not yet created with order Id {}", order.getOrderId());
        }
    }

    private void processAlertForBeaconNotReceived(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        if (!orderEventsService.isFirstBeaconPushed(events) && !refreshAlertIfPresent(alerts, AlertDefName.BEACON_NOT_PUSHED)) {

            //this alert needs to be processed only if MPULSE APP is CREATED
            List<EventData> eventDataList = orderEventsService.filterEventDataForEventType(OrderEventAction.MPULSE_APP_ENABLED, events);
            if (!eventDataList.isEmpty()) {
                Date eventDate = CommonUtils.formatEventDate(eventDataList.get(0)).toDate();
                int days = CommonUtils.calculateDaysBetweenDate(new LocalDate(eventDate), new LocalDate()) + 1;
                if (days > Integer.parseInt(propertyManager.getProperty(MpulseConstants.SOASTA_BEACON_ALERT_INTERVAL))) {
                    addNewAlert(order, AlertDefName.BEACON_NOT_PUSHED, new Date(), AlertState.ACTIVE, order.getAccount().getAccountName());
                    logger.info("Added alert for first beacon not yet received with order Id {}", order.getOrderId());
                }
            }
        }
        //clear the alert if present
        if (orderEventsService.isFirstBeaconPushed(events)) {
            clearAlertsIfPresent(alerts, Collections.singletonList(AlertDefName.BEACON_NOT_PUSHED));
            logger.info("cleared alert for first beacon not yet received with order Id {}", order.getOrderId());
        }
    }

    private void processAlertForDashboardLogin(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        //check if mpulse app is created, if its created check for alerts
        if (orderEventsService.isMpulseAppCreated(events)) {
            int eventDifferenceDays;
            Date dateToConsider;
            EventData eventData;

            //first login might not have been happened for that we need to consider mpulse app created time
            List<EventData> eventDataList = orderEventsService.filterEventDataForEventType(OrderEventAction.MPULSE_DASHBOARD_LOGIN, events);
            if (eventDataList.isEmpty()) {
                eventData = orderEventsService.filterEventDataForEventType(OrderEventAction.MPULSE_APP_CREATED, events).get(0);
                dateToConsider = CommonUtils.formatEventDate(eventData).toDate();
            } else {
                //if first login is already happened then should consider event data
                eventData = eventDataList.get(0);
                String loginTime = eventData.getData().get(MpulseConstants.DASHBOARD_LOGIN_TIMESTAMP_KEY);
                dateToConsider = CommonUtils.parseTimestamp(loginTime, BAConstants.DATE_FORMAT_FOR_GET_EVENTS);
            }

            eventDifferenceDays = CommonUtils.calculateDaysBetweenDate(new LocalDate(dateToConsider), new LocalDate());

            if (eventDifferenceDays < Integer.parseInt(propertyManager.getProperty(MpulseConstants.SOASTA_DASHBOARD_LOGIN_INTERVAL))) {
                deleteAlertIfPresent(alerts, AlertDefName.MPULSE_DASHBOARD_LOGIN);
                logger.info("Deleted alert for dashboard login with order Id {}", order.getOrderId());
            } else {
                if (!refreshAlertIfPresent(alerts, AlertDefName.MPULSE_DASHBOARD_LOGIN)) {
                    addNewAlert(order, AlertDefName.MPULSE_DASHBOARD_LOGIN, new Date(), AlertState.ACTIVE,
                            order.getAccount().getAccountName());
                    logger.info("added mpulse dashboard login alert for orderId {}", order.getOrderId());
                }
            }
        }
    }

    private void processAlertForMpulseAppLogin(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        //check if mpulse app is created, if its created check for alerts
        if (orderEventsService.isMpulseAppCreated(events)) {
            int eventDifferenceDays;
            Date dateToConsider;
            EventData eventData;

            //first login might not have been happened for that we need to consider mpulse app created time
            List<EventData> eventDataList = orderEventsService.filterEventDataForEventType(OrderEventAction.MPULSE_USER_LOGIN, events);
            if (eventDataList.isEmpty()) {
                eventData = orderEventsService.filterEventDataForEventType(OrderEventAction.MPULSE_APP_CREATED, events).get(0);
                dateToConsider = CommonUtils.formatEventDate(eventData).toDate();
            } else {
                //if first login is already happened then should consider event data
                eventData = eventDataList.get(0);
                String loginTime = eventData.getData().get(MpulseConstants.MPULSE_APP_LOGIN_TIMESTAMP_KEY);
                dateToConsider = CommonUtils.parseTimestamp(loginTime, BAConstants.DATE_FORMAT_FOR_GET_EVENTS);
            }

            eventDifferenceDays = CommonUtils.calculateDaysBetweenDate(new LocalDate(dateToConsider), new LocalDate());

            //get min val of the string
            String alertInterval = propertyManager.getProperty(MpulseConstants.SOASTA_APP_LOGIN_INTERVAL);
            List<String> alertIntervalsList = CommonUtils.convertCommaSeparatedStringToList(alertInterval);
            List<Integer> alertIntegerList = new ArrayList<>();
            alertIntervalsList.stream().forEach(v -> alertIntegerList.add(Integer.parseInt(v)));

            Optional<Integer> minValue = alertIntegerList.stream().min(Comparator.naturalOrder());

            if (eventDifferenceDays < minValue.get()) {
                deleteAlertIfPresent(alerts, AlertDefName.MPULSE_SITE_LOGIN);
                logger.info("Deleted alert for mpulse app login with order Id {}", order.getOrderId());
            } else {
                int daysToSet = getSuitableAlertDays(eventDifferenceDays, alertIntegerList);
                if (!refreshAlertIfPresent(alerts, AlertDefName.MPULSE_SITE_LOGIN)) {
                    //add new alert if not present
                    addNewAlert(order, AlertDefName.MPULSE_SITE_LOGIN, new Date(), AlertState.ACTIVE,
                            order.getAccount().getAccountName() + BAConstants.ALERTS_DESC_ARGS_SEPARATOR + daysToSet);
                    logger.info("added new alert for mpulse app login with order Id {}", order.getOrderId());
                } else {
                    Optional<AlertEntity> entity = fetchAlertForDefinition(alerts, AlertDefName.MPULSE_SITE_LOGIN);
                    if (!entity.get().getDescriptionArgs().split(BAConstants.ALERTS_DESC_ARGS_SEPARATOR)[1].equalsIgnoreCase(String.valueOf(daysToSet))) {
                        //refresh the existing alert as number of days increased
                        String longDesc = order.getAccount().getAccountName() +
                                BAConstants.ALERTS_DESC_ARGS_SEPARATOR + daysToSet;
                        logger.info("updating alert for mpulse app login with order Id {}", order.getOrderId());
                        updateDescriptionOfExistingAlert(alerts, AlertDefName.MPULSE_SITE_LOGIN, longDesc);
                    }
                }
            }
        }
    }

    private int getSuitableAlertDays(Integer eventDifferenceDays, List<Integer> alertIntegerList) {
        int suitableDays = 0;
        for (Integer unit : alertIntegerList) {
            if (unit > eventDifferenceDays) break;
            suitableDays = unit;
        }
        return suitableDays;
    }

    @Override
    protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
        return null;
    }

	/**
	 * process soasta alert for events - edgeInjectionEnabled and mPulseAppCreated
	 * @param order
	 * @param events
	 * @param alerts
	 */
	private void processEdgeInjectionAlert(SelectOrderResponse order, List<EventData> events,
			List<AlertEntity> alerts) {

		if (orderEventsService.isMpulseAppEnabled(events)) {
			clearAlertsIfPresent(alerts, Collections.singletonList(AlertDefName.INSIGHT_EDGE_INJECTION));
		} else {
			List<EventData> mpulseAppCreatedEvent = orderEventsService.filterEventDataForEventType(OrderEventAction.MPULSE_APP_CREATED, events);
			if (!mpulseAppCreatedEvent.isEmpty()) {
				//process alert after 1 day of app has been created
				DateTime eventCreatedate = CommonUtils.formatEventDate(mpulseAppCreatedEvent.get(0));
				LocalDate today = LocalDate.now();
				if(CommonUtils.calculateDaysBetweenDate(eventCreatedate.toLocalDate(), today) >= Integer.parseInt(propertyManager.getProperty(MpulseConstants.MPULSE_APP_ENABLED_ALERT_INTERVAL))) {
					processEdgeInjectionNotEnabledAlert(order, alerts);
				}
			}
		}
	}

	/**
	 * this method will create a new alert(if not present) for INSIGHT_EDGE_INJECTION with ACTIVE state.
	 * @param order
	 * @param alerts
	 */
	private void processEdgeInjectionNotEnabledAlert(SelectOrderResponse order, List<AlertEntity> alerts) {
		if (refreshAlertIfPresent(alerts, AlertDefName.INSIGHT_EDGE_INJECTION)) {
			logger.info("Alert already processed: INSIGHT_EDGE_INJECTION for order id: " + order.getOrderId());
			return;
		} else {
			String longDescription = order.getAccount().getAccountName();
			addNewAlert(order, AlertDefName.INSIGHT_EDGE_INJECTION, new Date(), AlertState.ACTIVE, longDescription);
		}
	}
}
