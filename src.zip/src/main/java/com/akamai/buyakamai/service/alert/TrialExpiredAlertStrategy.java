package com.akamai.buyakamai.service.alert;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class TrialExpiredAlertStrategy extends AlertStrategy {

	private static Logger logger = LoggerFactory.getLogger(TrialExpiredAlertStrategy.class);
	
	@Autowired
	private OrderServiceImpl orderService;
	
	@Override
	public void processAlertsForOrder(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		if ( order.getEndDate() == null ) {
			logger.info("Skipping TRIAL_EXPIRED for order id: {} since its a quote", order.getOrderId());
			return;
		}
		handleTrialExpiredAlerts(order, events, alerts);
	}

	private void handleTrialExpiredAlerts(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		logger.info("Alert being processed: TRIAL_EXPIRED for order id: " + order.getOrderId());

		boolean hasTrialExpiredEventOccurred = orderService.isOrderExpired(order);

		if (hasTrialExpiredEventOccurred && !containsAlert(alerts, AlertDefName.TRIAL_EXPIRED)) {
			logger.info("Found TRIAL_EXPIRED event for order: " + order.getOrderId());
			Date eventDate = CommonUtils.formatOrderDate(order.getEndDate()).plusDays(1).toDate();
			AlertEntity alert = addNewAlert(order, AlertDefName.TRIAL_EXPIRED, eventDate, AlertState.ACTIVE, order.getAccount().getAccountName());
			alerts.add(alert);
			clearAlertsIfPresent(alerts, Arrays.asList(AlertDefName.TRIAL_EXPIRING));
		}

		if (!hasTrialExpiredEventOccurred) {
			//delete the alert if trial has not yet expired
			deleteAlertIfPresent(alerts, AlertDefName.TRIAL_EXPIRED);
		}

	}

	@Override
	protected LocalDate getPreviousEventDate(SelectOrderResponse order, List<EventData> events, List<AlertEntity> alerts) {
		AlertEntity previousAlert = findAlertByName(alerts, AlertDefName.TRIAL_EXPIRING).get();
		return new LocalDate(previousAlert.getCreatedTime());
	}
}
