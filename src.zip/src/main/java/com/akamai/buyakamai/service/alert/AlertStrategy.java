package com.akamai.buyakamai.service.alert;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.service.impl.OrderEventsServiceImpl;
import org.apache.commons.lang.StringUtils;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.AlertDefName;
import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.controller.model.EventData;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertDefinition;
import com.akamai.buyakamai.dataaccess.buyakamdb.repositories.AlertRepository;
import com.akamai.buyakamai.service.common.cache.DBEntitiesCache;
import com.akamai.buyakamai.util.PropertyManager;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public abstract class AlertStrategy {

    private static final Logger logger = LoggerFactory.getLogger(AlertStrategy.class);

    @Autowired
    protected DBEntitiesCache dbEntitiesCache;

    @Autowired
    protected AlertRepository alertRepo;

    @Autowired
    protected PropertyManager propertyManager;

    @Autowired
	protected OrderEventsServiceImpl orderEventsService;

    public abstract void processAlertsForOrder(SelectOrderResponse order,
                                               List<EventData> events, List<AlertEntity> alerts);

    protected abstract LocalDate getPreviousEventDate(SelectOrderResponse order,
                                                      List<EventData> events, List<AlertEntity> alerts);

    protected void clearAlertsIfPresent(List<AlertEntity> alerts, List<AlertDefName> alertDefs) {
        logger.debug("Clearing alerts ...");
        alerts.stream()
                .filter(alert -> alertDefs.contains(dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId()).getName())
                        && (alert.getState() != AlertState.COMPLETE))
                .map(alert -> {
                    alert.setState(AlertState.COMPLETE);
                    alertRepo.save(alert);
                    return true;
                }).collect(Collectors.toList());
    }

	protected void deleteAlertIfPresent(List<AlertEntity> alerts, AlertDefName alertDefName) {

		List<AlertEntity> alertsToDelete = findMultipleAlertByName(alerts, alertDefName);
		for(AlertEntity alertEntity: alertsToDelete){
			logger.info("Removing alert: {} ", alertDefName);
			alertRepo.delete(alertEntity);
		}
	}


	
	protected void addOrRefreshNotOccurredAlert(List<AlertEntity> alerts, SelectOrderResponse order,
			List<EventData> events, AlertDefName alertDefName, int waitDaysForAlert) {
		LocalDate eventDate = getPreviousEventDate(order, events, alerts);
		if ( containsAlert(alerts, alertDefName) ) {
			refreshAlert(alerts, order, alertDefName);
		} else if ( Days.daysBetween(eventDate, LocalDate.now()).getDays() >= waitDaysForAlert ) {
			AlertEntity alert = addNewAlert(order, alertDefName, eventDate.plusDays(waitDaysForAlert).toDate(),
					AlertState.ACTIVE, getDirectAccountOrPartnerName(order));
			alerts.add(alert);
		}
	}

	protected void performRefreshActionOnAlert(AlertEntity alert){
		AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
		if ( alertDef.getSnoozable() && (alert.getState() == AlertState.SNOOZED) ) {
			int snoozeDuration = ((alert.getSnoozeDuration() != null) && (alert.getSnoozeDuration() != 0))
					? alert.getSnoozeDuration() : alertDef.getDefaultSnoozeDuration();
			if (Days.daysBetween(new LocalDate(alert.getSnoozedTime()), LocalDate.now()).getDays() >= snoozeDuration ) {
				alert.setState(AlertState.ACTIVE);
				alert.setSnoozedTime(null);
				alertRepo.save(alert);
			}
		} else if ( alert.getState() == AlertState.ACKNOWLEDGED ) {
			int acknowledgeDuration = Integer.parseInt(propertyManager.getPropertyWithDeafultValue(BAConstants.ALERT_ACK_DURATION, "2"));
			if (Days.daysBetween(new LocalDate(alert.getSnoozedTime()), LocalDate.now()).getDays() >= acknowledgeDuration ) {
				alert.setState(AlertState.ACTIVE);
				alert.setSnoozedTime(null);
				alertRepo.save(alert);
			}
		}
	}

	protected void refreshAlert(List<AlertEntity> alerts, SelectOrderResponse order, AlertDefName alertDefName) {
		logger.info("Refreshing alert for order {} and alert {}", order.getOrderId(), alertDefName.name());
		AlertEntity alert = findAlertByName(alerts, alertDefName).get();
		performRefreshActionOnAlert(alert);
	}


	protected void refreshRecurringEventSnoozableAlert(List<AlertEntity> alerts, SelectOrderResponse order,
													   AlertDefName alertDefName, String descArgs) {
		AlertEntity alert = findAlertByName(alerts, alertDefName).get();
		AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
		if (alertDef.getSnoozable()) {
			int snoozeDuration = ((alert.getSnoozeDuration() != null) && (alert.getSnoozeDuration() != 0))
					? alert.getSnoozeDuration() : alertDef.getDefaultSnoozeDuration();
			if (Days.daysBetween(new LocalDate(alert.getCreatedTime()), LocalDate.now()).getDays() >= snoozeDuration) {
				alert.setState(AlertState.ACTIVE);
				alert.setSnoozedTime(null);
				alert.setCreatedTime(new Date());
				if (!StringUtils.isEmpty(descArgs)) {
					alert.setDescriptionArgs(descArgs);
				}

				alertRepo.save(alert);
			}
		}
	}

	protected void updateDescriptionOfExistingAlert(List<AlertEntity> alerts,
										AlertDefName alertDefName, String descArgs){
		AlertEntity alert = findAlertByName(alerts, alertDefName).get();
		alert.setDescriptionArgs(descArgs);
		alert.setState(AlertState.ACTIVE);
		alertRepo.save(alert);
	}

	@Transactional(propagation = Propagation.REQUIRES_NEW)
	protected void updateDescriptionOfAlert(AlertEntity alert, String caseId) {
		String updatedArgs = alert.getDescriptionArgs().replace(BAConstants.POC_FAILURE_ALERT_HISTORY_TEXT, caseId);
		alert.setDescriptionArgs(updatedArgs);
		alertRepo.save(alert);
	}

	protected Optional<AlertEntity> findAlertByName(List<AlertEntity> alerts, AlertDefName alertDefName) {
		
		return alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			return (alertDef.getName() == alertDefName );
		}).findFirst();
	}

	protected List<AlertEntity> findMultipleAlertByName(List<AlertEntity> alerts, AlertDefName alertDefName) {

		return alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			return (alertDef.getName() == alertDefName );
		}).collect(Collectors.toList());
	}

	protected boolean refreshAlertIfPresent(List<AlertEntity> alerts, AlertDefName alertDefName) {

		Optional<AlertEntity> alertEntity = alerts.stream().filter(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			return (alertDef.getName() == alertDefName);
		}).findFirst();

		if (alertEntity.isPresent()) {
			performRefreshActionOnAlert(alertEntity.get());
			return true;
		}
		return false;
	}

	protected boolean containsAlert(List<AlertEntity> alerts, AlertDefName alertDefName) {

		return alerts.stream().anyMatch(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			return ( alertDef.getName() == alertDefName );
		});
	}


	protected Optional<AlertEntity> fetchAlertForDefinition(List<AlertEntity> alerts, AlertDefName alertDefName) {

        return alerts.stream().filter((AlertEntity alert) -> {
            AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
            return (alertDef.getName() == alertDefName);
        }).findAny();
    }

	protected boolean containsAlertWithTimeStamp(List<AlertEntity> alerts, AlertDefName alertDefName, Date eventTime) {

		return alerts.stream().anyMatch(alert -> {
			AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alert.getAlertDefinitionId());
			return (alertDef.getName() == alertDefName && alert.getCreatedTime().getTime() == eventTime.getTime());
		});
	}

	protected void addOrRefreshNotOccurredAlert(List<AlertEntity> alerts, SelectOrderResponse order,
			List<EventData> events, AlertDefName alertDefName, int waitDaysForAlert, String descArgs) {
		LocalDate eventDate = getPreviousEventDate(order, events, alerts);
		if ( containsAlert(alerts, alertDefName) ) {
			refreshAlert(alerts, order, alertDefName);
		} else if ( Days.daysBetween(eventDate, LocalDate.now()).getDays() >= waitDaysForAlert ) {
			AlertEntity alert = addNewAlert(order, alertDefName, eventDate.plusDays(waitDaysForAlert).toDate(), AlertState.ACTIVE, descArgs);
			alerts.add(alert);
		}
	}
	protected AlertEntity addNewAlert(SelectOrderResponse order, AlertDefName alertDef, Date alertDate, AlertState state, String descArgs) {
		logger.info("Adding new alert for order {} and alert {}", order.getOrderId(), alertDef.name());
		AlertEntity newAlert = new AlertEntity();
		newAlert.setOrderId(order.getOrderId());
		newAlert.setAlertDefinitionId(dbEntitiesCache.getAlertDefintion(alertDef, order.getTrialType()).getId());
		newAlert.setState(state);
		if(!StringUtils.isEmpty(descArgs))
			newAlert.setDescriptionArgs(descArgs);
		newAlert.setCreatedTime(alertDate);
		alertRepo.save(newAlert);
		return newAlert;
	}

	protected String getDirectAccountOrPartnerName(SelectOrderResponse orderResponse) {

		if (orderResponse.getPartnerAccount() != null) {
			return orderResponse.getPartnerAccount().getAccountName();
		} else {
			return orderResponse.getAccount().getAccountName();
		}

	}
}
