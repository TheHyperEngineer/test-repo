package com.akamai.buyakamai.service.common.cache;

import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.controller.model.LeadDto;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.google.common.cache.LoadingCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.akamai.buyakamai.constants.BAConstants.LEAD_CACHE_KEY;

@Service
public class OrderSourceCachingServiceImpl {

    @Autowired
    private CacheInitializerService cachingService;

    private static final Logger logger = LoggerFactory.getLogger(OrderSourceCachingServiceImpl.class.getName());

    public List<LeadDto> getLeadsFromCache() {
        logger.info("Getting leads from cache");
        try {
            LoadingCache<String, List<LeadDto>> cache = cachingService.getLeadsCache();
            return cache.get(LEAD_CACHE_KEY);

        } catch (Exception exception) {
            logger.error("Could not fetch leads since {}", exception);
            String title = "Unable to fetch lead from cache";
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.INTERNAL_SERVER_ERROR,ErrorConstants.GET_ALL_LEADS_FAILED_KEY);
        }
    }

}
