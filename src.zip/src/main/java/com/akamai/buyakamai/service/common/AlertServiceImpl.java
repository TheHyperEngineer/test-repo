package com.akamai.buyakamai.service.common;

import com.akamai.buyakamai.constants.AlertState;
import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.controller.model.Alert;
import com.akamai.buyakamai.controller.model.OrderAlertsDto;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertEntity;
import com.akamai.buyakamai.dataaccess.buyakamdb.model.AlertDefinition;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.common.Comparators.AlertComparator;
import com.akamai.buyakamai.service.common.cache.DBEntitiesCache;
import com.akamai.buyakamai.util.CommonUtils;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import static java.util.Arrays.asList;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

@Service
@Transactional
public class AlertServiceImpl {

    @Autowired
    private DBEntitiesCache dbEntitiesCache;


    private static final Logger logger = LoggerFactory.getLogger(AlertServiceImpl.class);

    private List<AlertState> snoozableStates = asList(AlertState.ACTIVE, AlertState.SNOOZED);

    public List<OrderAlertsDto> buildAlertResponseForAlertEntities(List<AlertEntity> alertList) {
        Map<Integer, List<Alert>> alertMap = getOrderAlertsMap(alertList);

        //sort based on the creation date
        alertMap.forEach((k, v) -> Collections.sort(v, new AlertComparator()));

        alertMap.forEach((k, v) -> Collections.reverse(v));

        List<OrderAlertsDto> responseList = new ArrayList<>();
        alertMap.forEach((k, v) -> {
            OrderAlertsDto unit = new OrderAlertsDto();
            unit.setOrderId(k);
            unit.setAlerts(v);
            responseList.add(unit);
        });
        return responseList;
    }

    private Map<Integer, List<Alert>> getOrderAlertsMap(List<AlertEntity> alertList) {
        Map<Integer, List<Alert>> alertMap = new HashMap<>();
        for (AlertEntity alertEntity : alertList) {
            Alert alert = getAlertForAlertEntity(alertEntity);
            if (alertMap.containsKey(alertEntity.getOrderId())) {
                List<Alert> list1 = alertMap.get(alertEntity.getOrderId());
                list1.add(alert);
            } else {
                List<Alert> list1 = new ArrayList<>();
                list1.add(alert);
                alertMap.put(alertEntity.getOrderId(), list1);
            }
        }
        return alertMap;
    }

    public void updateAlertState(Integer alertId, Alert alert, AlertEntity alertEntity) {

        if (alert == null || StringUtils.isEmpty(alert.getState())) {
            throw new BuyAkamaiApplicationException("Alert state cannot be null", "state cannot be null",
                HttpStatus.BAD_REQUEST, ErrorConstants.ALERT_UPDATE_FAILED);
        }

        if (alertEntity == null) {
            String title = "Invalid alert id: " + alertId;
            logger.error(title);
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.BAD_REQUEST,
                ErrorConstants.INVALID_ALERT_ID);
        }
        if (!EnumUtils.isValidEnum(AlertState.class, alert.getState().toUpperCase())) {
            String title = "Invalid alert state: " + alert.getState();
            logger.error(title);
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.BAD_REQUEST,
                ErrorConstants.INVALID_ALERT_STATE);
        }

        AlertState requestedState = AlertState.valueOf(alert.getState().toUpperCase());
        AlertState currentState = alertEntity.getState();
        if (currentState == requestedState) {
            throw new BuyAkamaiApplicationException("Current state of Alert is same as requested state",
                "Current state of Alert is same as requested state", HttpStatus.BAD_REQUEST,
                ErrorConstants.ALERT_UPDATE_FAILED);
        }

        if (requestedState == AlertState.SNOOZED) {
            handleSnoozableRequest(currentState, alertEntity, requestedState);
        } else if (requestedState == AlertState.ACKNOWLEDGED) {
            handleAcknowledgeRequest(alertEntity, requestedState);
        } else {
            alertEntity.setState(requestedState);
        }
    }

    private void handleAcknowledgeRequest(AlertEntity alertEntity, AlertState requestedState) {
        String actions = dbEntitiesCache.getAlertDefintion(alertEntity.getAlertDefinitionId()).getActions();
        if (isNotEmpty(actions) && actions.equalsIgnoreCase(BAConstants.ALERT_ACK_ACTION)) {
            alertEntity.setState(requestedState);
            alertEntity.setSnoozedTime(new Date());
        } else {
            throw new BuyAkamaiApplicationException("Alert cannot be acknowledged",
                "Acknowledge action is not associated for the requested alert", HttpStatus.BAD_REQUEST,
                ErrorConstants.ALERT_UPDATE_FAILED);
        }
    }

    private void handleSnoozableRequest(AlertState currentState, AlertEntity alertEntity, AlertState requestedState) {
        if (snoozableStates.contains(currentState)) {
            if (dbEntitiesCache.getAlertDefintion(alertEntity.getAlertDefinitionId()).getSnoozable()) {
                alertEntity.setState(requestedState);
                alertEntity.setSnoozedTime(new Date());
            } else {
                //TODO check with Vineet why should we mark it complete
                alertEntity.setState(AlertState.COMPLETE);
            }
        } else {
            throw new BuyAkamaiApplicationException("Current state of Alert is not Snoozable",
                "Completed or acknowledged alerts can't be snoozed ", HttpStatus.BAD_REQUEST,
                ErrorConstants.ALERT_UPDATE_FAILED);
        }
    }

    public Alert getAlertForAlertEntity(AlertEntity alertEntity) {
        AlertDefinition alertDef = dbEntitiesCache.getAlertDefintion(alertEntity.getAlertDefinitionId());
        Alert alert = new Alert();
        alert.setAlertId(alertEntity.getId());
        alert.setState(alertEntity.getState().name());
        alert.setDate(CommonUtils.formatDate(alertEntity.getCreatedTime(), BAConstants.DATE_FORMAT_FOR_GET_EVENTS));

        if (alertDef != null) {
            alert.setName(alertDef.getName().name());
            if (alertEntity.getDescriptionArgs() != null) {
                alert.setSummary(mergeArgsToDescription(alertDef.getShortDescription(),
                    (Object[]) alertEntity.getDescriptionArgs().split(BAConstants.ALERTS_DESC_ARGS_SEPARATOR)));
                alert.setDetails(mergeArgsToDescription(alertDef.getLongDescription(),
                    (Object[]) alertEntity.getDescriptionArgs().split(BAConstants.ALERTS_DESC_ARGS_SEPARATOR)));
            } else {
                alert.setSummary(alertDef.getShortDescription());
                alert.setDetails(alertDef.getLongDescription());
            }

            alert.setSummary(CommonUtils.getReplacedAlertPocFailureText(alert.getSummary()));
            alert.setDetails(CommonUtils.getReplacedAlertPocFailureText(alert.getDetails()));

            alert.setLevel(alertDef.getLevel().name());
            alert.setSeverity(alertDef.getSeverity().name());
            if (alertDef.getActions() != null) {
                alert.setActions(asList(alertDef.getActions().split("[,]")));
            }
            alert.setPrimaryActionEnabled(true);
        }

        return alert;
    }

    private String mergeArgsToDescription(String desc, Object[] args){

        String mergedDesc = "";
        try {
            mergedDesc = String.format(desc, args);
        }catch (Exception ex){
            logger.error("Exception while merging args with description", ex);
        }
        return mergedDesc;
    }

}
