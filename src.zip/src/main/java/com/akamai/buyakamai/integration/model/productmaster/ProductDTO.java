package com.akamai.buyakamai.integration.model.productmaster;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductDTO {

    private String marketingProductId;

    private String marketingProductName;

    private List<String> trafficTypes;

    private List<String> serverTypes;

    private String provisioningURL;

    private String businessUnit;

    private String communityURL;

    private List<String> includedFeatures;

    private List<String> engineeringProducts;

    private List<OptionGroupDTO> optionGroups;

    private List<ListItemDTO> listItems;

    private String rules;

    private String opportunityProductId;
    
    public String getMarketingProductId() {
        return marketingProductId;
    }

    public void setMarketingProductId(String marketingProductId) {
        this.marketingProductId = marketingProductId;
    }

    public String getMarketingProductName() {
        return marketingProductName;
    }

    public void setMarketingProductName(String marketingProductName) {
        this.marketingProductName = marketingProductName;
    }

    public List<String> getTrafficTypes() {
        return trafficTypes;
    }

    public void setTrafficTypes(List<String> trafficTypes) {
        this.trafficTypes = trafficTypes;
    }

    public List<String> getServerTypes() {
        return serverTypes;
    }

    public void setServerTypes(List<String> serverTypes) {
        this.serverTypes = serverTypes;
    }

    public String getProvisioningURL() {
        return provisioningURL;
    }

    public void setProvisioningURL(String provisioningURL) {
        this.provisioningURL = provisioningURL;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getCommunityURL() {
        return communityURL;
    }

    public void setCommunityURL(String communityURL) {
        this.communityURL = communityURL;
    }

    public List<String> getIncludedFeatures() {
        return includedFeatures;
    }

    public void setIncludedFeatures(List<String> includedFeatures) {
        this.includedFeatures = includedFeatures;
    }

    public List<String> getEngineeringProducts() {
        return engineeringProducts;
    }

    public void setEngineeringProducts(List<String> engineeringProducts) {
        this.engineeringProducts = engineeringProducts;
    }

    public List<OptionGroupDTO> getOptionGroups() {
        return optionGroups;
    }

    public void setOptionGroups(List<OptionGroupDTO> optionGroups) {
        this.optionGroups = optionGroups;
    }

    public List<ListItemDTO> getListItems() {
        return listItems;
    }

    public void setListItems(List<ListItemDTO> listItems) {
        this.listItems = listItems;
    }

    public String getRules() {
        return rules;
    }

    public void setRules(String rules) {
        this.rules = rules;
    }

    public String getOpportunityProductId() {
        return opportunityProductId;
    }

    public void setOpportunityProductId(String opportunityProductId) {
        this.opportunityProductId = opportunityProductId;
    }

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((businessUnit == null) ? 0 : businessUnit.hashCode());
		result = prime * result + ((communityURL == null) ? 0 : communityURL.hashCode());
		result = prime * result + ((engineeringProducts == null) ? 0 : engineeringProducts.hashCode());
		result = prime * result + ((includedFeatures == null) ? 0 : includedFeatures.hashCode());
		result = prime * result + ((listItems == null) ? 0 : listItems.hashCode());
		result = prime * result + ((marketingProductId == null) ? 0 : marketingProductId.hashCode());
		result = prime * result + ((marketingProductName == null) ? 0 : marketingProductName.hashCode());
		result = prime * result + ((opportunityProductId == null) ? 0 : opportunityProductId.hashCode());
		result = prime * result + ((optionGroups == null) ? 0 : optionGroups.hashCode());
		result = prime * result + ((provisioningURL == null) ? 0 : provisioningURL.hashCode());
		result = prime * result + ((rules == null) ? 0 : rules.hashCode());
		result = prime * result + ((serverTypes == null) ? 0 : serverTypes.hashCode());
		result = prime * result + ((trafficTypes == null) ? 0 : trafficTypes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductDTO other = (ProductDTO) obj;
		if (businessUnit == null) {
			if (other.businessUnit != null)
				return false;
		} else if (!businessUnit.equals(other.businessUnit))
			return false;
		if (communityURL == null) {
			if (other.communityURL != null)
				return false;
		} else if (!communityURL.equals(other.communityURL))
			return false;
		if (engineeringProducts == null) {
			if (other.engineeringProducts != null)
				return false;
		} else if (!engineeringProducts.equals(other.engineeringProducts))
			return false;
		if (includedFeatures == null) {
			if (other.includedFeatures != null)
				return false;
		} else if (!includedFeatures.equals(other.includedFeatures))
			return false;
		if (listItems == null) {
			if (other.listItems != null)
				return false;
		} else if (!listItems.equals(other.listItems))
			return false;
		if (marketingProductId == null) {
			if (other.marketingProductId != null)
				return false;
		} else if (!marketingProductId.equals(other.marketingProductId))
			return false;
		if (marketingProductName == null) {
			if (other.marketingProductName != null)
				return false;
		} else if (!marketingProductName.equals(other.marketingProductName))
			return false;
		if (opportunityProductId == null) {
			if (other.opportunityProductId != null)
				return false;
		} else if (!opportunityProductId.equals(other.opportunityProductId))
			return false;
		if (optionGroups == null) {
			if (other.optionGroups != null)
				return false;
		} else if (!optionGroups.equals(other.optionGroups))
			return false;
		if (provisioningURL == null) {
			if (other.provisioningURL != null)
				return false;
		} else if (!provisioningURL.equals(other.provisioningURL))
			return false;
		if (rules == null) {
			if (other.rules != null)
				return false;
		} else if (!rules.equals(other.rules))
			return false;
		if (serverTypes == null) {
			if (other.serverTypes != null)
				return false;
		} else if (!serverTypes.equals(other.serverTypes))
			return false;
		if (trafficTypes == null) {
			if (other.trafficTypes != null)
				return false;
		} else if (!trafficTypes.equals(other.trafficTypes))
			return false;
		return true;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

}
