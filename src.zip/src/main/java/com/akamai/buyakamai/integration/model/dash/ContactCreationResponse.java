package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContactCreationResponse {

    private String akamContactId;

    public String getAkamContactId() {
        return akamContactId;
    }

    public void setAkamContactId(String akamContactId) {
        this.akamContactId = akamContactId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ContactCreationResponse that = (ContactCreationResponse) o;

        return akamContactId != null ? akamContactId.equals(that.akamContactId) : that.akamContactId == null;
    }

    @Override
    public int hashCode() {
        return akamContactId != null ? akamContactId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ContactCreationResponse{" +
                "akamContactId='" + akamContactId + '\'' +
                '}';
    }
}
