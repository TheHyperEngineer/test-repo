package com.akamai.buyakamai.integration.clients.model;

public class EmailNotificationResponse {
	
	private String messageId;
	
    private boolean persistent;

    public String getMessageId() {
        return messageId;
    }

    public boolean isPersistent() {
		return persistent;
	}

	public void setPersistent(boolean persistent) {
		this.persistent = persistent;
	}

	public void setMessageId(String messageId) {
        this.messageId = messageId;
    }

	@Override
	public String toString() {
		return "EmailNotificationResponse [messageId=" + messageId + ", persistent=" + persistent + "]";
	}
}