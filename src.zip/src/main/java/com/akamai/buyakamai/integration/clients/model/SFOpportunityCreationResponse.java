package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SFOpportunityCreationResponse {

    private String id;
    private Boolean success;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SFOpportunityCreationResponse that = (SFOpportunityCreationResponse) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        return success != null ? success.equals(that.success) : that.success == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (success != null ? success.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SFOpportunityCreationResponse{" +
                "id='" + id + '\'' +
                ", success=" + success +
                '}';
    }
}
