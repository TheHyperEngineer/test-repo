package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;


import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.akamai.buyakamai.constants.WebDeliveryHttpConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.util.PropertyManager;



@Component("MetisHttpClient")
public class MetisHttpClient extends WebDeliveryHttpClient {

    private static final Logger logger = LoggerFactory.getLogger(MetisHttpClient.class);
    @Autowired
    private PropertyManager propertyManager;

    public String callPostRequest(String url, MultiValueMap<String, String> postBody) throws Exception {
        logger.debug("making post request for url {} with body {}", url, postBody);
        try {
            RestTemplate restTemplate = new RestTemplate(getSocketFactory());
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(postBody, headers);
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                logger.debug("Response for url {} is {}", url, response.getBody());
                return response.getBody();
            }
        } catch (HttpStatusCodeException scEx) {
            logger.error("Exception occurred while executing post call to URL {} with status code {} and exception {}", url, scEx.getStatusCode(), scEx.getMessage());
            logger.error("Response Body {}", scEx.getResponseBodyAsString());
            throw scEx;
        } catch (Exception e) {
            throw e;
        }

        return StringUtils.EMPTY;
    }

    protected HttpComponentsClientHttpRequestFactory getSocketFactory() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        InputStream keyInput = new FileInputStream(propertyManager.getProperty(WebDeliveryHttpConstants.PFX_FILE_LOCATION));
        String pwd = getDecryptedString(propertyManager.getProperty(WebDeliveryHttpConstants.ENCRYPTED_STRING));
        keyStore.load(keyInput, pwd.toCharArray());
        keyInput.close();

        SSLContextBuilder contextBuilder = new SSLContextBuilder();
        contextBuilder.useProtocol("TLSv1.2");
        contextBuilder.loadKeyMaterial(keyStore, pwd.toCharArray());

        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(
                contextBuilder.build(), NoopHostnameVerifier.INSTANCE);
        HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(
                socketFactory).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        requestFactory.setReadTimeout(180 * 1000);
        requestFactory.setConnectTimeout(180 * 1000);
        return requestFactory;
    }

    public String callGetRequest(String url, String rrId) {
        logger.debug("making get request for url {} and rrId {}", url, rrId);
        try {
            RestTemplate restTemplate = new RestTemplate(getSocketFactory());
            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("rr_id", rrId);
            ResponseEntity<String> response = restTemplate.getForEntity(builder.build().encode().toUri(), String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                logger.debug("Response for url {} is {}", url, response.getBody());
                return response.getBody();
            }
        } catch (HttpStatusCodeException scEx) {
            logger.error("Exception occurred while executing get call to URL {} with status code {} and exception {}", url, scEx.getStatusCode(), scEx.getMessage());
            logger.error("Response Body {}", scEx.getResponseBodyAsString());
        } catch (Exception e) {
            logger.error("Exception occurred while executing get call to URL {} exception: {}", url, e);
        }
        return StringUtils.EMPTY;
    }

    static String getDecryptedString(String encryptedSting) {
        try {

            String cipher = encryptedSting.substring(12);
            return new String(Base64Utils.decodeFromString(cipher));
        } catch (Exception e) {
            logger.error("Exception while getting decrypted password");
            String title = "Exception while getting decrypted password for certificate";
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }



}
