package com.akamai.buyakamai.integration.service.impl;

import com.akamai.buyakamai.constants.AuthzConstants;
import com.akamai.buyakamai.integration.clients.impl.PulsarIdentityHttpClient;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObject;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObjectBuilder;
import com.akamai.buyakamai.integration.model.authz.IdentityDetails;
import com.akamai.buyakamai.util.PropertyManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

@Service
public class AuthzIdentityServiceImpl {

    @Autowired
    private PulsarIdentityHttpClient pulsarIdentityHttpClient;

    @Autowired
    private PropertyManager propertyManager;


    public IdentityDetails getIdentityDetailsForUser(String user) {
        String urlSuffix = propertyManager.getProperty(AuthzConstants.IDENTITY_SERVICE_URL_SUFFIX);
        HttpRequestObject<IdentityDetails> builder = new HttpRequestObjectBuilder<IdentityDetails>().
                responseClass(IdentityDetails.class).urlSuffix(urlSuffix).method(HttpMethod.GET).build();
        return pulsarIdentityHttpClient.call(builder, user);
    }

}
