package com.akamai.buyakamai.integration.model.productmaster;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectActionDTO {

    private String affectedProdOptId;
    private String type;
    private List<String> value;

    public String getAffectedProdOptId() {
        return affectedProdOptId;
    }

    public void setAffectedProdOptId(String affectedProdOptId) {
        this.affectedProdOptId = affectedProdOptId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getValue() {
        return value;
    }

    public void setValue(List<String> value) {
        this.value = value;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SelectActionDTO that = (SelectActionDTO) o;

        if (affectedProdOptId != null ? !affectedProdOptId.equals(that.affectedProdOptId) : that.affectedProdOptId != null)
            return false;
        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        return value != null ? value.equals(that.value) : that.value == null;
    }

    @Override
    public int hashCode() {
        int result = affectedProdOptId != null ? affectedProdOptId.hashCode() : 0;
        result = 31 * result + (type != null ? type.hashCode() : 0);
        result = 31 * result + (value != null ? value.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SelectActionDTO{" +
                "affectedProdOptId='" + affectedProdOptId + '\'' +
                ", type='" + type + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
