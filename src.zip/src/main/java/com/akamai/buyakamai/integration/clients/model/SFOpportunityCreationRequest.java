package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.joda.time.LocalDate;

import static com.akamai.buyakamai.util.CommonUtils.formatLocalDate;


@JsonIgnoreProperties(ignoreUnknown = true)
public class SFOpportunityCreationRequest {

    @JsonProperty("Name")
    private String opportunityName;

    @JsonProperty("StageName")
    private String stageName;

    @JsonProperty("CurrencyIsoCode")
    private String currency;

    @JsonProperty("AccountId")
    private String accountSrcId;

    @JsonProperty("CloseDate")
    private String closeDate;

    @JsonProperty("Deal_Type__c")
    private String dealType;

    @JsonProperty("product_name__c")
    private String productName;

    @JsonProperty("DB_Competitor__c")
    private String competitor;

    @JsonProperty("username__c")
    private String userName;

    public String getOpportunityName() {
        return opportunityName;
    }

    public void setOpportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
    }

    public String getStageName() {
        return stageName;
    }

    public void setStageName(String stageName) {
        this.stageName = stageName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAccountSrcId() {
        return accountSrcId;
    }

    public void setAccountSrcId(String accountSrcId) {
        this.accountSrcId = accountSrcId;
    }

    public String getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(LocalDate closeDate) {
        this.closeDate = formatLocalDate(closeDate);
    }

    public String getDealType() {
        return dealType;
    }

    public void setDealType(String dealType) {
        this.dealType = dealType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getCompetitor() {
        return competitor;
    }

    public void setCompetitor(String competitor) {
        this.competitor = competitor;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SFOpportunityCreationRequest that = (SFOpportunityCreationRequest) o;

        if (opportunityName != null ? !opportunityName.equals(that.opportunityName) : that.opportunityName != null)
            return false;
        if (stageName != null ? !stageName.equals(that.stageName) : that.stageName != null) return false;
        if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
        if (accountSrcId != null ? !accountSrcId.equals(that.accountSrcId) : that.accountSrcId != null) return false;
        if (closeDate != null ? !closeDate.equals(that.closeDate) : that.closeDate != null) return false;
        if (dealType != null ? !dealType.equals(that.dealType) : that.dealType != null) return false;
        if (productName != null ? !productName.equals(that.productName) : that.productName != null) return false;
        if (competitor != null ? !competitor.equals(that.competitor) : that.competitor != null) return false;
        return userName != null ? userName.equals(that.userName) : that.userName == null;
    }

    @Override
    public int hashCode() {
        int result = opportunityName != null ? opportunityName.hashCode() : 0;
        result = 31 * result + (stageName != null ? stageName.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (accountSrcId != null ? accountSrcId.hashCode() : 0);
        result = 31 * result + (closeDate != null ? closeDate.hashCode() : 0);
        result = 31 * result + (dealType != null ? dealType.hashCode() : 0);
        result = 31 * result + (productName != null ? productName.hashCode() : 0);
        result = 31 * result + (competitor != null ? competitor.hashCode() : 0);
        result = 31 * result + (userName != null ? userName.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SFOpportunityCreationRequest{" +
                "opportunityName='" + opportunityName + '\'' +
                ", stageName='" + stageName + '\'' +
                ", currency='" + currency + '\'' +
                ", accountSrcId='" + accountSrcId + '\'' +
                ", closeDate='" + closeDate + '\'' +
                ", dealType='" + dealType + '\'' +
                ", productName='" + productName + '\'' +
                ", competitor='" + competitor + '\'' +
                ", userName='" + userName + '\'' +
                '}';
    }
}
