package com.akamai.buyakamai.integration.model.productmaster;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RuleDTO {

    private String ruleId;
    private String ruleName;
    private String ruleDescription;
    private String ruleType;
    private RuleExpressionDTO ruleExpression;

    public String getRuleId() {
        return ruleId;
    }

    public void setRuleId(String ruleId) {
        this.ruleId = ruleId;
    }

    public String getRuleName() {
        return ruleName;
    }

    public void setRuleName(String ruleName) {
        this.ruleName = ruleName;
    }

    public String getRuleDescription() {
        return ruleDescription;
    }

    public void setRuleDescription(String ruleDescription) {
        this.ruleDescription = ruleDescription;
    }

    public String getRuleType() {
        return ruleType;
    }

    public void setRuleType(String ruleType) {
        this.ruleType = ruleType;
    }

    public RuleExpressionDTO getRuleExpression() {
        return ruleExpression;
    }

    public void setRuleExpression(RuleExpressionDTO ruleExpression) {
        this.ruleExpression = ruleExpression;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RuleDTO ruleDTO = (RuleDTO) o;

        if (ruleId != null ? !ruleId.equals(ruleDTO.ruleId) : ruleDTO.ruleId != null) return false;
        if (ruleName != null ? !ruleName.equals(ruleDTO.ruleName) : ruleDTO.ruleName != null) return false;
        if (ruleDescription != null ? !ruleDescription.equals(ruleDTO.ruleDescription) : ruleDTO.ruleDescription != null)
            return false;
        if (ruleType != null ? !ruleType.equals(ruleDTO.ruleType) : ruleDTO.ruleType != null) return false;
        return ruleExpression != null ? ruleExpression.equals(ruleDTO.ruleExpression) : ruleDTO.ruleExpression == null;
    }

    @Override
    public int hashCode() {
        int result = ruleId != null ? ruleId.hashCode() : 0;
        result = 31 * result + (ruleName != null ? ruleName.hashCode() : 0);
        result = 31 * result + (ruleDescription != null ? ruleDescription.hashCode() : 0);
        result = 31 * result + (ruleType != null ? ruleType.hashCode() : 0);
        result = 31 * result + (ruleExpression != null ? ruleExpression.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RuleDTO{" +
                "ruleId='" + ruleId + '\'' +
                ", ruleName='" + ruleName + '\'' +
                ", ruleDescription='" + ruleDescription + '\'' +
                ", ruleType='" + ruleType + '\'' +
                ", ruleExpression=" + ruleExpression +
                '}';
    }
}
