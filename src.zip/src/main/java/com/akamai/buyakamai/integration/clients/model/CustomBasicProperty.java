package com.akamai.buyakamai.integration.clients.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Enhanced com.akamai.se.domain.property.BasicProperty with DNS resolutions
 * 
 * A property is backed by an arl file and one asset.  Owners of properties
 * should extend this class and add or override data that pertains there view of property data.
 *
 * Data for this implementation comes from the  asset, arl_file,
 * arl_file_versions, arl_active_files table and authz.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomBasicProperty {

	/** Property arlFileId */
	private Integer arlFileId;

	/** Property groupIds */
	private List<Integer> groupIds;

	/** Property assetId */
	private Integer assetId;

	/** Property propertyName */
	private String propertyName;

	/** Property assetType */
	private String assetType;

	/** Property contractId */
	private String contractId;

	/** Property accountId */
	private String accountId;

	/** Property configManagerVisible */
	private Boolean configManagerVisible;

	/** Property fileName */
	private String filename;

	/** Property description */
	private String description;

	/** Property productionArlFileVersion */
	private CustomARLFileVersion productionArlFileVersion;

	/** Property stagingArlFileVersion */
	private CustomARLFileVersion stagingArlFileVersion;

	/** Property productionActivationDate */
	private String activeProductionActivationDate;

	/** Property stagingActivationDate */
	private String activeStagingActivationDate;

	public String getActiveProductionActivationDate() {
		return activeProductionActivationDate;
	}

	public void setActiveProductionActivationDate(String activeProductionActivationDate) {
		this.activeProductionActivationDate = activeProductionActivationDate;
	}

	public String getActiveStagingActivationDate() {
		return activeStagingActivationDate;
	}

	public void setActiveStagingActivationDate(String activeStagingActivationDate) {
		this.activeStagingActivationDate = activeStagingActivationDate;
	}

	public Integer getArlFileId() {
		return arlFileId;
	}

	public void setArlFileId(Integer arlFileId) {
		this.arlFileId = arlFileId;
	}

	public List<Integer> getGroupIds() {
		return groupIds;
	}

	public void setGroupIds(List<Integer> groupIds) {
		this.groupIds = groupIds;
	}

	public Integer getAssetId() {
		return assetId;
	}

	public void setAssetId(Integer assetId) {
		this.assetId = assetId;
	}

	public String getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

	public String getAssetType() {
		return assetType;
	}

	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Boolean isConfigManagerVisible() {
		return configManagerVisible;
	}

	public void setConfigManagerVisible(Boolean configManagerVisible) {
		this.configManagerVisible = configManagerVisible;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public CustomARLFileVersion getProductionArlFileVersion() {
		return productionArlFileVersion;
	}

	public void setProductionArlFileVersion(CustomARLFileVersion productionArlFileVersion) {
		this.productionArlFileVersion = productionArlFileVersion;
	}

	public CustomARLFileVersion getStagingArlFileVersion() {
		return stagingArlFileVersion;
	}

	public void setStagingArlFileVersion(CustomARLFileVersion stagingArlFileVersion) {
		this.stagingArlFileVersion = stagingArlFileVersion;
	}
	
    @Override
    public final int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public final boolean equals(final Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}