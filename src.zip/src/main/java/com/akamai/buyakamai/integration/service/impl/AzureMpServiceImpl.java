package com.akamai.buyakamai.integration.service.impl;

import com.akamai.buyakamai.constants.AzureConstants;
import com.akamai.buyakamai.controller.model.AzureMpOperationList;
import com.akamai.buyakamai.controller.model.AzureOperationUpdateRequest;
import com.akamai.buyakamai.controller.model.AzureSubscriptionRequest;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.model.azuremp.AzureAccessToken;
import com.akamai.buyakamai.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
public class AzureMpServiceImpl {

    private static Logger logger = LoggerFactory.getLogger(AzureMpServiceImpl.class);

    @Autowired
    private PropertyManager propertyManager;

    public void activateSubscription(String subscriptionId, AzureSubscriptionRequest azureSubscriptionRequest) {
        HttpHeaders headers = getHeadersForAzureCall();
        HttpEntity<AzureSubscriptionRequest> request = new HttpEntity<>(azureSubscriptionRequest, headers);
        logger.info("Activating subscription: " + subscriptionId + " with plan id: " + azureSubscriptionRequest.getPlanId());
        String activateUrlSuffix = propertyManager.getProperty(AzureConstants.AZURE_ACTIVATE_SUBS_API_PROPERTY_KEY);
        activateUrlSuffix = activateUrlSuffix.replace("{subscriptionId}", subscriptionId);
        ResponseEntity<String> response = fetchResponseFromAzure(getURI(activateUrlSuffix),
                HttpMethod.POST, request, String.class);
        logger.info("Response from azure is {}", response.getBody());
    }

    public void updateSubscription(String subscriptionId, AzureSubscriptionRequest azureSubscriptionRequest) {
        HttpHeaders headers = getHeadersForAzureCall();
        HttpEntity<AzureSubscriptionRequest> request = new HttpEntity<>(azureSubscriptionRequest, headers);
        logger.info("updating subscription: " + subscriptionId + " with plan id: " + azureSubscriptionRequest.getPlanId());
        String updateUrlSuffix = propertyManager.getProperty(AzureConstants.AZURE_UPDATE_SUBS_API_PROPERTY_KEY);
        updateUrlSuffix = updateUrlSuffix.replace("{subscriptionId}", subscriptionId);
        ResponseEntity<String> response = fetchResponseFromAzure(getURI(updateUrlSuffix),
                HttpMethod.PATCH, request, String.class);
        logger.info("Response from azure is {}", response.getBody());
    }

    public AzureMpOperationList getOpenOperationsForSubscription(String subscriptionId) {
        HttpHeaders headers = getHeadersForAzureCall();
        HttpEntity<AzureSubscriptionRequest> request = new HttpEntity<>(headers);
        logger.info("List operations for subscription: " + subscriptionId);
        String getOperationsUrlSuffix = propertyManager.getProperty(AzureConstants.AZURE_LIST_OPS_API_PROPERTY_KEY);
        getOperationsUrlSuffix = getOperationsUrlSuffix.replace("{subscriptionId}", subscriptionId);
        ResponseEntity<AzureMpOperationList> response = fetchResponseFromAzure(getURI(getOperationsUrlSuffix),
                HttpMethod.GET, request, AzureMpOperationList.class);
        logger.info("operations for subsciption id: {} is {}", subscriptionId, response.getBody());
        return response.getBody();
    }
    
    public void updateOperation(String subscriptionId, String operationId,
			AzureOperationUpdateRequest azureOperationUpdateRequest) {
        HttpHeaders headers = getHeadersForAzureCall();
        HttpEntity<AzureOperationUpdateRequest> request = new HttpEntity<>(azureOperationUpdateRequest, headers);
        logger.info("Updating operation with subscription id: " + subscriptionId + " with plan id: " + azureOperationUpdateRequest.getPlanId());
        String updateOperationsUrlSuffix = propertyManager.getProperty(AzureConstants.AZURE_UPDATE_OPS_API_PROPERTY_KEY);
        updateOperationsUrlSuffix = updateOperationsUrlSuffix.replace("{subscriptionId}", subscriptionId);
        updateOperationsUrlSuffix = updateOperationsUrlSuffix.replace("{operationId}", operationId);
        ResponseEntity<String> response = fetchResponseFromAzure(getURI(updateOperationsUrlSuffix),
                HttpMethod.PATCH, request, String.class);
        logger.info("Response from azure is {}", response.getBody());
    }


    private String getURI(String urlSuffix) {

        String azureServerAddress = propertyManager.getProperty(AzureConstants.AZURE_MP_BASE_URL_PROPERTY_KEY);
        MultiValueMap<String, String> queryParams = new LinkedMultiValueMap<>();
        queryParams.add(propertyManager.getProperty(AzureConstants.AZURE_API_VERSION_PROPERTY_KEY),
        		propertyManager.getProperty(AzureConstants.AZURE_API_VERSION_PROPERTY_VALUE));
        String uri = UriComponentsBuilder.fromUriString(azureServerAddress).path(urlSuffix)
                .queryParams(queryParams).toUriString();
        logger.info("Url value is : " + uri);
        return uri;
    }

    private <T> ResponseEntity<T> fetchResponseFromAzure(String uri, HttpMethod httpMethod, HttpEntity<?> request,
                                                Class<T> className) {
        RestTemplate restTemplate = new RestTemplate();
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        requestFactory.setConnectTimeout(5000);
        requestFactory.setReadTimeout(5000);
        restTemplate.setRequestFactory(requestFactory);
        
        ResponseEntity<T> responseJson = null;
        logger.info("Making http Request to Azure");
        try {
            responseJson = restTemplate.exchange(uri, httpMethod, request, className);
            logger.info("Response value has been retrieved from Azure");
            if (!responseJson.getStatusCode().is2xxSuccessful()) {
                String title = "Error Response from Azure";
                String detail = "Failed with the following response " + responseJson.toString();
                logger.error("error response from Azure: {}", responseJson.toString());
                throw new BuyAkamaiApplicationException(title, detail,
                        responseJson.getStatusCode());
            }
        } catch (HttpStatusCodeException e) {
            logger.info("Error response from Azure: status code {} \n response body: {}", e.getStatusCode(), e.getResponseBodyAsString());
            logger.error("Failed with the following exception ", e);
            if (e.getStatusCode() == HttpStatus.CONFLICT) {
                //pass the conflict
                throw new BuyAkamaiApplicationException(e.getMessage(), "Conflict response", HttpStatus.CONFLICT);
            }
            throw new BuyAkamaiApplicationException(e.getMessage(), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            String msg = "There is an error with Azure connection " + e.getMessage();
            logger.error(msg + "\n", e);
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseJson;
    }

    private HttpHeaders getHeadersForAzureCall() {
        String accessToken = getAccessToken();
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.AUTHORIZATION, "Bearer " + accessToken);
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
        return headers;
    }

    private String getAccessToken() {

    	RestTemplate restTemplate = new RestTemplate();

    	String loginURL = propertyManager.getProperty(AzureConstants.AZURE_LOGIN_URL_PROPERTY_KEY);
    	String akamTenantId = propertyManager.getProperty(AzureConstants.AZURE_AKAMAI_TENANT_ID_PROPERTY);
    	loginURL = loginURL.replace("{tenantId}", akamTenantId);
    	
    	HttpHeaders headers = new HttpHeaders();
    	headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

    	MultiValueMap<String, String> map = new LinkedMultiValueMap<>();
    	// client id and secret to be replaced after KMI Drop
    	map.add(AzureConstants.AZURE_CLIENT_ID_KEY, propertyManager.getProperty(AzureConstants.AZURE_CLIENT));
    	map.add(AzureConstants.AZURE_CLIENT_SECRET_KEY, propertyManager.getProperty(AzureConstants.AZURE_CLIENT_SECRET));
    	map.add(AzureConstants.AZURE_RESOURCE_KEY, AzureConstants.AZURE_SUBSCRIPTION_RESOURCE);
    	map.add(AzureConstants.AZURE_GRANT_TYPE_KEY, AzureConstants.AZURE_GRANT_TYPE_VALUE);

    	HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(map, headers);

    	ResponseEntity<AzureAccessToken> response =
    	    restTemplate.exchange(loginURL, HttpMethod.POST, entity, AzureAccessToken.class);
    	return response.getBody().getAccessToken();
    }
}
