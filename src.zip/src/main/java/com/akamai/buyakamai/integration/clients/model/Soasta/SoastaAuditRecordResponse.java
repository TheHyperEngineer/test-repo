package com.akamai.buyakamai.integration.clients.model.Soasta;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SoastaAuditRecordResponse {
    private List<SoastaAuditRecordModel> objects;

    public List<SoastaAuditRecordModel> getObjects() {
        return objects;
    }

    public void setObjects(List<SoastaAuditRecordModel> objects) {
        this.objects = objects;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoastaAuditRecordResponse that = (SoastaAuditRecordResponse) o;

        return objects != null ? objects.equals(that.objects) : that.objects == null;
    }

    @Override
    public int hashCode() {
        return objects != null ? objects.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SoastaAuditRecordResponse{" +
                "objects=" + objects +
                '}';
    }
}
