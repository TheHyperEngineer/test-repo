package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SfdcCountryDto {
    @JsonIgnore
    private String id;
    private String name;
    private String currencyIsoCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrencyIsoCode() {
        return currencyIsoCode;
    }

    public void setCurrencyIsoCode(String currencyIsoCode) {
        this.currencyIsoCode = currencyIsoCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SfdcCountryDto that = (SfdcCountryDto) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        return currencyIsoCode != null ? currencyIsoCode.equals(that.currencyIsoCode) : that.currencyIsoCode == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (currencyIsoCode != null ? currencyIsoCode.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "CountryDto{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", currencyIsoCode='" + currencyIsoCode + '\'' +
                '}';
    }
}
