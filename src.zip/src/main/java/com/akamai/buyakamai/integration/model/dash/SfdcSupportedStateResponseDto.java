package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SfdcSupportedStateResponseDto {

    private List<SfdcStateDto> states;

    public List<SfdcStateDto> getStates() {
        return states;
    }

    public void setStates(List<SfdcStateDto> states) {
        this.states = states;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SfdcSupportedStateResponseDto that = (SfdcSupportedStateResponseDto) o;

        return states != null ? states.equals(that.states) : that.states == null;
    }

    @Override
    public int hashCode() {
        return states != null ? states.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SupportedStateDto{" +
                "states=" + states +
                '}';
    }
}
