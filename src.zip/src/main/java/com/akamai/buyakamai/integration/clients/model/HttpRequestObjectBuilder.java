package com.akamai.buyakamai.integration.clients.model;


import org.springframework.http.HttpMethod;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.Map;

/**
 * 
 * @author jdixit
 *
 * @param <T>
 */
public class HttpRequestObjectBuilder<T> {

    private Class<T> responseClass;
    private String urlSuffix;
    private MultiValueMap<String, String> queryParams;
    private HttpMethod method;
    private Object requestObject;
    private Map<String, String> headers;
    private Object[] pathParams;
    private boolean hasAttachments;

    public HttpRequestObjectBuilder() {}

    public HttpRequestObjectBuilder<T> responseClass(Class<T> responseClass) {
        this.responseClass = responseClass;
        return this;
    }

    public HttpRequestObjectBuilder<T> urlSuffix(String urlSuffix) {
        this.urlSuffix = urlSuffix;
        return this;
    }

    public HttpRequestObjectBuilder<T> queryParams(MultiValueMap<String, String> queryParams) {
        this.queryParams = queryParams;
        return this;
    }

    public HttpRequestObjectBuilder<T> method(HttpMethod method) {
        this.method = method;
        return this;
    }

    public HttpRequestObjectBuilder<T> requestObject(Object requestObject) {
        this.requestObject = requestObject;
        return this;
    }

    public HttpRequestObjectBuilder<T> headers(Map<String, String> headers) {
        this.headers = headers;
        return this;
    }
    
    public HttpRequestObjectBuilder<T> pathParams(Object[] pathParams) {
        this.pathParams = pathParams;
        return this;
    }
    public HttpRequestObjectBuilder<T> hasAttachments(boolean hasAttachments) {
        this.hasAttachments = hasAttachments;
        return this;
    }

    public HttpRequestObject<T> build() {
        return new HttpRequestObject<T>(responseClass, urlSuffix, queryParams, method, requestObject, headers,pathParams,hasAttachments);
    }

    public boolean hasAttachments() {
        return hasAttachments;
    }

    public Class<T> getResponseClass() {
        return responseClass;
    }

    public HttpMethod getMethod() {
        return method;
    }

    public MultiValueMap<String, String> getQueryParams() {
        return queryParams;
    }

    public Object getRequestObject() {
        return requestObject;
    }

    public String getUrlSuffix() {
        return urlSuffix;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }
    
    public Object[] getPathParams() {
    	return pathParams;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HttpRequestObjectBuilder)) return false;

        HttpRequestObjectBuilder<?> builder = (HttpRequestObjectBuilder<?>) o;

        if (responseClass != null ? !responseClass.equals(builder.responseClass) : builder.responseClass != null)
            return false;
        if (urlSuffix != null ? !urlSuffix.equals(builder.urlSuffix) : builder.urlSuffix != null) return false;
        if (queryParams != null ? !queryParams.equals(builder.queryParams) : builder.queryParams != null) return false;
        if (method != builder.method) return false;
        if (requestObject != null ? !requestObject.equals(builder.requestObject) : builder.requestObject != null)
            return false;
        if(pathParams!=null?!Arrays.equals(pathParams,builder.pathParams): builder.pathParams!=null) return false;
        return headers != null ? headers.equals(builder.headers) : builder.headers == null;
    }

    @Override
    public int hashCode() {
        int result = responseClass != null ? responseClass.hashCode() : 0;
        result = 31 * result + (urlSuffix != null ? urlSuffix.hashCode() : 0);
        result = 31 * result + (queryParams != null ? queryParams.hashCode() : 0);
        result = 31 * result + (method != null ? method.hashCode() : 0);
        result = 31 * result + (requestObject != null ? requestObject.hashCode() : 0);
        result = 31 * result + (headers != null ? headers.hashCode() : 0);
        result = 31 * result + (pathParams != null ? Arrays.hashCode(pathParams) : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("HttpRequestObjectBuilder{");
        sb.append("responseClass=").append(responseClass);
        sb.append(", urlSuffix='").append(urlSuffix).append('\'');
        sb.append(", queryParams=").append(queryParams);
        sb.append(", method=").append(method);
        sb.append(", requestObject=").append(requestObject);
        sb.append(", headers=").append(headers);
        sb.append(", pathParams=").append(pathParams);
        sb.append(", hasAttachments=").append(hasAttachments);
        sb.append('}');
        return sb.toString();
    }
}

