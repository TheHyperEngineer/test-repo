package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SalesRepOrderSourceDto {
    private String name;
    private String salesForceUrl;
    private String userId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSalesForceUrl() {
        return salesForceUrl;
    }

    public void setSalesForceUrl(String salesForceUrl) {
        this.salesForceUrl = salesForceUrl;
    }
    
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((salesForceUrl == null) ? 0 : salesForceUrl.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SalesRepOrderSourceDto other = (SalesRepOrderSourceDto) obj;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (salesForceUrl == null) {
			if (other.salesForceUrl != null)
				return false;
		} else if (!salesForceUrl.equals(other.salesForceUrl))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SalesRepOrderSourceDto [name=" + name + ", salesForceUrl=" + salesForceUrl + ", userId=" + userId + "]";
	}

}
