package com.akamai.buyakamai.integration.clients.impl;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.PulsarConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObject;
import com.akamai.buyakamai.integration.clients.model.HttpResponseObject;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import com.akamai.ids.authn.sdk.resource.IdentityClientCredentialsClient;
import com.akamai.ids.authn.sdk.resource.RequestBuilder;
import com.akamai.ids.authn.sdk.resource.RequestResult;
import com.akamai.ids.authn.sdk.resource.model.ClientToken;
import com.akamai.ids.authn.sdk.resource.model.IdentityClientCredentials;
import com.akamai.se.rest.problem.exception.client.MethodNotAllowedException;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.*;

import static com.akamai.ids.authn.sdk.resource.RequestBuilder.*;

@Component
public class PulsarIdentityHttpClient {
	
	// Logger
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	// prop manager
	@Autowired
	private PropertyManager propertyManager;
	
	/**
	 * Calls the pulsar end point based on the HttpRequestObject
	 * @param	T Expected response object
	 * @param	httpRequestObject
	 * @return 	T Response Object
	 * @throws	ByAkamaiApplicationException
	 */

	public <T> T call(HttpRequestObject<T> httpRequestObject, String identity) throws BuyAkamaiApplicationException {
		logger.info("Processing http request through client");
		String url = getURI(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams());
		logger.debug("generated url : {}" , url);
		if (StringUtils.isEmpty(identity)) {
			throw new BuyAkamaiApplicationException("Cannot query as identity is empty","Identity client cannot be performed",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		IdentityClientCredentialsClient client = buildIdentityClientCredentials(identity);
		return getResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), false,client).getResponseBody();
	}

	public <T> T call(HttpRequestObject<T> httpRequestObject, String identity, String contractTypeId) throws BuyAkamaiApplicationException {
		logger.info("Processing http request through client");
		String url = getInternalUri(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams());
		logger.debug("generated url : {}" , url);
		if (StringUtils.isEmpty(identity)) {
			throw new BuyAkamaiApplicationException("Cannot query as identity is empty","Identity client cannot be performed",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		IdentityClientCredentialsClient client = buildIdentityClientCredentialsWithContractTypeId(identity, contractTypeId);

		return getResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), false,client).getResponseBody();
	}

	private String getInternalUri(String urlSuffix, MultiValueMap<String, String> queryParams, Object... pathValues) {

		String serverAddress = getServerAddress();

		logger.debug("Server Address is : {}", serverAddress);
		String uri = null;
		if (pathValues == null || pathValues.length == 0) {
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix)
					.queryParams(queryParams).toUriString();
		} else {
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix).queryParams(queryParams).buildAndExpand(pathValues).toUriString();
		}
		logger.info("Url value is : {}", uri);
		return uri;
	}

	public <T> T callWithUserAndAccountId(HttpRequestObject<T> httpRequestObject, String user, String accountId) {
		logger.info("inside method : call");
		String url = getURI(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams(), httpRequestObject.getPathParams());
		logger.info("generated url : {}", url);
		IdentityClientCredentialsClient client = buildIdentityClientCredentialsForUserWithAccountId(user, accountId);
		return getResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(),
				httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), false, client).getResponseBody();
	}

	/**
	 * Calls the Pulsar end point based on the HttpRequestObject
	 * @param	T Expected response object
	 * @param	httpRequestObject
	 * @return 	HttpResponseObject<T> Raw response Object
	 * @throws	ByAkamaiApplicationException
	 */

	public <T> HttpResponseObject<T> getRawResponse(HttpRequestObject<T> httpRequestObject, String identity)
			throws BuyAkamaiApplicationException {
		logger.info("Processing http request from client[raw response]");
		String url = getURI(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams());
		logger.debug("generated url : {}" , url);
		if (StringUtils.isEmpty(identity)) {
			throw new BuyAkamaiApplicationException("Cannot query as identity is empty","Identity client cannot be performed",HttpStatus.INTERNAL_SERVER_ERROR);
		}
		IdentityClientCredentialsClient client = buildIdentityClientCredentials(identity);
		return getResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), true,client);
	}
	
	/**
	 * Build the final URI based on its parameters
	 * 
	 * @param urlSuffix		PATH part of the uri
	 * @param queryParams	QS-parameters of the uri
	 * @param pathValues		PATH values of the uri
	 * @return				The absolute URI
	 */
	private String getURI(String urlSuffix, MultiValueMap<String, String> queryParams, Object... pathValues) {
		String serverAddress = getServerAddress();
		logger.debug("Server Address is : {}", serverAddress);
		String uri=null;
		if(pathValues==null||pathValues.length==0){
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix)
					.queryParams(queryParams).toUriString();
		} else {
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix).queryParams(queryParams).buildAndExpand(pathValues).toUriString();
		}
		logger.info("Url value is : {}" , uri);
		logger.debug("Exiting method getURI");
		return uri;
	}
	
	/**
	 * Get the HTTPResponseObject from Pulsar
	 * 
	 * @param responseClass		Response class
	 * @param url				Pulsar end point url
	 * @param method				HttpMethod
	 * @param requestObject		Request
	 * @param headers			Headers to add in the request
	 * @param isRawResponse		If true the response will be returned as raw, otherwise an object instance will be returned
	 * @return					The Http response
	 * @throws BuyAkamaiApplicationException
	 */
	private <T> HttpResponseObject<T> getResponse(Class<T> responseClass, String url, HttpMethod method, Object requestObject, Map<String, String> headers, boolean isRawResponse, IdentityClientCredentialsClient client)
			throws BuyAkamaiApplicationException {

		Optional<ClientToken> optionalToken = client.authenticate();

		if (optionalToken.isPresent()) {
			RequestResult<String> requestResult = performRequest(url, client, optionalToken, method,
					CommonUtils.getJsonFromObject(requestObject), headers);
			return getHttpResponseObject(responseClass, url, requestResult, isRawResponse);
		} else {
			String title = "Failed to obtain token from client credentials";
			throw new BuyAkamaiApplicationException(title,title, HttpStatus.FORBIDDEN);
		}
	}

	private IdentityClientCredentialsClient buildIdentityClientCredentials(String identity) {
		return IdentityClientCredentialsClient
				.builder(IdentityClientCredentials.builder(BAConstants.BUY_AKAMAI_CLIENT,identity).build()).build();
	}
	
	private IdentityClientCredentialsClient buildIdentityClientCredentialsWithContractTypeId(String identity, String contractTypeId) {
		return IdentityClientCredentialsClient
				.builder(IdentityClientCredentials.builder(BAConstants.BUY_AKAMAI_CLIENT,identity).contractTypeId(contractTypeId).build()).build();

	}

	private IdentityClientCredentialsClient buildIdentityClientCredentialsForUserWithAccountId(String user, String accountId) {
		return IdentityClientCredentialsClient
				.builder(IdentityClientCredentials.builder(BAConstants.BUY_AKAMAI_CLIENT, user).account(accountId).build()).build();
	}

	/**
	 * Return the cleaned-up HttpResponseObject based on the RequestResult
	 * Errors are filtered and Location header case handled
	 * 
	 * @param responseClass		response class
	 * @param url				Pulsar end point url
	 * @param requestResult		request result
	 * @param isRawResponse		If true the response will be returned as raw, otherwise an object instance will be returned
	 * @return
	 * @throws BuyAkamaiApplicationException
	 */
	private <T> HttpResponseObject<T> getHttpResponseObject(Class<T> responseClass, String url, RequestResult<String> requestResult, boolean isRawResponse) throws BuyAkamaiApplicationException {
		int statusCode = requestResult.getStatusCode();
		if (requestResult.getException().isPresent()) {
			logger.error("Exception in pulsar request for url{} ", url, requestResult.getException().get());
			String title = "Exception in pulsar response";
			throw new BuyAkamaiApplicationException(title, requestResult.getException().get().getMessage(), HttpStatus.valueOf(statusCode));
		}
		List<Integer> validStatusCodes = Arrays.asList(200, 201, 202, 204);
		if (!validStatusCodes.contains(statusCode)) {
			logger.error("Non OK response from pulsar for url{} :", url, requestResult);
			String response = "Non OK response received from call to url: "+url;

			String title = "Non OK response for Pulsar Call : Response Received "+ HttpStatus.valueOf(statusCode).getReasonPhrase();

			throw new BuyAkamaiApplicationException(title,response, HttpStatus.valueOf(statusCode));
		}
		String response = requestResult.getBody().isPresent() ? requestResult.getBody().get() : null;
		HttpResponseObject<T> responseObject= new HttpResponseObject<T>();
		responseObject.setResponseCode(statusCode);
        if (isRawResponse) {
            responseObject.setRawResponse(response);
        } else if (!StringUtils.isEmpty(response)) {
            responseObject.setResponseBody(CommonUtils.getObjectFromStringJson(response, responseClass));
        }


		if(requestResult.getFirstHeaderValue("Location").isPresent())
		{
			logger.info("Response Location:"+requestResult.getFirstHeaderValue("Location").get());
			responseObject.setHeaders(Collections.singletonMap("Location", requestResult.getFirstHeaderValue("Location").get()));
		}
		return responseObject;
	}

	/**
	 * Perform a request against a Pulsar endpoint with a set of credentials
	 * @param url				Pulsar end point
	 * @param client				IdentityClientCredentialsClient instance
	 * @param optionalToken		optional Token
	 * @param method				request method
	 * @param stringEntity		request content 
	 * @param headers			request headers
	 * @return					the corresponding RequestResult<String> instance
	 */
	private RequestResult<String> performRequest(String url, IdentityClientCredentialsClient client,
			Optional<ClientToken> optionalToken, HttpMethod method, String stringEntity, Map<String, String> headers) {
		RequestResult<String> requestResult = null;
		RequestBuilder requestBuilder = null;
		
		// Apply logic to the corresponding request method
		if (method == HttpMethod.GET) {
			requestBuilder = get(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
		} else if (method == HttpMethod.POST) {
			if (stringEntity != null) {
				requestBuilder = post(url).token(optionalToken.get())
						.content(() -> new StringEntity(stringEntity, ContentType.APPLICATION_JSON))
						.accept(ContentType.APPLICATION_JSON);
			} else {
				requestBuilder = post(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
			}
		} else if (method == HttpMethod.PUT) {
			if (stringEntity != null) {
				requestBuilder = put(url).token(optionalToken.get())
						.content(() -> new StringEntity(stringEntity, ContentType.APPLICATION_JSON))
						.accept(ContentType.APPLICATION_JSON);
			}

			else {
				requestBuilder = put(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
			}
		} else if (method == HttpMethod.DELETE){
			if (stringEntity != null) {
				requestBuilder = delete(url).token(optionalToken.get())
						.content(() -> new StringEntity(stringEntity, ContentType.APPLICATION_JSON))
						.accept(ContentType.APPLICATION_JSON);
			} else {
				requestBuilder = delete(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
			}
		}
		else {
			throw new MethodNotAllowedException();
		}

		if(headers != null) {
			for(Map.Entry<String, String> headerEntry : headers.entrySet()) {
				requestBuilder.header(headerEntry.getKey(), headerEntry.getValue());
			}
		}
		requestResult = client.perform(requestBuilder);
		return requestResult;
	}

	private String getServerAddress(){
		return String.format("%s://%s/",
				Optional.ofNullable(propertyManager.getProperty(PulsarConstants.ENV_KEY_HOST_SCHEME)).orElse(PulsarConstants.DEFAULT_SCHEME),
				propertyManager.getProperty(PulsarConstants.ENV_KEY_HOST)
		);
	}

}
