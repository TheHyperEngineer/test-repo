package com.akamai.buyakamai.integration.model.reports;

public enum ReportInterval {

    FIVE_MINUTES("FIVE_MINUTES"), HOUR("HOUR"), DAY("DAY"),
    WEEK("WEEK"), MONTH("MONTH");

    private String reportValue;

    ReportInterval(String reportValue) {
        this.reportValue = reportValue;
    }

    public String getReportValue() {
        return reportValue;
    }
}
