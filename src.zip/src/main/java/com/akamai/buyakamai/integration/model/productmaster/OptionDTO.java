package com.akamai.buyakamai.integration.model.productmaster;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class OptionDTO {
	
	private String optionId;
	
	private String optionName;
    
	private Boolean mandatory;

	private String footNote;

	private String optionNotes;

	private String provisioningURL;

	private List<String> serverType;

	private List<String> optionFeatures;
	
	private List<String> engineeringProducts;

	private List<ListItemDTO> listItems;

	public String getOptionId() {
		return optionId;
	}

	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	public String getOptionName() {
		return optionName;
	}

	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}

	public Boolean getMandatory() {
		return mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public String getFootNote() {
		return footNote;
	}

	public void setFootNote(String footNote) {
		this.footNote = footNote;
	}

	public String getOptionNotes() {
		return optionNotes;
	}

	public void setOptionNotes(String optionNotes) {
		this.optionNotes = optionNotes;
	}

	public String getProvisioningURL() {
		return provisioningURL;
	}

	public void setProvisioningURL(String provisioningURL) {
		this.provisioningURL = provisioningURL;
	}

	public List<String> getServerType() {
		return serverType;
	}

	public void setServerType(List<String> serverType) {
		this.serverType = serverType;
	}

	public List<String> getOptionFeatures() {
		return optionFeatures;
	}

	public void setOptionFeatures(List<String> optionFeatures) {
		this.optionFeatures = optionFeatures;
	}

	public List<String> getEngineeringProducts() {
		return engineeringProducts;
	}

	public void setEngineeringProducts(List<String> engineeringProducts) {
		this.engineeringProducts = engineeringProducts;
	}

	public List<ListItemDTO> getListItems() {
		return listItems;
	}

	public void setListItems(List<ListItemDTO> listItems) {
		this.listItems = listItems;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		OptionDTO optionDTO = (OptionDTO) o;

		if (optionId != null ? !optionId.equals(optionDTO.optionId) : optionDTO.optionId != null) return false;
		if (optionName != null ? !optionName.equals(optionDTO.optionName) : optionDTO.optionName != null) return false;
		if (mandatory != null ? !mandatory.equals(optionDTO.mandatory) : optionDTO.mandatory != null) return false;
		if (footNote != null ? !footNote.equals(optionDTO.footNote) : optionDTO.footNote != null) return false;
		if (optionNotes != null ? !optionNotes.equals(optionDTO.optionNotes) : optionDTO.optionNotes != null)
			return false;
		if (provisioningURL != null ? !provisioningURL.equals(optionDTO.provisioningURL) : optionDTO.provisioningURL != null)
			return false;
		if (serverType != null ? !serverType.equals(optionDTO.serverType) : optionDTO.serverType != null) return false;
		if (optionFeatures != null ? !optionFeatures.equals(optionDTO.optionFeatures) : optionDTO.optionFeatures != null)
			return false;
		if (engineeringProducts != null ? !engineeringProducts.equals(optionDTO.engineeringProducts) : optionDTO.engineeringProducts != null)
			return false;
		return listItems != null ? listItems.equals(optionDTO.listItems) : optionDTO.listItems == null;
	}

	@Override
	public int hashCode() {
		int result = optionId != null ? optionId.hashCode() : 0;
		result = 31 * result + (optionName != null ? optionName.hashCode() : 0);
		result = 31 * result + (mandatory != null ? mandatory.hashCode() : 0);
		result = 31 * result + (footNote != null ? footNote.hashCode() : 0);
		result = 31 * result + (optionNotes != null ? optionNotes.hashCode() : 0);
		result = 31 * result + (provisioningURL != null ? provisioningURL.hashCode() : 0);
		result = 31 * result + (serverType != null ? serverType.hashCode() : 0);
		result = 31 * result + (optionFeatures != null ? optionFeatures.hashCode() : 0);
		result = 31 * result + (engineeringProducts != null ? engineeringProducts.hashCode() : 0);
		result = 31 * result + (listItems != null ? listItems.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
