package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.util.List;

@JsonInclude(Include.NON_NULL)
public class EmailDTO {

    private String subject;
    private List<String> to;
    private List<String> cc;
    private List<String> bcc;
    private String from;
    private String textBody;
    private String htmlBody;

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<String> getTo() {
        return to;
    }

    public void setTo(List<String> to) {
        this.to = to;
    }

    public List<String> getCc() {
        return cc;
    }

    public void setCc(List<String> cc) {
        this.cc = cc;
    }

    public List<String> getBcc() {
        return bcc;
    }

    public void setBcc(List<String> bcc) {
        this.bcc = bcc;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTextBody() {
        return textBody;
    }

    public void setTextBody(String textBody) {
        this.textBody = textBody;
    }

    public String getHtmlBody() {
        return htmlBody;
    }

    public void setHtmlBody(String htmlBody) {
        this.htmlBody = htmlBody;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((bcc == null) ? 0 : bcc.hashCode());
        result = prime * result + ((cc == null) ? 0 : cc.hashCode());
        result = prime * result + ((from == null) ? 0 : from.hashCode());
        result = prime * result + ((htmlBody == null) ? 0 : htmlBody.hashCode());
        result = prime * result + ((subject == null) ? 0 : subject.hashCode());
        result = prime * result + ((textBody == null) ? 0 : textBody.hashCode());
        result = prime * result + ((to == null) ? 0 : to.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        EmailDTO other = (EmailDTO) obj;
        if (bcc == null) {
            if (other.bcc != null)
                return false;
        } else if (!bcc.equals(other.bcc))
            return false;
        if (cc == null) {
            if (other.cc != null)
                return false;
        } else if (!cc.equals(other.cc))
            return false;
        if (from == null) {
            if (other.from != null)
                return false;
        } else if (!from.equals(other.from))
            return false;
        if (htmlBody == null) {
            if (other.htmlBody != null)
                return false;
        } else if (!htmlBody.equals(other.htmlBody))
            return false;
        if (subject == null) {
            if (other.subject != null)
                return false;
        } else if (!subject.equals(other.subject))
            return false;
        if (textBody == null) {
            if (other.textBody != null)
                return false;
        } else if (!textBody.equals(other.textBody))
            return false;
        if (to == null) {
            if (other.to != null)
                return false;
        } else if (!to.equals(other.to))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "EmailDTO [subject=" + subject + ", to=" + to + ", cc=" + cc + ", bcc=" + bcc + ", from=" + from
                + ", textBody=" + textBody + ", htmlBody=" + htmlBody + "]";
    }
}
