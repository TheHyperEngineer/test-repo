package com.akamai.buyakamai.integration.model.reports;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

import java.util.List;
import java.util.Map;
import java.util.Set;

@JsonInclude(JsonInclude.Include.NON_EMPTY)
@Data
public class PulsarReportRequest {

    private String objectType;
    private Set<String> objectIds;
    private Set<String> metrics;
    private Map<String, List<String>> filters;
}
