package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SfdcStateDto {

    @JsonIgnore
    private String id;
    private String name;
    private String currencyIsoCode;
    private String associatedCounty;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrencyIsoCode() {
        return currencyIsoCode;
    }

    public void setCurrencyIsoCode(String currencyIsoCode) {
        this.currencyIsoCode = currencyIsoCode;
    }

    public String getAssociatedCounty() {
        return associatedCounty;
    }

    public void setAssociatedCounty(String associatedCounty) {
        this.associatedCounty = associatedCounty;
    }

    @Override
    public String toString() {
        return "StateDto{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", currencyIsoCode='" + currencyIsoCode + '\'' +
                ", associatedCounty='" + associatedCounty + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SfdcStateDto sfdcStateDto = (SfdcStateDto) o;

        if (id != null ? !id.equals(sfdcStateDto.id) : sfdcStateDto.id != null) return false;
        if (name != null ? !name.equals(sfdcStateDto.name) : sfdcStateDto.name != null) return false;
        if (currencyIsoCode != null ? !currencyIsoCode.equals(sfdcStateDto.currencyIsoCode) : sfdcStateDto.currencyIsoCode != null)
            return false;
        return associatedCounty != null ? associatedCounty.equals(sfdcStateDto.associatedCounty) : sfdcStateDto.associatedCounty == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (currencyIsoCode != null ? currencyIsoCode.hashCode() : 0);
        result = 31 * result + (associatedCounty != null ? associatedCounty.hashCode() : 0);
        return result;
    }
}
