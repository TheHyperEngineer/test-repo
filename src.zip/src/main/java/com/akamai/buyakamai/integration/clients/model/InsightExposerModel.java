package com.akamai.buyakamai.integration.clients.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InsightExposerModel {

	private String type;
	private String uuid;
	private String creationDate;
	private InsightExposerScope scope;
	private List<InsightExposerAppModel> supportingData;
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public InsightExposerScope getScope() {
		return scope;
	}
	public void setScope(InsightExposerScope scope) {
		this.scope = scope;
	}
	public List<InsightExposerAppModel> getSupportingData() {
		return supportingData;
	}
	public void setSupportingData(List<InsightExposerAppModel> supportingData) {
		this.supportingData = supportingData;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((creationDate == null) ? 0 : creationDate.hashCode());
		result = prime * result + ((scope == null) ? 0 : scope.hashCode());
		result = prime * result + ((supportingData == null) ? 0 : supportingData.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InsightExposerModel other = (InsightExposerModel) obj;
		if (creationDate == null) {
			if (other.creationDate != null)
				return false;
		} else if (!creationDate.equals(other.creationDate))
			return false;
		if (scope == null) {
			if (other.scope != null)
				return false;
		} else if (!scope.equals(other.scope))
			return false;
		if (supportingData == null) {
			if (other.supportingData != null)
				return false;
		} else if (!supportingData.equals(other.supportingData))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		if (uuid == null) {
			if (other.uuid != null)
				return false;
		} else if (!uuid.equals(other.uuid))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "MPulseInsightModel [type=" + type + ", uuid=" + uuid + ", creationDate=" + creationDate + ", scope="
				+ scope + ", supportingData=" + supportingData + "]";
	}
	
}
