package com.akamai.buyakamai.integration.model.dash;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SfdcCaseCreationDto {

    private String subject;
    private String status;
    private String account;
    private String severity;
    private String recordType;
    private String service;
    private String description;
    private String opportunity;
    private String platformProduct;
    private String requestType;
    private int loeHours;

    //some mandatory parameters for case creation
    private String visibility;


    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getSeverity() {
        return severity;
    }

    public void setSeverity(String severity) {
        this.severity = severity;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public String getService() {
        return service;
    }

    public void setService(String service) {
        this.service = service;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(String opportunity) {
        this.opportunity = opportunity;
    }

    public String getPlatformProduct() {
        return platformProduct;
    }

    public void setPlatformProduct(String platformProduct) {
        this.platformProduct = platformProduct;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public String getVisibility() {
        return visibility;
    }

    public void setVisibility(String visibility) {
        this.visibility = visibility;
    }

    public int getLoeHours() {
        return loeHours;
    }

    public void setLoeHours(int loeHours) {
        this.loeHours = loeHours;
    }

    @Override
    public String toString() {
        return "SfdcCaseCreationDto{" +
                "subject='" + subject + '\'' +
                ", status='" + status + '\'' +
                ", account='" + account + '\'' +
                ", severity='" + severity + '\'' +
                ", recordType='" + recordType + '\'' +
                ", service='" + service + '\'' +
                ", description='" + description + '\'' +
                ", opportunity='" + opportunity + '\'' +
                ", platformProduct='" + platformProduct + '\'' +
                ", requestType='" + requestType + '\'' +
                ", visibility='" + visibility + '\'' +
                '}';
    }
}