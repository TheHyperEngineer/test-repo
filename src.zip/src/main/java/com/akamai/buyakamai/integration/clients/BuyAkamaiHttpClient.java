package com.akamai.buyakamai.integration.clients;

import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObject;
import com.akamai.buyakamai.integration.clients.model.HttpResponseObject;

/**
 * @author jdixit
 */
public interface BuyAkamaiHttpClient {
	
	 /**
     * Make a call to the http service
     * @param httpRequestObject
     * @param <T>
     * @return
     */
    <T> T call(HttpRequestObject<T> httpRequestObject) throws BuyAkamaiApplicationException;
    
   
    <T>HttpResponseObject<T> getRawResponse(HttpRequestObject<T> httpRequestObject) throws BuyAkamaiApplicationException;

}
