package com.akamai.buyakamai.integration.model.productmaster;

public class SelectedOptionDTO {
    private String optionGroupId;
    private String optionId;
    
    public SelectedOptionDTO(){
    }
    
    public SelectedOptionDTO(String optionGroupId,String optionId){
    	
    	this.optionId = optionId;
    	this.optionGroupId = optionGroupId;
    }

    public String getOptionGroupId() {
        return optionGroupId;
    }


    public String getOptionId() {
        return optionId;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SelectedOptionDTO that = (SelectedOptionDTO) o;

        if (optionGroupId != null ? !optionGroupId.equals(that.optionGroupId) : that.optionGroupId != null)
            return false;
        return optionId != null ? optionId.equals(that.optionId) : that.optionId == null;
    }

    @Override
    public int hashCode() {
        int result = optionGroupId != null ? optionGroupId.hashCode() : 0;
        result = 31 * result + (optionId != null ? optionId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SelectedOptionDTO{" +
                "optionGroupId='" + optionGroupId + '\'' +
                ", optionId='" + optionId + '\'' +
                '}';
    }
}
