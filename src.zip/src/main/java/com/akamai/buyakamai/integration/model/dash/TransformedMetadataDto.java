package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

public class TransformedMetadataDto {

    @JsonIgnore
    private String id;
    private String name;
    private String currencyIsoCode;
    private List<SfdcStateDto> states;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCurrencyIsoCode() {
        return currencyIsoCode;
    }

    public void setCurrencyIsoCode(String currencyIsoCode) {
        this.currencyIsoCode = currencyIsoCode;
    }

    public List<SfdcStateDto> getStates() {
        return states;
    }

    public void setStates(List<SfdcStateDto> states) {
        this.states = states;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TransformedMetadataDto that = (TransformedMetadataDto) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (currencyIsoCode != null ? !currencyIsoCode.equals(that.currencyIsoCode) : that.currencyIsoCode != null)
            return false;
        return states != null ? states.equals(that.states) : that.states == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (currencyIsoCode != null ? currencyIsoCode.hashCode() : 0);
        result = 31 * result + (states != null ? states.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RegionMergedResponseDto{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", currencyIsoCode='" + currencyIsoCode + '\'' +
                ", states=" + states +
                '}';
    }
}
