package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountOpportunityDto {

    private String id;
    private String name;
    private String currency;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String salesForceUrl;
    
    private String dealType;
    private String stage;
    private String createdDate;
    private String country;
    private String opportunityOwner;
    private String accntSrcId;
    
    private AccountDto customerAccount;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private AccountDto partnerAccount;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Contact partnerContact;

    private Contact customerContact;
    

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSalesForceUrl() {
		return salesForceUrl;
	}

	public void setSalesForceUrl(String salesForceUrl) {
		this.salesForceUrl = salesForceUrl;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getOpportunityOwner() {
		return opportunityOwner;
	}

	public void setOpportunityOwner(String opportunityOwner) {
		this.opportunityOwner = opportunityOwner;
	}

	public AccountDto getCustomerAccount() {
		return customerAccount;
	}

	public void setCustomerAccount(AccountDto customerAccount) {
		this.customerAccount = customerAccount;
	}
	
	public String getAccntSrcId() {
		return accntSrcId;
	}

	public void setAccntSrcId(String accntSrcId) {
		this.accntSrcId = accntSrcId;
	}
	
	public AccountDto getPartnerAccount() {
		return partnerAccount;
	}

	public void setPartnerAccount(AccountDto partnerAccount) {
		this.partnerAccount = partnerAccount;
	}

	public Contact getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(Contact customerContact) {
		this.customerContact = customerContact;
	}

	public Contact getPartnerContact() {
		return partnerContact;
	}

	public void setPartnerContact(Contact partnerContact) {
		this.partnerContact = partnerContact;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountOpportunityDto other = (AccountOpportunityDto) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AccountOpportunityDto [id=" + id + ", name=" + name + ", currency=" + currency + ", salesForceUrl="
				+ salesForceUrl + ", dealType=" + dealType + ", stage=" + stage + ", createdDate=" + createdDate
				+ ", country=" + country + ", opportunityOwner=" + opportunityOwner + ", accntSrcId=" + accntSrcId
				+ ", customerAccount=" + customerAccount + ", partnerAccount=" + partnerAccount + ", partnerContact="
				+ partnerContact + ", customerContact=" + customerContact + "]";
	}


}
