package com.akamai.buyakamai.integration.clients.impl;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.akamai.buyakamai.constants.MpulseConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.Soasta.SoastaTokenModel;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;

@Component
public class SoastaHttpClient {
    private static final Logger logger = LoggerFactory.getLogger(SoastaHttpClient.class);

    @Autowired
    private PropertyManager propertyManager;

    private HttpHeaders getHeaders(String tenantName) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(MpulseConstants.SOASTA_AUTHORIZATION_HEADER, "Bearer " + propertyManager.getProperty(MpulseConstants.SOASTA_API_TOKEN));
        headers.add(MpulseConstants.SOASTA_TENANT_NAME_HEADER, tenantName);
        return headers;
    }

    private String getBaseUrl() {
        return propertyManager.getProperty(MpulseConstants.SOASTA_BASE_URL);
    }

    private String callGetRequest(HttpHeaders headers, String url, String accountId) {

        logger.info("headers for get request tenantName {}", headers.get(MpulseConstants.SOASTA_TENANT_NAME_HEADER));

        HttpEntity request = new HttpEntity<>(headers);
        String strResponse;
        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, request, String.class);
            strResponse = response.getBody();
            logger.debug("Response for url {} is {}", url, strResponse);
        } catch (HttpStatusCodeException scEx) {
            logger.error("Exception occurred while executing get call to URL {} with status code {} and exception {}", url, scEx.getStatusCode(), scEx.getMessage());
            logger.error("Response Body {}", scEx.getResponseBodyAsString());

            throw new BuyAkamaiApplicationException("HTTP status exception", "Get to Soasta Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            logger.error("Exception occurred while executing get call to URL {} cause {}", url, e.getStackTrace());
            throw new BuyAkamaiApplicationException("Get to Soasta Failed", "Get to Soasta Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }

        return strResponse;
    }

    private String callPutMethod(String url, String accountId) {
        logger.info("Executing put request with url {}", url);
        JSONObject request = new JSONObject();
        request.put("apiToken", propertyManager.getProperty(MpulseConstants.SOASTA_API_TOKEN));
        String strResponse;
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        HttpEntity<String> entity = new HttpEntity<>(request.toString(), headers);
        try {
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, entity, String.class);
            strResponse = response.getBody();
            logger.debug("Response for url {} is {}", url, strResponse);
        } catch (HttpStatusCodeException scEx) {

            logger.error("Exception occurred while executing get call to URL {} with status code {} and exception {}", url, scEx.getStatusCode(), scEx.getMessage());
            logger.error("Response Body {}", scEx.getResponseBodyAsString());

            throw new BuyAkamaiApplicationException("Put to Soasta Failed", "Put to Soasta Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {

            logger.error("Exception occurred while executing get call to URL {} cause {}", url, e.getStackTrace());
            throw new BuyAkamaiApplicationException("Put to Soasta Failed", "Put to Soasta Failed", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return strResponse;
    }

    public String getUserRepositoryServiceObjects(String tenantId, String accountId) {
        HttpHeaders headers = new HttpHeaders();
        headers.add(MpulseConstants.SOASTA_AUTHORIZATION_HEADER, "Bearer " +
                propertyManager.getProperty(MpulseConstants.SOASTA_API_TOKEN));

        logger.info("getting user repository service objects for accountId {} with tenantId {}", accountId, tenantId);
        String url = getBaseUrl() + propertyManager.getProperty(MpulseConstants.SOASTA_REPOSITORY_USER_URL);
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
                .queryParam(MpulseConstants.SOASTA_TENANT_QUERY_PARAM, tenantId);

        return callGetRequest(headers, builder.build().toUriString(), accountId);
    }

    public String getDomainRepositoryServiceObjects(String tenantName, String accountId) {
        logger.info("getting domain repository service objects for tenant name  {}", tenantName);
        HttpHeaders headers = getHeaders(tenantName);
        String url = getBaseUrl() + propertyManager.getProperty(MpulseConstants.SOASTA_REPOSITORY_DOMAIN_URL);
        return callGetRequest(headers, url, accountId);
    }

    private SoastaTokenModel getAccessTokenForConcertoAuditRecord(String accountId) {
        String url = getBaseUrl() + propertyManager.getProperty(MpulseConstants.SOASTA_AUDIT_TOKEN_URL);
        String tokenResponse = callPutMethod(url, accountId);
        return CommonUtils.getObjectFromStringJson(tokenResponse, SoastaTokenModel.class);
    }

    public String getAuditRecord(String objectType, String category, String tenantId, String accountId) {
        logger.info("getting audit record info for tenantId {}", tenantId);
        String url = getBaseUrl() + propertyManager.getProperty(MpulseConstants.SOASTA_AUDIT_RECORD_URL);
        SoastaTokenModel soastaTokenModel = getAccessTokenForConcertoAuditRecord(accountId);
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Auth-Token", soastaTokenModel.getToken());
        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
                .queryParam(MpulseConstants.SOASTA_OBJECT_TYPE_QUERY_PARAM, objectType)
                .queryParam(MpulseConstants.SOASTA_CATEGORY_QUERY_PARAM, category)
                .queryParam(MpulseConstants.SOASTA_TENANT_QUERY_PARAM, tenantId);
        return callGetRequest(headers, builder.build().toUriString(), accountId);
    }

    public String getTenantInfo(String accountId) {
        logger.info("getting tenant info for account Id {}", accountId);
        String url = getBaseUrl() + propertyManager.getProperty(MpulseConstants.SOASTA_TENANT_DETAIL_URL);

        HttpHeaders headers = new HttpHeaders();
        headers.add(MpulseConstants.SOASTA_AUTHORIZATION_HEADER, "Bearer " +
                propertyManager.getProperty(MpulseConstants.SOASTA_API_TOKEN));

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(url)
                .queryParam(MpulseConstants.SOASTA_ACCOUNTID_QUERY_PARAM, accountId);
        return callGetRequest(headers, builder.build().toUriString(), accountId);
    }

}