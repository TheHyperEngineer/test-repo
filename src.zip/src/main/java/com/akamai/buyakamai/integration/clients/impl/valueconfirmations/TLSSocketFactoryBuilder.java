package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.DashConstants;
import com.akamai.buyakamai.util.PropertyManager;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import java.io.FileInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

@Slf4j
@Component
public class TLSSocketFactoryBuilder {

    private static Logger logger = LoggerFactory.getLogger(TLSSocketFactoryBuilder.class.getName());

    @Autowired
    private PropertyManager propertyManager;


    public RestTemplate getRestTemplate() {

        try {
            String env = propertyManager.getProperty(DashConstants.DASH_ENVIRONMENT_KEY);
            if (env.contains("cloud")) {
                logger.debug("building context for cloud env");
                return buildRestTemplateWithSSLConfig();
            } else {
                return buildRestTemplate();
            }
        } catch (Exception e) {
            log.error("Exception in building socket factory");
        }
        return null;
    }

    private RestTemplate buildRestTemplate() {
        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
        return new RestTemplate(requestFactory);
    }

    private RestTemplate buildRestTemplateWithSSLConfig() throws Exception {
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = getSocketFactory();
        return new RestTemplate(clientHttpRequestFactory);
    }

    private HttpComponentsClientHttpRequestFactory getSocketFactory() throws Exception {

        /*   byte[] keyBytes;

        File f = new File("/secrets/pulsar_secrets__ssl_cert.workplace_marketplace_eaa_client.private_key");
        try (FileInputStream fis = new FileInputStream(f)) {
            try (DataInputStream dis = new DataInputStream(fis)) {
                keyBytes = new byte[(int) f.length()];
                dis.readFully(keyBytes);
            }
        } catch (Exception e) {
            throw e;
        }

        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);*/

        String privateKeyContent = new String(Files.readAllBytes(Paths.get(propertyManager.getProperty(BAConstants.EAA_PRIVATE_KEY_PATH))));
        privateKeyContent = privateKeyContent.replaceAll("\\n", "").replace("-----BEGIN PRIVATE KEY-----", "").replace("-----END PRIVATE KEY-----", "");
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(privateKeyContent));

        KeyFactory kf = KeyFactory.getInstance("RSA");
        PrivateKey privateKey = kf.generatePrivate(spec);

        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate cert;
        try (FileInputStream fis = new FileInputStream(propertyManager.getProperty(BAConstants.EAA_CERT_PATH))) {
            cert = cf.generateCertificate(fis);
        } catch (Exception e) {
            throw e;
        }

        KeyStore clientStore = KeyStore.getInstance(KeyStore.getDefaultType());
        clientStore.load(null, null);
        clientStore.setKeyEntry("key", privateKey, "".toCharArray(),
                new Certificate[]{cert});

        SSLContextBuilder sslContextBuilder = new SSLContextBuilder();
        sslContextBuilder.setProtocol("TLSv1.2");
        sslContextBuilder.loadKeyMaterial(clientStore, "".toCharArray());
        sslContextBuilder.loadTrustMaterial(new TrustSelfSignedStrategy());


        SSLContext sslContext = sslContextBuilder.build();

        KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance("SunX509", "SunJSSE");
        keyManagerFactory.init(clientStore, "".toCharArray());
        sslContext.init(keyManagerFactory.getKeyManagers(), null, new java.security.SecureRandom());

        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
        HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        requestFactory.setConnectTimeout(0);
        requestFactory.setReadTimeout(0);
        return requestFactory;
    }

}
