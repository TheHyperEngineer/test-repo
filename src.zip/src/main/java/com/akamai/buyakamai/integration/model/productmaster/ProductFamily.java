package com.akamai.buyakamai.integration.model.productmaster;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductFamily {

	private String marketingProductId;
	
	private String family;
}
