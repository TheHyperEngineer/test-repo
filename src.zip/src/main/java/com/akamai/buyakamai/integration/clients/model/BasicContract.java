package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BasicContract {

    private String contractId;

    private String accountId;

    private boolean expired;

    private String contractTypeId;

    private String parentContractId;

    private List<String> childContractIds;

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public boolean isExpired() {
        return expired;
    }

    public void setExpired(boolean expired) {
        this.expired = expired;
    }

    public String getContractTypeId() {
        return contractTypeId;
    }

    public void setContractTypeId(String contractTypeId) {
        this.contractTypeId = contractTypeId;
    }

    public String getParentContractId() {
        return parentContractId;
    }

    public void setParentContractId(String parentContractId) {
        this.parentContractId = parentContractId;
    }

    public List<String> getChildContractIds() {
        return childContractIds;
    }

    public void setChildContractIds(List<String> childContractIds) {
        this.childContractIds = childContractIds;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("BasicContract{");
        sb.append("contractId='").append(contractId).append('\'');
        sb.append(", accountId='").append(accountId).append('\'');
        sb.append(", expired=").append(expired);
        sb.append(", contractTypeId='").append(contractTypeId).append('\'');
        sb.append(", parentContractId='").append(parentContractId).append('\'');
        sb.append(", childContractIds=").append(childContractIds);
        sb.append('}');
        return sb.toString();
    }
}
