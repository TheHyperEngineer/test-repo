package com.akamai.buyakamai.integration.clients.impl;

import static com.akamai.buyakamai.constants.BAConstants.BUY_AKAMAI_CLIENT;
import static com.akamai.buyakamai.constants.DBLoggerConstants.CHANNEL;
import static com.akamai.ids.authn.sdk.resource.RequestBuilder.delete;
import static com.akamai.ids.authn.sdk.resource.RequestBuilder.get;
import static com.akamai.ids.authn.sdk.resource.RequestBuilder.post;
import static com.akamai.ids.authn.sdk.resource.RequestBuilder.put;


import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.akamai.se.dto.problem.Problem;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponentsBuilder;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.PulsarConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.BuyAkamaiHttpClient;
import com.akamai.buyakamai.integration.clients.model.HttpRequestObject;
import com.akamai.buyakamai.integration.clients.model.HttpResponseObject;
import com.akamai.buyakamai.service.common.MaskingServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import com.akamai.ids.authn.sdk.resource.ClientCredentialsClient;
import com.akamai.ids.authn.sdk.resource.ConnectionManagerBuilder;
import com.akamai.ids.authn.sdk.resource.RequestBuilder;
import com.akamai.ids.authn.sdk.resource.RequestResult;
import com.akamai.ids.authn.sdk.resource.model.ClientCredentials;
import com.akamai.ids.authn.sdk.resource.model.ClientToken;
import com.akamai.se.rest.problem.exception.client.MethodNotAllowedException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
/**
 *
 * @author jdixit
 *
 */
@Component
public class PulsarHttpClient implements BuyAkamaiHttpClient{

	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private PropertyManager propertyManager;

	@Autowired
	private MaskingServiceImpl maskingService;

	@Override
	public <T> T call(HttpRequestObject<T> httpRequestObject)
			throws BuyAkamaiApplicationException {
		logger.info("Processing http request through client");
		String url = getInternalUri(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams(),httpRequestObject.getPathParams());
		logger.debug("generated url : {}" , url);
		return getPulsarResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), false).getResponseBody();
	}

	/**
	 * Method to call internally routed APIs
	 * @param httpRequestObject
	 * @param <T>
	 * @return
	 */
	public <T> T callInternalResource(HttpRequestObject<T> httpRequestObject) throws BuyAkamaiApplicationException{
		logger.info("Processing localhost http request through client");
		String url = getInternalUri(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams());
		logger.debug("generated url : {}" , url);
		return getPulsarResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), false).getResponseBody();
	}

	private String getInternalUri(String urlSuffix, MultiValueMap<String, String> queryParams, Object... pathValues) {

		String serverAddress = getServerAddress();
		logger.debug("Server Address is : {}", serverAddress);
		String uri = null;
		if (pathValues == null || pathValues.length == 0) {
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix)
					.queryParams(queryParams).toUriString();
		} else {
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix).queryParams(queryParams).buildAndExpand(pathValues).toUriString();
		}
		logger.info("Url value is : {}", uri);
		return uri;
	}

	@Override
	public <T> HttpResponseObject<T> getRawResponse(HttpRequestObject<T> httpRequestObject)
			throws BuyAkamaiApplicationException {
		logger.info("Processing http request from client[raw response]");
		String url = getURI(httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams());
		logger.debug("generated url : {}" , url);
		return getPulsarResponse(httpRequestObject.getResponseClass(), url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders(), true);
	}

	private String getURI(String urlSuffix, MultiValueMap<String, String> queryParams, Object... pathValues) {
		String serverAddress = getServerAddress();

		logger.debug("Server Address is : {}", serverAddress);
		String uri=null;
		if(pathValues==null||pathValues.length==0){
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix)
					.queryParams(queryParams).toUriString();
		} else {
			uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix).queryParams(queryParams).buildAndExpand(pathValues).toUriString();
		}
		logger.info("Url value is : {}" , uri);
		logger.debug("Exiting method getURI");
		return uri;
	}

	private <T> HttpResponseObject<T> getPulsarResponse(Class<T> responseClass, String url, HttpMethod method, Object requestObject, Map<String, String> headers, boolean isRawResponse)
			throws BuyAkamaiApplicationException {

		logger.info("Request Sent to  {} {} ",url,method);
		logger.debug("Reuqest data {} ",requestObject);
		ClientCredentialsClient client = ClientCredentialsClient.builder(ClientCredentials.build(BUY_AKAMAI_CLIENT))
				.connectionManager(ConnectionManagerBuilder.custom()).build();
		Optional<ClientToken> optionalToken = client.authenticate();
		if (optionalToken.isPresent()) {
			RequestResult<String> requestResult = performRequest(url, client, optionalToken, method,
					CommonUtils.getJsonFromObject(requestObject), headers);
			logger.debug("Response Received {} ",requestResult.getBody());
			return getHttpResponseObject(responseClass, url, requestResult, isRawResponse);
		} else {
			String title = "Failed to obtain token from client credentials";
			throw new BuyAkamaiApplicationException(title,title, HttpStatus.FORBIDDEN);
		}
	}

	private <T> HttpResponseObject<T> getHttpResponseObject(Class<T> responseClass, String url, RequestResult<String> requestResult, boolean isRawResponse) throws BuyAkamaiApplicationException {
		int statusCode = requestResult.getStatusCode();
		logger.debug("Response  from pulsar call:" + maskingService.mask(requestResult.getBody().get()));
		if (requestResult.getException().isPresent()) {
			logger.error("Exception in pulsar request for url{} {} ", url, requestResult.getException().get());
			String title = "Exception in pulsar response";
			String responseBody = requestResult.getBody().get();
			Problem problem = getProblem(responseBody);
			BuyAkamaiApplicationException buyAkamaiApplicationException = new BuyAkamaiApplicationException(title, requestResult.getException().get().getMessage(), problem, HttpStatus.valueOf(statusCode));
			setErrorCodeFromResponse(responseBody, buyAkamaiApplicationException);
			throw buyAkamaiApplicationException;
		}
		List<Integer> validStatusCodes = Arrays.asList(200, 201, 202, 204);
		if (!validStatusCodes.contains(statusCode)) {
			String responseBody = requestResult.getBody().get();
			logger.error("Non OK response from pulsar for url{} :", url, requestResult);
			String response = "Non OK response received from call to url: "+url;

			String title = "Non OK response for Pulsar Call : Response Received "+ HttpStatus.valueOf(statusCode).getReasonPhrase();
			Problem problem = getProblem(responseBody);

			BuyAkamaiApplicationException ex =  new BuyAkamaiApplicationException(title,response, problem, HttpStatus.valueOf(statusCode));
			setErrorCodeFromResponse(responseBody, ex);
			throw ex;
		}
		String response = requestResult.getBody().get();
		HttpResponseObject<T> responseObject= new HttpResponseObject<T>();
		responseObject.setResponseCode(statusCode);
        if (isRawResponse) {
            responseObject.setRawResponse(response);
        } else if (!StringUtils.isEmpty(response)) {
            responseObject.setResponseBody(CommonUtils.getObjectFromStringJson(response, responseClass));
        }


		if(requestResult.getFirstHeaderValue("Location").isPresent())
		{
			logger.info("Response Location:"+requestResult.getFirstHeaderValue("Location").get());
			responseObject.setHeaders(Collections.singletonMap("Location", requestResult.getFirstHeaderValue("Location").get()));
		}
		return responseObject;
	}

	private Problem getProblem(String responseBody) {
		Problem problem = null;
		try {
			 problem = CommonUtils.getObjectFromStringJson(responseBody, Problem.class);
		}catch (Exception ex){
			logger.error("Exception parsing error response body ", ex);
		}
		return problem;
	}

	private void setErrorCodeFromResponse(String responseBody, BuyAkamaiApplicationException ex) {
		if (!StringUtils.isEmpty(responseBody)) {

			try {
				ObjectMapper mapper = new ObjectMapper();
				JsonNode actualObj = mapper.readTree(responseBody);
				JsonNode errorKey = actualObj.get("error_key");
				JsonNode errorKey2 = actualObj.get("errorKey");

				logger.info("Error key received {}", errorKey);
				if (null != errorKey) {
					ex.setErrorKey(errorKey.asText());
				}else if(errorKey2 != null){
					ex.setErrorKey(errorKey2.asText());
				}

				JsonNode errorData = actualObj.get("errorData");
				logger.info("Error data received {}", errorData);
				if (null != errorData) {
					Map<String, String> errorDataMap = new HashMap<>();
					Iterator<Map.Entry<String, JsonNode>> iterator = errorData.fields();
					while (iterator.hasNext()) {
						Map.Entry<String, JsonNode> entry = iterator.next();
						errorDataMap.put(entry.getKey(), entry.getValue().asText());
					}
					if (!errorDataMap.isEmpty()) {
						ex.setErrorData(errorDataMap);
					}
				}
			} catch (Exception parseExcption) {
				logger.error("Exception while Parsing : Should be swallowed {}", parseExcption);
			}
		}
	}

	private RequestResult<String> performRequest(String url, ClientCredentialsClient client,
			Optional<ClientToken> optionalToken, HttpMethod method, String stringEntity, Map<String, String> headers) {
		RequestResult<String> requestResult = null;
		RequestBuilder requestBuilder = null;
		if (method == HttpMethod.GET) {
			requestBuilder = get(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
		} else if (method == HttpMethod.POST) {
			if (stringEntity != null) {
				requestBuilder = post(url).token(optionalToken.get())
						.content(() -> new StringEntity(stringEntity, ContentType.APPLICATION_JSON))
						.accept(ContentType.APPLICATION_JSON);
			} else {
				requestBuilder = post(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
			}
		} else if (method == HttpMethod.PUT) {
			if (stringEntity != null) {
				requestBuilder = put(url).token(optionalToken.get())
						.content(() -> new StringEntity(stringEntity, ContentType.APPLICATION_JSON))
						.accept(ContentType.APPLICATION_JSON);
			}

			else {
				requestBuilder = put(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
			}
		}else if (method == HttpMethod.DELETE){
			if (stringEntity != null) {
				requestBuilder = delete(url).token(optionalToken.get())
						.content(() -> new StringEntity(stringEntity, ContentType.APPLICATION_JSON))
						.accept(ContentType.APPLICATION_JSON);
			} else {
				requestBuilder = delete(url).token(optionalToken.get()).accept(ContentType.APPLICATION_JSON);
			}
		}
		else {
			throw new MethodNotAllowedException();
		}

		if(headers != null) {
			for(Map.Entry<String, String> headerEntry : headers.entrySet()) {
				requestBuilder.header(headerEntry.getKey(), headerEntry.getValue());
			}
		}
		requestResult = client.perform(requestBuilder);
		return requestResult;
	}

	private String getServerAddress(){
		return String.format("%s://%s/",
				Optional.ofNullable(propertyManager.getProperty(PulsarConstants.ENV_KEY_HOST_SCHEME)).orElse(PulsarConstants.DEFAULT_SCHEME),
				propertyManager.getProperty(PulsarConstants.ENV_KEY_HOST)
		);
	}

}