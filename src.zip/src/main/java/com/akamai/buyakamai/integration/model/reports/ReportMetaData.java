package com.akamai.buyakamai.integration.model.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ReportMetaData {

    private String name;
    private String version;
    private String interval;
    private String availableDataEnds;
    private String start;
    private String end;

}
