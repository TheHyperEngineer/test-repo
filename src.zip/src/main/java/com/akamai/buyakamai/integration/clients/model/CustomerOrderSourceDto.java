package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;


@JsonIgnoreProperties(ignoreUnknown=true)
public class CustomerOrderSourceDto {

    private String accountName;
    private String accountId;
    private AddressDto accountAddress;
    private String name;
    private String email;
    private String phonenumber;
    private String salesForceUrl;
	private String accountSalesForceUrl;
    private String contactId;
    private String title;
    private Boolean activePortalUser;

    @JsonInclude(JsonInclude.Include.NON_NULL)
	private AddressDto contactAddress;

	public Boolean getActivePortalUser() {
		return activePortalUser;
	}

	public void setActivePortalUser(Boolean activePortalUser) {
		this.activePortalUser = activePortalUser;
	}

	public AddressDto getContactAddress() {
		return contactAddress;
	}
	public void setContactAddress(AddressDto contactAddress) {
		this.contactAddress = contactAddress;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhonenumber() {
		return phonenumber;
	}
	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}
	public String getSalesForceUrl() {
		return salesForceUrl;
	}
	public void setSalesForceUrl(String salesForceUrl) {
		this.salesForceUrl = salesForceUrl;
	}
	public AddressDto getAccountAddress() {
		return accountAddress;
	}
	public void setAccountAddress(AddressDto accountAddress) {
		this.accountAddress = accountAddress;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public String getAccountSalesForceUrl() {
		return accountSalesForceUrl;
	}
	public void setAccountSalesForceUrl(String accountSalesForceUrl) {
		this.accountSalesForceUrl = accountSalesForceUrl;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		CustomerOrderSourceDto that = (CustomerOrderSourceDto) o;

		if (accountName != null ? !accountName.equals(that.accountName) : that.accountName != null) return false;
		if (accountId != null ? !accountId.equals(that.accountId) : that.accountId != null) return false;
		if (accountAddress != null ? !accountAddress.equals(that.accountAddress) : that.accountAddress != null)
			return false;
		if (name != null ? !name.equals(that.name) : that.name != null) return false;
		if (email != null ? !email.equals(that.email) : that.email != null) return false;
		if (phonenumber != null ? !phonenumber.equals(that.phonenumber) : that.phonenumber != null) return false;
		if (salesForceUrl != null ? !salesForceUrl.equals(that.salesForceUrl) : that.salesForceUrl != null)
			return false;
		if (accountSalesForceUrl != null ? !accountSalesForceUrl.equals(that.accountSalesForceUrl) : that.accountSalesForceUrl != null)
			return false;
		if (contactId != null ? !contactId.equals(that.contactId) : that.contactId != null) return false;
		return title != null ? title.equals(that.title) : that.title == null;
	}

	@Override
	public int hashCode() {
		int result = accountName != null ? accountName.hashCode() : 0;
		result = 31 * result + (accountId != null ? accountId.hashCode() : 0);
		result = 31 * result + (accountAddress != null ? accountAddress.hashCode() : 0);
		result = 31 * result + (name != null ? name.hashCode() : 0);
		result = 31 * result + (email != null ? email.hashCode() : 0);
		result = 31 * result + (phonenumber != null ? phonenumber.hashCode() : 0);
		result = 31 * result + (salesForceUrl != null ? salesForceUrl.hashCode() : 0);
		result = 31 * result + (accountSalesForceUrl != null ? accountSalesForceUrl.hashCode() : 0);
		result = 31 * result + (contactId != null ? contactId.hashCode() : 0);
		result = 31 * result + (title != null ? title.hashCode() : 0);
		return result;
	}

	@Override
    public String toString() {
        return "CustomerOpportunityDto{" +
                "accountName='" + accountName + '\'' +
                ", accountId='" + accountId + '\'' +
                ", accountAddress='" + accountAddress + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", phonenumber='" + phonenumber + '\'' +
                ", salesForceUrl='" + salesForceUrl + '\'' +
                ", accountSalesForceUrl='" + accountSalesForceUrl + '\'' +
                ", contactId='" + contactId + '\'' +
                ", title='" + title + '\'' +
                '}';
    }
}
