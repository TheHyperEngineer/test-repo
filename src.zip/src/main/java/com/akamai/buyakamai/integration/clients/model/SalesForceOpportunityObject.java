package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SalesForceOpportunityObject {

    @JsonProperty("AKAM_Opportunity_ID__c")
    private String akamOpportunityId;

    public String getAkamOpportunityId() {
        return akamOpportunityId;
    }

    public void setAkamOpportunityId(String akamOpportunityId) {
        this.akamOpportunityId = akamOpportunityId;
    }
}
