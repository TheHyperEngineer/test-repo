package com.akamai.buyakamai.integration.clients.model.Soasta;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SoastaTenantResponse {

    private List<SoastaTenantResponseModel> objects;

    public List<SoastaTenantResponseModel> getObjects() {
        return objects;
    }

    public void setObjects(List<SoastaTenantResponseModel> objects) {
        this.objects = objects;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoastaTenantResponse that = (SoastaTenantResponse) o;

        return objects != null ? objects.equals(that.objects) : that.objects == null;
    }

    @Override
    public int hashCode() {
        return objects != null ? objects.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SoastaTenantResponse{" +
                "objects=" + objects +
                '}';
    }
}
