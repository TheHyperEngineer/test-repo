package com.akamai.buyakamai.integration.model.productmaster;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductMasterTrialDetailDTO {

    private String bundleId;

    private String bundleName;

    private String bundleTrialDuration;

    private Object termsAndConditions;

    private String bundleLifeCyclePhase;

    private Object bundleVersion;

    private String billingCurrency;

    private String paymentTerm;

    private List<ProductDTO> products;

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public String getBundleTrialDuration() {
        return bundleTrialDuration;
    }

    public void setBundleTrialDuration(String bundleTrialDuration) {
        this.bundleTrialDuration = bundleTrialDuration;
    }

    public Object getTermsAndConditions() {
        return termsAndConditions;
    }

    public void setTermsAndConditions(Object termsAndConditions) {
        this.termsAndConditions = termsAndConditions;
    }

    public String getBundleLifeCyclePhase() {
        return bundleLifeCyclePhase;
    }

    public void setBundleLifeCyclePhase(String bundleLifeCyclePhase) {
        this.bundleLifeCyclePhase = bundleLifeCyclePhase;
    }

    public Object getBundleVersion() {
        return bundleVersion;
    }

    public void setBundleVersion(Object bundleVersion) {
        this.bundleVersion = bundleVersion;
    }

    public String getBillingCurrency() {
        return billingCurrency;
    }

    public void setBillingCurrency(String billingCurrency) {
        this.billingCurrency = billingCurrency;
    }

    public String getPaymentTerm() {
        return paymentTerm;
    }

    public void setPaymentTerm(String paymentTerm) {
        this.paymentTerm = paymentTerm;
    }

    public List<ProductDTO> getProducts() {
        return products;
    }

    public void setProducts(List<ProductDTO> products) {
        this.products = products;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProductMasterTrialDetailDTO that = (ProductMasterTrialDetailDTO) o;

        if (bundleId != null ? !bundleId.equals(that.bundleId) : that.bundleId != null) return false;
        if (bundleName != null ? !bundleName.equals(that.bundleName) : that.bundleName != null) return false;
        if (bundleTrialDuration != null ? !bundleTrialDuration.equals(that.bundleTrialDuration) : that.bundleTrialDuration != null)
            return false;
        if (termsAndConditions != null ? !termsAndConditions.equals(that.termsAndConditions) : that.termsAndConditions != null)
            return false;
        if (bundleLifeCyclePhase != null ? !bundleLifeCyclePhase.equals(that.bundleLifeCyclePhase) : that.bundleLifeCyclePhase != null)
            return false;
        if (bundleVersion != null ? !bundleVersion.equals(that.bundleVersion) : that.bundleVersion != null)
            return false;
        if (billingCurrency != null ? !billingCurrency.equals(that.billingCurrency) : that.billingCurrency != null)
            return false;
        if (paymentTerm != null ? !paymentTerm.equals(that.paymentTerm) : that.paymentTerm != null) return false;
        return products != null ? products.equals(that.products) : that.products == null;
    }

    @Override
    public int hashCode() {
        int result = bundleId != null ? bundleId.hashCode() : 0;
        result = 31 * result + (bundleName != null ? bundleName.hashCode() : 0);
        result = 31 * result + (bundleTrialDuration != null ? bundleTrialDuration.hashCode() : 0);
        result = 31 * result + (termsAndConditions != null ? termsAndConditions.hashCode() : 0);
        result = 31 * result + (bundleLifeCyclePhase != null ? bundleLifeCyclePhase.hashCode() : 0);
        result = 31 * result + (bundleVersion != null ? bundleVersion.hashCode() : 0);
        result = 31 * result + (billingCurrency != null ? billingCurrency.hashCode() : 0);
        result = 31 * result + (paymentTerm != null ? paymentTerm.hashCode() : 0);
        result = 31 * result + (products != null ? products.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }


}
