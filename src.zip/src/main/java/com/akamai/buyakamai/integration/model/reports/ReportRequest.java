package com.akamai.buyakamai.integration.model.reports;

import lombok.Data;
import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.util.Strings;
import org.joda.time.LocalDate;


import java.util.List;
import java.util.Objects;

@Data
public class ReportRequest {

    private static final String DEFAULT_USER = "online-channel-sme";
    private LocalDate startDate;
    private LocalDate endDate;
    private ReportInterval interval;
    private String ipVersion;
    private String deliveryType;
    private List<String> cpCodes;
    private String accountId;
    private String contractId;

    public ReportRequest(LocalDate startDate, LocalDate endDate, ReportInterval interval, List<String> cpCodes, String accountId, String contractId) {
        assert Strings.isNotBlank(accountId);
        assert CollectionUtils.isNotEmpty(cpCodes);
        assert !Objects.isNull(startDate);
        assert !Objects.isNull(endDate);

        this.startDate = startDate;
        this.endDate = endDate;
        this.interval = interval;
        this.cpCodes = cpCodes;
        this.accountId = accountId;
        this.interval = Objects.isNull(interval) ? ReportInterval.DAY : interval;
    }


}
