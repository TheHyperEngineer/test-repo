package com.akamai.buyakamai.integration.model.dash;


public class OpportunityRequestDTO {

    private String accountId;
    private String opportunityName;
    private String stage;
    private String closeDate;
    private String source;
    private String productName;
    private String username;
    private String currency;
    private String dealType;
    private String orderType;
    private String competitorPrimary;
    private String partnerAccountId;
    private String opportunityType;



    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getOpportunityName() {
        return opportunityName;
    }

    public void setOpportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDealType() {
        return dealType;
    }

    public void setDealType(String dealType) {
        this.dealType = dealType;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getCompetitorPrimary() {
        return competitorPrimary;
    }

    public void setCompetitorPrimary(String competitorPrimary) {
        this.competitorPrimary = competitorPrimary;
    }

    public String getPartnerAccountId() {
        return partnerAccountId;
    }

    public void setPartnerAccountId(String partnerAccountId) {
        this.partnerAccountId = partnerAccountId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OpportunityRequestDTO that = (OpportunityRequestDTO) o;

        if (accountId != null ? !accountId.equals(that.accountId) : that.accountId != null) return false;
        if (opportunityName != null ? !opportunityName.equals(that.opportunityName) : that.opportunityName != null)
            return false;
        if (stage != null ? !stage.equals(that.stage) : that.stage != null) return false;
        if (closeDate != null ? !closeDate.equals(that.closeDate) : that.closeDate != null) return false;
        if (source != null ? !source.equals(that.source) : that.source != null) return false;
        if (username != null ? !username.equals(that.username) : that.username != null) return false;
        if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
        if (dealType != null ? !dealType.equals(that.dealType) : that.dealType != null) return false;
        if (orderType != null ? !orderType.equals(that.orderType) : that.orderType != null) return false;
        return competitorPrimary != null ? competitorPrimary.equals(that.competitorPrimary) : that.competitorPrimary == null;
    }

    @Override
    public int hashCode() {
        int result = accountId != null ? accountId.hashCode() : 0;
        result = 31 * result + (opportunityName != null ? opportunityName.hashCode() : 0);
        result = 31 * result + (stage != null ? stage.hashCode() : 0);
        result = 31 * result + (closeDate != null ? closeDate.hashCode() : 0);
        result = 31 * result + (source != null ? source.hashCode() : 0);
        result = 31 * result + (username != null ? username.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (dealType != null ? dealType.hashCode() : 0);
        result = 31 * result + (orderType != null ? orderType.hashCode() : 0);
        result = 31 * result + (competitorPrimary != null ? competitorPrimary.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OpportunityRequestDTO{" +
                "accountId='" + accountId + '\'' +
                ", opportunityName='" + opportunityName + '\'' +
                ", stage='" + stage + '\'' +
                ", closeDate='" + closeDate + '\'' +
                ", source='" + source + '\'' +
                ", productName='" + productName + '\'' +
                ", username='" + username + '\'' +
                ", currency='" + currency + '\'' +
                ", dealType='" + dealType + '\'' +
                ", orderType='" + orderType + '\'' +
                ", competitorPrimary='" + competitorPrimary + '\'' +
                '}';
    }

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}
}
