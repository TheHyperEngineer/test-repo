package com.akamai.buyakamai.integration.clients.model;

import java.util.Set;

public class AccountSelectRequest {
    private Set<String> accountIds;

    public Set<String> getAccountIds() {
        return accountIds;
    }

    public void setAccountIds(Set<String> accountIds) {
        this.accountIds = accountIds;
    }
}
