package com.akamai.buyakamai.integration.clients.model;
import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * 
 * @author jdixit
 * @param <T>
 */
public class HttpRequestObject<T> {

    private final Class<T> responseClass;
    private final String urlSuffix;
    private final MultiValueMap<String, String> queryParams;
    private final HttpMethod method;
    private final Object requestObject;
    private final Map<String, String> headers;
    private final Object[] pathParams;
    private boolean hasAttachments;

    public HttpRequestObject(Class<T> responseClass, String urlSuffix, MultiValueMap<String, String> queryParams,
                             HttpMethod method, Object requestObject, Map<String, String> headers, Object[] pathParams,boolean hasAttachments) {
        if(responseClass == null) {
            throw new NullPointerException("response class cannot be null");
        } else if(urlSuffix == null) {
            throw new NullPointerException("url suffix cannot be null");
        } else {
            this.responseClass = responseClass;
            this.urlSuffix = urlSuffix;
            this.queryParams = queryParams == null ? new LinkedMultiValueMap<>() : queryParams;
            this.method = method == null ? HttpMethod.GET : method;
            this.requestObject = requestObject;
            this.headers = headers == null? new HashMap<>() : headers;
            Object[] emptyPathParams = {};
            this.pathParams = pathParams==null? emptyPathParams :pathParams;
            this.hasAttachments = hasAttachments;
        }
    }


    public Class<T> getResponseClass() {
        return responseClass;
    }

    public String getUrlSuffix() {
        return urlSuffix;
    }

    public MultiValueMap<String, String> getQueryParams() {
        return new LinkedMultiValueMap<>(queryParams);
    }

    public HttpMethod getMethod() {
        return method;
    }

    public Object getRequestObject() {
        return requestObject;
    }

    public Map<String, String> getHeaders() {
        return new HashMap<>(headers);
    }
    
    public Object[] getPathParams() {
    	return Arrays.copyOf(pathParams, pathParams.length);
    }
    public boolean hasAttachments() {
        return hasAttachments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof HttpRequestObject)) return false;

        HttpRequestObject<?> that = (HttpRequestObject<?>) o;

        if (responseClass != null ? !responseClass.equals(that.responseClass) : that.responseClass != null)
            return false;
        if (urlSuffix != null ? !urlSuffix.equals(that.urlSuffix) : that.urlSuffix != null) return false;
        if (queryParams != null ? !queryParams.equals(that.queryParams) : that.queryParams != null) return false;
        if (method != that.method) return false;
        if (requestObject != null ? !requestObject.equals(that.requestObject) : that.requestObject != null)
            return false;
        if(pathParams!=null?!Arrays.equals(pathParams,that.pathParams): that.pathParams!=null) return false;
        return headers != null ? headers.equals(that.headers) : that.headers == null;
    }

    @Override
    public int hashCode() {
        int result = responseClass != null ? responseClass.hashCode() : 0;
        result = 31 * result + (urlSuffix != null ? urlSuffix.hashCode() : 0);
        result = 31 * result + (queryParams != null ? queryParams.hashCode() : 0);
        result = 31 * result + (method != null ? method.hashCode() : 0);
        result = 31 * result + (requestObject != null ? requestObject.hashCode() : 0);
        result = 31 * result + (headers != null ? headers.hashCode() : 0);
        result = 31 * result + (pathParams != null ? Arrays.hashCode(pathParams) : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("HttpRequestObject{");
        sb.append("responseClass=").append(responseClass);
        sb.append(", urlSuffix='").append(urlSuffix).append('\'');
        sb.append(", queryParams=").append(queryParams);
        sb.append(", method=").append(method);
        sb.append(", requestObject=").append(requestObject);
        sb.append(", headers=").append(headers);
        sb.append(", pathParams=").append(pathParams);
        sb.append(", hasAttachments=").append(hasAttachments);
        sb.append('}');
        return sb.toString();
    }
}
