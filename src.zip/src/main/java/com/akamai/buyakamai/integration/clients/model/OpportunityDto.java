package com.akamai.buyakamai.integration.clients.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpportunityDto {

    private String id;
    private String name;
    private String currency;
    private String salesForceUrl;
    private String dealType;
    private String productName;
    private String trialType;
    private String domain;
    private String stage;
    private String date;

    private String bundleId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String accountType;

    @JsonInclude(JsonInclude.Include.NON_EMPTY)
    private Boolean owner;

    private CustomerOrderSourceDto customer;
    private SalesRepOrderSourceDto salesRep;

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public Boolean getOwner() {
        return owner;
    }

    public void setOwner(Boolean owner) {
        this.owner = owner;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSalesForceUrl() {
        return salesForceUrl;
    }

    public void setSalesForceUrl(String salesForceUrl) {
        this.salesForceUrl = salesForceUrl;
    }

    public String getDealType() {
        return dealType;
    }

    public void setDealType(String dealType) {
        this.dealType = dealType;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getTrialType() {
        return trialType;
    }

    public void setTrialType(String trialType) {
        this.trialType = trialType;
    }

    public String getDomain() {
        return domain;
    }

    public void setDomain(String domain) {
        this.domain = domain;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public CustomerOrderSourceDto getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerOrderSourceDto customer) {
        this.customer = customer;
    }

    public SalesRepOrderSourceDto getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(SalesRepOrderSourceDto salesRep) {
        this.salesRep = salesRep;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OpportunityDto that = (OpportunityDto) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
        if (salesForceUrl != null ? !salesForceUrl.equals(that.salesForceUrl) : that.salesForceUrl != null)
            return false;
        if (dealType != null ? !dealType.equals(that.dealType) : that.dealType != null) return false;
        if (productName != null ? !productName.equals(that.productName) : that.productName != null) return false;
        if (trialType != null ? !trialType.equals(that.trialType) : that.trialType != null) return false;
        if (domain != null ? !domain.equals(that.domain) : that.domain != null) return false;
        if (stage != null ? !stage.equals(that.stage) : that.stage != null) return false;
        if (date != null ? !date.equals(that.date) : that.date != null) return false;
        if (bundleId != null ? !bundleId.equals(that.bundleId) : that.bundleId != null) return false;
        if (customer != null ? !customer.equals(that.customer) : that.customer != null) return false;
        return salesRep != null ? salesRep.equals(that.salesRep) : that.salesRep == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (salesForceUrl != null ? salesForceUrl.hashCode() : 0);
        result = 31 * result + (dealType != null ? dealType.hashCode() : 0);
        result = 31 * result + (productName != null ? productName.hashCode() : 0);
        result = 31 * result + (trialType != null ? trialType.hashCode() : 0);
        result = 31 * result + (domain != null ? domain.hashCode() : 0);
        result = 31 * result + (stage != null ? stage.hashCode() : 0);
        result = 31 * result + (date != null ? date.hashCode() : 0);
        result = 31 * result + (bundleId != null ? bundleId.hashCode() : 0);
        result = 31 * result + (customer != null ? customer.hashCode() : 0);
        result = 31 * result + (salesRep != null ? salesRep.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OpportunityDto{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", currency='" + currency + '\'' +
                ", salesForceUrl='" + salesForceUrl + '\'' +
                ", dealType='" + dealType + '\'' +
                ", productName='" + productName + '\'' +
                ", trialType='" + trialType + '\'' +
                ", domain='" + domain + '\'' +
                ", stage='" + stage + '\'' +
                ", date='" + date + '\'' +
                ", bundleId='" + bundleId + '\'' +
                ", customer=" + customer +
                ", salesRep=" + salesRep +
                '}';
    }
}
