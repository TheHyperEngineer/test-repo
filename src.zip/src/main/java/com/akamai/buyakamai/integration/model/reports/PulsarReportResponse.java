package com.akamai.buyakamai.integration.model.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import org.apache.commons.collections.map.HashedMap;

import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class PulsarReportResponse {

    private ReportMetaData metadata;
    private Map<String, MetricData> summaryStatistics = new HashMap<>();
}
