package com.akamai.buyakamai.integration.clients.impl.rule;

import com.akamai.buyakamai.constants.BREConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyStore;
import java.util.Date;
import java.util.Map;
import java.util.Random;

@Component
public class BreHttpClient {

    // Logger
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    // prop manager
    @Autowired
    protected PropertyManager propertyManager;

    protected String getURI(String serverAddress, String urlSuffix, MultiValueMap<String, String> queryParams, Object... pathValues) {
        logger.debug("Server Address is : {}", serverAddress);
        String uri = StringUtils.EMPTY;
        if (pathValues == null || pathValues.length == 0) {
            uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix)
                    .queryParams(queryParams).toUriString();
        } else {
            uri = UriComponentsBuilder.fromUriString(serverAddress).path(urlSuffix).queryParams(queryParams).buildAndExpand(pathValues).toUriString();
        }
        logger.info("Url value is : {}", uri);
        logger.debug("Exiting method getURI");
        return uri;
    }

    protected BreHttpResponseObject getServerResponse(String url, HttpMethod method, Object requestObject, Map<String, String> headers)
            throws BuyAkamaiApplicationException {
        logger.info("Request Sent to  {} {} ", url, method);
        MultiValueMap<String, String> httpHeaders = new LinkedMultiValueMap<>();
        headers.entrySet().stream().forEach(V -> httpHeaders.add(V.getKey(), V.getValue()));
        logger.debug("Request data {} ", requestObject);

        try {
            ResponseEntity<String> requestResult = performRequest(url, method, CommonUtils.getJsonFromObject(requestObject), httpHeaders);
            logger.debug("Response Received {} ", requestResult.getBody());
            BreHttpResponseObject responseObject = getHttpResponseObject(requestResult);
            return responseObject;
        } catch (HttpStatusCodeException httpStatusCodeException) {
            logger.error("Exception occurred : ", httpStatusCodeException);
            logger.error("Exception occurred while executing call to URL {} with status code {} and exception {}", url, httpStatusCodeException.getStatusCode(), httpStatusCodeException.getMessage());
            logger.error("Response Body {}", httpStatusCodeException.getResponseBodyAsString());
            throw new BuyAkamaiApplicationException("Exception in Server Response", httpStatusCodeException.getMessage(), httpStatusCodeException.getStatusCode());
        } catch (Exception e) {
            logger.error("Exception occurred : ", e);
            logger.error("Exception occurred while executing call to URL {} cause {}", url, e.getStackTrace());
            throw new BuyAkamaiApplicationException("Exception in Server Response", e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }


    public String call(BreHttpRequestObject httpRequestObject) throws BuyAkamaiApplicationException {
        logger.info("Processing http request through client");
        String serverAddress = propertyManager.getProperty(BREConstants.SERVER_ADDRESS);
        String url = getURI(serverAddress, httpRequestObject.getUrlSuffix(), httpRequestObject.getQueryParams());
        logger.debug("generated url : {}", url);
        return getServerResponse(url, httpRequestObject.getMethod(), httpRequestObject.getRequestObject(), httpRequestObject.getHeaders()).getResponseBody();
    }

    protected BreHttpResponseObject getHttpResponseObject(ResponseEntity<String> responseEntity) throws BuyAkamaiApplicationException {
        int statusCode = responseEntity.getStatusCodeValue();
        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            String response = responseEntity.getBody();
            logger.debug("Response body : {}", response);
            BreHttpResponseObject responseObject = new BreHttpResponseObject();
            responseObject.setResponseCode(statusCode);
            responseObject.setResponseBody(response);
            logger.info("Response Object : {}", responseObject.toString());
            return responseObject;
        } else {
            throw new BuyAkamaiApplicationException("Non 2xx Response received", "Non ok Response ", responseEntity.getStatusCode());
        }
    }

    private ResponseEntity<String> performRequest(String url, HttpMethod method, String stringEntity, MultiValueMap<String, String> httpHeaders) {
        RestTemplate restTemplate = buildRestTemplate();
        HttpEntity<String> request;
        if (method == HttpMethod.GET) {
            request = new HttpEntity<String>(httpHeaders);
        } else {
            request = new HttpEntity<String>(stringEntity, httpHeaders);
        }
        return restTemplate.exchange(url, method, request, String.class);
    }


    protected RestTemplate buildRestTemplate() {
        try {
            HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = getSocketFactory();
            return new RestTemplate(clientHttpRequestFactory);
        } catch (Exception ex) {
            logger.info("Exception while building rest template");
        }
        return null;

    }

    private HttpComponentsClientHttpRequestFactory getSocketFactory() throws Exception {
        KeyStore keyStore = KeyStore.getInstance("PKCS12");
        InputStream keyInput = new FileInputStream(
                propertyManager.getProperty(BREConstants.PFX_FILE_LOCATION));
        String pwd = getDecryptedString(propertyManager.getProperty(BREConstants.ENCRYPTED_STRING));
        keyStore.load(keyInput, pwd.toCharArray());
        keyInput.close();

        SSLContextBuilder contextBuilder = new SSLContextBuilder();
        contextBuilder.setProtocol("TLSv1.2");
        contextBuilder.loadKeyMaterial(keyStore, pwd.toCharArray());

        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(contextBuilder.build(),
                NoopHostnameVerifier.INSTANCE);
        HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();

        HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        int timeOut = getTimeOutValue();
        requestFactory.setReadTimeout(timeOut);
        requestFactory.setConnectTimeout(timeOut);
        return requestFactory;
    }

    private String getDecryptedString(String encryptedSting) {
        try {
            if (encryptedSting.length() > 12) {
                String cipher = encryptedSting.substring(12);
                return new String(Base64Utils.decodeFromString(cipher));
            }
        } catch (Exception e) {
            logger.info("Exception while getting decrypted password");
        }
        return null;
    }

    public int getTimeOutValue() {
        String timeOutString = propertyManager.getProperty(BREConstants.CONNECTION_TIMEOUT);
        if(NumberUtils.isNumber(timeOutString)){
            return Integer.parseInt(timeOutString);
        }else{
            return 0;
        }
    }

    public String encryptString(String test) {
        Random random = new Random(new Date().getTime());
        byte[] salt = new byte[8];
        random.nextBytes(salt);
        return Base64Utils.encodeToString(salt) + Base64Utils.encodeToString(test.getBytes());
    }

}
