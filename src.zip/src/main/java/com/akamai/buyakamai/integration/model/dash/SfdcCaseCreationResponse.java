package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SfdcCaseCreationResponse {

    private String success;

    @JsonProperty("caseid")
    private String AKAMCaseId;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getAKAMCaseId() {
        return AKAMCaseId;
    }

    public void setAKAMCaseId(String AKAMCaseId) {
        this.AKAMCaseId = AKAMCaseId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SfdcCaseCreationResponse that = (SfdcCaseCreationResponse) o;

        if (success != null ? !success.equals(that.success) : that.success != null) return false;
        return AKAMCaseId != null ? AKAMCaseId.equals(that.AKAMCaseId) : that.AKAMCaseId == null;
    }

    @Override
    public int hashCode() {
        int result = success != null ? success.hashCode() : 0;
        result = 31 * result + (AKAMCaseId != null ? AKAMCaseId.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SfdcCaseCreationResponse{" +
                "success='" + success + '\'' +
                ", AKAMCaseId='" + AKAMCaseId + '\'' +
                '}';
    }
}