package com.akamai.buyakamai.integration.model.authz;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class IdentityDetails {

    private String identityId;

    private String accountId;

    private IdentityCommonAttributes identityCommonAttributes;

    private Boolean isInternalUser;

    public String getIdentityId() {
        return identityId;
    }

    public void setIdentityId(String identityId) {
        this.identityId = identityId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public IdentityCommonAttributes getIdentityCommonAttributes() {
        return identityCommonAttributes;
    }

    public void setIdentityCommonAttributes(IdentityCommonAttributes identityCommonAttributes) {
        this.identityCommonAttributes = identityCommonAttributes;
    }

    public Boolean isInternalUser() {
        return isInternalUser;
    }

    public void setInternalUser(Boolean isInternalUser) {
        this.isInternalUser = isInternalUser;
    }


    @Override
    public String toString() {
        return "IdentityDetails{" +
                "identityId='" + identityId + '\'' +
                ", accountId='" + accountId + '\'' +
                ", identityCommonAttributes=" + identityCommonAttributes +
                ", isInternalUser=" + isInternalUser +
                '}';
    }
}
