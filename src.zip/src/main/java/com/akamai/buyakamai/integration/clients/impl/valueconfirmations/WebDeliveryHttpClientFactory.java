package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;

import com.akamai.buyakamai.constants.DashConstants;
import com.akamai.buyakamai.util.BeanUtil;
import com.akamai.buyakamai.util.PropertyManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class WebDeliveryHttpClientFactory {

    private static Logger logger = LoggerFactory.getLogger(WebDeliveryHttpClientFactory.class.getName());

    @Autowired
    private PropertyManager propertyManager;

    public WebDeliveryHttpClient getAppropriateWebDeliveryHttpClient() {
        String env = propertyManager.getProperty(DashConstants.DASH_ENVIRONMENT_KEY);
        if (env.contains("cloud")) {
            logger.debug("building context for cloud env");
            return (WebDeliveryHttpClient) BeanUtil.getBean("WebDeliveryEAAHttpClient");
        } else {
            return (WebDeliveryHttpClient) BeanUtil.getBean("MetisHttpClient");
        }
    }
}
