package com.akamai.buyakamai.integration.service.impl;

import com.akamai.buyakamai.constants.DashConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.impl.valueconfirmations.TLSSocketFactoryBuilder;
import com.akamai.buyakamai.integration.clients.model.AccessTokenModel;
import com.akamai.buyakamai.integration.model.dash.*;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.nio.charset.Charset;
import java.util.*;

import static com.akamai.buyakamai.util.CommonUtils.getObjectFromStringJson;
import static java.util.stream.Collectors.groupingBy;

@Service
public class DashServiceImpl {

    private static Logger logger = LoggerFactory.getLogger(DashServiceImpl.class.getName());

    @Autowired
    private PropertyManager propertyManager;

    @Autowired
    private TLSSocketFactoryBuilder tlsSocketFactoryBuilder;

    public String createOpportunity(OpportunityRequestDTO opportunity) {
        HttpHeaders headers = getHeadersForDashCall();
        HttpEntity<OpportunityRequestDTO> request = new HttpEntity<>(opportunity, headers);
        logger.info("Create opportunity json: " + new Gson().toJson(opportunity));
        String opportunityUrlSuffix = propertyManager.getProperty(DashConstants.DASH_CREATE_OPPORTUNITY_URL_SUFFIX);
        logger.info("Making request to create opportunity");
        ResponseEntity<String> response = fetchResponseFromDash(getURI(opportunityUrlSuffix, null),
                HttpMethod.POST, request, String.class);
        logger.info("Response from the Dash is (createOpportunity) for accountId: {} is {}", opportunity.getAccountId(), response.getBody());
        String locationHeaderValue = response.getHeaders().getLocation().toString();
        String opportunityId = locationHeaderValue.substring(locationHeaderValue.lastIndexOf('/') + 1);
        return opportunityId;
    }

    public List<String> fetchCompetitors() {

        logger.info("fetching competitor list through Dash service");

        String accessToken = getAccessToken();
        HttpHeaders headers = new HttpHeaders();
        headers.set(DashConstants.DASH_ACCESS_TOKEN, accessToken);
        HttpEntity request = new HttpEntity<>(headers);
        String competitorUrlSuffix = propertyManager.getProperty(DashConstants.DASH_OPPORTUNITY_COMEPITITOR_URL_SUFFIX);
        ResponseEntity<String> response = fetchResponseFromDash(getURI(competitorUrlSuffix, null),
                HttpMethod.GET, request, String.class);
        logger.debug("Response competitor list is {}", response.getBody());

        return convertToCompetitorsList(response.getBody());
    }

    public ContactUiMetaDataResponse fetchContactsUIMetaData() {
        logger.info("getting contact UI meta data");

        HttpHeaders headers = getHeadersForDashCall();
        HttpEntity request = new HttpEntity<>(headers);
        String statesUrlSuffix = propertyManager.getProperty(DashConstants.DASH_GET_STATES_URL_SUFFIX);
        ResponseEntity<String> stateResponse = fetchResponseFromDash(getURI(statesUrlSuffix, null),
                HttpMethod.GET, request, String.class);
        logger.debug("Response competitor list is {}", stateResponse.getBody());

        String countryUrlSuffix = propertyManager.getProperty(DashConstants.DASH_GET_COUNTRIES_URL_SUFFIX);
        ResponseEntity<String> countryResponse = fetchResponseFromDash(getURI(countryUrlSuffix, null),
                HttpMethod.GET, request, String.class);
        logger.debug("Response competitor list is {}", countryResponse.getBody());

        ContactUiMetaDataResponse response = new ContactUiMetaDataResponse();
        response.setCountries(mergeStateCountryList(countryResponse.getBody(), stateResponse.getBody()));

        logger.debug("Returning contact UI metadata response {}", response);
        return response;
    }

    public List<TransformedMetadataDto> mergeStateCountryList(String countryResponse, String stateResponse) {
        SfdcSupportedCountryResponseDto sfdcSupportedCountryResponseDto = CommonUtils.getObjectFromStringJson(countryResponse, SfdcSupportedCountryResponseDto.class);
        SfdcSupportedStateResponseDto sfdcSupportedStateResponseDto = CommonUtils.getObjectFromStringJson(stateResponse, SfdcSupportedStateResponseDto.class);

        Map<String, TransformedMetadataDto> mergedCountryList = new HashMap<>();
        sfdcSupportedCountryResponseDto.getCountries().stream().map(V -> mergedCountryList.put(V.getName(), copyCountryBean(V))).count();

        Map<String, List<SfdcStateDto>> countryStateMapping = sfdcSupportedStateResponseDto.getStates().stream().sorted(Comparator.comparing(SfdcStateDto::getName)).
                collect(groupingBy(SfdcStateDto::getAssociatedCounty));

        mergedCountryList.entrySet().stream().map(
                V -> {
                    V.getValue().setStates(countryStateMapping.get(V.getKey()));
                    return true;
                }
        ).count();

        List<TransformedMetadataDto> responseList = new ArrayList<>(mergedCountryList.values());
        Collections.sort(responseList, Comparator.comparing(TransformedMetadataDto::getName));
        return responseList;
    }

    public static TransformedMetadataDto copyCountryBean(SfdcCountryDto sfdcCountryDto) {
        TransformedMetadataDto responseDto = new TransformedMetadataDto();
        responseDto.setId(sfdcCountryDto.getId());
        responseDto.setName(sfdcCountryDto.getName());
        responseDto.setCurrencyIsoCode(sfdcCountryDto.getCurrencyIsoCode());
        return responseDto;
    }

    private String getAccessToken() {

        logger.info("Getting the access token from the l2c bridge");
        HttpHeaders headers = getHeadersForFetchingAccessToken(HttpHeaders.AUTHORIZATION, getBase64EncodedIdAndSecret());
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return fetchAccessTokenUsingHeader(headers);

    }

    private String fetchAccessTokenUsingHeader(HttpHeaders headers) {
        String accessTokenUrlSuffix = propertyManager.getProperty(DashConstants.DASH_ACCESS_TOKEN_URL_SUFFIX);
        HttpEntity<?> request = new HttpEntity<>(headers);
        ResponseEntity<String> responseJson = fetchResponseFromDash(getURI(accessTokenUrlSuffix, null), HttpMethod.GET,
                request, String.class);
        AccessTokenModel accessTokenModel = getObjectFromStringJson(responseJson.getBody(), AccessTokenModel.class);
        logger.info("access token retrieved");
        return accessTokenModel.getAccessToken();
    }


    private String getURI(String urlSuffix, MultiValueMap<String, String> queryParams, String... pathValues) {

        String ltocServerAddress = propertyManager.getProperty(DashConstants.DASH_SERVER_ADDRESS);
        String uri = UriComponentsBuilder.fromUriString(ltocServerAddress).path(urlSuffix).pathSegment(pathValues)
                .queryParams(queryParams).toUriString();
        logger.info("Url value is : " + uri);
        return uri;
    }


    private HttpHeaders getHeadersForFetchingAccessToken(String headerKey, String headerValue) {

        String grantTypeValue = propertyManager.getProperty(DashConstants.DASH_GRANT_TYPE_PROPERTY_STRING);
        String scopeValue = propertyManager.getProperty(DashConstants.DASH_SCOPE_PROPERTY_STRING);
        HttpHeaders headers = new HttpHeaders();
        headers.set(headerKey, headerValue);
        headers.set(DashConstants.DASH_GRANT_TYPE_STRING, grantTypeValue);
        headers.set(DashConstants.DASH_SCOPE_STRING, scopeValue);
        return headers;
    }

    private String getBase64EncodedIdAndSecret() {

        String clientId = propertyManager.getProperty(DashConstants.DASH_CLIENT_ID_PROPERTY_STRING);
        String clientSecret = propertyManager.getProperty(DashConstants.DASH_CLIENT_SECRET_PROPERTY_STRING);
        String clientIdAndClientSecret = clientId + ":" + clientSecret;
        String base64EncodedString = Base64Utils.encodeToString(clientIdAndClientSecret.getBytes());
        return "Basic " + base64EncodedString;
    }

    <T> ResponseEntity<T> fetchResponseFromDash(String uri, HttpMethod httpMethod, HttpEntity<?> request,
                                                Class<T> className) {
        RestTemplate restTemplate = tlsSocketFactoryBuilder.getRestTemplate();
        ResponseEntity<T> responseJson = null;
        logger.info("Making http Request to Dash");
        try {
            restTemplate.getMessageConverters()
                    .add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
            responseJson = restTemplate.exchange(uri, httpMethod, request, className);
            logger.info("Response value has been retrieved from the Dash ");
            if (!responseJson.getStatusCode().is2xxSuccessful()) {
                String title = "Error Response from Dash";
                String detail = "Failed with the following response " + responseJson.toString();
                logger.error("error response from Dash: {}", responseJson.toString());
                throw new BuyAkamaiApplicationException(title, detail,
                        responseJson.getStatusCode());
            }
        } catch (HttpStatusCodeException e) {
            logger.info("Error response from Dash: status code {} \n response body: {}", e.getStatusCode(), e.getResponseBodyAsString());
            logger.error("Failed with the following exception ", e);
            if (e.getStatusCode() == HttpStatus.CONFLICT) {
                //pass the conflict
                throw new BuyAkamaiApplicationException(e.getMessage(), "Conflict response", HttpStatus.CONFLICT);
            }
            throw new BuyAkamaiApplicationException(e.getMessage(), e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            String msg = "There is an error with Dash connection " + e.getMessage();
            logger.error(msg + "\n", e);
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseJson;
    }

    HttpHeaders getHeadersForDashCall() {
        String accessToken = getAccessToken();
        HttpHeaders headers = new HttpHeaders();
        headers.set(DashConstants.DASH_ACCESS_TOKEN, accessToken);
        headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
        return headers;
    }

    private List<String> convertToCompetitorsList(String jsonResponse) {

        JsonParser jsonParser = new JsonParser();
        JsonObject jsonObject = (JsonObject) jsonParser.parse(jsonResponse);
        JsonArray jsonArray = jsonObject.getAsJsonArray(DashConstants.COMPETITOR_LIST_KEY);

        List<String> competitors = new ArrayList<>();

        for (int i = 0; i < jsonArray.size(); i++) {
            String competitor = ((JsonObject) jsonArray.get(i)).get("Name").getAsString();
            competitors.add(competitor);
        }
        return competitors;
    }

    private HttpHeaders buildHeadersForMetis() {

        String grantTypeValue = propertyManager.getProperty(DashConstants.DASH_GRANT_TYPE_PROPERTY_STRING);
        HttpHeaders headers = new HttpHeaders();
        headers.set(HttpHeaders.AUTHORIZATION, getBase64EncodedIdAndSecret());
        headers.set(DashConstants.DASH_GRANT_TYPE_STRING, grantTypeValue);
        headers.set(DashConstants.DASH_SCOPE_STRING, propertyManager.getProperty(DashConstants.DASH_SCOPE_FOR_METIS));
        return headers;
    }


    public String getAccessTokenForMetis() {
        logger.info("Getting the access token from the Dash");
        HttpHeaders headers = buildHeadersForMetis();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        return fetchAccessTokenUsingHeader(headers);
    }


}
