package com.akamai.buyakamai.integration.model.reports;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class MetricData {

    private String value;

}

