package com.akamai.buyakamai.integration.model.productmaster;



import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RuleExpressionDTO {

    private SelectedOptionDTO selected;
    private List<SelectActionDTO> enable;
    private List<SelectActionDTO> elseEnable;

    public SelectedOptionDTO getSelected() {
        return selected;
    }

    public void setSelected(SelectedOptionDTO selected) {
        this.selected = selected;
    }

    public List<SelectActionDTO> getEnable() {
        return enable;
    }

    public void setEnable(List<SelectActionDTO> enable) {
        this.enable = enable;
    }

    public List<SelectActionDTO> getElseEnable() {
        return elseEnable;
    }

    public void setElseEnable(List<SelectActionDTO> elseEnable) {
        this.elseEnable = elseEnable;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        RuleExpressionDTO that = (RuleExpressionDTO) o;

        if (selected != null ? !selected.equals(that.selected) : that.selected != null) return false;
        if (enable != null ? !enable.equals(that.enable) : that.enable != null) return false;
        return elseEnable != null ? elseEnable.equals(that.elseEnable) : that.elseEnable == null;
    }

    @Override
    public int hashCode() {
        int result = selected != null ? selected.hashCode() : 0;
        result = 31 * result + (enable != null ? enable.hashCode() : 0);
        result = 31 * result + (elseEnable != null ? elseEnable.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "RuleExpressionDTO{" +
                "selected=" + selected +
                ", enable=" + enable +
                ", elseEnable=" + elseEnable +
                '}';
    }
}
