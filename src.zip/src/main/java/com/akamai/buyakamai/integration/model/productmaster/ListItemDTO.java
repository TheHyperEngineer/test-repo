package com.akamai.buyakamai.integration.model.productmaster;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ToStringBuilder;


import java.util.List;


@JsonIgnoreProperties(ignoreUnknown=true)
public class ListItemDTO {

	private String listItemId;

	private String pricingMethod;

	private String usageMethod;
	
	private String quantity;
	
	private TrialUomDTO uom;
	
	private String billingFrequency;

	private String chargeType;

	private String gsaSINCode;

	private String description;

	private List<TierDTO> tiers;

	public String getListItemId() {
		return listItemId;
	}

	public void setListItemId(String listItemId) {
		this.listItemId = listItemId;
	}

	public String getPricingMethod() {
		return pricingMethod;
	}

	public void setPricingMethod(String pricingMethod) {
		this.pricingMethod = pricingMethod;
	}

	public String getUsageMethod() {
		return usageMethod;
	}

	public void setUsageMethod(String usageMethod) {
		this.usageMethod = usageMethod;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public TrialUomDTO getUom() {
		return uom;
	}

	public void setUom(TrialUomDTO uom) {
		this.uom = uom;
	}

	public String getBillingFrequency() {
		return billingFrequency;
	}

	public void setBillingFrequency(String billingFrequency) {
		this.billingFrequency = billingFrequency;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public String getGsaSINCode() {
		return gsaSINCode;
	}

	public void setGsaSINCode(String gsaSINCode) {
		this.gsaSINCode = gsaSINCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<TierDTO> getTiers() {
		return tiers;
	}

	public void setTiers(List<TierDTO> tiers) {
		this.tiers = tiers;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		ListItemDTO that = (ListItemDTO) o;

		if (listItemId != null ? !listItemId.equals(that.listItemId) : that.listItemId != null) return false;
		if (pricingMethod != null ? !pricingMethod.equals(that.pricingMethod) : that.pricingMethod != null)
			return false;
		if (usageMethod != null ? !usageMethod.equals(that.usageMethod) : that.usageMethod != null) return false;
		if (quantity != null ? !quantity.equals(that.quantity) : that.quantity != null) return false;
		if (uom != null ? !uom.equals(that.uom) : that.uom != null) return false;
		if (billingFrequency != null ? !billingFrequency.equals(that.billingFrequency) : that.billingFrequency != null)
			return false;
		if (chargeType != null ? !chargeType.equals(that.chargeType) : that.chargeType != null) return false;
		if (gsaSINCode != null ? !gsaSINCode.equals(that.gsaSINCode) : that.gsaSINCode != null) return false;
		if (description != null ? !description.equals(that.description) : that.description != null) return false;
		return tiers != null ? tiers.equals(that.tiers) : that.tiers == null;
	}

	@Override
	public int hashCode() {
		int result = listItemId != null ? listItemId.hashCode() : 0;
		result = 31 * result + (pricingMethod != null ? pricingMethod.hashCode() : 0);
		result = 31 * result + (usageMethod != null ? usageMethod.hashCode() : 0);
		result = 31 * result + (quantity != null ? quantity.hashCode() : 0);
		result = 31 * result + (uom != null ? uom.hashCode() : 0);
		result = 31 * result + (billingFrequency != null ? billingFrequency.hashCode() : 0);
		result = 31 * result + (chargeType != null ? chargeType.hashCode() : 0);
		result = 31 * result + (gsaSINCode != null ? gsaSINCode.hashCode() : 0);
		result = 31 * result + (description != null ? description.hashCode() : 0);
		result = 31 * result + (tiers != null ? tiers.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
