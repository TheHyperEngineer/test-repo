package com.akamai.buyakamai.integration.model.productmaster;

import java.math.BigDecimal;

import javax.validation.constraints.DecimalMin;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Pricing information for 
 * @author jdixit
 *
 */
@JsonIgnoreProperties(ignoreUnknown=true)
public class TierDTO {

	private Long unitLow;

	private Long unitHigh;

	@DecimalMin(value = "0.0" , message = "Unit price can not be negative.")
	private BigDecimal unitPrice;

	@DecimalMin(value = "0.0" , message = "Overage price can not be negative.")
	private BigDecimal overagePrice;

	public long getUnitLow() {
		return unitLow;
	}

	public void setUnitLow(Long unitLow) {
		this.unitLow = unitLow;
	}

	public long getUnitHigh() {
		return unitHigh;
	}

	public void setUnitHigh(Long unitHigh) {
		this.unitHigh = unitHigh;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public BigDecimal getOveragePrice() {
		return overagePrice;
	}

	public void setOveragePrice(BigDecimal overagePrice) {
		this.overagePrice = overagePrice;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
