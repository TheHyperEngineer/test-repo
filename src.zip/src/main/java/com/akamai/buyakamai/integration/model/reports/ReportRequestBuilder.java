package com.akamai.buyakamai.integration.model.reports;


import org.joda.time.LocalDate;

import java.util.List;

public class ReportRequestBuilder {

    private LocalDate startDate;
    private LocalDate endDate;
    private ReportInterval interval;
    private List<String> cpCodes;
    private String accountId;
    private String contractId;

    public ReportRequestBuilder startDate(LocalDate startDate) {
        this.startDate = startDate;
        return this;
    }

    public ReportRequestBuilder endDate(LocalDate endDate) {
        this.endDate = endDate;
        return this;
    }

    public ReportRequestBuilder interval(ReportInterval interval) {
        this.interval = interval;
        return this;
    }

    public ReportRequestBuilder cpCodes(List<String> cpCodes) {
        this.cpCodes = cpCodes;
        return this;
    }

    public ReportRequestBuilder accountId(String accountId) {
        this.accountId = accountId;
        return this;
    }

    public ReportRequestBuilder contractId(String contractId) {
        this.contractId = contractId;
        return this;
    }

    public ReportRequest build() {
        return new ReportRequest(startDate, endDate, interval, cpCodes, accountId, contractId);
    }

}
