package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;


public class WebDeliveryRequestParameterBuilder {

    private String metric;
    private String aggregate;
    private String testSetUpId;
    private String countryList;
    private String method;
    private String startTime;
    private String endTime;
    private String geoList;
    private String unit;

    private String goodExperience;
    private String badExperience;
    private String min;
    private String max;
    private String step;

    public WebDeliveryRequestParameterBuilder unit(String value){
        this.unit=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder geoList(String value){
        this.geoList=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder goodExperience(String value){
        this.goodExperience=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder badExperience(String value){
        this.badExperience=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder min(String value){
        this.min=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder max(String value){
        this.max=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder step(String value){
        this.step=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder metric(String value){
        this.metric=value;
        return this;
    }


    public WebDeliveryRequestParameterBuilder aggregate(String value){
        this.aggregate=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder testSetUpId(String value){
        this.testSetUpId=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder countryList(String value){
        this.countryList=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder method(String value){
        this.method=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder startTime(String value){
        this.startTime=value;
        return this;
    }

    public WebDeliveryRequestParameterBuilder endTime(String value){
        this.endTime=value;
        return this;
    }

    public WebDeliveryRequestParameter build(){
        return new WebDeliveryRequestParameter(metric,aggregate,testSetUpId,countryList,method,startTime,endTime,geoList,unit);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryRequestParameterBuilder that = (WebDeliveryRequestParameterBuilder) o;

        if (metric != null ? !metric.equals(that.metric) : that.metric != null) return false;
        if (aggregate != null ? !aggregate.equals(that.aggregate) : that.aggregate != null) return false;
        if (testSetUpId != null ? !testSetUpId.equals(that.testSetUpId) : that.testSetUpId != null) return false;
        if (countryList != null ? !countryList.equals(that.countryList) : that.countryList != null) return false;
        if (method != null ? !method.equals(that.method) : that.method != null) return false;
        if (startTime != null ? !startTime.equals(that.startTime) : that.startTime != null) return false;
        if (endTime != null ? !endTime.equals(that.endTime) : that.endTime != null) return false;
        if (geoList != null ? !geoList.equals(that.geoList) : that.geoList != null) return false;
        if (goodExperience != null ? !goodExperience.equals(that.goodExperience) : that.goodExperience != null)
            return false;
        if (badExperience != null ? !badExperience.equals(that.badExperience) : that.badExperience != null)
            return false;
        if (min != null ? !min.equals(that.min) : that.min != null) return false;
        if (max != null ? !max.equals(that.max) : that.max != null) return false;
        return step != null ? step.equals(that.step) : that.step == null;
    }

    @Override
    public int hashCode() {
        int result = metric != null ? metric.hashCode() : 0;
        result = 31 * result + (aggregate != null ? aggregate.hashCode() : 0);
        result = 31 * result + (testSetUpId != null ? testSetUpId.hashCode() : 0);
        result = 31 * result + (countryList != null ? countryList.hashCode() : 0);
        result = 31 * result + (method != null ? method.hashCode() : 0);
        result = 31 * result + (startTime != null ? startTime.hashCode() : 0);
        result = 31 * result + (endTime != null ? endTime.hashCode() : 0);
        result = 31 * result + (geoList != null ? geoList.hashCode() : 0);
        result = 31 * result + (goodExperience != null ? goodExperience.hashCode() : 0);
        result = 31 * result + (badExperience != null ? badExperience.hashCode() : 0);
        result = 31 * result + (min != null ? min.hashCode() : 0);
        result = 31 * result + (max != null ? max.hashCode() : 0);
        result = 31 * result + (step != null ? step.hashCode() : 0);
        return result;
    }
}
