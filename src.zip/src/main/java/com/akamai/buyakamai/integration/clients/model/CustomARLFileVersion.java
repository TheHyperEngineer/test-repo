package com.akamai.buyakamai.integration.clients.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomARLFileVersion {

	private Integer fileVersion;
	
	private List<CustomARLFileHost> arlFileHosts;
	
	private Boolean deleted;
	
	private String comments;
	
	private String arlConfigType;
	
	private Integer quickstartVersion;
	
	private Boolean activatedOnStaging;
	
	private Boolean activatedOnProduction;

	public Integer getFileVersion() {
		return fileVersion;
	}

	public void setFileVersion(Integer fileVersion) {
		this.fileVersion = fileVersion;
	}

	public List<CustomARLFileHost> getArlFileHosts() {
		return arlFileHosts;
	}

	public void setArlFileHosts(List<CustomARLFileHost> arlFileHosts) {
		this.arlFileHosts = arlFileHosts;
	}

	public Boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(Boolean deleted) {
		this.deleted = deleted;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getArlConfigType() {
		return arlConfigType;
	}

	public void setArlConfigType(String arlConfigType) {
		this.arlConfigType = arlConfigType;
	}

	public Integer getQuickstartVersion() {
		return quickstartVersion;
	}

	public void setQuickstartVersion(Integer quickstartVersion) {
		this.quickstartVersion = quickstartVersion;
	}

	public Boolean isActivatedOnStaging() {
		return activatedOnStaging;
	}

	public void setActivatedOnStaging(Boolean activatedOnStaging) {
		this.activatedOnStaging = activatedOnStaging;
	}

	public Boolean isActivatedOnProduction() {
		return activatedOnProduction;
	}

	public void setActivatedOnProduction(Boolean activatedOnProduction) {
		this.activatedOnProduction = activatedOnProduction;
	}
	
    @Override
    public final int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public final boolean equals(final Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}