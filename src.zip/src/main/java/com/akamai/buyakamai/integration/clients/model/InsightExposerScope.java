package com.akamai.buyakamai.integration.clients.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class InsightExposerScope {

	private String accountID;
	private List<String> cpCodes;
	 
	public String getAccountID() {
		return accountID;
	}
	public void setAccountID(String accountID) {
		this.accountID = accountID;
	}
	public List<String> getCpCodes() {
		return cpCodes;
	}
	public void setCpCodes(List<String> cpCodes) {
		this.cpCodes = cpCodes;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountID == null) ? 0 : accountID.hashCode());
		result = prime * result + ((cpCodes == null) ? 0 : cpCodes.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		InsightExposerScope other = (InsightExposerScope) obj;
		if (accountID == null) {
			if (other.accountID != null)
				return false;
		} else if (!accountID.equals(other.accountID))
			return false;
		if (cpCodes == null) {
			if (other.cpCodes != null)
				return false;
		} else if (!cpCodes.equals(other.cpCodes))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return "MPulseScope [accountID=" + accountID + ", cpCodes=" + cpCodes + "]";
	}
}
