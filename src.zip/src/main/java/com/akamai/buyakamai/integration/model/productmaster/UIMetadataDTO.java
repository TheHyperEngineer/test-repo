package com.akamai.buyakamai.integration.model.productmaster;


public class UIMetadataDTO {

	private String metadata;
	private String locale;

	public UIMetadataDTO(String metadataJson, String locale) {
		this.metadata = metadataJson;
		this.locale = locale;
	}

	public UIMetadataDTO() {
	}

	public String getMetadata() {
		return metadata;
	}

	public void setMetadata(String metadata) {
		this.metadata = metadata;
	}

	public String getLocale() {
		return locale;
	}

	public void setLocale(String locale) {
		this.locale = locale;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((locale == null) ? 0 : locale.hashCode());
		result = prime * result + ((metadata == null) ? 0 : metadata.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UIMetadataDTO other = (UIMetadataDTO) obj;
		if (locale == null) {
			if (other.locale != null)
				return false;
		} else if (!locale.equals(other.locale))
			return false;
		if (metadata == null) {
			if (other.metadata != null)
				return false;
		} else if (!metadata.equals(other.metadata))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "UIMetadataDTO [metadata=" + metadata + ", locale=" + locale + "]";
	}

}