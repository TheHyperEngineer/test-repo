package com.akamai.buyakamai.integration.model.productmaster;

public class ProductMasterKey {
	private String bundleId;
	private String locale;

	public ProductMasterKey(String bundleId, String locale) {
		super();
		this.bundleId = bundleId;
		this.locale = locale;
	}

	public String getBundleId() {
		return bundleId;
	}

	public String getLocale() {
		return locale;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bundleId == null) ? 0 : bundleId.hashCode());
		result = prime * result + ((locale == null) ? 0 : locale.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductMasterKey other = (ProductMasterKey) obj;
		if (bundleId == null) {
			if (other.bundleId != null)
				return false;
		} else if (!bundleId.equals(other.bundleId))
			return false;
		if (locale == null) {
			if (other.locale != null)
				return false;
		} else if (!locale.equals(other.locale))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ProductMasterKey [bundleId=" + bundleId + ", locale=" + locale + "]";
	}

}
