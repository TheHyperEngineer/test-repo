package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;

import com.akamai.buyakamai.constants.WebDeliveryHttpConstants;
import com.akamai.buyakamai.util.PropertyManager;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.ArrayList;
import java.util.List;


public class WebDeliveryRequestParameter {

    private final String metric;
    private final String aggregate;
    private final String testSetUpId;
    private final String countryList;
    private final String method;
    private final String startTime;
    private final String endTime;
    private final String geoList;
    private final String unit;

    //properties for Aggregation
    private String overall;

    //properties for Histogram
    private String goodExperience;
    private String badExperience;
    private String min;
    private String max;
    private String step;

    private final MultiValueMap<String, String> map;


    public WebDeliveryRequestParameter(String metric, String aggregate, String testSetUpId, String countryList, String method, String startTime, String endTime, String geoList, String unit) {
        if (method == null) {
            throw new NullPointerException("Method can't be empty");
        } else if (testSetUpId == null) {
            throw new NullPointerException("Test setup Id can't be null");
        } else if (metric == null) {
            throw new NullPointerException("Metric can't be null");
        } else {

            //values are expected
            this.testSetUpId = testSetUpId;
            this.method = method;
            this.metric = metric;
            this.countryList = countryList;
            this.geoList = geoList;
            this.unit = unit;

            //default values
            this.aggregate = aggregate == null ? WebDeliveryHttpConstants.AGGREGATE_DEFAULT_VALUE : aggregate;
            this.startTime = startTime == null ? WebDeliveryHttpConstants.START_DATE_DEFAULT_VALUE : startTime;
            this.endTime = endTime == null ? WebDeliveryHttpConstants.END_DATE_DEFAULT_VALUE : endTime;

            if (method.equals("GetHistogram")) {

                this.goodExperience = WebDeliveryHttpConstants.HISTOGRAM_GOOD_EXPERIENCE_DEFAULT_VALUE;
                this.badExperience = WebDeliveryHttpConstants.HISTOGRAM_BAD_EXPERIENCE_DEFAULT_VALUE;
                this.min = WebDeliveryHttpConstants.HISTOGRAM_MIN_DEFAULT_VALUE;
                this.max = WebDeliveryHttpConstants.HISTOGRAM_MAX_DEFAULT_VALUE;
                this.step = WebDeliveryHttpConstants.HISTOGRAM_STEP_DEFAULT_VALUE;
            }

            if (method.equals("GetMetricAggregation")) {
                this.overall = WebDeliveryHttpConstants.AGGREGATION_REFRESH_DEFAULT_VALUE;
            }
        }

        this.map= new LinkedMultiValueMap<String, String>();
        this.map.add(WebDeliveryHttpConstants.METRIC_PARAMETER_KEY, this.metric);
        this.map.add(WebDeliveryHttpConstants.START_TIME_PARAMETER_KEY, this.startTime);
        this.map.add(WebDeliveryHttpConstants.END_TIME_PARAMETER_KEY, this.endTime);

        if(null != unit)
            this.map.add(WebDeliveryHttpConstants.UNIT_PARAMETER_KEY, this.unit);

        this.map.add(WebDeliveryHttpConstants.AGGREGATE_PARAMETER_KEY, this.aggregate);
        this.map.add(WebDeliveryHttpConstants.TEST_SETUP_INFO_PARAMETER_KEY, this.testSetUpId);

        //country list not needed for metric aggregation
        if (null != countryList)
            this.map.add(WebDeliveryHttpConstants.COUNTRY_LIST_PARAMETER_KEY, this.countryList);

        if (null != geoList)
            this.map.add(WebDeliveryHttpConstants.GEO_LIST_PARAMETER_KEY, this.geoList);

        this.map.add(WebDeliveryHttpConstants.METHOD_PARAMETER_KEY, this.method);

        if (method.equals("GetMetricAggregation"))
            this.map.add(WebDeliveryHttpConstants.AGGREGATE_REFRESH_PARAMETER_KEY, this.overall);

        if (method.equals("GetHistogram")) {
            this.map.add(WebDeliveryHttpConstants.GOOD_EXPERIENCE_PARAMETER_KEY, this.goodExperience);
            this.map.add(WebDeliveryHttpConstants.BAD_EXPERIENCE_PARAMETER_KEY, this.badExperience);
            this.map.add(WebDeliveryHttpConstants.MIN_PARAMETER_KEY, this.min);
            this.map.add(WebDeliveryHttpConstants.MAX_PARAMETER_KEY, this.max);
            this.map.add(WebDeliveryHttpConstants.STEP_PARAMETER_KEY, this.step);
        }
    }

    public String getUnit() {
        return unit;
    }

    public String getGoodExperience() {
        return goodExperience;
    }

    public String getBadExperience() {
        return badExperience;
    }

    public String getMin() {
        return min;
    }

    public String getMax() {
        return max;
    }

    public String getStep() {
        return step;
    }

    public String getMetric() {
        return metric;
    }

    public String getAggregate() {
        return aggregate;
    }

    public String getTestSetUpId() {
        return testSetUpId;
    }

    public String getCountryList() {
        return countryList;
    }

    public String getGeoList() {
        return geoList;
    }

    public String getMethod() {
        return method;
    }

    public String getStartTime() {
        return startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public String getOverall() {
        return overall;
    }

    public MultiValueMap<String, String> getMap() {
        return map;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryRequestParameter that = (WebDeliveryRequestParameter) o;

        if (metric != null ? !metric.equals(that.metric) : that.metric != null) return false;
        if (aggregate != null ? !aggregate.equals(that.aggregate) : that.aggregate != null) return false;
        if (testSetUpId != null ? !testSetUpId.equals(that.testSetUpId) : that.testSetUpId != null) return false;
        if (countryList != null ? !countryList.equals(that.countryList) : that.countryList != null) return false;
        if (method != null ? !method.equals(that.method) : that.method != null) return false;
        if (startTime != null ? !startTime.equals(that.startTime) : that.startTime != null) return false;
        if (endTime != null ? !endTime.equals(that.endTime) : that.endTime != null) return false;
        if (geoList != null ? !geoList.equals(that.geoList) : that.geoList != null) return false;
        if (unit != null ? !unit.equals(that.unit) : that.unit != null) return false;
        if (overall != null ? !overall.equals(that.overall) : that.overall != null) return false;
        if (goodExperience != null ? !goodExperience.equals(that.goodExperience) : that.goodExperience != null)
            return false;
        if (badExperience != null ? !badExperience.equals(that.badExperience) : that.badExperience != null)
            return false;
        if (min != null ? !min.equals(that.min) : that.min != null) return false;
        if (max != null ? !max.equals(that.max) : that.max != null) return false;
        if (step != null ? !step.equals(that.step) : that.step != null) return false;
        return map != null ? map.equals(that.map) : that.map == null;
    }

    @Override
    public int hashCode() {
        int result = metric != null ? metric.hashCode() : 0;
        result = 31 * result + (aggregate != null ? aggregate.hashCode() : 0);
        result = 31 * result + (testSetUpId != null ? testSetUpId.hashCode() : 0);
        result = 31 * result + (countryList != null ? countryList.hashCode() : 0);
        result = 31 * result + (method != null ? method.hashCode() : 0);
        result = 31 * result + (startTime != null ? startTime.hashCode() : 0);
        result = 31 * result + (endTime != null ? endTime.hashCode() : 0);
        result = 31 * result + (geoList != null ? geoList.hashCode() : 0);
        result = 31 * result + (unit != null ? unit.hashCode() : 0);
        result = 31 * result + (overall != null ? overall.hashCode() : 0);
        result = 31 * result + (goodExperience != null ? goodExperience.hashCode() : 0);
        result = 31 * result + (badExperience != null ? badExperience.hashCode() : 0);
        result = 31 * result + (min != null ? min.hashCode() : 0);
        result = 31 * result + (max != null ? max.hashCode() : 0);
        result = 31 * result + (step != null ? step.hashCode() : 0);
        result = 31 * result + (map != null ? map.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "WebDeliveryRequestParameter{" +
                "metric='" + metric + '\'' +
                ", aggregate='" + aggregate + '\'' +
                ", testSetUpId='" + testSetUpId + '\'' +
                ", countryList='" + countryList + '\'' +
                ", method='" + method + '\'' +
                ", startTime='" + startTime + '\'' +
                ", endTime='" + endTime + '\'' +
                ", geoList='" + geoList + '\'' +
                ", unit='" + unit + '\'' +
                ", overall='" + overall + '\'' +
                ", goodExperience='" + goodExperience + '\'' +
                ", badExperience='" + badExperience + '\'' +
                ", min='" + min + '\'' +
                ", max='" + max + '\'' +
                ", step='" + step + '\'' +
                ", map=" + map +
                '}';
    }
}
