package com.akamai.buyakamai.integration.model.dash;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SfdcSupportedCountryResponseDto {

    private List<SfdcCountryDto> countries;

    public List<SfdcCountryDto> getCountries() {
        return countries;
    }

    public void setCountries(List<SfdcCountryDto> countries) {
        this.countries = countries;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SfdcSupportedCountryResponseDto that = (SfdcSupportedCountryResponseDto) o;

        return countries != null ? countries.equals(that.countries) : that.countries == null;
    }

    @Override
    public int hashCode() {
        return countries != null ? countries.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SupportedCountryDto{" +
                "countries=" + countries +
                '}';
    }
}
