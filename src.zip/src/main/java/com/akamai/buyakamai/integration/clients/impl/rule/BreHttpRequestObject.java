package com.akamai.buyakamai.integration.clients.impl.rule;

import org.springframework.http.HttpMethod;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

public class BreHttpRequestObject {

    private final String urlSuffix;
    private final MultiValueMap<String, String> queryParams;
    private final HttpMethod method;
    private final Object requestObject;
    private final Map<String, String> headers;
    private final Object[] pathParams;
    private boolean hasAttachments;

    public BreHttpRequestObject(String urlSuffix, MultiValueMap<String, String> queryParams,
                                HttpMethod method, Object requestObject, Map<String, String> headers, Object[] pathParams, boolean hasAttachments) {
        if (urlSuffix == null) {
            throw new NullPointerException("url suffix cannot be null");
        } else {
            this.urlSuffix = urlSuffix;
            this.queryParams = queryParams == null ? new LinkedMultiValueMap<>() : queryParams;
            this.method = method == null ? HttpMethod.GET : method;
            this.requestObject = requestObject;
            this.headers = headers == null ? new HashMap<>() : headers;
            Object[] emptyPathParams = {};
            this.pathParams = pathParams == null ? emptyPathParams : pathParams;
            this.hasAttachments = hasAttachments;
        }
    }


    public String getUrlSuffix() {
        return urlSuffix;
    }

    public MultiValueMap<String, String> getQueryParams() {
        return new LinkedMultiValueMap<>(queryParams);
    }

    public HttpMethod getMethod() {
        return method;
    }

    public Object getRequestObject() {
        return requestObject;
    }

    public Map<String, String> getHeaders() {
        return new HashMap<>(headers);
    }

    public Object[] getPathParams() {
        return Arrays.copyOf(pathParams, pathParams.length);
    }

    public boolean hasAttachments() {
        return hasAttachments;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BreHttpRequestObject that = (BreHttpRequestObject) o;
        return hasAttachments == that.hasAttachments &&
                Objects.equals(urlSuffix, that.urlSuffix) &&
                Objects.equals(queryParams, that.queryParams) &&
                method == that.method &&
                Objects.equals(requestObject, that.requestObject) &&
                Objects.equals(headers, that.headers) &&
                Arrays.equals(pathParams, that.pathParams);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(urlSuffix, queryParams, method, requestObject, headers, hasAttachments);
        result = 31 * result + Arrays.hashCode(pathParams);
        return result;
    }

    @Override
    public String toString() {
        return "BreHttpRequestObject{" +
                "urlSuffix='" + urlSuffix + '\'' +
                ", queryParams=" + queryParams +
                ", method=" + method +
                ", requestObject=" + requestObject +
                ", headers=" + headers +
                ", pathParams=" + Arrays.toString(pathParams) +
                ", hasAttachments=" + hasAttachments +
                '}';
    }
}
