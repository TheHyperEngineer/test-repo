package com.akamai.buyakamai.integration.clients.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Response wrapper for paged results
 * @param <T> type of returned collection
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomPageableResponse {

    private List<CustomBasicProperty> items;
    private CustomPageInfo pageInfo;

    public void setItems(List<CustomBasicProperty> items) {
		this.items = items;
	}

	public void setPageInfo(CustomPageInfo pageInfo) {
		this.pageInfo = pageInfo;
	}

	/**
     * @return collection of returned items
     */
    public List<CustomBasicProperty> getItems() {
        return items;
    }

    /**
     * @return detailed information about pagination results
     */
    public CustomPageInfo getPageInfo() {
        return pageInfo;
    }

    /**
     * Constructor to be used for creating response
     */
    public CustomPageableResponse() {
    }

    @Override
    public final int hashCode() {
        return HashCodeBuilder.reflectionHashCode(this);
    }

    @Override
    public final boolean equals(final Object o) {
        return EqualsBuilder.reflectionEquals(this, o);
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
