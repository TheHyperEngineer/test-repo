package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;


import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;


@Slf4j
@Component
public abstract class WebDeliveryHttpClient {

    public abstract String callPostRequest(String url, MultiValueMap<String, String> postBody) throws Exception;

    public abstract String callGetRequest(String url, String rrId) throws Exception;

}
