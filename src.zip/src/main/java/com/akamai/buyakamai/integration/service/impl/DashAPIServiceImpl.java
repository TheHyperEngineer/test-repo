package com.akamai.buyakamai.integration.service.impl;


import com.akamai.buyakamai.constants.DashConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.impl.valueconfirmations.TLSSocketFactoryBuilder;
import com.akamai.buyakamai.integration.clients.model.AccessTokenModel;
import com.akamai.buyakamai.integration.model.dash.SfdcCaseCreationDto;
import com.akamai.buyakamai.integration.model.dash.SfdcCaseCreationResponse;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.Base64Utils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Optional;

/**
 * This class was created to handle changes from Dash service.
 * All APIs exposed from dash will not be on single server. This class allows user to provide base url for server and auth token generation.
 * Default server address is https://api.dash.akamai.com:443
 * one can also use this class if we have a different base url for dash service other than convention one
 */
@Service
public class DashAPIServiceImpl {

    private static Logger logger = LoggerFactory.getLogger(DashAPIServiceImpl.class.getName());

    @Autowired
    private TLSSocketFactoryBuilder tlsSocketFactoryBuilder;

    @Autowired
    private PropertyManager propertyManager;

    public String getAccessToken(Optional<String> dashServerBaseUrl, Optional<String> accessTokenUrl, Optional<String> scopes) {
        logger.debug("Getting the access token from the l2c bridge since access token is null");
        String accessTokenUrlSuffix = accessTokenUrl.isPresent() ? accessTokenUrl.get() : propertyManager.getProperty(DashConstants.DASH_ACCESS_TOKEN_URL_SUFFIX);
        HttpHeaders headers = getAuthHeaders(HttpHeaders.AUTHORIZATION, getBase64EncodedIdAndSecret(), scopes);
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
        HttpEntity<?> request = new HttpEntity<>(headers);

        ResponseEntity<String> responseJson = executeOnDash(getURI(dashServerBaseUrl, accessTokenUrlSuffix, null), HttpMethod.POST,
                request, String.class);
        AccessTokenModel accessTokenModel = CommonUtils.getObjectFromStringJson(responseJson.getBody(), AccessTokenModel.class);
        logger.debug("access token retrieved");
        return accessTokenModel.getAccessToken();
    }

    private String getURI(Optional<String> dashServerBaseUrl, String urlSuffix, MultiValueMap<String, String> queryParams, String... pathValues) {

        String dashServerAddress = dashServerBaseUrl.isPresent() ? dashServerBaseUrl.get() : propertyManager.getProperty(DashConstants.DASH_API_SERVER_ADDRESS);
        String uri = UriComponentsBuilder.fromUriString(dashServerAddress).path(urlSuffix).pathSegment(pathValues)
                .queryParams(queryParams).toUriString();
        logger.info("Url value is : " + uri);
        return uri;
    }

    private <T> ResponseEntity<T> executeOnDash(String uri, HttpMethod httpMethod, HttpEntity<?> request,
                                                Class<T> className) {

        RestTemplate restTemplate = tlsSocketFactoryBuilder.getRestTemplate();
        ResponseEntity<T> responseJson;
        logger.info("Sending Request to ltoc");
        try {
            responseJson = restTemplate.exchange(uri, httpMethod, request, className);
            logger.info("Response value has been retrieved from the ltoc ");
            if (!responseJson.getStatusCode().is2xxSuccessful()) {
                logger.error("Failed with the following response {} " ,responseJson.getBody());
                throw new BuyAkamaiApplicationException("Could not get proper response from Dash :",
                        responseJson.getStatusCode().toString(), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        }  catch (HttpStatusCodeException exception) {
            logger.error("status code: {} Error response from Dash {} ",exception.getStatusCode(), exception.getResponseBodyAsString());
            logger.error("Exception occured", exception);
            throw new BuyAkamaiApplicationException("Could not get proper response from Dash ",
                    exception.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (Exception e) {
            logger.error("Failed with the following exception ", e);
            throw new BuyAkamaiApplicationException("Exception while calling Dash API", e.getMessage(),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return responseJson;
    }

    private String getBase64EncodedIdAndSecret() {
        String clientId = propertyManager.getProperty(DashConstants.DASH_CLIENT_ID_PROPERTY_STRING);
        String clientSecret = propertyManager.getProperty(DashConstants.DASH_CLIENT_SECRET_PROPERTY_STRING);
        String clientIdAndClientSecret = clientId + ":" + clientSecret;
        String base64EncodedString = Base64Utils.encodeToString(clientIdAndClientSecret.getBytes());
        return "Basic " + base64EncodedString;
    }

    private HttpHeaders getAuthHeaders(String headerKey, String headerValue, Optional<String> scopes) {
        String grantTypeValue = propertyManager.getProperty(DashConstants.DASH_GRANT_TYPE_PROPERTY_STRING);
        String scopeValue;
        if(scopes.isPresent()){
            scopeValue = scopes.get();
        }else {
            scopeValue = propertyManager.getProperty(DashConstants.DASH_SCOPE_PROPERTY_STRING);
        }
        HttpHeaders headers = new HttpHeaders();
        headers.set(headerKey, headerValue);
        headers.set(DashConstants.DASH_GRANT_TYPE_STRING, grantTypeValue);
        headers.set(DashConstants.DASH_SCOPE_STRING, scopeValue);
        return headers;
    }


    private HttpHeaders getAllHeaders(String contentType, String accept, Optional<String> dashServerBaseUrl, Optional<String> accessTokenUrlSuffix, Optional<String> scopes) {
        String accessToken = getAccessToken(dashServerBaseUrl, accessTokenUrlSuffix, scopes);
        HttpHeaders headers = getAuthHeaders(DashConstants.DASH_ACCESS_TOKEN, accessToken, scopes);
        headers.set(HttpHeaders.ACCEPT_LANGUAGE, "en_US");
        if (contentType != null) {
            headers.set(HttpHeaders.CONTENT_TYPE, contentType);
        }
        if (accept != null) {
            headers.set(HttpHeaders.ACCEPT, accept);
        }
        return headers;
    }

    public SfdcCaseCreationResponse createSfdcCase(SfdcCaseCreationDto caseCreationDto) {
        String scopes = propertyManager.getProperty(DashConstants.DASH_CASE_CREATION_SCOPE_PROPERTY_STRING);
        HttpHeaders headers = getAllHeaders(MediaType.APPLICATION_JSON_VALUE, null, Optional.empty(), Optional.empty(), Optional.of(scopes));
        HttpEntity<SfdcCaseCreationDto> request = new HttpEntity<>(caseCreationDto, headers);
        logger.info("Create Sales Force Case json: {}", new Gson().toJson(caseCreationDto));
        String caseCreationUriSuffix = propertyManager.getProperty(DashConstants.DASH_CREATE_CASE_URL_SUFFIX);
        ResponseEntity<String> response = executeOnDash(getURI(Optional.empty(), caseCreationUriSuffix, null),
                HttpMethod.POST, request, String.class);
        logger.info("Response from the ltoc for (createSfdcCase) is {}", response);
        return CommonUtils.getObjectFromStringJson(response.getBody(), SfdcCaseCreationResponse.class);
    }
}
