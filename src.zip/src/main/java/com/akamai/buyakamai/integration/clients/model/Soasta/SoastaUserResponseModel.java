package com.akamai.buyakamai.integration.clients.model.Soasta;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SoastaUserResponseModel {
    private List<SoastaUserActivityModel> objects;

    public List<SoastaUserActivityModel> getObjects() {
        return objects;
    }

    public void setObjects(List<SoastaUserActivityModel> objects) {
        this.objects = objects;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SoastaUserResponseModel that = (SoastaUserResponseModel) o;

        return objects != null ? objects.equals(that.objects) : that.objects == null;
    }

    @Override
    public int hashCode() {
        return objects != null ? objects.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "SoastaUserResponseModel{" +
                "objects=" + objects +
                '}';
    }
}
