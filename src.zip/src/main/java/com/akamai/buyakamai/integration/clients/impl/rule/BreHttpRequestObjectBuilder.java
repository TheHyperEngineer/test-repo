package com.akamai.buyakamai.integration.clients.impl.rule;

import org.springframework.http.HttpMethod;
import org.springframework.util.MultiValueMap;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;

public class BreHttpRequestObjectBuilder {

    private String urlSuffix;
    private MultiValueMap<String, String> queryParams;
    private HttpMethod method;
    private Object requestObject;
    private Map<String, String> headers;
    private Object[] pathParams;
    private boolean hasAttachments;

    public BreHttpRequestObjectBuilder() {
    }


    public BreHttpRequestObjectBuilder urlSuffix(String urlSuffix) {
        this.urlSuffix = urlSuffix;
        return this;
    }

    public BreHttpRequestObjectBuilder queryParams(MultiValueMap<String, String> queryParams) {
        this.queryParams = queryParams;
        return this;
    }

    public BreHttpRequestObjectBuilder method(HttpMethod method) {
        this.method = method;
        return this;
    }

    public BreHttpRequestObjectBuilder requestObject(Object requestObject) {
        this.requestObject = requestObject;
        return this;
    }

    public BreHttpRequestObjectBuilder headers(Map<String, String> headers) {
        this.headers = headers;
        return this;
    }

    public BreHttpRequestObjectBuilder pathParams(Object[] pathParams) {
        this.pathParams = pathParams;
        return this;
    }

    public BreHttpRequestObjectBuilder hasAttachments(boolean hasAttachments) {
        this.hasAttachments = hasAttachments;
        return this;
    }

    public BreHttpRequestObject build() {
        return new BreHttpRequestObject(urlSuffix, queryParams, method, requestObject, headers, pathParams, hasAttachments);
    }

    public boolean hasAttachments() {
        return hasAttachments;
    }


    public HttpMethod getMethod() {
        return method;
    }

    public MultiValueMap<String, String> getQueryParams() {
        return queryParams;
    }

    public Object getRequestObject() {
        return requestObject;
    }

    public String getUrlSuffix() {
        return urlSuffix;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public Object[] getPathParams() {
        return pathParams;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BreHttpRequestObjectBuilder that = (BreHttpRequestObjectBuilder) o;
        return hasAttachments == that.hasAttachments &&
                Objects.equals(urlSuffix, that.urlSuffix) &&
                Objects.equals(queryParams, that.queryParams) &&
                method == that.method &&
                Objects.equals(requestObject, that.requestObject) &&
                Objects.equals(headers, that.headers) &&
                Arrays.equals(pathParams, that.pathParams);
    }

    @Override
    public int hashCode() {
        int result = Objects.hash(urlSuffix, queryParams, method, requestObject, headers, hasAttachments);
        result = 31 * result + Arrays.hashCode(pathParams);
        return result;
    }

    @Override
    public String toString() {
        return "BreHttpRequestObjectBuilder{" +
                "urlSuffix='" + urlSuffix + '\'' +
                ", queryParams=" + queryParams +
                ", method=" + method +
                ", requestObject=" + requestObject +
                ", headers=" + headers +
                ", pathParams=" + Arrays.toString(pathParams) +
                ", hasAttachments=" + hasAttachments +
                '}';
    }
}

