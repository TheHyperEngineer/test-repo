package com.akamai.buyakamai.integration.clients.model.Soasta;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SoastaTokenModel {

    String token;

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @Override
    public String toString() {
        return "SoastaTokenModel{" +
                "token='" + token + '\'' +
                '}';
    }
}
