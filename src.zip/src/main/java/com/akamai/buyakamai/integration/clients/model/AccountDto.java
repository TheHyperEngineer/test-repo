package com.akamai.buyakamai.integration.clients.model;

import com.akamai.buyakamai.controller.model.AccountMemberDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
public class AccountDto {

	 @JsonInclude(Include.NON_NULL)
    private String accountSrcId;
	 
    private String accountId;
    
    private String accountName;
    
    @JsonInclude(Include.NON_NULL)
    private AddressDto address;

	@JsonInclude(Include.NON_NULL)
	private AddressDto billToAddress;
    
    @JsonInclude(Include.NON_NULL)
	private String ownerSrcId;
    
    @JsonInclude(Include.NON_NULL)
	private String ownerUserName;
    
	private String accountType;
	
    private String region;
	 
    private String territoryName;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String industry;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String vertical;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String subVertical;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<BAContactDto> customerContacts;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String ownerFullName;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<AccountMemberDto> accountMembers;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String salesForceLink;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String restrictedCountry;
	
    @JsonInclude(Include.NON_NULL)
    private String creditCheckStatus;
    
    @JsonInclude(Include.NON_NULL)
    private String accountCurrency;

	public String getOwnerFullName() {
		return ownerFullName;
	}

	public void setOwnerFullName(String ownerFullName) {
		this.ownerFullName = ownerFullName;
	}

	public List<AccountMemberDto> getAccountMembers() {
		return accountMembers;
	}

	public void setAccountMembers(List<AccountMemberDto> accountMembers) {
		this.accountMembers = accountMembers;
	}

	public String getSalesForceLink() {
		return salesForceLink;
	}

	public void setSalesForceLink(String salesForceLink) {
		this.salesForceLink = salesForceLink;
	}

	public String getRestrictedCountry() {
		return restrictedCountry;
	}

	public void setRestrictedCountry(String restrictedCountry) {
		this.restrictedCountry = restrictedCountry;
	}

	public List<BAContactDto> getCustomerContacts() {
		return customerContacts;
	}

	public void setCustomerContacts(List<BAContactDto> customerContacts) {
		this.customerContacts = customerContacts;
	}

	public String getAccountSrcId() {
        return accountSrcId;
    }

    public void setAccountSrcId(String accountSrcId) {
        this.accountSrcId = accountSrcId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

	public AddressDto getAddress() {
		return address;
	}

	public void setAddress(AddressDto address) {
		this.address = address;
	}

	public String getOwnerSrcId() {
		return ownerSrcId;
	}

	public void setOwnerSrcId(String ownerSrcId) {
		this.ownerSrcId = ownerSrcId;
	}

	public String getOwnerUserName() {
		return ownerUserName;
	}

	public void setOwnerUserName(String ownerUserName) {
		this.ownerUserName = ownerUserName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getVertical() {
		return vertical;
	}

	public void setVertical(String vertical) {
		this.vertical = vertical;
	}

	public String getSubVertical() {
		return subVertical;
	}

	public void setSubVertical(String subVertical) {
		this.subVertical = subVertical;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public String getTerritoryName() {
		return territoryName;
	}

	public void setTerritoryName(String territoryName) {
		this.territoryName = territoryName;
	}

	public String getCreditCheckStatus() {
		return creditCheckStatus;
	}

	public void setCreditCheckStatus(String creditCheckStatus) {
		this.creditCheckStatus = creditCheckStatus;
	}

	public AddressDto getBillToAddress() {
		return billToAddress;
	}

	public void setBillToAddress(AddressDto billToAddress) {
		this.billToAddress = billToAddress;
	}
	
	public String getAccountCurrency() {
		return accountCurrency;
	}

	public void setAccountCurrency(String accountCurrency) {
		this.accountCurrency = accountCurrency;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((accountMembers == null) ? 0 : accountMembers.hashCode());
		result = prime * result + ((accountName == null) ? 0 : accountName.hashCode());
		result = prime * result + ((accountSrcId == null) ? 0 : accountSrcId.hashCode());
		result = prime * result + ((accountType == null) ? 0 : accountType.hashCode());
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((creditCheckStatus == null) ? 0 : creditCheckStatus.hashCode());
		result = prime * result + ((customerContacts == null) ? 0 : customerContacts.hashCode());
		result = prime * result + ((industry == null) ? 0 : industry.hashCode());
		result = prime * result + ((ownerFullName == null) ? 0 : ownerFullName.hashCode());
		result = prime * result + ((ownerSrcId == null) ? 0 : ownerSrcId.hashCode());
		result = prime * result + ((ownerUserName == null) ? 0 : ownerUserName.hashCode());
		result = prime * result + ((region == null) ? 0 : region.hashCode());
		result = prime * result + ((restrictedCountry == null) ? 0 : restrictedCountry.hashCode());
		result = prime * result + ((salesForceLink == null) ? 0 : salesForceLink.hashCode());
		result = prime * result + ((subVertical == null) ? 0 : subVertical.hashCode());
		result = prime * result + ((territoryName == null) ? 0 : territoryName.hashCode());
		result = prime * result + ((vertical == null) ? 0 : vertical.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountDto other = (AccountDto) obj;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (accountMembers == null) {
			if (other.accountMembers != null)
				return false;
		} else if (!accountMembers.equals(other.accountMembers))
			return false;
		if (accountName == null) {
			if (other.accountName != null)
				return false;
		} else if (!accountName.equals(other.accountName))
			return false;
		if (accountSrcId == null) {
			if (other.accountSrcId != null)
				return false;
		} else if (!accountSrcId.equals(other.accountSrcId))
			return false;
		if (accountType == null) {
			if (other.accountType != null)
				return false;
		} else if (!accountType.equals(other.accountType))
			return false;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (creditCheckStatus == null) {
			if (other.creditCheckStatus != null)
				return false;
		} else if (!creditCheckStatus.equals(other.creditCheckStatus))
			return false;
		if (customerContacts == null) {
			if (other.customerContacts != null)
				return false;
		} else if (!customerContacts.equals(other.customerContacts))
			return false;
		if (industry == null) {
			if (other.industry != null)
				return false;
		} else if (!industry.equals(other.industry))
			return false;
		if (ownerFullName == null) {
			if (other.ownerFullName != null)
				return false;
		} else if (!ownerFullName.equals(other.ownerFullName))
			return false;
		if (ownerSrcId == null) {
			if (other.ownerSrcId != null)
				return false;
		} else if (!ownerSrcId.equals(other.ownerSrcId))
			return false;
		if (ownerUserName == null) {
			if (other.ownerUserName != null)
				return false;
		} else if (!ownerUserName.equals(other.ownerUserName))
			return false;
		if (region == null) {
			if (other.region != null)
				return false;
		} else if (!region.equals(other.region))
			return false;
		if (restrictedCountry == null) {
			if (other.restrictedCountry != null)
				return false;
		} else if (!restrictedCountry.equals(other.restrictedCountry))
			return false;
		if (salesForceLink == null) {
			if (other.salesForceLink != null)
				return false;
		} else if (!salesForceLink.equals(other.salesForceLink))
			return false;
		if (subVertical == null) {
			if (other.subVertical != null)
				return false;
		} else if (!subVertical.equals(other.subVertical))
			return false;
		if (territoryName == null) {
			if (other.territoryName != null)
				return false;
		} else if (!territoryName.equals(other.territoryName))
			return false;
		if (vertical == null) {
			if (other.vertical != null)
				return false;
		} else if (!vertical.equals(other.vertical))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AccountDto [accountSrcId=" + accountSrcId + ", accountId=" + accountId + ", accountName=" + accountName
				+ ", address=" + address + ", ownerSrcId=" + ownerSrcId + ", ownerUserName=" + ownerUserName
				+ ", accountType=" + accountType + ", region=" + region + ", territoryName=" + territoryName
				+ ", industry=" + industry + ", vertical=" + vertical + ", subVertical=" + subVertical
				+ ", customerContacts=" + customerContacts + ", ownerFullName=" + ownerFullName + ", accountMembers="
				+ accountMembers + ", salesForceLink=" + salesForceLink + ", restrictedCountry=" + restrictedCountry
				+ ", creditCheckStatus=" + creditCheckStatus +"accountCurrency="+accountCurrency + "]";
	}

}
