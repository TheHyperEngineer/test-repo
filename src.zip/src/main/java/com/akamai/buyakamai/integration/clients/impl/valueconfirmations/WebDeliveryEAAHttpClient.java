package com.akamai.buyakamai.integration.clients.impl.valueconfirmations;

import com.akamai.buyakamai.constants.DashConstants;
import com.akamai.buyakamai.integration.service.impl.DashServiceImpl;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;


@Component("WebDeliveryEAAHttpClient")
public class WebDeliveryEAAHttpClient extends WebDeliveryHttpClient {

    private static final Logger logger = LoggerFactory.getLogger(WebDeliveryHttpClient.class);

    @Autowired
    private DashServiceImpl dashService;

    @Autowired
    private TLSSocketFactoryBuilder tlsSocketFactoryBuilder;


    @Override
    public String callPostRequest(String url, MultiValueMap<String, String> postBody) throws Exception {

        //update the urls to consume v2 apis
        url = modifyUrlToV2(url);

        logger.debug("making post request for url {} with body {}", url, postBody);
        try {

            HttpHeaders headers = new HttpHeaders();

            //add dash access token to header
            headers.set(DashConstants.DASH_ACCESS_TOKEN, dashService.getAccessTokenForMetis());
            headers.setContentType(MediaType.APPLICATION_JSON);

            HttpEntity<MultiValueMap<String, String>> request = new HttpEntity<>(postBody, headers);

            //fetch rest template with eaa cert
            RestTemplate restTemplate = tlsSocketFactoryBuilder.getRestTemplate();
            ResponseEntity<String> response = restTemplate.postForEntity(url, request, String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                logger.debug("Response for url {} is {}", url, response.getBody());
                return response.getBody();
            }
        } catch (HttpStatusCodeException scEx) {
            logger.error("Exception occurred while executing post call to URL {} with status code {} and exception {}", url, scEx.getStatusCode(), scEx.getMessage());
            logger.error("Response Body {}", scEx.getResponseBodyAsString());
            throw scEx;
        } catch (Exception e) {
            throw e;
        }

        return StringUtils.EMPTY;


    }

    @Override
    public String callGetRequest(String url, String rrId) throws Exception {

        //update the urls to consume v2 apis
        url = modifyUrlToV2(url);

        logger.debug("making get request for url {} and rrId {}", url, rrId);
        try {
            //add headers with dash tokens
            HttpHeaders headers = new HttpHeaders();
            headers.set(DashConstants.DASH_ACCESS_TOKEN, dashService.getAccessTokenForMetis());
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity(headers);

            UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(url).queryParam("rr_id", rrId);

            //fetch rest template with eaa cert
            RestTemplate restTemplate = tlsSocketFactoryBuilder.getRestTemplate();
            ResponseEntity<String> response = restTemplate.exchange(builder.build().encode().toUri(), HttpMethod.GET, entity, String.class);

            if (response.getStatusCode().is2xxSuccessful()) {
                logger.debug("Response for url {} is {}", url, response.getBody());
                return response.getBody();
            }
        } catch (HttpStatusCodeException scEx) {
            logger.error("Exception occurred while executing get call to URL {} with status code {} and exception {}", url, scEx.getStatusCode(), scEx.getMessage());
            logger.error("Response Body {}", scEx.getResponseBodyAsString());
        } catch (Exception e) {
            logger.error("Exception occurred while executing get call to URL {} exception: {}", url, e);
        }
        return StringUtils.EMPTY;
    }

    private String modifyUrlToV2(String url) {
        UriComponents originalUriComponents = UriComponentsBuilder.fromHttpUrl(url).build();
        String v2Path = "v2/" + originalUriComponents.getPath();
        UriComponents newUriComponent = UriComponentsBuilder.fromHttpUrl(url).replacePath(v2Path).build();
        return newUriComponent.toUriString() + "/";
    }

}
