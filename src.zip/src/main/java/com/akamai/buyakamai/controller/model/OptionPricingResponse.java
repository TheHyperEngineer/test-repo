package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OptionPricingResponse {

	private String marketingProductId;

	private String name;

	private List<MarketplacePricingResponseListItem> pricingResponseListItem;

	public String getMarketingProductId() {
		return marketingProductId;
	}

	public void setMarketingProductId(String marketingProductId) {
		this.marketingProductId = marketingProductId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<MarketplacePricingResponseListItem> getPricingResponseListItem() {
		return pricingResponseListItem;
	}

	public void setPricingResponseListItem(List<MarketplacePricingResponseListItem> pricingResponseListItem) {
		this.pricingResponseListItem = pricingResponseListItem;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((marketingProductId == null) ? 0 : marketingProductId.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((pricingResponseListItem == null) ? 0 : pricingResponseListItem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OptionPricingResponse other = (OptionPricingResponse) obj;
		if (marketingProductId == null) {
			if (other.marketingProductId != null)
				return false;
		} else if (!marketingProductId.equals(other.marketingProductId))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (pricingResponseListItem == null) {
			if (other.pricingResponseListItem != null)
				return false;
		} else if (!pricingResponseListItem.equals(other.pricingResponseListItem))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OptionPricingResponse [marketingProductId=" + marketingProductId + ", name=" + name
		        + ", pricingResponseListItem=" + pricingResponseListItem + "]";
	}
}