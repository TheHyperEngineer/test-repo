package com.akamai.buyakamai.controller.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Enhanced com.akamai.se.domain.site.HttpConfiguration with DNSResolutions
 * @author jplans
 *
 */
public class HttpConfiguration {
 
   /** Property accountId */
   private String accountId;
 
   /** Property cpCodeIds */
   private List<Integer> cpCodeIds;
 
   /** Property digitalProperties */
   private List<DigitalProperty> digitalProperties;
 
   /** Property fileId */
   private long fileId;
 
   /** Property fileName */
   private String fileName;
 
   /** Property propertyType */
   private String propertyType;
 
   /**
    * Constructor
    */
   public HttpConfiguration() {
	   cpCodeIds = new ArrayList<Integer>();
	   digitalProperties = new ArrayList<DigitalProperty>();
	   
   }
   
   /**
    * Builds the object based on a com.akamai.se.domain.site.HttpConfiguration and available resolutions
    * 
    * @param dto
    */
   public HttpConfiguration(com.akamai.se.domain.site.HttpConfiguration dto) {
	   this.accountId = dto.getAccountId();
	   this.cpCodeIds = dto.getCpCodeIds();
	   this.digitalProperties = dto.getDigitalProperties()
			   .stream()
			   .map(dp -> new DigitalProperty(dp))
			   .collect(Collectors.toList());
	   this.fileId = dto.getFileId();
	   this.fileName = dto.getFileName();
   }
 
   /**
    * Gets the accountId
    */
   public String getAccountId() {
      return this.accountId;
   }
 
   /**
    * Sets the accountId
    */
   public void setAccountId(String value) {
      this.accountId = value;
   }
 
   /**
    * Gets the cpCodeIds
    */
   public List<Integer> getCpCodeIds() {
      return this.cpCodeIds;
   }
 
   /**
    * Sets the cpCodeIds
    */
   public void setCpCodeIds(List<Integer> value) {
      this.cpCodeIds = value;
   }
 
   /**
    * Gets the digitalProperties
    */
   public List<DigitalProperty> getDigitalProperties() {
      return this.digitalProperties;
   }
 
   /**
    * Sets the digitalProperties
    */
   public void setDigitalProperties(List<DigitalProperty> value) {
      this.digitalProperties = value;
   }
 
   /**
    * Gets the fileId
    */
   public long getFileId() {
      return this.fileId;
   }
 
   /**
    * Sets the fileId
    */
   public void setFileId(long value) {
      this.fileId = value;
   }
 
   /**
    * Gets the fileName
    */
   public String getFileName() {
      return this.fileName;
   }
 
   /**
    * Sets the fileName
    */
   public void setFileName(String value) {
      this.fileName = value;
   }
 
   /**
    * Gets the propertyType
    */
   public String getPropertyType() {
      return this.propertyType;
   }
 
   /**
    * Sets the propertyType
    */
   public void setPropertyType(String value) {
      this.propertyType = value;
   }
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fileName == null) ? 0 : fileName.hashCode());
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((cpCodeIds == null) ? 0 : cpCodeIds.hashCode());
		result = prime * result + Long.hashCode(fileId);
		result = prime * result + ((propertyType == null) ? 0 : propertyType.hashCode());
		result = prime * result + ((digitalProperties == null) ? 0 : digitalProperties.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		HttpConfiguration other = (HttpConfiguration) obj;
		if(!Objects.equals(fileName, other.fileName)) {
			return false;
		}
		
		if(!Objects.equals(accountId, other.accountId)) {
			return false;
		}
		
		if (!Objects.deepEquals(cpCodeIds, other.cpCodeIds)) {
			return false;
		}
		if (!Objects.deepEquals(digitalProperties, other.digitalProperties)) {
			return false;
		}	
		
		if (fileId != other.fileId) {
			return false;
		}
		
		if(!Objects.equals(propertyType, other.propertyType)) {
			return false;
		}
		
		return true;
	}
}