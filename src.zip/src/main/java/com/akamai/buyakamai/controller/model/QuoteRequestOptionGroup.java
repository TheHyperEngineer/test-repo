package com.akamai.buyakamai.controller.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;


public class QuoteRequestOptionGroup {
	
	@NotBlank(message="OptionGroupId cannot be empty")
	private String optionGroupId;
	
	@Valid
	@NotEmpty(message = "Options for a selected option group cannot be empty")
	@NotNull(message = "Options for a selected option group cannot be null")
	private List<QuoteRequestOption> options;

	public String getOptionGroupId() {
		return optionGroupId;
	}

	public void setOptionGroupId(String optionGroupId) {
		this.optionGroupId = optionGroupId;
	}

	public List<QuoteRequestOption> getOptions() {
		return options;
	}

	public void setOptions(List<QuoteRequestOption> options) {
		this.options = options;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((optionGroupId == null) ? 0 : optionGroupId.hashCode());
		result = prime * result + ((options == null) ? 0 : options.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuoteRequestOptionGroup other = (QuoteRequestOptionGroup) obj;
		if (optionGroupId == null) {
			if (other.optionGroupId != null)
				return false;
		} else if (!optionGroupId.equals(other.optionGroupId))
			return false;
		if (options == null) {
			if (other.options != null)
				return false;
		} else if (!options.equals(other.options))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
