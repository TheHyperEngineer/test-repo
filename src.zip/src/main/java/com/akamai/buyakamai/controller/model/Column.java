package com.akamai.buyakamai.controller.model;

import java.util.Objects;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Column {

	/** Property total */
	float total;

	/** Property min_value */
	float min_value;

	/** Property max_value */
	float max_value;

	/** Property position */
	long position;

	/** Property max_row */
	long max_row;

	/** Property columnName */
	String columnName;

	/** Property min_row */
	long min_row;

	/**
	 * Constructor
	 */
	public Column() {
	}

	/**
	 * Gets the total
	 */
	public float getTotal() {
		return this.total;
	}

	/**
	 * Sets the total
	 */
	public void setTotal(float value) {
		this.total = value;
	}

	/**
	 * Gets the min_value
	 */
	public float getMin_value() {
		return this.min_value;
	}

	/**
	 * Sets the min_value
	 */
	public void setMin_value(float value) {
		this.min_value = value;
	}

	/**
	 * Gets the max_value
	 */
	public float getMax_value() {
		return this.max_value;
	}

	/**
	 * Sets the max_value
	 */
	public void setMax_value(float value) {
		this.max_value = value;
	}

	/**
	 * Gets the position
	 */
	public long getPosition() {
		return this.position;
	}

	/**
	 * Sets the position
	 */
	public void setPosition(long value) {
		this.position = value;
	}

	/**
	 * Gets the max_row
	 */
	public long getMax_row() {
		return this.max_row;
	}

	/**
	 * Sets the max_row
	 */
	public void setMax_row(long value) {
		this.max_row = value;
	}

	/**
	 * Gets the columnName
	 */
	public String getColumnName() {
		return this.columnName;
	}

	/**
	 * Sets the columnName
	 */
	public void setColumnName(String value) {
		this.columnName = value;
	}

	/**
	 * Gets the min_row
	 */
	public long getMin_row() {
		return this.min_row;
	}

	/**
	 * Sets the min_row
	 */
	public void setMin_row(long value) {
		this.min_row = value;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.hashCode(total);
		result = prime * result + Float.hashCode(min_value);
		result = prime * result + Float.hashCode(max_value);
		result = prime * result + Long.hashCode(position);
		result = prime * result + Long.hashCode(max_row);
		result = prime * result + ((columnName == null) ? 0 : columnName.hashCode());
		result = prime * result + Long.hashCode(min_row);
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		Column other = (Column) obj;

		if(!Objects.equals(total, other.total)) {
			return false;
		}
		
		if(!Objects.equals(min_value, other.min_value)) {
			return false;
		}
		
		if(!Objects.equals(max_value, other.max_value)) {
			return false;
		}
		
		if(!Objects.equals(position, other.position)) {
			return false;
		}
		
		if(!Objects.equals(max_row, other.max_row)) {
			return false;
		}
		
		if(!Objects.equals(columnName, other.columnName)) {
			return false;
		}
		
		if(!Objects.equals(min_row, other.min_row)) {
			return false;
		}
		
		return true;
	}
}

