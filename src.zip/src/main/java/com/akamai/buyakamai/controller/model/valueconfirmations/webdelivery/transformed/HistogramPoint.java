package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class HistogramPoint {

    private String bin;
    private String performance;

    public String getBin() {
        return bin;
    }

    public void setBin(String bin) {
        this.bin = bin;
    }

    public String getPerformance() {
        return performance;
    }

    public void setPerformance(String performance) {
        this.performance = performance;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HistogramPoint that = (HistogramPoint) o;

        if (bin != null ? !bin.equals(that.bin) : that.bin != null) return false;
        return performance != null ? performance.equals(that.performance) : that.performance == null;
    }

    @Override
    public int hashCode() {
        int result = bin != null ? bin.hashCode() : 0;
        result = 31 * result + (performance != null ? performance.hashCode() : 0);
        return result;
    }
}
