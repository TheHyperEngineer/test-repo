package com.akamai.buyakamai.controller.model.partner;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by Abhishyam on 03-Sep,2018
 */

@JsonIgnoreProperties(ignoreUnknown = true)
public class BasicPartnerAccountDto {

    private String accountId;

    private String accountName;

    private Boolean masterChannelMappingFlag;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Boolean getMasterChannelMappingFlag() {
        return masterChannelMappingFlag;
    }

    public void setMasterChannelMappingFlag(Boolean masterChannelMappingFlag) {
        this.masterChannelMappingFlag = masterChannelMappingFlag;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BasicPartnerAccountDto)) return false;

        BasicPartnerAccountDto that = (BasicPartnerAccountDto) o;

        if (getAccountId() != null ? !getAccountId().equals(that.getAccountId()) : that.getAccountId() != null)
            return false;
        if (getAccountName() != null ? !getAccountName().equals(that.getAccountName()) : that.getAccountName() != null)
            return false;
        return getMasterChannelMappingFlag() != null ? getMasterChannelMappingFlag().equals(that.getMasterChannelMappingFlag()) : that.getMasterChannelMappingFlag() == null;
    }

    @Override
    public int hashCode() {
        int result = getAccountId() != null ? getAccountId().hashCode() : 0;
        result = 31 * result + (getAccountName() != null ? getAccountName().hashCode() : 0);
        result = 31 * result + (getMasterChannelMappingFlag() != null ? getMasterChannelMappingFlag().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("PartnerAccountDto{");
        sb.append("accountId='").append(accountId).append('\'');
        sb.append(", accountName='").append(accountName).append('\'');
        sb.append(", masterChannelMappingFlag=").append(masterChannelMappingFlag);
        sb.append('}');
        return sb.toString();
    }
}
