package com.akamai.buyakamai.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.service.impl.UserServiceImpl;


@RestController
@EnableAutoConfiguration
public class UserController {

	private static final Logger logger = LoggerFactory.getLogger(UserController.class.getName());
	
	@Autowired
	private UserServiceImpl userService;
	
	@RequestMapping(value = BAConstants.GET_USER_REGISTRATION_URL, method = RequestMethod.GET , produces = "application/json;charset=UTF-8")
	@ResponseBody
	public ResponseEntity<String> getUserCreationStatus(@PathVariable String contactId)  {
		logger.info("Entering getUserCreationStatus for {} ",contactId);
		String status = userService.getUserCreationStatus(contactId);

		logger.info("Exiting getUserCreationStatus for {} Response {} ",contactId,status);
		return new ResponseEntity<>(status, HttpStatus.OK); 
	}

}
