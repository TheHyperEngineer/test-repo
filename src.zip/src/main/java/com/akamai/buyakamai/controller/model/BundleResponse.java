package com.akamai.buyakamai.controller.model;
import java.util.List;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Class to contain the bundle information.
 *
 * @author jdixit
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class BundleResponse {

    private String bundleId;

    private String bundleName;

    private String bundleType;

    private String bundleFamily;

    private String solutionSet;

    private String bundleTrialDuration;

    private String billingCurrency;

    private String bundleLifeCyclePhase;

    private List<ProductResponse> products;

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    public String getBundleType() {
        return bundleType;
    }

    public void setBundleType(String bundleType) {
        this.bundleType = bundleType;
    }

    public String getBundleFamily() {
        return bundleFamily;
    }

    public void setBundleFamily(String bundleFamily) {
        this.bundleFamily = bundleFamily;
    }

    public String getSolutionSet() {
        return solutionSet;
    }

    public void setSolutionSet(String solutionSet) {
        this.solutionSet = solutionSet;
    }

    public String getBundleTrialDuration() {
        return bundleTrialDuration;
    }

    public void setBundleTrialDuration(String bundleTrialDuration) {
        this.bundleTrialDuration = bundleTrialDuration;
    }

    public String getBillingCurrency() {
        return billingCurrency;
    }

    public void setBillingCurrency(String billingCurrency) {
        this.billingCurrency = billingCurrency;
    }

    public String getBundleLifeCyclePhase() {
        return bundleLifeCyclePhase;
    }

    public void setBundleLifeCyclePhase(String bundleLifeCyclePhase) {
        this.bundleLifeCyclePhase = bundleLifeCyclePhase;
    }

    public List<ProductResponse> getProducts() {
        return products;
    }

    public void setProducts(List<ProductResponse> products) {
        this.products = products;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        BundleResponse that = (BundleResponse) o;

        if (bundleId != null ? !bundleId.equals(that.bundleId) : that.bundleId != null) return false;
        if (bundleName != null ? !bundleName.equals(that.bundleName) : that.bundleName != null) return false;
        if (bundleType != null ? !bundleType.equals(that.bundleType) : that.bundleType != null) return false;
        if (bundleFamily != null ? !bundleFamily.equals(that.bundleFamily) : that.bundleFamily != null) return false;
        if (solutionSet != null ? !solutionSet.equals(that.solutionSet) : that.solutionSet != null) return false;
        if (bundleTrialDuration != null ? !bundleTrialDuration.equals(that.bundleTrialDuration) : that.bundleTrialDuration != null)
            return false;
        if (billingCurrency != null ? !billingCurrency.equals(that.billingCurrency) : that.billingCurrency != null)
            return false;
        if (bundleLifeCyclePhase != null ? !bundleLifeCyclePhase.equals(that.bundleLifeCyclePhase) : that.bundleLifeCyclePhase != null)
            return false;
        return products != null ? products.equals(that.products) : that.products == null;
    }

    @Override
    public int hashCode() {
        int result = bundleId != null ? bundleId.hashCode() : 0;
        result = 31 * result + (bundleName != null ? bundleName.hashCode() : 0);
        result = 31 * result + (bundleType != null ? bundleType.hashCode() : 0);
        result = 31 * result + (bundleFamily != null ? bundleFamily.hashCode() : 0);
        result = 31 * result + (solutionSet != null ? solutionSet.hashCode() : 0);
        result = 31 * result + (bundleTrialDuration != null ? bundleTrialDuration.hashCode() : 0);
        result = 31 * result + (billingCurrency != null ? billingCurrency.hashCode() : 0);
        result = 31 * result + (bundleLifeCyclePhase != null ? bundleLifeCyclePhase.hashCode() : 0);
        result = 31 * result + (products != null ? products.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "BundleResponse{" +
                "bundleId='" + bundleId + '\'' +
                ", bundleName='" + bundleName + '\'' +
                ", bundleType='" + bundleType + '\'' +
                ", bundleFamily='" + bundleFamily + '\'' +
                ", solutionSet='" + solutionSet + '\'' +
                ", bundleTrialDuration='" + bundleTrialDuration + '\'' +
                ", billingCurrency='" + billingCurrency + '\'' +
                ", bundleLifeCyclePhase='" + bundleLifeCyclePhase + '\'' +
                ", products=" + products +
                '}';
    }
}
