package com.akamai.buyakamai.controller.model;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import com.akamai.buyakamai.integration.clients.model.CustomARLFileVersion;
import com.akamai.buyakamai.integration.clients.model.CustomBasicProperty;
import com.akamai.buyakamai.service.dns.DNSCategorizedResolution;

import java.util.Optional;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;

/**
 * Enhanced com.akamai.se.domain.property.BasicProperty with DNS resolutions
 * 
 * A property is backed by an arl file and one asset.  Owners of properties
 * should extend this class and add or override data that pertains there view of property data.
 *
 * Data for this implementation comes from the  asset, arl_file,
 * arl_file_versions, arl_active_files table and authz.
 */
public class BasicProperty {

	/** Property arlFileId */
	private Integer arlFileId;

	/** Property groupIds */
	private List<Integer> groupIds;

	/** Property assetId */
	private Integer assetId;

	/** Property propertyName */
	private String propertyName;

	/** Property assetType */
	private String assetType;

	/** Property contractId */
	private String contractId;

	/** Property configManagerVisible */
	private Boolean configManagerVisible;

	/** Property fileName */
	private String fileName;

	/** Property description */
	private String description;

	/** Property productionArlFileVersion */
	private Optional<ArlFileVersion> productionArlFileVersion;

	private Optional<String> productionActivationDate;

	/** Property stagingArlFileVersion */
	private Optional<ArlFileVersion> stagingArlFileVersion;

	private Optional<String> stagingActivationDate;

	/**
	 * Constructor
	 */
	public BasicProperty() {
	}

	/**
	 * Constructor
	 */
	public BasicProperty(CustomBasicProperty other) {
		this.arlFileId = other.getArlFileId();
		this.assetId = other.getAssetId();
		this.assetType = other.getAssetType();
		this.configManagerVisible = other.isConfigManagerVisible();
		this.description = other.getDescription();
		this.fileName = other.getFilename();
		this.propertyName = other.getPropertyName();
		this.contractId = other.getContractId();
		this.groupIds = other.getGroupIds();

		CustomARLFileVersion prodVersion = other.getProductionArlFileVersion();
		this.productionArlFileVersion = (prodVersion != null) ? Optional.of(new ArlFileVersion(prodVersion)) : Optional.empty();
		CustomARLFileVersion stagingVersion = other.getStagingArlFileVersion();
		this.stagingArlFileVersion = (stagingVersion != null) ? Optional.of(new ArlFileVersion(stagingVersion)) : Optional.empty(); 
	}

	/**
	 * Builds the object based on a com.akamai.se.domain.property.BasicProperty and available resolutions
	 * @param other
	 * @param resolutions
	 */
	public BasicProperty(CustomBasicProperty other,
			Map<String, DNSCategorizedResolution> resolutions) {
		this.arlFileId = other.getArlFileId();
		this.assetId = other.getAssetId();
		this.assetType = other.getAssetType();
		this.configManagerVisible = other.isConfigManagerVisible();
		this.description = other.getDescription();
		this.fileName = other.getFilename();
		this.propertyName = other.getPropertyName();
		this.contractId = other.getContractId();
		this.groupIds = other.getGroupIds();
		
		CustomARLFileVersion prodVersion = other.getProductionArlFileVersion();
		this.productionArlFileVersion = (prodVersion != null) ? Optional.of(new ArlFileVersion(prodVersion, resolutions)) : Optional.empty();
		CustomARLFileVersion stagingVersion = other.getStagingArlFileVersion();
		this.stagingArlFileVersion = (stagingVersion != null) ? Optional.of(new ArlFileVersion(stagingVersion, resolutions)) : Optional.empty();

		String productionDate = other.getActiveProductionActivationDate();
		this.productionActivationDate = (StringUtils.isNotEmpty(productionDate)) ? Optional.of(productionDate) : Optional.empty();

		String stagingDate = other.getActiveStagingActivationDate();
		this.stagingActivationDate = (StringUtils.isNotEmpty(stagingDate)) ? Optional.of(stagingDate) : Optional.empty();
	}

	/**
	 * Gets the arlFileId
	 */
	public Integer getArlFileId() {
		return this.arlFileId;
	}

	/**
	 * Sets the arlFileId
	 */
	public void setArlFileId(Integer value) {
		this.arlFileId = value;
	}

	/**
	 * Gets the groupIds
	 */
	public List<Integer> getGroupIds() {
		return this.groupIds;
	}

	/**
	 * Sets the groupIds
	 */
	public void setGroupIds(List<Integer> value) {
		this.groupIds = value;
	}

	/**
	 * Gets the assetId
	 */
	public Integer getAssetId() {
		return this.assetId;
	}

	/**
	 * Sets the assetId
	 */
	public void setAssetId(Integer value) {
		this.assetId = value;
	}

	/**
	 * Gets the propertyName
	 */
	public String getPropertyName() {
		return this.propertyName;
	}

	/**
	 * Sets the propertyName
	 */
	public void setPropertyName(String value) {
		this.propertyName = value;
	}

	/**
	 * Gets the assetType
	 */
	public String getAssetType() {
		return this.assetType;
	}

	/**
	 * Sets the assetType
	 */
	public void setAssetType(String value) {
		this.assetType = value;
	}

	/**
	 * Gets the contractId
	 */
	public String getContractId() {
		return this.contractId;
	}

	/**
	 * Sets the contractId
	 */
	public void setContractId(String value) {
		this.contractId = value;
	}

	/**
	 * Gets the configManagerVisible
	 */
	public Boolean getConfigManagerVisible() {
		return this.configManagerVisible;
	}

	/**
	 * Sets the configManagerVisible
	 */
	public void setConfigManagerVisible(Boolean value) {
		this.configManagerVisible = value;
	}

	/**
	 * Gets the fileName
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * Sets the fileName
	 */
	public void setFileName(String value) {
		this.fileName = value;
	}

	/**
	 * Gets the description
	 */
	public String getDescription() {
		return this.description;
	}

	/**
	 * Sets the description
	 */
	public void setDescription(String value) {
		this.description = value;
	}

	/**
	 * Gets the productionArlFileVersion
	 */
	public Optional<ArlFileVersion> getProductionArlFileVersion() {
		return this.productionArlFileVersion;
	}

	/**
	 * Sets the productionArlFileVersion
	 */
	public void setProductionArlFileVersion(ArlFileVersion value) {
		this.productionArlFileVersion = value == null ? Optional.empty() : Optional.of(value);
	}

	/**
	 * Gets the stagingArlFileVersion
	 */
	public Optional<ArlFileVersion> getStagingArlFileVersion() {
		return this.stagingArlFileVersion;
	}

	/**
	 * Sets the stagingArlFileVersion
	 */
	public void setStagingArlFileVersion(ArlFileVersion value) {
		this.stagingArlFileVersion = value == null ? Optional.empty() : Optional.of(value);
	}

	public Optional<String> getProductionActivationDate() {
		return productionActivationDate;
	}

	public void setProductionActivationDate(Optional<String> productionActivationDate) {
		this.productionActivationDate = productionActivationDate;
	}

	public Optional<String> getStagingActivationDate() {
		return stagingActivationDate;
	}

	public void setStagingActivationDate(Optional<String> stagingActivationDate) {
		this.stagingActivationDate = stagingActivationDate;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@Override
	public int hashCode() {
		int result = arlFileId != null ? arlFileId.hashCode() : 0;
		result = 31 * result + (groupIds != null ? groupIds.hashCode() : 0);
		result = 31 * result + (assetId != null ? assetId.hashCode() : 0);
		result = 31 * result + (propertyName != null ? propertyName.hashCode() : 0);
		result = 31 * result + (assetType != null ? assetType.hashCode() : 0);
		result = 31 * result + (contractId != null ? contractId.hashCode() : 0);
		result = 31 * result + (configManagerVisible != null ? configManagerVisible.hashCode() : 0);
		result = 31 * result + (fileName != null ? fileName.hashCode() : 0);
		result = 31 * result + (description != null ? description.hashCode() : 0);
		result = 31 * result + (productionArlFileVersion != null ? productionArlFileVersion.hashCode() : 0);
		result = 31 * result + (productionActivationDate != null ? productionActivationDate.hashCode() : 0);
		result = 31 * result + (stagingArlFileVersion != null ? stagingArlFileVersion.hashCode() : 0);
		result = 31 * result + (stagingActivationDate != null ? stagingActivationDate.hashCode() : 0);
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		BasicProperty other = (BasicProperty) obj;
		if(!Objects.equals(arlFileId, other.arlFileId)) {
			return false;
		}
		if (!Objects.deepEquals(groupIds, other.groupIds)) {
			return false;
		}
		if(!Objects.equals(assetId, other.assetId)) {
			return false;
		}
		if(!Objects.equals(propertyName, other.propertyName)) {
			return false;
		}
		if(!Objects.equals(assetType, other.assetType)) {
			return false;
		}
		if(!Objects.equals(contractId, other.contractId)) {
			return false;
		}
		if(!Objects.equals(configManagerVisible, other.configManagerVisible)) {
			return false;
		}
		if(!Objects.equals(fileName, other.fileName)) {
			return false;
		}
		if(!Objects.equals(description, other.description)) {
			return false;
		}
		if(!Objects.equals(productionArlFileVersion, other.productionArlFileVersion)) {
			return false;
		}
		if(!Objects.equals(stagingArlFileVersion, other.stagingArlFileVersion)) {
			return false;
		}
		if(!Objects.equals(productionActivationDate, other.productionActivationDate)) {
			return false;
		}
		if(!Objects.equals(stagingActivationDate, other.stagingActivationDate)) {
			return false;
		}
		return true;
	}
}
