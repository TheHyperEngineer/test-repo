package com.akamai.buyakamai.controller.model;

import java.util.List;

public class OpportunityMetaData {
    private List<String> competitor;
    private List<String> currency;
    private List<String> stages;
    private List<String> dealType;


    public List<String> getCompetitor() {
        return competitor;
    }

    public void setCompetitor(List<String> competitor) {
        this.competitor = competitor;
    }

    public List<String> getDealType() {
        return dealType;
    }

    public void setDealType(List<String> dealType) {
        this.dealType = dealType;
    }

    public List<String> getStages() {
        return stages;
    }

    public void setStages(List<String> stages) {
        this.stages = stages;
    }

    public List<String> getCurrency() {
        return currency;
    }

    public void setCurrency(List<String> currency) {
        this.currency = currency;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OpportunityMetaData that = (OpportunityMetaData) o;

        if (competitor != null ? !competitor.equals(that.competitor) : that.competitor != null) return false;
        if (currency != null ? !currency.equals(that.currency) : that.currency != null) return false;
        if (stages != null ? !stages.equals(that.stages) : that.stages != null) return false;
        return dealType != null ? dealType.equals(that.dealType) : that.dealType == null;
    }

    @Override
    public int hashCode() {
        int result = competitor != null ? competitor.hashCode() : 0;
        result = 31 * result + (currency != null ? currency.hashCode() : 0);
        result = 31 * result + (stages != null ? stages.hashCode() : 0);
        result = 31 * result + (dealType != null ? dealType.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OpportunityMetaData{" +
                "competitor=" + competitor +
                ", currency=" + currency +
                ", stages=" + stages +
                ", dealType=" + dealType +
                '}';
    }
}
