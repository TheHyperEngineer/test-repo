package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderUpdateRequestV2 {

	private boolean tncAccepted;

	private String trialDuration;

	private List<String> contractIdList;

	private String acceptedByContactId;
	
	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public List<String> getContractIdList() {
		return contractIdList;
	}

	public void setContractIdList(List<String> contractIdList) {
		this.contractIdList = contractIdList;
	}

	public String getTrialDuration() {
		return trialDuration;
	}

	public void setTrialDuration(String trialDuration) {
		this.trialDuration = trialDuration;
	}

	public String getAcceptedByContactId() {
		return acceptedByContactId;
	}

	public void setAcceptedByContactId(String acceptedByContactId) {
		this.acceptedByContactId = acceptedByContactId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((acceptedByContactId == null) ? 0 : acceptedByContactId.hashCode());
		result = prime * result + ((contractIdList == null) ? 0 : contractIdList.hashCode());
		result = prime * result + (tncAccepted ? 1231 : 1237);
		result = prime * result + ((trialDuration == null) ? 0 : trialDuration.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderUpdateRequestV2 other = (OrderUpdateRequestV2) obj;
		if (acceptedByContactId == null) {
			if (other.acceptedByContactId != null)
				return false;
		} else if (!acceptedByContactId.equals(other.acceptedByContactId))
			return false;
		if (contractIdList == null) {
			if (other.contractIdList != null)
				return false;
		} else if (!contractIdList.equals(other.contractIdList))
			return false;
		if (tncAccepted != other.tncAccepted)
			return false;
		if (trialDuration == null) {
			if (other.trialDuration != null)
				return false;
		} else if (!trialDuration.equals(other.trialDuration))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OrderUpdateRequestV2 [tncAccepted=" + tncAccepted + ", trialDuration=" + trialDuration
		        + ", contractIdList=" + contractIdList + ", acceptedByContactId=" + acceptedByContactId + "]";
	}
}
