package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class HistogramTransformedResponse {

    private HistogramDataSetCollection performanceResult;
    private HistogramExperience experience;
    private String product;

    public HistogramDataSetCollection getPerformanceResult() {
        return performanceResult;
    }

    public void setPerformanceResult(HistogramDataSetCollection performanceResult) {
        this.performanceResult = performanceResult;
    }

    public HistogramExperience getExperience() {
        return experience;
    }

    public void setExperience(HistogramExperience experience) {
        this.experience = experience;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HistogramTransformedResponse that = (HistogramTransformedResponse) o;

        if (performanceResult != null ? !performanceResult.equals(that.performanceResult) : that.performanceResult != null)
            return false;
        if (experience != null ? !experience.equals(that.experience) : that.experience != null) return false;
        return product != null ? product.equals(that.product) : that.product == null;
    }

    @Override
    public int hashCode() {
        int result = performanceResult != null ? performanceResult.hashCode() : 0;
        result = 31 * result + (experience != null ? experience.hashCode() : 0);
        result = 31 * result + (product != null ? product.hashCode() : 0);
        return result;
    }
}
