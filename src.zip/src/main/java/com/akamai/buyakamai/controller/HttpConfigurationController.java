package com.akamai.buyakamai.controller;

import java.util.List;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.controller.model.HttpConfiguration;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.HttpConfigurationServiceImpl;

/**
 * HttpConfiguration controller.
 * 
 * Provides access to enhanced HttpConfiguration (including DNSResolution) for DigitalProperty.
 * 
 * @author jplans
 *
 */
@RestController
@EnableAutoConfiguration
public class HttpConfigurationController {

	// Logger
	private static final Logger logger = LoggerFactory.getLogger(HttpConfigurationController.class);

	// Service that will be used as data source
	@Autowired
	private HttpConfigurationServiceImpl configurationService;

	/**
	 * Return the list of enhanced HttpConfiguration (with DNS resolution) for a given accountId
	 * @param accountId						AccountId to lookup
	 * @return								List of enhanced HttpConfiguration corresponding to the accountId
	 * @throws BuyAkamaiApplicationException	Should be the only raised exception
	 */
	@RequestMapping(value = "/v1/httpconfigurations/{accountId}", method = RequestMethod.GET)
	public ResponseEntity<List<HttpConfiguration>> getConfigurationsForAccount(@Valid @PathVariable String accountId) throws BuyAkamaiApplicationException {

		logger.info("Entering getConfigurationsForAccount for account ID {} ",accountId);

		List<HttpConfiguration> response = configurationService.getConfigurationsForAccount(accountId);
		
		final HttpHeaders httpHeaders= new HttpHeaders();
	    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	    
		ResponseEntity<List<HttpConfiguration>> result = new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		
		logger.info("Exiting getConfigurationsForAccount with Response {} ",response);
		return result;
	}

}