package com.akamai.buyakamai.controller.model;

import java.util.List;
import java.util.Objects;

import org.apache.commons.lang.builder.ToStringBuilder;

public class Row {

	/** Property data */
	List<Float> data;

	/**
	 * Constructor
	 */
	public Row() {
	}

	/**
	 * Gets the data
	 */
	public List<Float> getData() {
		return this.data;
	}

	/**
	 * Sets the data
	 */
	public void setData(List<Float> value) {
		this.data = value;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		Row other = (Row) obj;

		if(!Objects.deepEquals(data, other.data)) {
			return false;
		}
		
		return true;
	}
}
