package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class MetricAggregationTransformedResponse {

    private MetricAggregationDataSet performanceResult;
    private String product;

    public MetricAggregationDataSet getPerformanceResult() {
        return performanceResult;
    }

    public void setPerformanceResult(MetricAggregationDataSet performanceResult) {
        this.performanceResult = performanceResult;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MetricAggregationTransformedResponse that = (MetricAggregationTransformedResponse) o;

        if (performanceResult != null ? !performanceResult.equals(that.performanceResult) : that.performanceResult != null)
            return false;
        return product != null ? product.equals(that.product) : that.product == null;
    }

    @Override
    public int hashCode() {
        int result = performanceResult != null ? performanceResult.hashCode() : 0;
        result = 31 * result + (product != null ? product.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "MetricAggregationTransformedResponse{" +
                "performanceResult=" + performanceResult +
                ", product='" + product + '\'' +
                '}';
    }
}
