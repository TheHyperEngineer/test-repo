package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderUpdateRequest {
	
	private boolean tncAccepted;

	private String partnerContractId;

	private String acceptedByContactId;

	private String trialDuration;

	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public String getPartnerContractId() {
		return partnerContractId;
	}

	public void setPartnerContractId(String partnerContractId) {
		this.partnerContractId = partnerContractId;
	}

	public String getAcceptedByContactId() {
		return acceptedByContactId;
	}

	public void setAcceptedByContactId(String acceptedByContactId) {
		this.acceptedByContactId = acceptedByContactId;
	}

	public String getTrialDuration() {
		return trialDuration;
	}

	public void setTrialDuration(String trialDuration) {
		this.trialDuration = trialDuration;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		OrderUpdateRequest that = (OrderUpdateRequest) o;

		if (tncAccepted != that.tncAccepted) return false;
		if (partnerContractId != null ? !partnerContractId.equals(that.partnerContractId) : that.partnerContractId != null)
			return false;
		if (acceptedByContactId != null ? !acceptedByContactId.equals(that.acceptedByContactId) : that.acceptedByContactId != null)
			return false;
		return trialDuration != null ? trialDuration.equals(that.trialDuration) : that.trialDuration == null;
	}

	@Override
	public int hashCode() {
		int result = (tncAccepted ? 1 : 0);
		result = 31 * result + (partnerContractId != null ? partnerContractId.hashCode() : 0);
		result = 31 * result + (acceptedByContactId != null ? acceptedByContactId.hashCode() : 0);
		result = 31 * result + (trialDuration != null ? trialDuration.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "OrderUpdateRequest{" +
				"tncAccepted=" + tncAccepted +
				", partnerContractId='" + partnerContractId + '\'' +
				", acceptedByContactId='" + acceptedByContactId + '\'' +
				", trialDuration='" + trialDuration + '\'' +
				'}';
	}
}