package com.akamai.buyakamai.controller.model;

import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MarketplacePricingResponse extends ResourceSupport {
	
	private String marketingProductId;

	private String defaultTrialDuration;
	
	private List<MarketplacePricingResponseListItem> pricingResponseListItem;
	
	private String expressInterestReason;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private List<OptionPricingResponse> options;

	public String getMarketingProductId() {
		return marketingProductId;
	}

	public void setMarketingProductId(String marketingProductId) {
		this.marketingProductId = marketingProductId;
	}

	public List<MarketplacePricingResponseListItem> getPricingResponseListItem() {
		return pricingResponseListItem;
	}

	public void setPricingResponseListItem(List<MarketplacePricingResponseListItem> pricingResponseListItem) {
		this.pricingResponseListItem = pricingResponseListItem;
	}

	public String getExpressInterestReason() {
		return expressInterestReason;
	}

	public void setExpressInterestReason(String expressInterestReason) {
		this.expressInterestReason = expressInterestReason;
	}

	public String getDefaultTrialDuration() {
		return defaultTrialDuration;
	}

	public void setDefaultTrialDuration(String defaultTrialDuration) {
		this.defaultTrialDuration = defaultTrialDuration;
	}

	public List<OptionPricingResponse> getOptions() {
		return options;
	}

	public void setOptions(List<OptionPricingResponse> options) {
		this.options = options;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((defaultTrialDuration == null) ? 0 : defaultTrialDuration.hashCode());
		result = prime * result + ((expressInterestReason == null) ? 0 : expressInterestReason.hashCode());
		result = prime * result + ((marketingProductId == null) ? 0 : marketingProductId.hashCode());
		result = prime * result + ((pricingResponseListItem == null) ? 0 : pricingResponseListItem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		MarketplacePricingResponse other = (MarketplacePricingResponse) obj;
		if (defaultTrialDuration == null) {
			if (other.defaultTrialDuration != null)
				return false;
		} else if (!defaultTrialDuration.equals(other.defaultTrialDuration))
			return false;
		if (expressInterestReason == null) {
			if (other.expressInterestReason != null)
				return false;
		} else if (!expressInterestReason.equals(other.expressInterestReason))
			return false;
		if (marketingProductId == null) {
			if (other.marketingProductId != null)
				return false;
		} else if (!marketingProductId.equals(other.marketingProductId))
			return false;
		if (pricingResponseListItem == null) {
			if (other.pricingResponseListItem != null)
				return false;
		} else if (!pricingResponseListItem.equals(other.pricingResponseListItem))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "MarketplacePricingResponse [marketingProductId=" + marketingProductId + ", defaultTrialDuration="
		        + defaultTrialDuration + ", pricingResponseListItem=" + pricingResponseListItem
		        + ", expressInterestReason=" + expressInterestReason + "]";
	}
}