package com.akamai.buyakamai.controller.model.partner;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ContractInfo {

	private String contractId;
	
    @JsonInclude(JsonInclude.Include.NON_NULL)
	private PartnerContractInfo partnerContract;

	private List<String> marketingProducts;

	private String contractStartDate;

	private String contractEndDate;

	private String currency;

	private Boolean isUserSelectedContract = false;
	
	@JsonIgnore
	private boolean dependencySatisfied;

	private String billToCountry;

	private List<ChildContractInfo> childContracts;

	public String getContractId() {
		return contractId;
	}

	public void setContractId(String contractId) {
		this.contractId = contractId;
	}

	public List<String> getMarketingProducts() {
		return marketingProducts;
	}

	public void setMarketingProducts(List<String> marketingProducts) {
		this.marketingProducts = marketingProducts;
	}

	public String getContractStartDate() {
		return contractStartDate;
	}

	public void setContractStartDate(String contractStartDate) {
		this.contractStartDate = contractStartDate;
	}

	public String getContractEndDate() {
		return contractEndDate;
	}

	public void setContractEndDate(String contractEndDate) {
		this.contractEndDate = contractEndDate;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public Boolean getUserSelectedContract() {
		return isUserSelectedContract;
	}

	public void setUserSelectedContract(Boolean userSelectedContract) {
		isUserSelectedContract = userSelectedContract;
	}
	
	public boolean isDependencySatisfied() {
		return dependencySatisfied;
	}

	public void setDependencySatisfied(boolean dependencySatisfied) {
		this.dependencySatisfied = dependencySatisfied;
	}

	public PartnerContractInfo getPartnerContract() {
		return partnerContract;
	}

	public void setPartnerContract(PartnerContractInfo partnerContract) {
		this.partnerContract = partnerContract;
	}

	public String getBillToCountry() {
		return billToCountry;
	}

	public void setBillToCountry(String billToCountry) {
		this.billToCountry = billToCountry;
	}

	public List<ChildContractInfo> getChildContracts() {
		return childContracts;
	}

	public void setChildContracts(List<ChildContractInfo> childContracts) {
		this.childContracts = childContracts;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof ContractInfo)) return false;

		ContractInfo that = (ContractInfo) o;

		if (isDependencySatisfied() != that.isDependencySatisfied()) return false;
		if (getContractId() != null ? !getContractId().equals(that.getContractId()) : that.getContractId() != null)
			return false;
		if (getPartnerContract() != null ? !getPartnerContract().equals(that.getPartnerContract()) : that.getPartnerContract() != null)
			return false;
		if (getMarketingProducts() != null ? !getMarketingProducts().equals(that.getMarketingProducts()) : that.getMarketingProducts() != null)
			return false;
		if (getContractStartDate() != null ? !getContractStartDate().equals(that.getContractStartDate()) : that.getContractStartDate() != null)
			return false;
		if (getContractEndDate() != null ? !getContractEndDate().equals(that.getContractEndDate()) : that.getContractEndDate() != null)
			return false;
		if (getCurrency() != null ? !getCurrency().equals(that.getCurrency()) : that.getCurrency() != null)
			return false;
		if (isUserSelectedContract != null ? !isUserSelectedContract.equals(that.isUserSelectedContract) : that.isUserSelectedContract != null)
			return false;
		if (getBillToCountry() != null ? !getBillToCountry().equals(that.getBillToCountry()) : that.getBillToCountry() != null)
			return false;
		return getChildContracts() != null ? getChildContracts().equals(that.getChildContracts()) : that.getChildContracts() == null;
	}

	@Override
	public int hashCode() {
		int result = getContractId() != null ? getContractId().hashCode() : 0;
		result = 31 * result + (getPartnerContract() != null ? getPartnerContract().hashCode() : 0);
		result = 31 * result + (getMarketingProducts() != null ? getMarketingProducts().hashCode() : 0);
		result = 31 * result + (getContractStartDate() != null ? getContractStartDate().hashCode() : 0);
		result = 31 * result + (getContractEndDate() != null ? getContractEndDate().hashCode() : 0);
		result = 31 * result + (getCurrency() != null ? getCurrency().hashCode() : 0);
		result = 31 * result + (isUserSelectedContract != null ? isUserSelectedContract.hashCode() : 0);
		result = 31 * result + (isDependencySatisfied() ? 1 : 0);
		result = 31 * result + (getBillToCountry() != null ? getBillToCountry().hashCode() : 0);
		result = 31 * result + (getChildContracts() != null ? getChildContracts().hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("ContractInfo{");
		sb.append("contractId='").append(contractId).append('\'');
		sb.append(", partnerContract=").append(partnerContract);
		sb.append(", marketingProducts=").append(marketingProducts);
		sb.append(", contractStartDate='").append(contractStartDate).append('\'');
		sb.append(", contractEndDate='").append(contractEndDate).append('\'');
		sb.append(", currency='").append(currency).append('\'');
		sb.append(", isUserSelectedContract=").append(isUserSelectedContract);
		sb.append(", dependencySatisfied=").append(dependencySatisfied);
		sb.append(", billToCountry='").append(billToCountry).append('\'');
		sb.append(", childContracts=").append(childContracts);
		sb.append('}');
		return sb.toString();
	}
}