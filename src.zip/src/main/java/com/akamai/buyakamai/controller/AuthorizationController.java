package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.UserEventAction;
import com.akamai.buyakamai.controller.model.UserInfo;
import com.akamai.buyakamai.service.events.EventInfo;
import com.akamai.buyakamai.service.events.EventProcessor;
import com.akamai.buyakamai.service.impl.AuthorizationServiceImpl;
import com.akamai.buyakamai.service.impl.PartnerService;
import com.akamai.buyakamai.util.AuthRuleInitializer;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.util.List;

@RestController
@EnableAutoConfiguration
public class AuthorizationController {

	private static final Logger logger = LoggerFactory.getLogger(AuthorizationController.class);

	@Autowired
	private AuthorizationServiceImpl authService;
	
	@Autowired
	private AuthRuleInitializer authRuleInitializer;

	@Autowired
	private EventProcessor eventProcessor;

	@Autowired
	private PartnerService partnerService;

	@RequestMapping(value = "/v1/user-info", method = RequestMethod.GET ,produces = "application/json")
	public ResponseEntity<UserInfo> getUserInfo(@Context HttpServletRequest httpRequest) {

		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		String impUserName = httpRequest.getHeader(BAConstants.IMP_USER_ID);
		logger.info("Getting user info for user name: {} & impersonator {}", userName, impUserName);

		boolean isPartnerUser = partnerService.isPartnerUser(userName);
		UserInfo response = authService.getUserInfo(userName, !StringUtils.isBlank(impUserName), isPartnerUser);

		logger.info("Role list for user {} : {}", userName, response.getRoles());
		EventInfo eventInfo = new EventInfo(userName, UserEventAction.USER_LOGIN_SUCCESS);
		eventProcessor.initiateEventProcessorThread(eventInfo);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/roles", method = RequestMethod.GET ,produces = "application/json")
	public ResponseEntity<List<String>> getRoles(@Context HttpServletRequest httpRequest) {

		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		String impUserName = httpRequest.getHeader(BAConstants.IMP_USER_ID);
		logger.info("Getting role list for user name: {}", userName);
		boolean isPartnerUser = partnerService.isPartnerUser(userName);
		List<String> response = authService.getRolesForUser(userName, !StringUtils.isBlank(impUserName), isPartnerUser);

		logger.info("Role list for user {} : {}", userName, response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/scopes", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<String>> getScopes(@Context HttpServletRequest httpRequest) {

		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		String impUserName = httpRequest.getHeader(BAConstants.IMP_USER_ID);
		logger.info("Getting scope list for user name: {}", userName);
		boolean isPartnerUser = partnerService.isPartnerUser(userName);
		List<String> response = authService.getScopesForUser(userName, !StringUtils.isBlank(impUserName), isPartnerUser);

		logger.info("Scope list for user {} : {}", userName, response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/refresh-rules", method = RequestMethod.POST, produces = "text/html")
	public ResponseEntity<String> refreshRules(@Context HttpServletRequest httpRequest) {

		logger.info("Reloading all the auth rules");
		try {
			authRuleInitializer.initilizeRules();
		} catch (Exception e) {
			// do nothing
		}
		String response = "<html><body>OK</body></html>";
		logger.info("Reloading all the auth rules");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}