package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TierResponse {
	private String tierId;
	private Long unitsLow;
	private Long unitsHigh;
	private BigDecimal unitPrice;
	private BigDecimal overagePrice;
	
	public String getTierId() {
		return tierId;
	}
	public void setTierId(String tierId) {
		this.tierId = tierId;
	}
	public Long getUnitsLow() {
		return unitsLow;
	}
	public void setUnitsLow(Long unitsLow) {
		this.unitsLow = unitsLow;
	}
	public Long getUnitsHigh() {
		return unitsHigh;
	}
	public void setUnitsHigh(Long unitsHigh) {
		this.unitsHigh = unitsHigh;
	}
	public BigDecimal getUnitPrice() {
		return unitPrice;
	}
	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}
	public BigDecimal getOveragePrice() {
		return overagePrice;
	}
	public void setOveragePrice(BigDecimal overagePrice) {
		this.overagePrice = overagePrice;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((tierId == null) ? 0 : tierId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TierResponse other = (TierResponse) obj;
		if (tierId == null) {
			if (other.tierId != null)
				return false;
		} else if (!tierId.equals(other.tierId))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "TierResponse [tierId=" + tierId + ", unitsLow=" + unitsLow + ", unitsHigh=" + unitsHigh + ", unitPrice="
				+ unitPrice + ", overagePrice=" + overagePrice + "]";
	}
	
}
