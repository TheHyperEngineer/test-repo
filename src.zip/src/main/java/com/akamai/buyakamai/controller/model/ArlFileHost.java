package com.akamai.buyakamai.controller.model;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.akamai.buyakamai.integration.clients.model.CustomARLFileHost;
import com.akamai.buyakamai.service.dns.DNSCategorizedResolution;
import com.akamai.buyakamai.service.dns.DNSResolution;

/**
 * Enhanced com.akamai.se.domain.property.ArlFileHost with DNS resolution
 * 
 * @author jplans
 *
 */
public class ArlFileHost {
	/** Property hostName */
	private String hostName;

	/** Property network */
	private String network;

	/** Property isActivated */
	private Boolean isActivated;

	/** Property resolution */
	private Optional<DNSResolution> resolution;

	/**
	 * Constructor
	 */
	public ArlFileHost() {
	}

	/**
	 * Constructor
	 */
	public ArlFileHost(CustomARLFileHost other) {
		hostName = other.getHostName();
		network = other.getNetwork();
		isActivated = other.isActivated();
	}

	/**
	 * Builds the object based on a com.akamai.se.domain.property.ArlFileHost and available resolutions
	 * @param other
	 * @param resolutions
	 */
	public ArlFileHost(CustomARLFileHost other,
			Map<String, DNSCategorizedResolution> resolutions) {
		hostName = other.getHostName();
		network = other.getNetwork();
		isActivated = other.isActivated();
		resolution = (resolutions.containsKey(hostName)) ? Optional.of(resolutions.get(hostName)) : Optional.empty();
	}

	/**
	 * Gets the hostName
	 */
	public String getHostName() {
		return this.hostName;
	}

	/**
	 * Sets the hostName
	 */
	public void setHostName(String value) {
		this.hostName = value;
	}

	/**
	 * Gets the resolution
	 */
	public Optional<DNSResolution> getResolution() {
		return this.resolution;
	}

	/**
	 * Sets the resolution
	 */
	public void setResolution(DNSResolution value) {
		this.resolution = value == null ? Optional.empty() : Optional.of(value);
	}

	/**
	 * Gets the network
	 */
	public String getNetwork() {
		return this.network;
	}

	/**
	 * Sets the network
	 */
	public void setNetwork(String value) {
		this.network = value;
	}

	/**
	 * Gets the isActivated
	 */
	public Boolean getIsActivated() {
		return this.isActivated;
	}

	/**
	 * Sets the isActivated
	 */
	public void setIsActivated(Boolean value) {
		this.isActivated = value;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hostName == null) ? 0 : hostName.hashCode());
		result = prime * result + ((network == null) ? 0 : network.hashCode());
		result = prime * result + ((isActivated == null) ? 0 : isActivated.hashCode());
		result = prime * result + ((resolution.isPresent() == false) ? 0 : resolution.get().hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		ArlFileHost other = (ArlFileHost) obj;

		if(!Objects.equals(hostName, other.hostName)) {
			return false;
		}

		if(!Objects.equals(network, other.network)) {
			return false;
		}

		if(!Objects.equals(isActivated, other.isActivated)) {
			return false;
		}

		if(!Objects.equals(resolution, other.resolution)) {
			return false;
		}

		return true;
	}
}
