package com.akamai.buyakamai.controller.model;

import java.util.List;

public class AccountContactsResponse {

	private List<String> contactIds;

	public List<String> getContactIds() {
		return contactIds;
	}

	public void setContactIds(List<String> contactIds) {
		this.contactIds = contactIds;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contactIds == null) ? 0 : contactIds.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountContactsResponse other = (AccountContactsResponse) obj;
		if (contactIds == null) {
			if (other.contactIds != null)
				return false;
		} else if (!contactIds.equals(other.contactIds))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "AccountContactsResponse [contactIds=" + contactIds + "]";
	}
}