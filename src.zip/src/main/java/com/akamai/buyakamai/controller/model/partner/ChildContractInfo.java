package com.akamai.buyakamai.controller.model.partner;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * Created by Abhishyam on 28-Dec,2018
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public class ChildContractInfo {

    private String contractId;

    private String contractTypeId;

    private String startDate;

    private String endDate;

    private String accountId;

    private String accountName;

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getContractTypeId() {
        return contractTypeId;
    }

    public void setContractTypeId(String contractTypeId) {
        this.contractTypeId = contractTypeId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ChildContractInfo)) return false;

        ChildContractInfo that = (ChildContractInfo) o;

        if (getContractId() != null ? !getContractId().equals(that.getContractId()) : that.getContractId() != null)
            return false;
        if (getContractTypeId() != null ? !getContractTypeId().equals(that.getContractTypeId()) : that.getContractTypeId() != null)
            return false;
        if (getStartDate() != null ? !getStartDate().equals(that.getStartDate()) : that.getStartDate() != null)
            return false;
        if (getEndDate() != null ? !getEndDate().equals(that.getEndDate()) : that.getEndDate() != null) return false;
        if (getAccountId() != null ? !getAccountId().equals(that.getAccountId()) : that.getAccountId() != null)
            return false;
        return getAccountName() != null ? getAccountName().equals(that.getAccountName()) : that.getAccountName() == null;
    }

    @Override
    public int hashCode() {
        int result = getContractId() != null ? getContractId().hashCode() : 0;
        result = 31 * result + (getContractTypeId() != null ? getContractTypeId().hashCode() : 0);
        result = 31 * result + (getStartDate() != null ? getStartDate().hashCode() : 0);
        result = 31 * result + (getEndDate() != null ? getEndDate().hashCode() : 0);
        result = 31 * result + (getAccountId() != null ? getAccountId().hashCode() : 0);
        result = 31 * result + (getAccountName() != null ? getAccountName().hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("ChildContractInfo{");
        sb.append("contractId='").append(contractId).append('\'');
        sb.append(", contractTypeId='").append(contractTypeId).append('\'');
        sb.append(", startDate='").append(startDate).append('\'');
        sb.append(", endDate='").append(endDate).append('\'');
        sb.append(", accountId='").append(accountId).append('\'');
        sb.append(", accountName='").append(accountName).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
