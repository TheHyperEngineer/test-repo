package com.akamai.buyakamai.controller.model;

import java.util.Set;

public class ContactSelectRequest {

	private Set<String> contactIds;

    public Set<String> getContactIds() {
        return contactIds;
    }

    public void setContactIds(Set<String> contactIds) {
        this.contactIds = contactIds;
    }

    @Override
    public String toString() {
        return "ContactSelectRequest{" +
                "contactIds=" + contactIds +
                '}';
    }
}
