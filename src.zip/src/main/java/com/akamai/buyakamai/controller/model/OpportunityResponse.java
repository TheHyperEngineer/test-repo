package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.controller.model.partner.PartnerOpportunityInfo;
import com.akamai.buyakamai.integration.clients.model.SalesRepOrderSourceDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpportunityResponse {

	private String id;

	private String name;

	private String currency;

	private String bundleId;

	private String dealType;

	private String productName;

	private String trialType;

	private String stage;

	private String salesForceUrl;

	private CustomerInfoDTO customer;

	private SalesRepOrderSourceDto owner;

	private PartnerOpportunityInfo partnerInfo;

	public PartnerOpportunityInfo getPartnerInfo() {
		return partnerInfo;
	}

	public void setPartnerInfo(PartnerOpportunityInfo partnerInfo) {
		this.partnerInfo = partnerInfo;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getTrialType() {
		return trialType;
	}

	public void setTrialType(String trialType) {
		this.trialType = trialType;
	}

	public CustomerInfoDTO getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerInfoDTO customer) {
		this.customer = customer;
	}

	public SalesRepOrderSourceDto getOwner() {
		return owner;
	}

	public void setOwner(SalesRepOrderSourceDto owner) {
		this.owner = owner;
	}

	public String getStage() {
		return stage;
	}

	public void setStage(String stage) {
		this.stage = stage;
	}

	public String getSalesForceUrl() {
		return salesForceUrl;
	}

	public void setSalesForceUrl(String salesForceUrl) {
		this.salesForceUrl = salesForceUrl;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		OpportunityResponse that = (OpportunityResponse) o;

		return id != null ? id.equals(that.id) : that.id == null;
	}

	@Override
	public int hashCode() {
		return id != null ? id.hashCode() : 0;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
}




