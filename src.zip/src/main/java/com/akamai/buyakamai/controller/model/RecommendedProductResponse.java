package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.springframework.hateoas.ResourceSupport;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RecommendedProductResponse extends ResourceSupport{

    private String productId;

    private String name;
    
    private String bundleId;
    
    private String bundleName;
    
    private boolean newContractAllowed;
    
    private boolean onlyNewContractAllowed;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean retryEnabled;

    private List<String> supportedIntegrationTypes;

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
	public List<String> getSupportedIntegrationTypes() {
		return supportedIntegrationTypes;
	}

	public void setSupportedIntegrationTypes(List<String> supportedIntegrationTypes) {
		this.supportedIntegrationTypes = supportedIntegrationTypes;
	}

	public Boolean getRetryEnabled() {
		return retryEnabled;
	}

	public void isRetryEnabled(Boolean retryEnabled) {
		this.retryEnabled = retryEnabled;
	}
	
	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getBundleName() {
		return bundleName;
	}

	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}

	public boolean isNewContractAllowed() {
		return newContractAllowed;
	}

	public void setNewContractAllowed(boolean newContractAllowed) {
		this.newContractAllowed = newContractAllowed;
	}

	public boolean isOnlyNewContractAllowed() {
		return onlyNewContractAllowed;
	}

	public void setOnlyNewContractAllowed(boolean onlyNewContractAllowed) {
		this.onlyNewContractAllowed = onlyNewContractAllowed;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bundleId == null) ? 0 : bundleId.hashCode());
		result = prime * result + ((productId == null) ? 0 : productId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RecommendedProductResponse other = (RecommendedProductResponse) obj;
		if (bundleId == null) {
			if (other.bundleId != null)
				return false;
		} else if (!bundleId.equals(other.bundleId))
			return false;
		if (productId == null) {
			if (other.productId != null)
				return false;
		} else if (!productId.equals(other.productId))
			return false;
		return true;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
