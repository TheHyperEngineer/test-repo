package com.akamai.buyakamai.controller.model;

import java.math.BigDecimal;

import org.apache.commons.lang.builder.ToStringBuilder;

public class OrderPricingDetails {
	
    private Long unitLow;
	
	private Long unitHigh;
	
	private BigDecimal unitPrice;
	
	private String billingFrequency;
	
	private String pricingMethod;
	
	private String usageMethod;
	
	private UOMInfo uom;
	
	private String currency;

	public Long getUnitLow() {
		return unitLow;
	}

	public void setUnitLow(Long unitLow) {
		this.unitLow = unitLow;
	}

	public Long getUnitHigh() {
		return unitHigh;
	}

	public void setUnitHigh(Long unitHigh) {
		this.unitHigh = unitHigh;
	}

	public BigDecimal getUnitPrice() {
		return unitPrice;
	}

	public void setUnitPrice(BigDecimal unitPrice) {
		this.unitPrice = unitPrice;
	}

	public String getBillingFrequency() {
		return billingFrequency;
	}

	public void setBillingFrequency(String billingFrequency) {
		this.billingFrequency = billingFrequency;
	}

	public String getPricingMethod() {
		return pricingMethod;
	}

	public void setPricingMethod(String pricingMethod) {
		this.pricingMethod = pricingMethod;
	}

	public String getUsageMethod() {
		return usageMethod;
	}

	public void setUsageMethod(String usageMethod) {
		this.usageMethod = usageMethod;
	}

	public UOMInfo getUom() {
		return uom;
	}

	public void setUom(UOMInfo uom) {
		this.uom = uom;
	}
	
	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((billingFrequency == null) ? 0 : billingFrequency.hashCode());
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + ((pricingMethod == null) ? 0 : pricingMethod.hashCode());
		result = prime * result + ((unitHigh == null) ? 0 : unitHigh.hashCode());
		result = prime * result + ((unitLow == null) ? 0 : unitLow.hashCode());
		result = prime * result + ((unitPrice == null) ? 0 : unitPrice.hashCode());
		result = prime * result + ((uom == null) ? 0 : uom.hashCode());
		result = prime * result + ((usageMethod == null) ? 0 : usageMethod.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderPricingDetails other = (OrderPricingDetails) obj;
		if (billingFrequency == null) {
			if (other.billingFrequency != null)
				return false;
		} else if (!billingFrequency.equals(other.billingFrequency))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (pricingMethod == null) {
			if (other.pricingMethod != null)
				return false;
		} else if (!pricingMethod.equals(other.pricingMethod))
			return false;
		if (unitHigh == null) {
			if (other.unitHigh != null)
				return false;
		} else if (!unitHigh.equals(other.unitHigh))
			return false;
		if (unitLow == null) {
			if (other.unitLow != null)
				return false;
		} else if (!unitLow.equals(other.unitLow))
			return false;
		if (unitPrice == null) {
			if (other.unitPrice != null)
				return false;
		} else if (!unitPrice.equals(other.unitPrice))
			return false;
		if (uom == null) {
			if (other.uom != null)
				return false;
		} else if (!uom.equals(other.uom))
			return false;
		if (usageMethod == null) {
			if (other.usageMethod != null)
				return false;
		} else if (!usageMethod.equals(other.usageMethod))
			return false;
		return true;
	}
	
	
	

}
