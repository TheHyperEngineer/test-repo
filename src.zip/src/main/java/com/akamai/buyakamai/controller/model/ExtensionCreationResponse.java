package com.akamai.buyakamai.controller.model;

public class ExtensionCreationResponse {

	private Integer orderId;

	private String status;
	
	private String autoExtensionStartDate;

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	

	public String getAutoExtensionStartDate() {
		return autoExtensionStartDate;
	}

	public void setAutoExtensionStartDate(String autoExtensionStartDate) {
		this.autoExtensionStartDate = autoExtensionStartDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExtensionCreationResponse other = (ExtensionCreationResponse) obj;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "ExtensionCreationResponse [orderId=" + orderId + ", status=" + status + "]";
	}

}
