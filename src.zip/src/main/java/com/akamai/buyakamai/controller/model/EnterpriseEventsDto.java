package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.enums.EnterpriseEventType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.ser.ZonedDateTimeSerializer;

import java.time.ZonedDateTime;

public class EnterpriseEventsDto {
    private EnterpriseEventType eventType;

    @JsonFormat(pattern = BAConstants.DATE_FORMAT_LEO_INTERNAL)
    @JsonSerialize(using = ZonedDateTimeSerializer.class)
    private ZonedDateTime completedDate;

    private String completedBy;

    public EnterpriseEventType getEventType() {
        return eventType;
    }

    public void setEventType(EnterpriseEventType eventType) {
        this.eventType = eventType;
    }

    public ZonedDateTime getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(ZonedDateTime completedDate) {
        this.completedDate = completedDate;
    }

    public String getCompletedBy() {
        return completedBy;
    }

    public void setCompletedBy(String completedBy) {
        this.completedBy = completedBy;
    }

    @Override
    public String toString() {
        return "EnterpriseEventsDto{" + "eventType=" + eventType + ", completedDate=" + completedDate
                + ", completedBy='" + completedBy + '\'' + '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        EnterpriseEventsDto that = (EnterpriseEventsDto) o;

        if (eventType != that.eventType)
            return false;
        if (completedDate != null ? !completedDate.equals(that.completedDate) : that.completedDate != null)
            return false;
        return completedBy != null ? completedBy.equals(that.completedBy) : that.completedBy == null;
    }

    @Override
    public int hashCode() {
        int result = eventType != null ? eventType.hashCode() : 0;
        result = 31 * result + (completedDate != null ? completedDate.hashCode() : 0);
        result = 31 * result + (completedBy != null ? completedBy.hashCode() : 0);
        return result;
    }
}
