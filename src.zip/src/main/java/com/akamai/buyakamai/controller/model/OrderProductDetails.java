package com.akamai.buyakamai.controller.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;


public class OrderProductDetails {
	
	private String id;
	
	private String name;
	
	private String type;
	
	private String parentProdOptId;
	
	private String parentProdOptName;
	
	private List<OrderPricingDetails> pricingDetails;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getParentProdOptId() {
		return parentProdOptId;
	}

	public void setParentProdOptId(String parentProdOptId) {
		this.parentProdOptId = parentProdOptId;
	}

	public String getParentProdOptName() {
		return parentProdOptName;
	}

	public void setParentProdOptName(String parentProdOptName) {
		this.parentProdOptName = parentProdOptName;
	}

	public List<OrderPricingDetails> getPricingDetails() {
		return pricingDetails;
	}

	public void setPricingDetails(List<OrderPricingDetails> pricingDetails) {
		this.pricingDetails = pricingDetails;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((parentProdOptId == null) ? 0 : parentProdOptId.hashCode());
		result = prime * result + ((parentProdOptName == null) ? 0 : parentProdOptName.hashCode());
		result = prime * result + ((pricingDetails == null) ? 0 : pricingDetails.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderProductDetails other = (OrderProductDetails) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (parentProdOptId == null) {
			if (other.parentProdOptId != null)
				return false;
		} else if (!parentProdOptId.equals(other.parentProdOptId))
			return false;
		if (parentProdOptName == null) {
			if (other.parentProdOptName != null)
				return false;
		} else if (!parentProdOptName.equals(other.parentProdOptName))
			return false;
		if (pricingDetails == null) {
			if (other.pricingDetails != null)
				return false;
		} else if (!pricingDetails.equals(other.pricingDetails))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}
