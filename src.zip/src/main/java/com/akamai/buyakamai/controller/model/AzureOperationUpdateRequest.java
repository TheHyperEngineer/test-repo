package com.akamai.buyakamai.controller.model;

public class AzureOperationUpdateRequest {

	private String planId;
	private String status;

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AzureOperationUpdateRequest [planId=" + planId + ", status=" + status + "]";
	}

}
