package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountLookupRequest {

    private String accountName;
    private String accountId;

    @Valid
    @NotNull(message = "Search filter cannot be empty")
    private SearchFilter filter;

    public SearchFilter getFilter() {
        return filter;
    }

    public void setFilter(SearchFilter filter) {
        this.filter = filter;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccountLookupRequest request = (AccountLookupRequest) o;

        if (accountName != null ? !accountName.equals(request.accountName) : request.accountName != null) return false;
        if (accountId != null ? !accountId.equals(request.accountId) : request.accountId != null) return false;
        return filter != null ? filter.equals(request.filter) : request.filter == null;
    }

    @Override
    public int hashCode() {
        int result = accountName != null ? accountName.hashCode() : 0;
        result = 31 * result + (accountId != null ? accountId.hashCode() : 0);
        result = 31 * result + (filter != null ? filter.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AccountLookupRequest{" +
                "accountName='" + accountName + '\'' +
                ", accountId='" + accountId + '\'' +
                ", filter=" + filter +
                '}';
    }
}
