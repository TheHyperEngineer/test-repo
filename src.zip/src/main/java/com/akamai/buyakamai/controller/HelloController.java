package com.akamai.buyakamai.controller;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.text.ParseException;
import java.util.Enumeration;

@RestController
public class HelloController {
    
    @GetMapping(value = "v1/hello", produces = { MediaType.TEXT_HTML_VALUE })
    public String sayHtmlHello(HttpServletRequest httpRequest) throws ParseException {        
        Enumeration<String> headerNames = httpRequest.getHeaderNames();
        int i = 0;
        while(headerNames.hasMoreElements()){
            String headerName = headerNames.nextElement();
            String headerVal = httpRequest.getHeader(headerName);
            System.out.println(i + ":> Header Name = " + headerName + "  ::  Header Value = " + headerVal);            
            i++;
        }
        return "<html><title>Hello World</title>"
                + "<body><h1>"
                + "Hello World, I am buy-akamai-api. <br>I have arrived "
                + "to change the way you try/buy from Akamai."
                + "</h1></body></html> ";
    }
}