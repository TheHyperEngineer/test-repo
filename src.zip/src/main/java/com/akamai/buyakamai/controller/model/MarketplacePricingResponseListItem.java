package com.akamai.buyakamai.controller.model;

import java.util.List;

public class MarketplacePricingResponseListItem {
	private String pricingStrategy;
	private String currency;
	private List<PricingListItem> listItem;
	private String pricingBlurb;
	public String getPricingStrategy() {
		return pricingStrategy;
	}
	public void setPricingStrategy(String pricingStrategy) {
		this.pricingStrategy = pricingStrategy;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public List<PricingListItem> getListItem() {
		return listItem;
	}
	public void setListItem(List<PricingListItem> listItem) {
		this.listItem = listItem;
	}
	public String getPricingBlurb() {
		return pricingBlurb;
	}
	public void setPricingBlurb(String pricingBlurb) {
		this.pricingBlurb = pricingBlurb;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + ((listItem == null) ? 0 : listItem.hashCode());
		result = prime * result + ((pricingBlurb == null) ? 0 : pricingBlurb.hashCode());
		result = prime * result + ((pricingStrategy == null) ? 0 : pricingStrategy.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MarketplacePricingResponseListItem other = (MarketplacePricingResponseListItem) obj;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (listItem == null) {
			if (other.listItem != null)
				return false;
		} else if (!listItem.equals(other.listItem))
			return false;
		if (pricingBlurb == null) {
			if (other.pricingBlurb != null)
				return false;
		} else if (!pricingBlurb.equals(other.pricingBlurb))
			return false;
		if (pricingStrategy == null) {
			if (other.pricingStrategy != null)
				return false;
		} else if (!pricingStrategy.equals(other.pricingStrategy))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "MarketplacePricingResponseListItem [pricingStrategy=" + pricingStrategy + ", currency=" + currency
				+ ", listItem=" + listItem + ", pricingBlurb=" + pricingBlurb + "]";
	}
	
}
