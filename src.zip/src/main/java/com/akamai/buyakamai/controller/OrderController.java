package com.akamai.buyakamai.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.core.Context;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.constants.EventDataPoint;
import com.akamai.buyakamai.constants.OrderSourceType;
import com.akamai.buyakamai.constants.UserEventAction;
import com.akamai.buyakamai.controller.model.Alert;
import com.akamai.buyakamai.controller.model.BAExtensionRequest;
import com.akamai.buyakamai.controller.model.ExtensionCreationResponse;
import com.akamai.buyakamai.controller.model.HappinessIndexResponse;
import com.akamai.buyakamai.controller.model.OKResponse;
import com.akamai.buyakamai.controller.model.OrderAlertsDto;
import com.akamai.buyakamai.controller.model.OrderCreationRequest;
import com.akamai.buyakamai.controller.model.OrderCreationResponse;
import com.akamai.buyakamai.controller.model.OrderHistory;
import com.akamai.buyakamai.controller.model.OrderMetaData;
import com.akamai.buyakamai.controller.model.OrderResponse;
import com.akamai.buyakamai.controller.model.OrderStatusResponse;
import com.akamai.buyakamai.controller.model.QuoteCreationRequest;
import com.akamai.buyakamai.controller.model.RevenueResponse;
import com.akamai.buyakamai.controller.model.SelectOrderRequest;
import com.akamai.buyakamai.controller.model.SelectOrderResponse;
import com.akamai.buyakamai.controller.model.TrafficDetails;
import com.akamai.buyakamai.controller.validator.QuoteCreationValidator;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.BAContactDto;
import com.akamai.buyakamai.model.oms.BuyOrderRequestDto;
import com.akamai.buyakamai.model.oms.CreatedResourceResponse;
import com.akamai.buyakamai.model.oms.OMSOrder;
import com.akamai.buyakamai.model.oms.OrderVersionHistoryResponse;
import com.akamai.buyakamai.model.oms.OrderVersionResponse;
import com.akamai.buyakamai.service.events.EventInfo;
import com.akamai.buyakamai.service.events.EventProcessor;
import com.akamai.buyakamai.service.impl.AuthorizationServiceImpl;
import com.akamai.buyakamai.service.impl.BuyOrderServiceImpl;
import com.akamai.buyakamai.service.impl.HappinessIndexCalculatorServiceImpl;
import com.akamai.buyakamai.service.impl.MarketplaceAPIServiceImpl;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import com.akamai.buyakamai.util.PulsarUrlBuilder;
import com.akamai.buyakamai.util.RequestFetcher;

@RestController
@EnableAutoConfiguration
public class OrderController {

	private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

	@Autowired
	private OrderServiceImpl orderService;

	@Autowired
	private RequestFetcher requestFetcher;

	@Autowired
	private HappinessIndexCalculatorServiceImpl happinessIndexCalculatorService;

	@Autowired
	private QuoteCreationValidator quoteCreationValidator;

	@Autowired
	private EventProcessor eventProcessor;
	
	@Autowired
	private MarketplaceAPIServiceImpl marketplaceService;

	@Autowired
	private AuthorizationServiceImpl authorizationService;
	
	@Autowired
	private BuyOrderServiceImpl buyOrderServiceImpl;

	private static final String NO_RECORD_FOUND = "Contacts are not available in request";

	@RequestMapping(value = BAConstants.V1_ORDERS_ORDER_ID_API, method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<OrderResponse> getOrderDetails(@Valid @PathVariable Integer orderId,
			@Context HttpServletRequest httpRequest) {

		logger.info("Entering getOrderDetails for order ID {} ", orderId);
		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		OrderResponse response = orderService.fetchOrder(orderId, userName);
		if (response != null && response.getPartnerInfo() != null) {
			throw new BuyAkamaiApplicationException("Not intend endPoint", "Not intend endPoint",
					HttpStatus.BAD_REQUEST);
		}
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		if (orderService.checkIfOrderIsBuyEnabled(response, userName, roles)) {
			response.setBuyEnabled(true);
		}
		logger.info("Exiting getOrderDetails for order ID {} successfully", orderId);
		logger.debug("Exiting getOrderDetails with order Response {} ", response);

		raiseEventForViewTrialDetails(orderId, userName);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

    private void raiseEventForViewTrialDetails(Integer orderId, String userName) {
        EventInfo eventInfo = new EventInfo(userName, UserEventAction.TRIAL_DETAILS_SUCCESS);
        Map<String, String> additionalInfo = new HashMap<>();
        additionalInfo.put(EventDataPoint.ORDER_ID.name(), orderId.toString());
        eventInfo.setAdditionalInfo(additionalInfo);
        eventProcessor.initiateEventProcessorThread(eventInfo);
    }


	@RequestMapping(value = "/v1/orders", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<SelectOrderResponse>> getOrdersForUser(@RequestParam(name = "orderType", required = true) String orderType,
			@RequestParam(name = "orderStatus", required = true) String orderStatus,
			@Context HttpServletRequest httpRequest) {
		logger.info("Get orders for user. orderType:{}, orderStatus:{}", orderType, orderStatus);

		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		logger.info("Getting role list for user name: {}", userName);


		List<SelectOrderResponse> response = orderService.getOrdersOfLoggedInUser(orderType, orderStatus, userName, roles);

		logger.info("Exiting Get orders for user. orderType:{}, orderStatus:{} successfully",orderType,orderStatus);
		logger.debug("Response for order query: {}", response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}


	@RequestMapping(value = "/v1/orders/select", method = RequestMethod.POST, produces = "application/json")
	public ResponseEntity<List<SelectOrderResponse>> getOrdersForAccount(@RequestBody SelectOrderRequest orderRequest,
																	  @Context HttpServletRequest httpRequest) {
		logger.info("Get orders for user. orderRequest", orderRequest);

		List<SelectOrderResponse> response = orderService.getOrdersForRequest(orderRequest);

		logger.debug("Response for order query: {}", response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}



	@RequestMapping(value = "/v1/orders/{orderId}/happiness", method = RequestMethod.GET)
	public ResponseEntity<HappinessIndexResponse> getHappinessIndexForOrderId(@Valid @PathVariable Integer orderId) {

		logger.info("Getting Happiness for orderId: {}", orderId);

		HappinessIndexResponse response = happinessIndexCalculatorService.getHappinessIndex(orderId);

		logger.info("Fetched happiness successfully, current happiness response is {}", response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/orders/{orderId}/alerts", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<Alert>> getAlertsForOrderId(@Valid @PathVariable Integer orderId, @Context HttpServletRequest
														   httpRequest) {

		logger.info("Getting alerts for orderId: {}", orderId);

		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		List<String> roles = requestFetcher.getLoggedInUserRoles();

		logger.info("Getting role list for user name: {}", userName);

		List<Alert> response = orderService.getAlertsForOrder(orderId, roles);

		logger.debug("Fetched alerts successfully, response is {}", response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/alerts/{alertId}", method = RequestMethod.PUT, consumes = "application/json")
	public ResponseEntity<OKResponse> updateAlert(@Valid @PathVariable Integer alertId,
												   @RequestBody Alert alert,  @Context HttpServletRequest httpRequest) {

		logger.info("Updating alert with id: {}", alertId);

		orderService.updateAlert(alertId, alert);

		logger.debug("Updated alert with id: {}", alertId);

		raiseEventForAlertAction(alertId, alert, httpRequest);

		return new ResponseEntity<>(new OKResponse(), HttpStatus.OK);
	}

	private void raiseEventForAlertAction(Integer alertId, Alert alert, HttpServletRequest httpRequest) {
		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		EventInfo eventInfo = new EventInfo(userName, UserEventAction.ACTION_ON_ALERTS_SUCCESS);
		Map<String, String> additionalInfo = new HashMap<>();
		additionalInfo.put(EventDataPoint.ALERT_ID.name(), alertId.toString());
		additionalInfo.put(EventDataPoint.ALERT_ACTION_TYPE.name(), alert.getState());
		eventInfo.setAdditionalInfo(additionalInfo);
		eventProcessor.initiateEventProcessorThread(eventInfo);
	}

	@RequestMapping(value = "/v1/orders/{orderId}/history", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<OrderHistory>> getOrderHistory(@Valid @PathVariable Integer orderId) {

		logger.info("Getting history for orderId: {}", orderId);

		List<OrderHistory> response = orderService.getHistoryEventsForOrder(orderId);

		logger.debug("Fetched history successfully, response is {}", response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "v1/alerts", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<List<OrderAlertsDto>> getAlerts(@RequestParam(name = "state", required = false) String state) {

		if (state != null && state.equals(""))
			throw new BuyAkamaiApplicationException("state can't be empty", "Bad Input", HttpStatus.BAD_REQUEST);

		logger.info("Getting alerts for all orders with state {}", state);

		List<OrderAlertsDto> response = orderService.getAlerts(state);

		logger.info("Fetched all alerts successfully");

		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/orders", method = RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<OrderStatusResponse> createQuote(@RequestBody QuoteCreationRequest userRequest) throws Exception{

		logger.info("Entering createQuote for Request {} ",userRequest);

		String locale = requestFetcher.getUserLocale();
		String userName = requestFetcher.getUserName();
		logger.info("Getting user info for user name: {}", userName);

		List<String> roles = authorizationService.getRolesForUser(userName, false, false);

		userRequest.setCreatedByUserId(userName);

		quoteCreationValidator.isValidQuoteCreationRequest(userRequest, roles);

		//if validation is passed , persist in ORDER and ORDER_CONTACT table by Calling Marktplace
		OrderStatusResponse response  = orderService.createQuote(userRequest, locale);

		String statusUrl =  BAConstants.V1_ORDERS_ORDER_ID_API;
		statusUrl = statusUrl.replace("{orderId}", response.getOrderId());
		String location = PulsarUrlBuilder.path(statusUrl).toUriString();

		HttpHeaders headers = new HttpHeaders();
		headers.add("Location", location);
		raiseEventForCreateQuote(userName, response.getOrderId(), userRequest);
		logger.info("Exiting createQuote with response {} for request {} ",response,userRequest);
		return new ResponseEntity<>(response, headers, HttpStatus.CREATED);
	}

	private void raiseEventForCreateQuote(String userName, String orderId, QuoteCreationRequest userRequest) {
		EventInfo eventInfo = null;
		Map<String, String> additionalInfo = new HashMap<>();
		additionalInfo.put(EventDataPoint.ORDER_ID.name(), orderId);
		additionalInfo.put(EventDataPoint.TRIAL_DURATION.name(), userRequest.getTrialDuration());

		OrderSourceType orderSourceEventDataPoints = OrderSourceType.valueOf(userRequest.getSourceType().toUpperCase());
		additionalInfo.put(orderSourceEventDataPoints.getEventDataPoint().name(), userRequest.getSourceId());
		eventInfo = new EventInfo(userName, orderSourceEventDataPoints.getUserSuccessEventAction());
		eventInfo.setAdditionalInfo(additionalInfo);
		eventProcessor.initiateEventProcessorThread(eventInfo);
	}

	@RequestMapping(value = "/v1/orders/{orderId}/traffic-data", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<TrafficDetails> getTrafficDetailsForOrder(@Valid @PathVariable Integer orderId) {

		logger.info("Getting traffic details for orderId: {}", orderId);

		TrafficDetails response = orderService.getTrafficDetailsForOrder(orderId, true);

		logger.debug("Fetched traffic details successfully, response is {}", response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/orders/{orderId}/contacts", method = RequestMethod.PUT)
	public ResponseEntity resendCredentials(@PathVariable Integer orderId, @RequestBody Set<String> contacts) {

		logger.info("Entering to update Contacts : resendCredentials {} {} ", orderId, contacts);

		if (null == contacts || contacts.isEmpty()) {
			logger.error(" Resend credentials failed for Order ID {} {} ", orderId, NO_RECORD_FOUND);
			throw new BuyAkamaiApplicationException("Invalid resend credential request",
			        NO_RECORD_FOUND + " Order ID " + orderId, HttpStatus.BAD_REQUEST);
		}
		marketplaceService.resendCredentials(orderId, contacts);

		logger.info("Resend Credential Service call returned for successfully {}", contacts);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/orders/{orderId}/contacts", method = RequestMethod.GET)
	public ResponseEntity<List<BAContactDto>> getContacts(@PathVariable Integer orderId){
		logger.info("Entering get Contacts for order ID  {} ",orderId);
		List<BAContactDto> contacts = marketplaceService.getContacts(orderId);
		
		logger.info("Exiting get Contacts for order ID  {} ",orderId,contacts);
		return new ResponseEntity<>(contacts, HttpStatus.OK);
	
	}

	@RequestMapping(value = "/v1/orders/{orderId}/extend", method = RequestMethod.POST)
	public ResponseEntity<ExtensionCreationResponse> extendTrial(@PathVariable Integer orderId,
	        @RequestBody BAExtensionRequest extensionRequest, @Context HttpServletRequest httpRequest) {
		logger.info("Entering extension for order ID:  {}  request: ", orderId, extensionRequest);
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		ExtensionCreationResponse response = marketplaceService.extendTrial(orderId, extensionRequest, roles);
		logger.info("extension request sent successfully");
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "v2/orders", method = RequestMethod.POST)
	public ResponseEntity createQuote(@RequestBody OrderCreationRequest orderCreationRequest) {
		OrderCreationResponse response = orderService.createCustomerQuote(orderCreationRequest, requestFetcher.getUserName());
		return new ResponseEntity(response, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/v1/orders/active-order", method = RequestMethod.GET)
	public ResponseEntity getActiveOrderAssociated(@RequestParam("orderId") Integer orderId) {
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		String accountId = requestFetcher.getDefaultAccountId();
		OrderResponse response = orderService.getAssociatedActiveOrder(roles, accountId, orderId);
		return new ResponseEntity(response, HttpStatus.OK);
	}
	
	@RequestMapping(value="/v4/orders/{orderId}/versions/{versionId}",method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	public ResponseEntity<OrderVersionResponse> getOrderVersionDetails(@Valid @PathVariable Integer orderId,
	        @Valid @PathVariable Integer versionId) {
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		OrderVersionResponse response = buyOrderServiceImpl.getOrderVersionDetails(orderId,versionId,requestFetcher.getUserName(),roles);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value="/v4/orders/{orderId}/versions/latest",method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	public ResponseEntity<OrderVersionResponse> getLatestOrderVersionDetails(@Valid @PathVariable Integer orderId) {
		List<String> roles =requestFetcher.getLoggedInUserRoles();
		OrderVersionResponse response = buyOrderServiceImpl.getOrderVersionDetails(orderId,requestFetcher.getUserName(),roles);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	
	@RequestMapping(value="/v4/orders/{orderId}/version-history",method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	public ResponseEntity<OrderVersionHistoryResponse> getOrderVersionHistory(@Valid @PathVariable Integer orderId) {
		OrderVersionHistoryResponse response = buyOrderServiceImpl.getOrderVersionHistory(orderId,requestFetcher.getUserName());
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value="/v4/orders",method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public ResponseEntity createBuyQuote(@RequestBody BuyOrderRequestDto buyOrderRequestDto) {
		restrictAccessForImpersonation();
		CreatedResourceResponse createdResourceResponse = buyOrderServiceImpl.createNewOrder(buyOrderRequestDto, requestFetcher.getContactId(),requestFetcher.getUserName(),
				requestFetcher.getLoggedInUserRoles());
		return new ResponseEntity<>(createdResourceResponse, HttpStatus.CREATED);
	}


	@PostMapping(value = "/v4/orders/{orderId}/versions",produces = "application/json;charset=UTF-8")
	public ResponseEntity<CreatedResourceResponse> createOrderVersion(@RequestBody BuyOrderRequestDto buyOrderRequestDto, @PathVariable("orderId") Integer orderId) {
		restrictAccessForImpersonation();
		CreatedResourceResponse createdResourceResponse = buyOrderServiceImpl.createOrderVersion(buyOrderRequestDto, orderId,
				requestFetcher.getContactId(),requestFetcher.getUserName(), requestFetcher.getLoggedInUserRoles());
		return new ResponseEntity<>(createdResourceResponse, HttpStatus.CREATED);
	}

	@GetMapping(value = "/v4/order-metadata")
	public ResponseEntity<OrderMetaData> getBuyOrderMetadata() {
		OrderMetaData orderMetaData = buyOrderServiceImpl.getOrderMetaData();
		return new ResponseEntity<>(orderMetaData, HttpStatus.OK);
	}

	@GetMapping(value = "/v4/orders")
	public ResponseEntity<List<OMSOrder>> getOrderForOrderId(@RequestParam("opportunityId")String opportunityId,
											 @RequestParam("attributes")List<String> attributes){

		List<OMSOrder> omsOrder = buyOrderServiceImpl.getOrderDetails(opportunityId, attributes);
		return new ResponseEntity<>(omsOrder, HttpStatus.OK);
	}

	@PutMapping(value = "/v4/orders/{orderId}/versions/{versionId}",produces = "application/json;charset=UTF-8")
	public ResponseEntity<CreatedResourceResponse> updateVersionEntity(@PathVariable Integer orderId, @PathVariable Integer versionId,
																	   @RequestBody BuyOrderRequestDto buyOrderRequestDto) {
		restrictAccessForImpersonation();
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		buyOrderServiceImpl.updateVersion(orderId, versionId, buyOrderRequestDto, roles, requestFetcher.getContactId());
		return new ResponseEntity(HttpStatus.OK);
	}

	@PostMapping(value = "v4/orders/revenue")
	public ResponseEntity<RevenueResponse> getRevenue(@RequestBody BuyOrderRequestDto buyOrderRequestDto){
		RevenueResponse revenueResponse = buyOrderServiceImpl.getRevenue(buyOrderRequestDto);
		return new ResponseEntity<>(revenueResponse, HttpStatus.OK);
	}

	private void restrictAccessForImpersonation() {
		if(!StringUtils.isEmpty(requestFetcher.getCurrentImpersonator())) {
			String msg = "Restricting the api access for impersonated user.";
			logger.info(msg);
			BuyAkamaiApplicationException exc = new BuyAkamaiApplicationException(msg,msg,HttpStatus.FORBIDDEN);
			exc.setErrorKey(ErrorConstants.OMS_RESTRICTION_ON_IMPERSONATION);
			throw exc;
		}
	}

	@PostMapping(value = "v1/orders/{orderId}/extension-approval")
	public ResponseEntity sendExtensionApprovalEmail(@Valid @PathVariable("orderId") Integer orderId) {
		logger.info("Entering extension approval for order ID: {}", orderId);
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		orderService.sendExtensionApprovalEmail(orderId, roles);
		logger.info("extension approval request sent successfully");
		return new ResponseEntity(HttpStatus.OK);
	}

}
