package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.enums.BuyOrderRoles;
import com.akamai.buyakamai.controller.model.AccountOpportunityOrderDTO;
import com.akamai.buyakamai.controller.model.OrderInformationDTO;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.BuyOpportunityServiceImpl;
import com.akamai.buyakamai.util.RequestFetcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;
import java.util.List;

@RestController
public class BuyOpportunityController {
	private static final Logger logger = LoggerFactory.getLogger(BuyOpportunityController.class);
	@Autowired
	private RequestFetcher requestFetcher;
	@Autowired
	private BuyOpportunityServiceImpl buyOpportunityServiceImpl;

	@RequestMapping(value = "v4/buy-oppportunities", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	public ResponseEntity<List<AccountOpportunityOrderDTO>> getBuyOpportunityInfo() {
		String userName = requestFetcher.getUserName();
		throwExceptionAfterRoleCheck();
		logger.info("v4/buy-oppportunities called for logged in user {} ", userName);
		List<AccountOpportunityOrderDTO> buyOpportunityInfo = buyOpportunityServiceImpl.getBuyOpportunityInfo(userName);
		return new ResponseEntity<>(buyOpportunityInfo, HttpStatus.OK);
	}

	@RequestMapping(value = "v4/buy-oppportunities/{opportunityId}/orders", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	public ResponseEntity<AccountOpportunityOrderDTO> getQuotesInformation(@Valid @PathVariable String opportunityId) {
		String userName = requestFetcher.getUserName();
		throwExceptionAfterRoleCheck();
		logger.info("v4/buy-oppportunities/{opportunityId}/orders called for logged in user {} ", userName);
		AccountOpportunityOrderDTO accountOpportunityOrderDTO = buyOpportunityServiceImpl.getQuotes(userName, opportunityId);
		return new ResponseEntity<>(accountOpportunityOrderDTO, HttpStatus.OK);
	}

	private void throwExceptionAfterRoleCheck() {
		List<String> roles = requestFetcher.getLoggedInUserRoles();
		if (!roles.contains(BuyOrderRoles.SALES_REP_PURCHASE.name())) {
			String title = "no access to buy opportunities";
			throw new BuyAkamaiApplicationException(title, title, HttpStatus.FORBIDDEN);
		}
	}
}
