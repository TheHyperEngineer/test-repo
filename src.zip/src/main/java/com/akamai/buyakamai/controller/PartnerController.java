package com.akamai.buyakamai.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.Context;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.enums.DealType;
import com.akamai.buyakamai.constants.enums.RequestorType;
import com.akamai.buyakamai.controller.model.Alert;
import com.akamai.buyakamai.controller.model.BAExtensionRequest;
import com.akamai.buyakamai.controller.model.HappinessIndexResponse;
import com.akamai.buyakamai.controller.model.MarketplaceExtensionRequest;
import com.akamai.buyakamai.controller.model.OpportunityResponse;
import com.akamai.buyakamai.controller.model.OrderAlertsDto;
import com.akamai.buyakamai.controller.model.OrderCreationRequest;
import com.akamai.buyakamai.controller.model.OrderCreationResponse;
import com.akamai.buyakamai.controller.model.OrderHistory;
import com.akamai.buyakamai.controller.model.OrderResponse;
import com.akamai.buyakamai.controller.model.OrderStatusResponse;
import com.akamai.buyakamai.controller.model.OrderUpdateRequest;
import com.akamai.buyakamai.controller.model.OrderUpdateRequestV2;
import com.akamai.buyakamai.controller.model.QuoteCreationRequest;
import com.akamai.buyakamai.controller.model.RecommendedProductResponse;
import com.akamai.buyakamai.controller.model.TrafficDetails;
import com.akamai.buyakamai.controller.model.partner.BasicPartnerAccountDto;
import com.akamai.buyakamai.controller.model.partner.ContractsResponse;
import com.akamai.buyakamai.controller.model.partner.OrderMember;
import com.akamai.buyakamai.controller.model.partner.PartnerSelectOrderResponse;
import com.akamai.buyakamai.controller.model.partner.PartnerTeamMember;
import com.akamai.buyakamai.controller.validator.QuoteCreationValidator;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.AccountDto;
import com.akamai.buyakamai.integration.clients.model.AccountOpportunityDto;
import com.akamai.buyakamai.service.impl.AccountServiceImpl;
import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.akamai.buyakamai.service.impl.HappinessIndexCalculatorServiceImpl;
import com.akamai.buyakamai.service.impl.MarketplaceAPIServiceImpl;
import com.akamai.buyakamai.service.impl.OrderServiceImpl;
import com.akamai.buyakamai.service.impl.OrderSourceServiceImpl;
import com.akamai.buyakamai.service.impl.PartnerOrderServiceImpl;
import com.akamai.buyakamai.service.impl.PartnerService;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.RequestFetcher;
import com.akamai.ids.commons.model.request.IdsRequest;
import com.akamai.se.manager.identity.IdentityServiceFactory;
import com.akamai.se.manager.identity.IdentityServiceResourceClient;
import com.akamai.se.manager.identity.service.impl.IdentityServiceFactoryImpl;

@RestController
@EnableAutoConfiguration
public class PartnerController {

    @Autowired
    private PartnerOrderServiceImpl partnerOrderService;

    @Autowired
    private OrderServiceImpl orderService;

    @Autowired
    private HappinessIndexCalculatorServiceImpl happinessIndexCalculatorService;

    @Autowired
    private RequestFetcher requestFetcher;

    @Autowired
    private MarketplaceAPIServiceImpl marketplaceAPIService;

    @Autowired
    private AccountServiceImpl accountService;

    @Autowired
    private PartnerService partnerService;
    
    @Autowired
    private QuoteCreationValidator quoteCreationValidator;

    @Autowired
    private OrderSourceServiceImpl orderSourceService;

    @Autowired
    private BACoreAPIServiceImpl baCoreAPIService;

    @Autowired
    private MarketplaceAPIServiceImpl marketplaceService;

    private static final Logger logger = LoggerFactory.getLogger(PartnerController.class);

    @RequestMapping(value = "/v1/partner-orders", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<PartnerSelectOrderResponse>> getOrdersForUser(@RequestParam(name = "orderType", required = true) String orderType,
                                                                             @RequestParam(name = "orderStatus", required = true) String orderStatus,
                                                                             @Context HttpServletRequest httpRequest) {
        logger.info("Get orders for user. orderType:{}, orderStatus:{}", orderType, orderStatus);

        String userName = httpRequest.getHeader(BAConstants.USER_NAME);

        logger.info("Partner getting orders userName: {}", userName);


        List<PartnerSelectOrderResponse> response = partnerOrderService.getPartnerOrders(orderType, orderStatus, userName);

        logger.info("Exiting Get orders for user. orderType:{}, orderStatus:{} successfully", orderType, orderStatus);
        logger.debug("Response for order query: {}", response);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @RequestMapping(value = "/v1/partner-alerts", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<OrderAlertsDto>> getAlerts(@RequestParam(name = "state", required = false) String state,
                                                          @Context HttpServletRequest httpRequest) {

        if (state != null && state.equals(""))
            throw new BuyAkamaiApplicationException("state can't be empty", "Bad Input", HttpStatus.BAD_REQUEST);


        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        logger.info("Partner getting alerts userName: {}", userName);

        List<String> roles = requestFetcher.getLoggedInUserRoles();

        List<OrderAlertsDto> response = partnerOrderService.getAlerts(state, userName, roles);

        logger.info("Fetched all alerts successfully");

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/partner-orders/{orderId}/extend", method = RequestMethod.POST)
    public ResponseEntity extendPartnerOrder(@PathVariable Integer orderId, @RequestBody BAExtensionRequest extensionRequest,
                                             @Context HttpServletRequest httpRequest) {

        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);
        List<String> roles = requestFetcher.getLoggedInUserRoles();
        String userName = requestFetcher.getUserName();
        marketplaceAPIService.extendPartnerTrial(orderId, extensionRequest, roles, userName);
        logger.info("extension request sent successfully");
        return new ResponseEntity<>(HttpStatus.ACCEPTED);

    }
    
    @RequestMapping(value = "v1/partner-orders/{orderId}/extend", method = RequestMethod.PUT)
    public ResponseEntity acceptPartnerExtensionOrder(@PathVariable Integer orderId, @RequestBody MarketplaceExtensionRequest extensionRequest, @Context HttpServletRequest httpRequest) {
        if(extensionRequest.getTncAccepted() == null || !extensionRequest.getTncAccepted()) {
     	   String msg = "Request input is not valid. tncAccepted : "+extensionRequest.getTncAccepted();
     	   logger.info(msg);
     	   throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
        }
        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);
        List<String> roles = requestFetcher.getLoggedInUserRoles();
        String userName = requestFetcher.getUserName();
        extensionRequest.setCreatedByUserName(userName);
        marketplaceAPIService.acceptPartnerExtensionOrder(orderId, extensionRequest, roles);
        logger.info("Trial extended successfully");
        return new ResponseEntity<>(HttpStatus.ACCEPTED);

    }

    @RequestMapping(value = "/v1/partner-orders/{orderId}/traffic-data", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<TrafficDetails> getPartnerTrafficDetails(@Valid @PathVariable Integer orderId,
                                                                   @Context HttpServletRequest httpRequest) {

        logger.info("Getting traffic details for orderId: {}", orderId);

        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);
        TrafficDetails response = orderService.getTrafficDetailsForOrder(orderId, true);

        logger.debug("Fetched traffic details successfully, response is {}", response);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @RequestMapping(value = "/v1/partner-orders/{orderId}/alerts", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<Alert>> getAlertsForOrderId(@Valid @PathVariable Integer orderId, @Context HttpServletRequest
            httpRequest) {

        logger.info("Getting alerts for partner orderId: {}", orderId);

        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        List<String> roles = requestFetcher.getLoggedInUserRoles();

        List<Alert> response = orderService.getAlertsForOrder(orderId, roles);

        logger.debug("Fetched alerts successfully for partner, response is {}", response);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @RequestMapping(value = "/v1/partner-orders/{orderId}/history", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<OrderHistory>> getPartnerOrderHistory(@Valid @PathVariable Integer orderId,
                                                                     @Context HttpServletRequest httpRequest) {

        logger.info("Getting history for partner orderId: {}", orderId);
        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        List<OrderHistory> response = orderService.getHistoryEventsForOrder(orderId);

        logger.debug("Fetched history successfully for partner, response is {}", response);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @RequestMapping(value = "/v1/partner-orders/{orderId}/happiness", method = RequestMethod.GET)
    public ResponseEntity<HappinessIndexResponse> getHappinessIndexForOrderId(@Valid @PathVariable Integer orderId,
                                                                              @Context HttpServletRequest httpRequest) {

        logger.info("Getting Happiness for partner orderId: {}", orderId);
        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        HappinessIndexResponse response = happinessIndexCalculatorService.getHappinessIndex(orderId);

        logger.info("Fetched happiness successfully for partner, current happiness response is {}", response);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/v1/partner-orders", method = RequestMethod.POST)
	public ResponseEntity<OrderStatusResponse> createQuoteAndStartOrder(@RequestBody QuoteCreationRequest userRequest,
                                                                        @Context HttpServletRequest httpRequest) throws Exception{
    	logger.info("Entering createQuote for Request {} ",userRequest);
		String locale = requestFetcher.getUserLocale();
		String userName = requestFetcher.getUserName();
		logger.info("Getting user info for user name: {}", userName);

		List<String> roles = requestFetcher.getLoggedInUserRoles();
		String requestorType = getCurrentRequestorType(requestFetcher.getLoggedInUserRoles());
		userRequest.setCreatedByUserId(userName);
		userRequest.setRequestorType(requestorType);
		quoteCreationValidator.isValidQuoteCreationRequest(userRequest, roles);

		OrderStatusResponse response  = orderService.createQuoteAndStartOrder(userRequest, locale);

        HttpHeaders headers = getStatusAPIHeader(requestorType, response.getOrderId());
        logger.info("Exiting createQuote with response {} for request {} ",response,userRequest);
		return new ResponseEntity<>(response, headers, HttpStatus.CREATED);
    }

    private String getCurrentRequestorType(List<String> roles) {
        boolean isPartnerUser = partnerService.isPartnerUser(roles);
        if (isPartnerUser) {
            return RequestorType.PARTNER.name();
        }
        if (roles.contains(BAConstants.PAE_ROLE)) {
            return RequestorType.PAE.name();
        }
        if (roles.contains(BAConstants.INTEGRATED_OPS_ROLE)) {
            return RequestorType.INT_OPS.name();
        }
        return null;
    }
    
	@RequestMapping(value = "/v2/partner-orders", method = RequestMethod.POST)
	public ResponseEntity<OrderCreationResponse> createCustomerQuoteAndStartOrder(
	        @RequestBody OrderCreationRequest userRequest) throws Exception {
		logger.info("Entering createCustomerQuoteAndStartOrder for Request {} ", userRequest);
		String userName = requestFetcher.getUserName();
		logger.info("Getting user info for user name: {}", userName);

		String requestorType = getCurrentRequestorType(requestFetcher.getLoggedInUserRoles());
		userRequest.setRequestorType(requestorType);

		OrderCreationResponse response = orderService.createCustomerQuoteAndStartOrder(userRequest, userName);

        HttpHeaders headers = getStatusAPIHeader(requestorType, response.getOrderId().toString());
        logger.info("Exiting createCustomerQuoteAndStartOrder with response {} for request {} ", response, userRequest);
		return new ResponseEntity<>(response, headers, HttpStatus.CREATED);
	}

    private HttpHeaders getStatusAPIHeader(String requestorType, String orderId) {
        HttpHeaders headers = new HttpHeaders();

        if (RequestorType.PARTNER.name().equalsIgnoreCase(requestorType)) {
            String statusUrl = BAConstants.V1_PARTNER_ORDER_STATUS_API;
            String location = statusUrl.replace("{orderId}", orderId);
            headers.add("Location", location);
        }
        return headers;
    }


    @RequestMapping(value = "/v1/partner-orders/{orderId}", method = RequestMethod.PUT)
    public ResponseEntity acceptQuoteByPartners(@PathVariable Integer orderId,
                                                @RequestBody OrderUpdateRequest updateRequest,
                                                @Context HttpServletRequest httpRequest) throws Exception {
        logger.info("Entering quote acceptance by partner flow for prospect");

        //verify if logged in user is authorized to accept terms for this order Id
        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        updateRequest.setAcceptedByContactId(requestFetcher.getContactId());
        orderService.acceptTNCForPartnerProspect(updateRequest, orderId, requestFetcher.getUserName());


        HttpHeaders statusAPIHeader = getStatusAPIHeader(getCurrentRequestorType(requestFetcher.getLoggedInUserRoles()), orderId.toString());
        return new ResponseEntity<>(statusAPIHeader,HttpStatus.ACCEPTED);
    }

    @RequestMapping(value = "/v2/partner-orders/{orderId}", method = RequestMethod.PUT)
    public ResponseEntity acceptOrderByPartners(@PathVariable Integer orderId,
                                                @RequestBody OrderUpdateRequestV2 updateRequest,
                                                @Context HttpServletRequest httpRequest) throws Exception {
        logger.info("Entering quote acceptance by partner flow for existing customer");

        //verify if logged in user is authorized to accept terms for this order Id
        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        updateRequest.setAcceptedByContactId(requestFetcher.getContactId());
        orderService.acceptTNCForPartnerCustomer(updateRequest, orderId, requestFetcher.getUserName());

        HttpHeaders statusAPIHeader = getStatusAPIHeader(getCurrentRequestorType(requestFetcher.getLoggedInUserRoles()), orderId.toString());
        return new ResponseEntity<>(statusAPIHeader,HttpStatus.ACCEPTED);
    }

    @RequestMapping(value = "/v1/partner-orders/{orderId}", method = RequestMethod.GET ,produces = "application/json")
    public ResponseEntity<OrderResponse> getPartnerOrderDetails(@Valid @PathVariable Integer orderId,
                                                                @Context HttpServletRequest httpRequest) {

        logger.info("Entering partner getOrderDetails for order ID {} ", orderId);
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        StopWatch stopWatch = new StopWatch("Get order detail API");

        stopWatch.start("marketplace api fetch");
        OrderResponse response = orderService.fetchOrder(orderId, userName);
        stopWatch.stop();

        stopWatch.start("authorization check");
        validateIfResponseIsAuthorizedForLoggedInPartner(response.getPartnerInfo().getPartnerAccount().getAccountId(), httpRequest);
        stopWatch.stop();

        logger.info("Order By Id {}: Performance : {}", orderId, stopWatch.prettyPrint());
        logger.info("Exiting  partner getOrderDetails for order ID {} successfully", orderId);
        logger.debug("Exiting partner getOrderDetails with order Response {} ", response);

        //TODO: raise partner order view event
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/v1/partner-orders/{orderId}/status", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<OrderStatusResponse> getOrderStatus(@Valid @PathVariable Integer orderId,
                                                              @Context HttpServletRequest httpRequest) {
		logger.info("Entering getOrderStatus for orderId {} ",orderId);
		OrderStatusResponse response = orderService.getOrderStatus(orderId);
		logger.info("Exiting getOrderStatus for orderId {} ",orderId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
    
    @RequestMapping(value = "/v1/partner-accounts/{partnerAccountId}/products", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<RecommendedProductResponse>> getProducts(@Valid @NotNull @PathVariable String partnerAccountId, @RequestParam(value = "select", required = true) String select,  @RequestParam(value = "inDirectAccountId", required = true) String inDirectAccountId, @Context HttpServletRequest httpRequest) {
      	String userName = httpRequest.getHeader(BAConstants.USER_NAME);
    	    logger.info("Inside getProducts for partner user : {}", userName);
    	    
    	    StopWatch stopWatch = new StopWatch("Start fetching recommended product response for partner/pae");
	    stopWatch.start("recommended product response for partner/pae");
	    
    	    if(BAConstants.RECOMMENDATION.equalsIgnoreCase(select)) {
    	      	List<String> roles = requestFetcher.getLoggedInUserRoles();
    	      	validateIfResponseIsAuthorizedForLoggedInPartner(partnerAccountId, httpRequest);
                List<RecommendedProductResponse> response = partnerOrderService.getPartnerProductsIntegrationDetails(inDirectAccountId, partnerAccountId, roles);
    	        logger.debug("Successfully retrieved product list along with their integration type support : {}", response);
    	        stopWatch.stop();
    	        logger.info(stopWatch.prettyPrint());
    	        return new ResponseEntity<>(response, HttpStatus.OK);  	    	
    	    }else{
    			String msg = "Invalid input. Product Integration Details can't be fetch.";
    			throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
    	    }
    }
    
	@RequestMapping(value = "/v1/partner-accounts/{partnerAccountId}/contracts", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<ContractsResponse> getContractsForIndirectCustomer(@Valid @NotNull @PathVariable String partnerAccountId,
			@RequestParam(value="marketingProductId", required = true) String marketingProductId,
			@RequestParam(value="indirectAccountId", required = false) String indirectAccountId,
			@Context HttpServletRequest httpRequest){
		
		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		logger.info("Entering getContractsForIndirectCustomer for user : {}",userName);
        validateIfResponseIsAuthorizedForLoggedInPartner(partnerAccountId, httpRequest);
        ContractsResponse response = marketplaceAPIService.getContractsForIndirectCustomer(partnerAccountId, indirectAccountId, marketingProductId, userName);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/v1/partner-accounts/{partnerAccountId}/opportunities", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<List<AccountOpportunityDto>> getPartnerOpportunities(@Valid @NotNull @PathVariable String partnerAccountId,
                                                                               @Context HttpServletRequest httpRequest){
		
		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		logger.info("Entering getOpportunitiesForPartner for partner : {}",userName);
		List<String> roles = requestFetcher.getLoggedInUserRoles();
        validateIfResponseIsAuthorizedForLoggedInPartner(partnerAccountId, httpRequest);
        List<AccountOpportunityDto> response = partnerOrderService.fetchPartnerOpportunities(partnerAccountId, roles, requestFetcher.getContactId());

        if (partnerService.isPartnerUser(roles)) {
                partnerService.markSalesForceLinkNullForOpportunityResponse(response);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
	}

    @RequestMapping(value = "/v1/partner-accounts/{accountId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<AccountDto> getPartnerAccountDetails(@PathVariable String accountId,
                                                               @RequestParam(name = "user", required = false) String user,
                                                               @Context HttpServletRequest httpRequest) {

        logger.info("Inside get partner account details for account Id {}", accountId);
        AccountDto response = accountService.getAccountDetailsWithContactsForUserType(accountId, user);
        validateIfResponseIsAuthorizedForLoggedInPartner(response.getAccountId(), httpRequest);
        if (partnerService.isPartnerUser(requestFetcher.getLoggedInUserRoles())) {
            accountService.markSalesForceLinkNullForAccountResponse(response);
        }
        logger.debug("Got partner Account response {}", CommonUtils.getJsonFromObject(response));
        return new ResponseEntity(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/v1/partner-opportunities/{opportunityId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<OpportunityResponse> fetchOpportunityDetails(@PathVariable(value = "opportunityId") String opportunityId,
                                                                       @Context HttpServletRequest httpRequest) {

        logger.info("Entering Get partner Opportunity Details API for oppID  {}", opportunityId);
        OpportunityResponse oppDetails = orderSourceService.fetchOpportunityDetails(opportunityId);

        if (DealType.DIRECT.getDealName().equalsIgnoreCase(oppDetails.getDealType())) {
            String title = "no access to direct opportunity";
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.FORBIDDEN);
        }

        List<String> roles = requestFetcher.getLoggedInUserRoles();
        if (partnerService.isPartnerUser(roles)) {
            partnerService.markSalesForceLinkNullForOpportunity(oppDetails);
        }
        validateIfResponseIsAuthorizedForLoggedInPartner(oppDetails.getPartnerInfo().getAccountDetails().getId(), httpRequest);
        logger.info("Exiting get opportunity Details API for oppID {}", opportunityId);
        logger.debug("Exiting Get Opportunity Details API for oppID  {} response as {} ", opportunityId, oppDetails);
        return new ResponseEntity<>(oppDetails, HttpStatus.OK);
    }

    @RequestMapping(value = "/v1/partner-accounts", method = RequestMethod.GET ,produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<BasicPartnerAccountDto>> getAllPartnerAccountsForPAE(@RequestParam(name = "paeUserId", required = true) String paeUserId,
                                                                                    @Context HttpServletRequest httpRequest) {

        logger.info("Getting all partner account id for pae: {}", paeUserId);

        List<BasicPartnerAccountDto> partnerAccounts = baCoreAPIService.getAllPartnerAccountsForPAE(paeUserId);

        logger.info("Got all partner account id for pae: {}", paeUserId);
        return new ResponseEntity<>(partnerAccounts, HttpStatus.OK);
    }

    @RequestMapping(value = "/v1/partner-orders/{orderId}/members", method = RequestMethod.PUT)
    public ResponseEntity updatePartnerOrderMemeber(@PathVariable Integer orderId, @RequestBody List<OrderMember> orderMembers,
                                                    @Context HttpServletRequest httpRequest) throws Exception {

        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        if(CollectionUtils.isEmpty(orderMembers)){
            String title = "request cannot be empty of null";
            throw new BuyAkamaiApplicationException(title, title, HttpStatus.BAD_REQUEST);
        }

        String userName = requestFetcher.getUserName();

        marketplaceAPIService.updateOrderManager(orderId, orderMembers, userName);
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @RequestMapping(value = "/v1/partner-orders/{orderId}/contacts", method = RequestMethod.PUT)
    public ResponseEntity resendCredentials(@PathVariable Integer orderId, @RequestBody Set<String> contacts,
                                            @Context HttpServletRequest httpRequest) throws Exception {
        logger.info("Entering to update Contacts : resendCredentials {} {} ", orderId, contacts);

        validateIfRequestedOrderBelongsToPartner(orderId, httpRequest);

        if (null == contacts || contacts.size() == 0) {
            logger.error(" Resend credentials failed for Order ID {} ", orderId);
            throw new BuyAkamaiApplicationException("Invalid resend credential request Order ID " + orderId, "contacts are empty", HttpStatus.BAD_REQUEST);
        }
        marketplaceService.resendCredentials(orderId, contacts);

        logger.info("Resend Credential Service call returned for successfully {}", contacts);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    private void validateIfRequestedOrderBelongsToPartner(Integer orderId, HttpServletRequest httpServletRequest) {
        if (!isInternalUser(httpServletRequest)) {
            partnerService.checkIfOrderBelongsToPartner(orderId, requestFetcher.getDefaultAccountId());
        }
    }

    @RequestMapping(value = "/v1/partner-accounts/{accountId}/members")
    public ResponseEntity<PartnerTeamMember> getPartnerTeamMembers(@Valid @PathVariable("accountId") String accountId,
                                                                   @Context HttpServletRequest httpRequest) {


        logger.info("Getting members for partner account {}", accountId);

        validateIfResponseIsAuthorizedForLoggedInPartner(accountId, httpRequest);
        PartnerTeamMember teamMember = baCoreAPIService.getPAEForPartnerAccountId(accountId);

        logger.debug("Response : {}", teamMember);

        return new ResponseEntity<>(teamMember, HttpStatus.OK);
    }

    private void validateIfResponseIsAuthorizedForLoggedInPartner(String responseAccountId, HttpServletRequest servletRequest) {
        boolean internalUser = isInternalUser(servletRequest);
        boolean isAuthorized = partnerService.checkIfResponseAccountMatchesToLoggedInPartner(requestFetcher.getDefaultAccountId(),
                internalUser, responseAccountId);
        if (!isAuthorized) {
            throw new BuyAkamaiApplicationException("Unauthorized to view this data", "Not accessible", HttpStatus.UNAUTHORIZED);
        }
    }

    private boolean isInternalUser(HttpServletRequest servletRequest) {
        IdsRequest idsRequest = IdsRequest.from(servletRequest);
        IdentityServiceResourceClient client = new IdentityServiceResourceClient();
        IdentityServiceFactory factory = new IdentityServiceFactoryImpl(client );
        return factory.getRequestIdentityService().isCurrentRequestInternal(idsRequest);
    }

    @RequestMapping(value = "/v1/all-partner-orders", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<PartnerSelectOrderResponse>> getPartnerOrdersForAdminPage(@RequestParam(name = "orderType", required = true) String orderType,
                                                                             @RequestParam(name = "orderStatus", required = true) String orderStatus,
                                                                             @Context HttpServletRequest httpRequest) {
        logger.info("Get all partner orders. orderType:{}, orderStatus:{}", orderType, orderStatus);

        List<PartnerSelectOrderResponse> response = partnerOrderService.getAllPartnerOrders(orderType, orderStatus);

        logger.info("Exiting Get all partner orders. orderType:{}, orderStatus:{} successfully", orderType, orderStatus);
        logger.debug("Response for order query: {}", response);

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}