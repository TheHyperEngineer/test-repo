package com.akamai.buyakamai.controller.model;

import java.util.List;

public class LeadBasicInfoRequest {

    private List<String> leadIds;

    public List<String> getLeadIds() {
        return leadIds;
    }

    public void setLeadIds(List<String> leadIds) {
        this.leadIds = leadIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LeadBasicInfoRequest that = (LeadBasicInfoRequest) o;

        return leadIds != null ? leadIds.equals(that.leadIds) : that.leadIds == null;
    }

    @Override
    public int hashCode() {
        return leadIds != null ? leadIds.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "LeadBasicInfoRequest{" +
                "leadIds=" + leadIds +
                '}';
    }
}
