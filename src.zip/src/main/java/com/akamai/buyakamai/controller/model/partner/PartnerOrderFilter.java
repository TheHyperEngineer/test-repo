package com.akamai.buyakamai.controller.model.partner;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerOrderFilter {

    private String accountId;

    private List<String> userIds;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public List<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(List<String> userIds) {
        this.userIds = userIds;
    }

    @Override
    public String toString() {
        return "PartnerOrderFilter{" +
                "accountId='" + accountId + '\'' +
                ", userIds=" + userIds +
                '}';
    }
}
