package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.integration.clients.model.AddressDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomerInfoDTO {

    private String contactId;

    private String name;

    private String email;

    private String phoneNumber;

    private String title;

    private AddressDto contactAddress;

    private AccountDetails accountDetails;

    private String salesForceURL;

    private Boolean ActivePortalUser;

    public Boolean isActivePortalUser() {
        return ActivePortalUser;
    }

    public void setActivePortalUser(Boolean activePortalUser) {
        ActivePortalUser = activePortalUser;
    }

    public AddressDto getContactAddress() {
        return contactAddress;
    }

    public void setContactAddress(AddressDto contactAddress) {
        this.contactAddress = contactAddress;
    }

    public String getSalesForceURL() {
        return salesForceURL;
    }

    public void setSalesForceURL(String salesForceURL) {
        this.salesForceURL = salesForceURL;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public AccountDetails getAccountDetails() {
        return accountDetails;
    }

    public void setAccountDetails(AccountDetails accountDetails) {
        this.accountDetails = accountDetails;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CustomerInfoDTO that = (CustomerInfoDTO) o;

        return contactId != null ? contactId.equals(that.contactId) : that.contactId == null;
    }

    @Override
    public int hashCode() {
        return contactId != null ? contactId.hashCode() : 0;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }


}