package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.origin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TestSetUpInfo {

    @JsonProperty("is_result_approved")
    private Boolean isApproved ;

    @JsonProperty("testing_platform")
    private TestSetUpMeta platform;

    private TestSetUpMeta metric;

    @JsonProperty("test_setup_info_id")
    private String id;

    @JsonProperty("test_status")
    private String status;

    public Boolean getApproved() {
        return isApproved;
    }

    public void setApproved(Boolean approved) {
        isApproved = approved;
    }

    public TestSetUpMeta getPlatform() {
        return platform;
    }

    public void setPlatform(TestSetUpMeta platform) {
        this.platform = platform;
    }

    public TestSetUpMeta getMetric() {
        return metric;
    }

    public void setMetric(TestSetUpMeta metric) {
        this.metric = metric;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        TestSetUpInfo that = (TestSetUpInfo) o;

        return id != null ? id.equals(that.id) : that.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
