package com.akamai.buyakamai.controller.model.partner;

import com.akamai.buyakamai.controller.model.AccountInfo;
import com.akamai.buyakamai.controller.model.ContactInfo;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerDetail {

    private AccountInfo partnerAccount;

    private List<ContactInfo> pae;

    private List<ContactInfo> partnerContact;

    private List<ContactInfo> trialManager;

    private List<ContactInfo> accountContact;

    public AccountInfo getPartnerAccount() {
        return partnerAccount;
    }

    public void setPartnerAccount(AccountInfo partnerAccount) {
        this.partnerAccount = partnerAccount;
    }

    public List<ContactInfo> getPae() {
        return pae;
    }

    public void setPae(List<ContactInfo> pae) {
        this.pae = pae;
    }

    public List<ContactInfo> getPartnerContact() {
        return partnerContact;
    }

    public void setPartnerContact(List<ContactInfo> partnerContact) {
        this.partnerContact = partnerContact;
    }

    public List<ContactInfo> getTrialManager() {
        return trialManager;
    }

    public void setTrialManager(List<ContactInfo> trialManager) {
        this.trialManager = trialManager;
    }

    public List<ContactInfo> getAccountContact() {
        return accountContact;
    }

    public void setAccountContact(List<ContactInfo> accountContact) {
        this.accountContact = accountContact;
    }
}
