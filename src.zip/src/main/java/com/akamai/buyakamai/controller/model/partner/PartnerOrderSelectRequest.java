package com.akamai.buyakamai.controller.model.partner;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerOrderSelectRequest {

    private String orderStatus;

    private String orderType;

    private List<PartnerOrderFilter> filters;


    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<PartnerOrderFilter> getFilters() {
        return filters;
    }

    public void setFilters(List<PartnerOrderFilter> filters) {
        this.filters = filters;
    }

    @Override
    public String toString() {
        return "PartnerOrderSelectRequest{" +
                "orderStatus='" + orderStatus + '\'' +
                ", orderType='" + orderType + '\'' +
                ", filters=" + filters +
                '}';
    }
}
