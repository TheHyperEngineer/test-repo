package com.akamai.buyakamai.controller.model.partner;

import com.akamai.buyakamai.controller.model.AccountInfo;
import com.akamai.buyakamai.controller.model.ContactInfo;
import com.akamai.buyakamai.controller.model.HrefLink;
import com.akamai.buyakamai.controller.model.TrialExtensionDetail;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerSelectOrderResponse {

    private Integer orderId;
    private String orderType;
    private String trialType;
    private String status;
    private AccountInfo account;
    private AccountInfo partnerAccount;
    private ContactInfo customer;
    private String type;
    private List<String> products;
    private String startDate;
    private String endDate;
    private String contractId;
    private String createdByUserName;
    private String bundleId;
    private String createdDate;
    private String daysLeft;
    private String updatedTime;
    private String signedDate;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer daysSinceLastCredentialSent;

    private TrialExtensionDetail childOrderHierarchy;
    private OpportunityInfo opportunity;
    private List<HrefLink> links;
    private ContactInfo trialManager;

    private ContactInfo salesRep;
    private ContactInfo se;

    private ContactInfo orderContact;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean owner;

    private boolean activeAccountNewContract;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getTrialType() {
        return trialType;
    }

    public void setTrialType(String trialType) {
        this.trialType = trialType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public AccountInfo getAccount() {
        return account;
    }

    public void setAccount(AccountInfo account) {
        this.account = account;
    }

    public ContactInfo getCustomer() {
        return customer;
    }

    public void setCustomer(ContactInfo customer) {
        this.customer = customer;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getProducts() {
        return products;
    }

    public void setProducts(List<String> products) {
        this.products = products;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getCreatedByUserName() {
        return createdByUserName;
    }

    public void setCreatedByUserName(String createdByUserName) {
        this.createdByUserName = createdByUserName;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public List<HrefLink> getLinks() {
        return links;
    }

    public void setLinks(List<HrefLink> links) {
        this.links = links;
    }

    public AccountInfo getPartnerAccount() {
        return partnerAccount;
    }

    public void setPartnerAccount(AccountInfo partnerAccount) {
        this.partnerAccount = partnerAccount;
    }

    public String getDaysLeft() {
        return daysLeft;
    }

    public void setDaysLeft(String daysLeft) {
        this.daysLeft = daysLeft;
    }

    public TrialExtensionDetail getChildOrderHierarchy() {
        return childOrderHierarchy;
    }

    public void setChildOrderHierarchy(TrialExtensionDetail childOrderHierarchy) {
        this.childOrderHierarchy = childOrderHierarchy;
    }

    public OpportunityInfo getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(OpportunityInfo opportunity) {
        this.opportunity = opportunity;
    }

	public ContactInfo getTrialManager() {
		return trialManager;
	}

	public void setTrialManager(ContactInfo trialManager) {
		this.trialManager = trialManager;
	}


    public Boolean isOwner() {
        return owner;
    }

    public void setOwner(Boolean owner) {
        this.owner = owner;
    }

    public ContactInfo getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(ContactInfo salesRep) {
        this.salesRep = salesRep;
    }

    public ContactInfo getSe() {
        return se;
    }

    public void setSe(ContactInfo se) {
        this.se = se;
    }

    public Integer getDaysSinceLastCredentialSent() {
        return daysSinceLastCredentialSent;
    }

    public void setDaysSinceLastCredentialSent(Integer daysSinceLastCredentialSent) {
        this.daysSinceLastCredentialSent = daysSinceLastCredentialSent;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    public ContactInfo getOrderContact() {
        return orderContact;
    }

    public void setOrderContact(ContactInfo orderContact) {
        this.orderContact = orderContact;
    }

    public String getSignedDate() {
        return signedDate;
    }

    public void setSignedDate(String signedDate) {
        this.signedDate = signedDate;
    }


    public boolean isActiveAccountNewContract() {
		return activeAccountNewContract;
	}

	public void setActiveAccountNewContract(boolean activeAccountNewContract) {
		this.activeAccountNewContract = activeAccountNewContract;
	}

	public Boolean getOwner() {
		return owner;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PartnerSelectOrderResponse that = (PartnerSelectOrderResponse) o;

        return orderId.equals(that.orderId);
    }

    @Override
    public int hashCode() {
        return orderId.hashCode();
    }

    @Override
	public String toString() {
		return "PartnerSelectOrderResponse [orderId=" + orderId + ", orderType=" + orderType + ", trialType="
		        + trialType + ", status=" + status + ", account=" + account + ", partnerAccount=" + partnerAccount
		        + ", customer=" + customer + ", type=" + type + ", products=" + products + ", startDate=" + startDate
		        + ", endDate=" + endDate + ", contractId=" + contractId + ", createdByUserName=" + createdByUserName
		        + ", bundleId=" + bundleId + ", createdDate=" + createdDate + ", daysLeft=" + daysLeft
		        + ", updatedTime=" + updatedTime + ", signedDate=" + signedDate + ", daysSinceLastCredentialSent="
		        + daysSinceLastCredentialSent + ", childOrderHierarchy=" + childOrderHierarchy + ", opportunity="
		        + opportunity + ", links=" + links + ", trialManager=" + trialManager + ", salesRep=" + salesRep
		        + ", se=" + se + ", orderContact=" + orderContact + ", owner=" + owner + ", activeAccountNewContract="
		        + activeAccountNewContract + "]";
	}
}
