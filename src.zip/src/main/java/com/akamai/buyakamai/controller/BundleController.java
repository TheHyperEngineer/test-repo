package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.controller.model.BundleResponse;
import com.akamai.buyakamai.controller.model.MarketplacePricingResponse;
import com.akamai.buyakamai.controller.model.ProductDesired;
import com.akamai.buyakamai.controller.model.TermsAndConditionResponse;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.BundleServiceImpl;
import com.akamai.buyakamai.service.impl.MarketplaceAPIServiceImpl;
import com.akamai.buyakamai.util.RequestFetcher;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.QueryParam;
import java.util.Currency;
import java.util.List;

@RestController
@EnableAutoConfiguration
public class BundleController {

    private static final Logger logger = LoggerFactory.getLogger(BundleController.class.getName());
	
	@Autowired
	private BundleServiceImpl bundleService;
	
	@Autowired
	private RequestFetcher requestFetcher;

	@Autowired
	private MarketplaceAPIServiceImpl marketplaceAPIService;
	
	@RequestMapping(value = "/v1/bundles/{bundleId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseEntity<BundleResponse> getBundleDetails(@Valid @PathVariable String bundleId,
			@Valid @QueryParam(value = "currency") String currency, @QueryParam(value = "partnerAccountId") String partnerAccountId) {
		// fetch logged in user information from Request fetcher
		String locale = requestFetcher.getUserLocale();
		validateCurrency(currency);
		String userId = requestFetcher.getUserName();
		logger.info("In getBundles : API call /v1/bundles Input bundleId {} and currency {} ", bundleId, currency);
		// invoke service layer to fetch bundle,contained products and trial
		// information.
		BundleResponse response = bundleService.getBundleDetails(bundleId, locale, currency, userId, partnerAccountId);
		logger.info("Exiting getBundles : API call /v1/bundles :bundleId ,response {} {} ", bundleId, response);

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	private void validateCurrency(String opportunityCurrency) {
		try {
			if(StringUtils.isEmpty(opportunityCurrency)){
				logger.error("Missing currency code {} ",opportunityCurrency);
				throw new BuyAkamaiApplicationException("Currency code missing","Provide currency code for trail details", HttpStatus.BAD_REQUEST);
			}
			Currency.getInstance(opportunityCurrency);
		} catch (IllegalArgumentException exception) {
			logger.error("Invalid currency code ",exception);
			throw new BuyAkamaiApplicationException("Invalid currency code", exception.getMessage(), HttpStatus.BAD_REQUEST,ErrorConstants.GET_BUNDLES_FAILED_KEY);
		}
	}
	
	@RequestMapping(value = "/v1/bundles/{bundleId}/ui-metadata", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseEntity<ObjectNode> getUIMetaData(@Valid @PathVariable String bundleId)  {
		logger.info("Entering getUIMetaData : API call /v1/ui-metadata/{bundleId} {} ",bundleId);

		//fetch logged in user information from Request fetcher
		String locale = requestFetcher.getUserLocale();
		ObjectNode metadata = bundleService.getUIMetadata(bundleId,locale);
		
		logger.info("Exiting getUIMetaData : API call /v1/ui-metadata/{bundleId}  {} :response {} ",bundleId,metadata);
		return new ResponseEntity<>(metadata, HttpStatus.OK);
	}

    @RequestMapping(value = "v1/bundles", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<List<ProductDesired>> getListOfProductDesired(){
		logger.info("Get Desired product list started");

        List<ProductDesired> productDesiredList = bundleService.getListOfProductDesired();

        logger.info("Product list retrieved successfully :{}",productDesiredList);

        return new ResponseEntity<>(productDesiredList, HttpStatus.OK);
    }

	@GetMapping(value = "v2/bundles/{marketingProductId}/pricing")
	public ResponseEntity<MarketplacePricingResponse> getPricing(
	        @Valid @NotNull @PathVariable String marketingProductId,
	        @RequestParam(value = "currency", required = true) String currency,
	        @RequestParam(value = "existingAccountNewContract", required = false) String existingAccountNewContract,
	        @RequestParam(value = "serviceType", required = true) String serviceType) {
		logger.info(" Getting pricing for productId {} and currency {} ", marketingProductId, currency);
		MarketplacePricingResponse pricingResponse =
				marketplaceAPIService.getPricingForProduct(marketingProductId, currency, serviceType, existingAccountNewContract);
		logger.debug("Pricing response: {}", pricingResponse);
		return new ResponseEntity<>(pricingResponse, HttpStatus.OK);
	}

	@RequestMapping(value = "v1/bundles/{productId}/tnc", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
	public ResponseEntity<TermsAndConditionResponse> getTermsAndConditions(
	        @Valid @NotNull @PathVariable String productId,
	        @RequestParam(value = "userType", required = true) String userType) {
		logger.info("Getting TnC for productId: {} and userType: {}", productId, userType);
		TermsAndConditionResponse termsAndConditionResponse = marketplaceAPIService.getTermsAndConditionsResponse(productId, userType);
		logger.info("Exiting TnC for productId: {} and userType: {}", productId, userType);
		return new ResponseEntity<>(termsAndConditionResponse, HttpStatus.OK);
	}
}