package com.akamai.buyakamai.controller.model.partner;

public class BasicPartnerOrderResponse {
    
    private Integer orderId;


    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    @Override
    public String toString() {
        return "BasicPartnerOrderResponse{" +
                "orderId=" + orderId +
                '}';
    }
}
