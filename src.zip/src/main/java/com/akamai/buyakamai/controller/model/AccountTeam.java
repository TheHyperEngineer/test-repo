package com.akamai.buyakamai.controller.model;


import java.util.List;

public class AccountTeam {

    private String accountId;
    private String accountName;
    private List<AccountTeamMember> teamMembers;


    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public List<AccountTeamMember> getTeamMembers() {
        return teamMembers;
    }

    public void setTeamMembers(List<AccountTeamMember> teamMembers) {
        this.teamMembers = teamMembers;
    }

    @Override
    public String toString() {
        return "AccountTeam{" +
                "accountId='" + accountId + '\'' +
                ", accountName='" + accountName + '\'' +
                ", teamMembers=" + teamMembers +
                '}';
    }
}
