package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AssistanceRequest {

	private Integer categoryId;
	
	private String assistanceText;

	private String requestPage;

	private Integer orderId;

	private String sourceId;

	private String sourceType;

	private String productName;

	private String integrationType;

	private String partnerAccountId;

	private String indirectCustomerId;

	private Integer quoteVersion;

	private String accountId;

	private Integer draftId;


	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}


    public String getRequestPage() {
        return requestPage;
    }

    public void setRequestPage(String requestPage) {
        this.requestPage = requestPage;
    }

    public Integer getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(Integer categoryId) {
		this.categoryId = categoryId;
	}

	public String getAssistanceText() {
		return assistanceText;
	}

	public void setAssistanceText(String assistanceText) {
		this.assistanceText = assistanceText;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getIntegrationType() {
		return integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getPartnerAccountId() {
		return partnerAccountId;
	}

	public void setPartnerAccountId(String partnerAccountId) {
		this.partnerAccountId = partnerAccountId;
	}

	public String getIndirectCustomerId() {
		return indirectCustomerId;
	}

	public void setIndirectCustomerId(String indirectCustomerId) {
		this.indirectCustomerId = indirectCustomerId;
	}

	public Integer getQuoteVersion() {
		return quoteVersion;
	}

	public void setQuoteVersion(Integer quoteVersion) {
		this.quoteVersion = quoteVersion;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Integer getDraftId() {
		return draftId;
	}

	public void setDraftId(Integer draftId) {
		this.draftId = draftId;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof AssistanceRequest)) return false;

		AssistanceRequest that = (AssistanceRequest) o;

		if (getCategoryId() != null ? !getCategoryId().equals(that.getCategoryId()) : that.getCategoryId() != null)
			return false;
		if (getAssistanceText() != null ? !getAssistanceText().equals(that.getAssistanceText()) : that.getAssistanceText() != null)
			return false;
		if (getRequestPage() != null ? !getRequestPage().equals(that.getRequestPage()) : that.getRequestPage() != null)
			return false;
		if (getOrderId() != null ? !getOrderId().equals(that.getOrderId()) : that.getOrderId() != null) return false;
		if (getSourceId() != null ? !getSourceId().equals(that.getSourceId()) : that.getSourceId() != null)
			return false;
		if (getSourceType() != null ? !getSourceType().equals(that.getSourceType()) : that.getSourceType() != null)
			return false;
		if (getProductName() != null ? !getProductName().equals(that.getProductName()) : that.getProductName() != null)
			return false;
		if (getIntegrationType() != null ? !getIntegrationType().equals(that.getIntegrationType()) : that.getIntegrationType() != null)
			return false;
		if (getPartnerAccountId() != null ? !getPartnerAccountId().equals(that.getPartnerAccountId()) : that.getPartnerAccountId() != null)
			return false;
		if (getIndirectCustomerId() != null ? !getIndirectCustomerId().equals(that.getIndirectCustomerId()) : that.getIndirectCustomerId() != null)
			return false;
		if (getQuoteVersion() != null ? !getQuoteVersion().equals(that.getQuoteVersion()) : that.getQuoteVersion() != null)
			return false;
		if (getAccountId() != null ? !getAccountId().equals(that.getAccountId()) : that.getAccountId() != null)
			return false;
		return getDraftId() != null ? getDraftId().equals(that.getDraftId()) : that.getDraftId() == null;
	}

	@Override
	public int hashCode() {
		int result = getCategoryId() != null ? getCategoryId().hashCode() : 0;
		result = 31 * result + (getAssistanceText() != null ? getAssistanceText().hashCode() : 0);
		result = 31 * result + (getRequestPage() != null ? getRequestPage().hashCode() : 0);
		result = 31 * result + (getOrderId() != null ? getOrderId().hashCode() : 0);
		result = 31 * result + (getSourceId() != null ? getSourceId().hashCode() : 0);
		result = 31 * result + (getSourceType() != null ? getSourceType().hashCode() : 0);
		result = 31 * result + (getProductName() != null ? getProductName().hashCode() : 0);
		result = 31 * result + (getIntegrationType() != null ? getIntegrationType().hashCode() : 0);
		result = 31 * result + (getPartnerAccountId() != null ? getPartnerAccountId().hashCode() : 0);
		result = 31 * result + (getIndirectCustomerId() != null ? getIndirectCustomerId().hashCode() : 0);
		result = 31 * result + (getQuoteVersion() != null ? getQuoteVersion().hashCode() : 0);
		result = 31 * result + (getAccountId() != null ? getAccountId().hashCode() : 0);
		result = 31 * result + (getDraftId() != null ? getDraftId().hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("AssistanceRequest{");
		sb.append("categoryId=").append(categoryId);
		sb.append(", assistanceText='").append(assistanceText).append('\'');
		sb.append(", requestPage='").append(requestPage).append('\'');
		sb.append(", orderId=").append(orderId);
		sb.append(", sourceId='").append(sourceId).append('\'');
		sb.append(", sourceType='").append(sourceType).append('\'');
		sb.append(", productName='").append(productName).append('\'');
		sb.append(", integrationType='").append(integrationType).append('\'');
		sb.append(", partnerAccountId='").append(partnerAccountId).append('\'');
		sb.append(", indirectCustomerId='").append(indirectCustomerId).append('\'');
		sb.append(", quoteVersion=").append(quoteVersion);
		sb.append(", accountId='").append(accountId).append('\'');
		sb.append(", draftId=").append(draftId);
		sb.append('}');
		return sb.toString();
	}
}
