package com.akamai.buyakamai.controller.model;

import java.math.BigDecimal;

public class TrafficDetails {
    private int orderId;

    private BigDecimal trafficAllotted;

    private BigDecimal trafficConsumed;

    private String startDate;

    private String endDate;

    private String trafficAllottedUOM;

    private String trafficConsumedUOM;

    private String trafficConsumedPercentage;

	public String getTrafficConsumedPercentage() {
		return trafficConsumedPercentage;
	}

	public void setTrafficConsumedPercentage(String trafficConsumedPercentage) {
		this.trafficConsumedPercentage = trafficConsumedPercentage;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public BigDecimal getTrafficAllotted() {
		return trafficAllotted;
	}

	public void setTrafficAllotted(BigDecimal trafficAllotted) {
		this.trafficAllotted = trafficAllotted;
	}

	public BigDecimal getTrafficConsumed() {
		return trafficConsumed;
	}

	public void setTrafficConsumed(BigDecimal trafficConsumed) {
		this.trafficConsumed = trafficConsumed;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTrafficAllottedUOM() {
		return trafficAllottedUOM;
	}

	public void setTrafficAllottedUOM(String trafficAllottedUOM) {
		this.trafficAllottedUOM = trafficAllottedUOM;
	}

	public String getTrafficConsumedUOM() {
		return trafficConsumedUOM;
	}

	public void setTrafficConsumedUOM(String trafficConsumedUOM) {
		this.trafficConsumedUOM = trafficConsumedUOM;
	}
}
