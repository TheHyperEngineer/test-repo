package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BAExtensionRequest {


    private String duration;

    private String reason;
    
    private List<String> contactIds;
    
    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }
    
	public List<String> getContactIds() {
		return contactIds;
	}

	public void setContactIds(List<String> contactIds) {
		this.contactIds = contactIds;
	}

	@Override
    public String toString() {
        return "BAExtensionRequest{" +
                "duration='" + duration + '\'' +
                ", reason='" + reason + '\'' +
                '}';
    }
}
