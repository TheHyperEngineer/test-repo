package com.akamai.buyakamai.controller;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.Context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.controller.model.AccountLookupRequest;
import com.akamai.buyakamai.controller.model.AccountTeam;
import com.akamai.buyakamai.controller.model.SearchFilter;
import com.akamai.buyakamai.controller.model.partner.ContractsResponse;
import com.akamai.buyakamai.integration.clients.model.AccountBasicInfoDto;
import com.akamai.buyakamai.integration.clients.model.AccountDto;
import com.akamai.buyakamai.integration.clients.model.AccountOpportunityDto;
import com.akamai.buyakamai.integration.clients.model.BAContactDto;
import com.akamai.buyakamai.service.impl.AccountServiceImpl;
import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.akamai.buyakamai.service.impl.MarketplaceAPIServiceImpl;
import com.akamai.buyakamai.service.impl.UserServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;

@RestController
public class AccountController {

    private static final Logger logger = LoggerFactory.getLogger(AccountController.class);

    @Autowired
    private BACoreAPIServiceImpl baCoreService;
    
    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private AccountServiceImpl accountService;

    @Autowired
    private PropertyManager propertyManager;
    
    @Autowired
    private MarketplaceAPIServiceImpl marketplaceAPIService;

    @RequestMapping(value = "/v1/accounts/{accountId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<AccountDto> getAccountDetails(@PathVariable String accountId, @RequestParam(name = "user", required = false) String user, @Context HttpServletRequest httpRequest) {
        logger.info("Inside getting account details for accountId {}", accountId);
        AccountDto response = accountService.getAccountDetailsWithContactsForUserType(accountId, user);
        logger.info("Successfully retrieved account details for accountId {}", accountId);
        logger.debug("Details for account : {}", response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/accounts/search", method = RequestMethod.POST, produces = "application/json;charset=UTF-8", consumes = "application/json;charset=UTF-8")
    public ResponseEntity searchForAccounts(@RequestBody AccountLookupRequest requestObj) {
        logger.info("Inside search Accounts either with request {}", requestObj);
        CommonUtils.validateRequestedData(requestObj, "Invalid account search request");
        String response = baCoreService.searchAccounts(requestObj);

        SearchFilter filter = requestObj.getFilter();

        if (filter != null && filter.getAccount().getType().equalsIgnoreCase("partner")) {
            return filterBlacklistedPartnerAccounts(response);
        }

        logger.info("search completed");
        logger.debug("Account Search response with name {} and id {} is {}", requestObj.getAccountName(), requestObj.getAccountId(), response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    private ResponseEntity filterBlacklistedPartnerAccounts(String response) {
        List<AccountBasicInfoDto> listObjectFromStringJson = CommonUtils.getListObjectFromStringJson(response, AccountBasicInfoDto.class);
        List<String> blockedAccounts = CommonUtils.convertCommaSeparatedStringToList(propertyManager.getProperty(BAConstants.BLOCKED_PARTNERS_PROPERTY_KEY));
        List<AccountBasicInfoDto> filtered = listObjectFromStringJson.stream().filter(x -> !blockedAccounts.contains(x.getAccountId())).collect(Collectors.toList());
        return new ResponseEntity<>(filtered, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/accounts", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<String> getAccounts(@RequestParam(name = "selfAccounts", required = true) boolean selfAccounts,
    		@Context HttpServletRequest httpRequest) {
    	String userName = httpRequest.getHeader(BAConstants.USER_NAME);
    	logger.info("Inside getting account list for user: {}", userName);
        String response = baCoreService.getAccountList(userName, selfAccounts);
        logger.info("Successfully retrieved account list for user {}",userName);
        logger.debug("Account list : {}", response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/accounts/{accountId}/team-members", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<AccountTeam> getAccounTeamMembers(@PathVariable String accountId,
                                                            @Context HttpServletRequest httpRequest) {

        logger.info("Team mebers fetching for account : {}", accountId);

        AccountTeam accountTeam = accountService.fetchAccountTeamMembers(accountId);

        logger.debug("Team members recieved for accountID {} : {}", accountId, accountTeam);
        return new ResponseEntity<>(accountTeam, HttpStatus.OK);
    }
    
    @RequestMapping(value = "v1/accounts/{accountId}/marketplace-users", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<BAContactDto>> getMPUsersForAccount(@PathVariable String accountId,
    		@Context HttpServletRequest httpRequest) {
    	String userName = httpRequest.getHeader(BAConstants.USER_NAME);
    	logger.info("Inside getting account list for user: {}", userName);
        List<BAContactDto> response = userService.getMPUsersForAccount(accountId);
        logger.info("Successfully retrieved mp user list for account {}", accountId);
        logger.debug("Account list : {}", response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/accounts/{accountId}/opportunities", method = RequestMethod.GET)
    @ResponseBody
    public ResponseEntity<List<AccountOpportunityDto>> getDirectAccountOpportunities(@Valid @NotNull @PathVariable String accountId,
                                                                                     @Context HttpServletRequest httpRequest){

        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        logger.info("Entering getOpportunities for account : {}",userName);
        List<AccountOpportunityDto> response = accountService.fetchDirectAccountOpportunities(accountId);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
	@RequestMapping(value = "/v1/accounts/{accountId}/contracts", method = RequestMethod.GET)
	@ResponseBody
	public ResponseEntity<ContractsResponse> getContractsForDirectCustomer(
	        @Valid @NotNull @PathVariable String accountId,
	        @RequestParam(value = "marketingProductId", required = true) String marketingProductId,
	        @Context HttpServletRequest httpRequest) {
		String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		logger.info("Entering getContractsForDirectCustomer for user : {}", userName);
		ContractsResponse response = marketplaceAPIService.getContractsForDirectCustomer(accountId,
		        marketingProductId, userName);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
