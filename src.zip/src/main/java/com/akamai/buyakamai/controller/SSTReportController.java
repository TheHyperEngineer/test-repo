package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.reports.CSVGenerator;
import com.akamai.buyakamai.service.reports.ExcelGenerator;
import com.akamai.buyakamai.service.reports.SstReportDataGeneratorServiceImpl;
import com.akamai.buyakamai.service.reports.SstReportModel;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.PropertyManager;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;

import static com.akamai.buyakamai.constants.BAConstants.*;

@RestController
public class SSTReportController {


    public static final String BINARY = "BINARY";

    private static Logger logger = LoggerFactory.getLogger(SSTReportController.class.getName());

    @Autowired
    private SstReportDataGeneratorServiceImpl sstReportDataGeneratorService;

    @Autowired
    private CSVGenerator csvGenerator;

    @Autowired
    private ExcelGenerator<SstReportModel> excelGenerator;

    @Autowired
    private PropertyManager propertyManager;

    private static final String CONTENT_TRANSFER_ENCODING = "Content-Transfer-Encoding";


    @RequestMapping(value = "/v1/orders/reports", method = RequestMethod.GET, produces = {"text/csv", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", MediaType.APPLICATION_JSON_VALUE})
    public void generateReport(@RequestParam(value = "start", required = false) String start, @RequestParam(value = "end", required = false) String end,
                               HttpServletRequest request, HttpServletResponse response) throws IOException {

        StopWatch stopWatch = new StopWatch("Overall watch");

        stopWatch.start("validation");

        Date startDate = null;
        Date endDate = null;

        if (start != null) {
            startDate = CommonUtils.parseTimeStampStrict(start, "yyyy-MM-dd");
        }
        if (end != null) {
            endDate = CommonUtils.parseTimeStampStrict(end, "yyyy-MM-dd");
        }

        validateDates(startDate, endDate);

        if (startDate == null) {
            String defaultDays = propertyManager.getProperty(BAConstants.DEFAULT_INTERVAL_SST_REPORT_DAYS);
            startDate = LocalDate.now().minusDays(Integer.valueOf(defaultDays)).toDate();
        }
        if (endDate == null) {
            endDate = LocalDate.now().toDate();
        }

        stopWatch.stop();
        String acceptHeader = request.getHeader(ACCEPT_HEADER);
        stopWatch.start("sst report data generator service");
        List<SstReportModel> models = sstReportDataGeneratorService.generateReportDataIntoModel(startDate, endDate);
        stopWatch.stop();

        stopWatch.start("file write");
        if (acceptHeader == null || acceptHeader.contains(CSV_MEDIA_TYPE)) {
            String csvFileName = "sst_report_" + start + "_" + end + ".csv";
            generateCSV(response, models, csvFileName);
        } else if (acceptHeader.contains(XLSX_MEDIA_TYPE)) {
            String xlsxFileName = "sst_report" + start + "_" + end + ".xlsx";
            generateExcel(response, models, xlsxFileName);
        } else {
            String msg = "invalid/unsupported accept header";
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
        }
        stopWatch.stop();

        logger.info("Total SST Report generation performance: {}", stopWatch.prettyPrint());

    }

    private void generateCSV(HttpServletResponse response, List<SstReportModel> models, String csvFileName) throws IOException {
        response.setContentType(BAConstants.CSV_MEDIA_TYPE);
        String headerValue = String.format("attachment; filename=\"%s\"", csvFileName);
        response.setHeader(BAConstants.CONTENT_DISPOSITION_HEADER, headerValue);
        response.setHeader(CONTENT_TRANSFER_ENCODING, BINARY);
        csvGenerator.generateCSV(models, response);
    }

    private void validateDates(Date startDate, Date endDate) {

        if (startDate != null && endDate != null) {

            if ((endDate.compareTo(startDate) < 0 || endDate.compareTo(LocalDate.now().toDate()) > 0)) {
                throw new BuyAkamaiApplicationException("End Date cannot be less than start date", "invalid end date", HttpStatus.BAD_REQUEST);
            }

            String maxDays = propertyManager.getProperty(BAConstants.MAX_INTERVAL_SST_REPORT_DAYS);
            int days = Days.daysBetween(new LocalDate(startDate), new LocalDate(endDate)).getDays();

            if (days > Integer.valueOf(maxDays)) {
                throw new BuyAkamaiApplicationException("too large duration", "interval exceeds max duration supported", HttpStatus.BAD_REQUEST);
            }
        }
    }

    private void generateExcel(HttpServletResponse response, List<SstReportModel> models, String xlsxFileName) throws IOException {
        String headerValue = String.format("attachment; filename=\"%s\"", xlsxFileName);
        response.setContentType(BAConstants.XLSX_MEDIA_TYPE);
        response.setHeader(CONTENT_DISPOSITION_HEADER, headerValue);
        response.setHeader(CONTENT_TRANSFER_ENCODING, BINARY);
        OutputStream outputStream = response.getOutputStream();
        excelGenerator.generateExcel(outputStream, models, xlsxFileName);
        outputStream.flush();
        outputStream.close();

    }


}
