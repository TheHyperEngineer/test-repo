package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;
import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpportunityFilter {

    private List<String> stages;
    private String createdBy;
    private String assignedTo;
    private Set<String> opportunityIds;
    private List<String> campaignOfferTypeList;
    private List<String> registrationStatusIgnoreList;

    //filter used to fetch opportunities for partners with members belonging to contact present in the list
    private List<String> partnerContactList;
    
    private String owner;

    public List<String> getRegistrationStatusIgnoreList() {
        return registrationStatusIgnoreList;
    }

    public void setRegistrationStatusIgnoreList(List<String> registrationStatusIgnoreList) {
        this.registrationStatusIgnoreList = registrationStatusIgnoreList;
    }

    public List<String> getCampaignOfferTypeList() {
        return campaignOfferTypeList;
    }

    public void setCampaignOfferTypeList(List<String> campaignOfferTypeList) {
        this.campaignOfferTypeList = campaignOfferTypeList;
    }

    public List<String> getStages() {
        return stages;
    }

    public void setStages(List<String> stages) {
        this.stages = stages;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    public Set<String> getOpportunityIds() {
        return opportunityIds;
    }

    public void setOpportunityIds(Set<String> opportunityIds) {
        this.opportunityIds = opportunityIds;
    }

    public List<String> getPartnerContactList() {
        return partnerContactList;
    }

    public void setPartnerContactList(List<String> partnerContactList) {
        this.partnerContactList = partnerContactList;
    }

    public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((assignedTo == null) ? 0 : assignedTo.hashCode());
		result = prime * result + ((campaignOfferTypeList == null) ? 0 : campaignOfferTypeList.hashCode());
		result = prime * result + ((createdBy == null) ? 0 : createdBy.hashCode());
		result = prime * result + ((opportunityIds == null) ? 0 : opportunityIds.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		result = prime * result + ((partnerContactList == null) ? 0 : partnerContactList.hashCode());
		result = prime * result
				+ ((registrationStatusIgnoreList == null) ? 0 : registrationStatusIgnoreList.hashCode());
		result = prime * result + ((stages == null) ? 0 : stages.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OpportunityFilter other = (OpportunityFilter) obj;
		if (assignedTo == null) {
			if (other.assignedTo != null)
				return false;
		} else if (!assignedTo.equals(other.assignedTo))
			return false;
		if (campaignOfferTypeList == null) {
			if (other.campaignOfferTypeList != null)
				return false;
		} else if (!campaignOfferTypeList.equals(other.campaignOfferTypeList))
			return false;
		if (createdBy == null) {
			if (other.createdBy != null)
				return false;
		} else if (!createdBy.equals(other.createdBy))
			return false;
		if (opportunityIds == null) {
			if (other.opportunityIds != null)
				return false;
		} else if (!opportunityIds.equals(other.opportunityIds))
			return false;
		if (owner == null) {
			if (other.owner != null)
				return false;
		} else if (!owner.equals(other.owner))
			return false;
		if (partnerContactList == null) {
			if (other.partnerContactList != null)
				return false;
		} else if (!partnerContactList.equals(other.partnerContactList))
			return false;
		if (registrationStatusIgnoreList == null) {
			if (other.registrationStatusIgnoreList != null)
				return false;
		} else if (!registrationStatusIgnoreList.equals(other.registrationStatusIgnoreList))
			return false;
		if (stages == null) {
			if (other.stages != null)
				return false;
		} else if (!stages.equals(other.stages))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "OpportunityFilter [stages=" + stages + ", createdBy=" + createdBy + ", assignedTo=" + assignedTo
				+ ", opportunityIds=" + opportunityIds + ", campaignOfferTypeList=" + campaignOfferTypeList
				+ ", registrationStatusIgnoreList=" + registrationStatusIgnoreList + ", partnerContactList="
				+ partnerContactList + ", owner=" + owner + "]";
	}

}
