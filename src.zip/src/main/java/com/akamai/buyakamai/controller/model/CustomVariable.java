package com.akamai.buyakamai.controller.model;

import java.util.Objects;

import org.apache.commons.lang.builder.ToStringBuilder;

public class CustomVariable {
	 
	   /** Property key */
	   String key;
	 
	   /** Property value */
	   String value;
	 
	   /**
	    * Constructor
	    */
	   public CustomVariable() {
	   }
	 
	   /**
	    * Gets the key
	    */
	   public String getKey() {
	      return this.key;
	   }
	 
	   /**
	    * Sets the key
	    */
	   public void setKey(String value) {
	      this.key = value;
	   }
	 
	   /**
	    * Gets the value
	    */
	   public String getValue() {
	      return this.value;
	   }
	 
	   /**
	    * Sets the value
	    */
	   public void setValue(String value) {
	      this.value = value;
	   }
	   
	   @Override
		public String toString() {
			return ToStringBuilder.reflectionToString(this);
		}
		
		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((key == null) ? 0 : key.hashCode());
			result = prime * result + ((value == null) ? 0 : value.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {

			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;

			CustomVariable other = (CustomVariable) obj;

			if(!Objects.equals(key, other.key)) {
				return false;
			}
			
			if(!Objects.equals(value, other.value)) {
				return false;
			}
			
			return true;
		}
	}
