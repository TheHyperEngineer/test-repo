package com.akamai.buyakamai.controller.model;

public class CustomerInfo {
	public String fullName;
	public String email;
	public String phoneNo;
	public String contactId;

	public CustomerInfo() {
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	@Override
	public String toString() {
		return "CustomerInfo{" +
				"fullName='" + fullName + '\'' +
				", email='" + email + '\'' +
				", phoneNo='" + phoneNo + '\'' +
				", contactId='" + contactId + '\'' +
				'}';
	}
}