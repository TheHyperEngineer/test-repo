package com.akamai.buyakamai.controller.model;


import java.util.List;

import com.akamai.buyakamai.integration.model.productmaster.ListItemDTO;
import com.akamai.buyakamai.integration.model.productmaster.RuleDTO;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProductResponse {

    private String marketingProductId;

    private String marketingProductName;

    private List<String> serverTypes;

    private String provisioningURL;

    private String businessUnit;

    private String communityURL;

    private List<ListItemDTO> listItems;
    
    private List<RuleDTO> rules;

    private List<OptionGroupResponse> optionGroups;
    

    public List<RuleDTO> getRules() {
		return rules;
	}

	public void setRules(List<RuleDTO> rules) {
		this.rules = rules;
	}

	public String getMarketingProductId() {
        return marketingProductId;
    }

    public void setMarketingProductId(String marketingProductId) {
        this.marketingProductId = marketingProductId;
    }

    public String getMarketingProductName() {
        return marketingProductName;
    }

    public void setMarketingProductName(String marketingProductName) {
        this.marketingProductName = marketingProductName;
    }

    public List<String> getServerTypes() {
        return serverTypes;
    }

    public void setServerTypes(List<String> serverTypes) {
        this.serverTypes = serverTypes;
    }

    public String getProvisioningURL() {
        return provisioningURL;
    }

    public void setProvisioningURL(String provisioningURL) {
        this.provisioningURL = provisioningURL;
    }

    public String getBusinessUnit() {
        return businessUnit;
    }

    public void setBusinessUnit(String businessUnit) {
        this.businessUnit = businessUnit;
    }

    public String getCommunityURL() {
        return communityURL;
    }

    public void setCommunityURL(String communityURL) {
        this.communityURL = communityURL;
    }

    public List<ListItemDTO> getListItems() {
        return listItems;
    }

    public void setListItems(List<ListItemDTO> listItems) {
        this.listItems = listItems;
    }

    public List<OptionGroupResponse> getOptionGroups() {
        return optionGroups;
    }

    public void setOptionGroups(List<OptionGroupResponse> optionGroups) {
        this.optionGroups = optionGroups;
    }

    

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((businessUnit == null) ? 0 : businessUnit.hashCode());
		result = prime * result + ((communityURL == null) ? 0 : communityURL.hashCode());
		result = prime * result + ((listItems == null) ? 0 : listItems.hashCode());
		result = prime * result + ((marketingProductId == null) ? 0 : marketingProductId.hashCode());
		result = prime * result + ((marketingProductName == null) ? 0 : marketingProductName.hashCode());
		result = prime * result + ((optionGroups == null) ? 0 : optionGroups.hashCode());
		result = prime * result + ((provisioningURL == null) ? 0 : provisioningURL.hashCode());
		result = prime * result + ((serverTypes == null) ? 0 : serverTypes.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ProductResponse other = (ProductResponse) obj;
		if (businessUnit == null) {
			if (other.businessUnit != null)
				return false;
		} else if (!businessUnit.equals(other.businessUnit))
			return false;
		if (communityURL == null) {
			if (other.communityURL != null)
				return false;
		} else if (!communityURL.equals(other.communityURL))
			return false;
		if (listItems == null) {
			if (other.listItems != null)
				return false;
		} else if (!listItems.equals(other.listItems))
			return false;
		if (marketingProductId == null) {
			if (other.marketingProductId != null)
				return false;
		} else if (!marketingProductId.equals(other.marketingProductId))
			return false;
		if (marketingProductName == null) {
			if (other.marketingProductName != null)
				return false;
		} else if (!marketingProductName.equals(other.marketingProductName))
			return false;
		if (optionGroups == null) {
			if (other.optionGroups != null)
				return false;
		} else if (!optionGroups.equals(other.optionGroups))
			return false;
		if (provisioningURL == null) {
			if (other.provisioningURL != null)
				return false;
		} else if (!provisioningURL.equals(other.provisioningURL))
			return false;
		if (serverTypes == null) {
			if (other.serverTypes != null)
				return false;
		} else if (!serverTypes.equals(other.serverTypes))
			return false;
		return true;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }


}
