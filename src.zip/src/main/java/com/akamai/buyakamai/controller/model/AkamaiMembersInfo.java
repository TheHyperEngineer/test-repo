package com.akamai.buyakamai.controller.model;

public class AkamaiMembersInfo {

    private ContactInfo salesRep;

    private ContactInfo se;

    public ContactInfo getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(ContactInfo salesRep) {
        this.salesRep = salesRep;
    }

    public ContactInfo getSe() {
        return se;
    }

    public void setSe(ContactInfo se) {
        this.se = se;
    }
}
