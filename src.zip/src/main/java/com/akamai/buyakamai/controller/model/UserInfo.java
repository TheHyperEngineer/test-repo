package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

public class UserInfo {

	private String contactId;
	
	private String userName;
	
	private String fullName;
	
	private String email;
	
	private String phone;
	
	private String accountId;

	private List<String> roles;
	
	private List<String> scopes;

	private List<BAProperty> properties;

	private Boolean downtime;
	
	private String title;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String downtimeMessage;

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public List<String> getRoles() {
		return roles;
	}

	public void setRoles(List<String> roles) {
		this.roles = roles;
	}

	public List<String> getScopes() {
		return scopes;
	}

	public void setScopes(List<String> scopes) {
		this.scopes = scopes;
	}

	public Boolean getDowntime() {
		return downtime;
	}

	public void isDowntime(Boolean downtime) {
		this.downtime = downtime;
	}

	public String getDowntimeMessage() {
		return downtimeMessage;
	}

	public void setDowntimeMessage(String downtimeMessage) {
		this.downtimeMessage = downtimeMessage;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public List<BAProperty> getProperties() {
		return properties;
	}

	public void setProperties(List<BAProperty> properties) {
		this.properties = properties;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contactId == null) ? 0 : contactId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserInfo other = (UserInfo) obj;
		if (contactId == null) {
			if (other.contactId != null)
				return false;
		} else if (!contactId.equals(other.contactId))
			return false;
		return true;
	}
}
