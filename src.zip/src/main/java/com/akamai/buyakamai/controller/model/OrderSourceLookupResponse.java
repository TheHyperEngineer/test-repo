package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown=true)
public class OrderSourceLookupResponse {

    private String id;
    private String name;
    private String accountId;
    private String currency;
    private String ownerId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String accountType;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String stage;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String closeDate;

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getCloseDate() {
        return closeDate;
    }

    public void setCloseDate(String closeDate) {
        this.closeDate = closeDate;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderSourceLookupResponse response = (OrderSourceLookupResponse) o;

        return id != null ? id.equals(response.id) : response.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "OrderSourceLookupResponse{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", accountId='" + accountId + '\'' +
                ", currency='" + currency + '\'' +
                ", ownerId='" + ownerId + '\'' +
                ", accountType='" + accountType + '\'' +
                ", stage='" + stage + '\'' +
                ", closeDate='" + closeDate + '\'' +
                '}';
    }
}
