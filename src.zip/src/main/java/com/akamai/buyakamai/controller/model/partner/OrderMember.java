package com.akamai.buyakamai.controller.model.partner;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderMember {

    private String role;

    private String contactId;

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    @Override
    public String toString() {
        return "OrderMember{" +
                "role='" + role + '\'' +
                ", contactId='" + contactId + '\'' +
                '}';
    }
}
