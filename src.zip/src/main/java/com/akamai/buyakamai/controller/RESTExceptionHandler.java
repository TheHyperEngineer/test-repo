package com.akamai.buyakamai.controller;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.util.HTTPResponseCodes;
import com.akamai.buyakamai.util.PulsarUrlBuilder;
import com.akamai.se.dto.problem.Problem;
import com.akamai.se.dto.problem.ProblemBuilder;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

/**
 * Any exception which goes out of the resource gets handled here.
 * 
 * @author vineek
 */

@ControllerAdvice
public class RESTExceptionHandler extends ResponseEntityExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(RESTExceptionHandler.class);

    public static final Map<HttpStatus, String> statusCodeTypeMap = new HashMap<HttpStatus, String>();
    static {
        statusCodeTypeMap.put(HttpStatus.INTERNAL_SERVER_ERROR, "/v1/error-types/E500");
        statusCodeTypeMap.put(HttpStatus.BAD_REQUEST, "/v1/error-types/E400");
        statusCodeTypeMap.put(HttpStatus.NOT_FOUND, "/v1/error-types/E404");
        statusCodeTypeMap.put(HttpStatus.UNAUTHORIZED, "/v1/error-types/E401");
        statusCodeTypeMap.put(HttpStatus.FORBIDDEN, "v1/error-types/E403");
    }
    
    private static final String HTTP_STATUS_ERROR = "Http Status error response ";

    @Override
    public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException exception,
            HttpHeaders headers, HttpStatus status, WebRequest request) {
        String message = "Unacceptable JSON " + exception.getMessage();
        Throwable cause = exception.getCause();
        ProblemBuilder builder = buildProblem(status).detail(message);

        if (cause instanceof InvalidFormatException) {
            InvalidFormatException er = (InvalidFormatException) cause;
            builder = builder.withExtension("field", er.getValue());
        }

        logger.warn(message);
        Problem problem = builder.build();
        logger.warn("problem instance id " + problem.getProblemId());
        return handle(exception, HttpStatus.BAD_REQUEST, problem);
    }

    
    @ExceptionHandler(BuyAkamaiApplicationException.class)
    public ResponseEntity<Problem> handleMarketplaceApplicationException(BuyAkamaiApplicationException exception) {
		logger.info("Building error response for BuyAkamaiApplicationException");

		HTTPResponseCodes httpResponseCode;
		String title;
		String detail;
		Problem problem;

		if (exception.getProblem() != null) {
			problem = exception.getProblem();
		} else {
			title = exception.getTitle() == null ? exception.getHttpStatus().name() : exception.getTitle();
			detail = exception.getDetails() == null ? exception.getHttpStatus().getReasonPhrase()
			        : exception.getDetails();

			if (EnumUtils.isValidEnum(HTTPResponseCodes.class, exception.getHttpStatus().name())) {
				httpResponseCode = HTTPResponseCodes.valueOf(exception.getHttpStatus().name());
			} else {
				httpResponseCode = HTTPResponseCodes.INTERNAL_SERVER_ERROR;
				exception.setHttpStatus(HttpStatus.INTERNAL_SERVER_ERROR);
			}
			Map<String, Object> extendedErrorKey = new HashMap<>();
			if (StringUtils.isNotBlank(exception.getErrorKey())) {
				extendedErrorKey.put("errorKey", exception.getErrorKey());
			}
			if (exception.getErrorData() != null && !exception.getErrorData().isEmpty()) {
				extendedErrorKey.put("errorData", exception.getErrorData());
			}
			if (extendedErrorKey.isEmpty()) {
				extendedErrorKey = null;
			}
			problem = new ProblemBuilder().title(title).detail(detail)
			        .type(PulsarUrlBuilder.path(httpResponseCode.getStatusTitle()).toUriString())
			        .status(exception.getHttpStatus().value()).extensionFields(extendedErrorKey)
			        .appendProblemIdToInstance().build();
		}
		return new ResponseEntity<>(problem, exception.getHttpStatus());
	}

    /**
     * Default handler for exceptions.
     * 
     * @param exception
     * @return
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleException(Exception exception) {
        logger.error("Internal Server Exception", exception);
        Problem problem = buildProblem(HttpStatus.INTERNAL_SERVER_ERROR).detail(exception.getMessage()).build();
        logger.warn("problem instance id " + problem.getProblemId());
        return handle(exception, HttpStatus.INTERNAL_SERVER_ERROR, problem);
    }

    protected ResponseEntity<Object> handle(Exception exception, HttpStatus status, Problem problem) {
        return handleExceptionInternal(exception, problem, null, status, null);
    }

    /*
     * We need to send out our own representation instead of spring's
     * 
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception exception, Object body, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        MultiValueMap<String, String> headerMap = new LinkedMultiValueMap<String, String>();
        headerMap.put(HttpHeaders.CONTENT_TYPE, Collections.singletonList(BAConstants.MEDIATYPE_PROBLEM_JSON));
        if (body == null) {
            // Since we always need to send the body. this is an unexpected exception, maybe spring handled it?, wrap it a Problem object.
            logger.error(" Got unexpected error ", exception);
            body = buildProblem(status).detail(exception.getMessage()).build();
        }
        return new ResponseEntity<Object>(body, headerMap, status);
    }

    private ProblemBuilder buildProblem(HttpStatus httpStatus) {
        ProblemBuilder problemBuilder = new ProblemBuilder().type(statusCodeTypeMap.get(httpStatus)).status(httpStatus
                .value()).title(httpStatus.getReasonPhrase()).appendProblemIdToInstance(
                        BAConstants.PROBLEM_INSTANCE_PREFIX);
        return problemBuilder;
    }
    
    @ExceptionHandler({ MethodArgumentTypeMismatchException.class })
    public ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex) {

    	logger.info("Building error response for MethodArgumentTypeMismatchException");
    	 String type = PulsarUrlBuilder.path(HTTPResponseCodes.BAD_REQUEST.getStatusTitle()).toUriString();
    	 
    	Problem problem = new ProblemBuilder().type(type)
    			.title(HTTP_STATUS_ERROR + HttpStatus.BAD_REQUEST)
    			.status(HttpStatus.BAD_REQUEST.value())
    			.detail(ex.getName() + " should be of type " + ex.getRequiredType().getName())
    			.appendProblemIdToInstance().build();
    	return new ResponseEntity<>(problem, HttpStatus.BAD_REQUEST);
    }
}