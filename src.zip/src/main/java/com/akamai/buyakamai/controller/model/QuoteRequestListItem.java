package com.akamai.buyakamai.controller.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.validator.constraints.NotBlank;

import com.akamai.buyakamai.integration.model.productmaster.TierDTO;

public class QuoteRequestListItem {

	@Valid
	@NotBlank(message="ListItemId cannot be empty")
	private String listItemId;

	@NotBlank(message="PricingMethod cannot be empty")
	private String pricingMethod;

	@NotBlank(message="UsageMethod cannot be empty")
	private String usageMethod;
	
	@Pattern(regexp="\\d+"  ,message ="Quantity should be specified in postive numbers")
	private String quantity;
	
	@NotBlank(message="UOM cannot be empty")
	private String uom;
	
	@NotBlank(message="billingFrequency cannot be empty")
	private String billingFrequency;

	@NotBlank(message="ChargeType cannot be empty")
	private String chargeType;
	
	@Valid
	private List<TierDTO> tiers;

	public String getListItemId() {
		return listItemId;
	}

	public void setListItemId(String listItemId) {
		this.listItemId = listItemId;
	}

	public String getPricingMethod() {
		return pricingMethod;
	}

	public void setPricingMethod(String pricingMethod) {
		this.pricingMethod = pricingMethod;
	}

	public String getUsageMethod() {
		return usageMethod;
	}

	public void setUsageMethod(String usageMethod) {
		this.usageMethod = usageMethod;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getBillingFrequency() {
		return billingFrequency;
	}

	public void setBillingFrequency(String billingFrequency) {
		this.billingFrequency = billingFrequency;
	}

	public String getChargeType() {
		return chargeType;
	}

	public void setChargeType(String chargeType) {
		this.chargeType = chargeType;
	}

	public List<TierDTO> getTiers() {
		return tiers;
	}

	public void setTiers(List<TierDTO> tiers) {
		this.tiers = tiers;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((billingFrequency == null) ? 0 : billingFrequency.hashCode());
		result = prime * result + ((chargeType == null) ? 0 : chargeType.hashCode());
		result = prime * result + ((listItemId == null) ? 0 : listItemId.hashCode());
		result = prime * result + ((pricingMethod == null) ? 0 : pricingMethod.hashCode());
		result = prime * result + ((quantity == null) ? 0 : quantity.hashCode());
		result = prime * result + ((tiers == null) ? 0 : tiers.hashCode());
		result = prime * result + ((uom == null) ? 0 : uom.hashCode());
		result = prime * result + ((usageMethod == null) ? 0 : usageMethod.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuoteRequestListItem other = (QuoteRequestListItem) obj;
		if (billingFrequency == null) {
			if (other.billingFrequency != null)
				return false;
		} else if (!billingFrequency.equals(other.billingFrequency))
			return false;
		if (chargeType == null) {
			if (other.chargeType != null)
				return false;
		} else if (!chargeType.equals(other.chargeType))
			return false;
		if (listItemId == null) {
			if (other.listItemId != null)
				return false;
		} else if (!listItemId.equals(other.listItemId))
			return false;
		if (pricingMethod == null) {
			if (other.pricingMethod != null)
				return false;
		} else if (!pricingMethod.equals(other.pricingMethod))
			return false;
		if (quantity == null) {
			if (other.quantity != null)
				return false;
		} else if (!quantity.equals(other.quantity))
			return false;
		if (uom == null) {
			if (other.uom != null)
				return false;
		} else if (!uom.equals(other.uom))
			return false;
		if (usageMethod == null) {
			if (other.usageMethod != null)
				return false;
		} else if (!usageMethod.equals(other.usageMethod))
			return false;
		return true;
	}


	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
