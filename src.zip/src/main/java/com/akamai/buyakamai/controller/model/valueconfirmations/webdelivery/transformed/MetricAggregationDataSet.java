package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

import java.util.List;

public class MetricAggregationDataSet {

    private List<MetricAggregationPoint> origin;
    private List<MetricAggregationPoint> akamai;

    public List<MetricAggregationPoint> getOrigin() {
        return origin;
    }

    public void setOrigin(List<MetricAggregationPoint> origin) {
        this.origin = origin;
    }

    public List<MetricAggregationPoint> getAkamai() {
        return akamai;
    }

    public void setAkamai(List<MetricAggregationPoint> akamai) {
        this.akamai = akamai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MetricAggregationDataSet that = (MetricAggregationDataSet) o;

        if (origin != null ? !origin.equals(that.origin) : that.origin != null) return false;
        return akamai != null ? akamai.equals(that.akamai) : that.akamai == null;
    }

    @Override
    public int hashCode() {
        int result = origin != null ? origin.hashCode() : 0;
        result = 31 * result + (akamai != null ? akamai.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "MetricAggregationDataSet{" +
                "origin=" + origin +
                ", akamai=" + akamai +
                '}';
    }
}
