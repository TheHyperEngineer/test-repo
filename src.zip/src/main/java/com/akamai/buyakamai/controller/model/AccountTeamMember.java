package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.integration.clients.model.Contact;

import java.util.List;

public class AccountTeamMember {

    private String roleName;
    private List<Contact> contacts;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccountTeamMember that = (AccountTeamMember) o;

        if (roleName != null ? !roleName.equals(that.roleName) : that.roleName != null) return false;
        return contacts != null ? contacts.equals(that.contacts) : that.contacts == null;
    }

    @Override
    public int hashCode() {
        int result = roleName != null ? roleName.hashCode() : 0;
        result = 31 * result + (contacts != null ? contacts.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AccountTeamMember{" +
                "roleName='" + roleName + '\'' +
                ", contacts=" + contacts +
                '}';
    }
}
