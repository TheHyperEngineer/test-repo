package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown=true)
public class BasicOrderResponse {

    Integer orderId;
    String accountId;
    String partnerAccountId;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getPartnerAccountId() {
        return partnerAccountId;
    }

    public void setPartnerAccountId(String partnerAccountId) {
        this.partnerAccountId = partnerAccountId;
    }

    @Override
    public String toString() {
        return "BasicOrderResponse{" +
                "orderId=" + orderId +
                ", accountId='" + accountId + '\'' +
                ", partnerAccountId='" + partnerAccountId + '\'' +
                '}';
    }
}
