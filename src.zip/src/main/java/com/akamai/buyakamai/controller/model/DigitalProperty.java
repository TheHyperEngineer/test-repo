package com.akamai.buyakamai.controller.model;

import java.util.Objects;
import java.util.Optional;

import com.akamai.buyakamai.service.dns.DNSResolution;

/**
 * Enhanced com.akamai.se.domain.site.DigitalProperty with resolutions
 * 
 * @author jplans
 *
 */
public class DigitalProperty {

	/** Property hostName */
	private String hostName;

	/** Property fileName */
	private String fileName;

	/** Property fileVersion */
	private long fileVersion;

	/** Property network */
	private String network;

	/** Property propertyName */
	private String propertyName;

	/** Property propertyType */
	private String propertyType;

	/** Property resolution */
	private Optional<DNSResolution> resolution;

	/**
	 * Constructor
	 */
	public DigitalProperty() {
	}

	/**
	 * Builds the object based on a com.akamai.se.domain.site.DigitalProperty and available resolutions
	 * 
	 * @param dto
	 */
	public DigitalProperty(com.akamai.se.domain.site.DigitalProperty dto) {
		this.fileName = dto.getFileName();
		this.fileVersion = dto.getFileVersion();
		this.hostName = dto.getHostname();
		this.network = dto.getNetwork();
		this.propertyName = dto.getPropertyName();
		this.propertyType = dto.getPropertyType();
		this.resolution = Optional.empty();
	}

	/**
	 * Gets the hostName
	 */
	public String getHostName() {
		return this.hostName;
	}

	/**
	 * Sets the hostName
	 */
	public void setHostName(String value) {
		this.hostName = value;
	}

	/**
	 * Gets the fileName
	 */
	public String getFileName() {
		return this.fileName;
	}

	/**
	 * Sets the fileName
	 */
	public void setFileName(String value) {
		this.fileName = value;
	}

	/**
	 * Gets the fileVersion
	 */
	public long getFileVersion() {
		return this.fileVersion;
	}

	/**
	 * Sets the fileVersion
	 */
	public void setFileVersion(long value) {
		this.fileVersion = value;
	}

	/**
	 * Gets the network
	 */
	public String getNetwork() {
		return this.network;
	}

	/**
	 * Sets the network
	 */
	public void setNetwork(String value) {
		this.network = value;
	}

	/**
	 * Gets the propertyName
	 */
	public String getPropertyName() {
		return this.propertyName;
	}

	/**
	 * Sets the propertyName
	 */
	public void setPropertyName(String value) {
		this.propertyName = value;
	}

	/**
	 * Gets the propertyType
	 */
	public String getPropertyType() {
		return this.propertyType;
	}

	/**
	 * Sets the propertyType
	 */
	public void setPropertyType(String value) {
		this.propertyType = value;
	}

	/**
	 * Gets the resolution
	 */
	public Optional<DNSResolution> getResolution() {
		return this.resolution;
	}

	/**
	 * Sets the propertyType
	 */
	public void setResolution(DNSResolution value) {
		this.resolution = value == null ? Optional.empty() : Optional.of(value);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fileName == null) ? 0 : fileName.hashCode());
		result = prime * result + ((hostName == null) ? 0 : hostName.hashCode());
		result = prime * result + ((network == null) ? 0 : network.hashCode());
		result = prime * result + Long.hashCode(fileVersion);
		result = prime * result + ((propertyType == null) ? 0 : propertyType.hashCode());
		result = prime * result + ((propertyName == null) ? 0 : propertyName.hashCode());
		result = prime * result + ((resolution == null) ? 0 : resolution.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		DigitalProperty other = (DigitalProperty) obj;

		if(!Objects.equals(fileName, other.fileName)) {
			return false;
		}
		if(!Objects.equals(hostName, other.hostName)) {
			return false;
		}
		if(!Objects.equals(network, other.network)) {
			return false;
		}if(!Objects.equals(fileVersion, other.fileVersion)) {
			return false;
		}if(!Objects.equals(propertyType, other.propertyType)) {
			return false;
		}
		if(!Objects.equals(propertyName, other.propertyName)) {
			return false;
		}
		if(!Objects.equals(resolution, other.resolution)) {
			return false;
		}

		return true;
	}
}
