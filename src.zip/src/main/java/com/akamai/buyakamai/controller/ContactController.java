package com.akamai.buyakamai.controller;


import com.akamai.buyakamai.controller.model.ContactRegistrationDto;
import com.akamai.buyakamai.integration.model.dash.ContactCreationResponse;
import com.akamai.buyakamai.integration.model.dash.ContactUiMetaDataResponse;
import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.akamai.buyakamai.service.impl.ContactServiceImpl;
import com.akamai.buyakamai.util.RequestFetcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@EnableAutoConfiguration
public class ContactController {

    @Autowired
    private ContactServiceImpl contactService;

    @Autowired
    private RequestFetcher requestFetcher;

    @Autowired
    private BACoreAPIServiceImpl baCoreAPIService;

    private static final Logger logger = LoggerFactory.getLogger(ContactController.class);

    @RequestMapping(value = "v1/contacts/register", method = RequestMethod.POST)
    public ResponseEntity<String> registerContact(@RequestBody ContactRegistrationDto contactRegistrationDto) {
        logger.info("Inside register contact creation with request {}", contactRegistrationDto);
        List<String> roles = requestFetcher.getLoggedInUserRoles();
        String accountId = requestFetcher.getDefaultAccountId();
        String response = contactService.registerContact(contactRegistrationDto, roles, accountId);
        return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    }

    @RequestMapping(value = "/v1/contacts/ui-meta-data", method = RequestMethod.GET)
    public ResponseEntity<ContactUiMetaDataResponse> getContactsUiMetadata() throws Exception{
        ContactUiMetaDataResponse response = contactService.getContactsUIMetaData();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PostMapping(value = "/v4/accounts/{accountId}/contacts", produces = "application/json;charset=UTF-8")
    public ResponseEntity<ContactCreationResponse> createContactForAccount(@Valid @PathVariable String accountId,
                                                                           @RequestBody ContactRegistrationDto contactCreationRequestDTO) {

        logger.info("Creating Contact for accountId {}", accountId);
        ContactCreationResponse contact = baCoreAPIService.createContact(accountId, contactCreationRequestDTO);
        return new ResponseEntity<>(contact, HttpStatus.CREATED);
    }
}
