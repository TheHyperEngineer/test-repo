package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class MarketplaceExtensionRequest {

    private int freeDays;

    private String reason;

    private String createdByUserName;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private List<String> contactIds;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean tncAccepted;

    public Boolean getTncAccepted() {
        return tncAccepted;
    }

    public void isTncAccepted(Boolean tncAccepted) {
        this.tncAccepted = tncAccepted;
    }

    public int getFreeDays() {
        return freeDays;
    }

    public void setFreeDays(int freeDays) {
        this.freeDays = freeDays;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getCreatedByUserName() {
        return createdByUserName;
    }

    public void setCreatedByUserName(String createdByUserName) {
        this.createdByUserName = createdByUserName;
    }
    
	public List<String> getContactIds() {
		return contactIds;
	}

	public void setContactIds(List<String> contactIds) {
		this.contactIds = contactIds;
	}

	@Override
    public String toString() {
        return "MarketplaceExtensionRequest{" +
                "freeDays=" + freeDays +
                '}';
    }
}
