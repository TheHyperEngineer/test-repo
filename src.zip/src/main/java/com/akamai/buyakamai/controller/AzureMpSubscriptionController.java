package com.akamai.buyakamai.controller;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.controller.model.AzureMpOperationList;
import com.akamai.buyakamai.controller.model.AzureOperationUpdateRequest;
import com.akamai.buyakamai.controller.model.AzureSubscriptionRequest;
import com.akamai.buyakamai.integration.service.impl.AzureMpServiceImpl;

@RestController
@EnableAutoConfiguration
public class AzureMpSubscriptionController {
	private static final Logger logger = LoggerFactory.getLogger(AzureMpSubscriptionController.class);

    @Autowired
    private AzureMpServiceImpl azureMpServiceImpl;

	@RequestMapping(value = "/v1/azure-mp/subscriptions/{subscriptionId}/activate", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseEntity<?> activateSubscription(@PathVariable @Valid @NotNull String subscriptionId,
			@RequestBody AzureSubscriptionRequest azureSubscriptionRequest) {

		logger.info("Received activation request for subscription id: " + subscriptionId);
		azureMpServiceImpl.activateSubscription(subscriptionId, azureSubscriptionRequest);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/v1/azure-mp/subscriptions/{subscriptionId}/operations", method = RequestMethod.GET, produces = "application/json")
	public ResponseEntity<AzureMpOperationList> getOpenOperationsForSubscription(
			@PathVariable @Valid @NotNull String subscriptionId) {

		AzureMpOperationList response = azureMpServiceImpl.getOpenOperationsForSubscription(subscriptionId);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "/v1/azure-mp/subscriptions/{subscriptionId}/operations/{operationId}", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity<?> updateOperation(@PathVariable @Valid @NotNull String subscriptionId,
			@PathVariable @Valid @NotNull String operationId,
			@RequestBody AzureOperationUpdateRequest azureOperationUpdateRequest) {

		azureMpServiceImpl.updateOperation(subscriptionId, operationId, azureOperationUpdateRequest);
		return ResponseEntity.status(HttpStatus.OK).build();
	}

	@RequestMapping(value = "/v1/azure-mp/subscriptions/{subscriptionId}", method = RequestMethod.PUT, produces = "application/json")
	public ResponseEntity<?> updateSubscription(@PathVariable @Valid @NotNull String subscriptionId,
			@RequestBody AzureSubscriptionRequest azureSubscriptionRequest) {

		azureMpServiceImpl.updateSubscription(subscriptionId, azureSubscriptionRequest);
		return ResponseEntity.status(HttpStatus.OK).build();
	}
}
