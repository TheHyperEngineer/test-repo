package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

import java.util.List;

public class HistogramDataSetCollection {
    List<HistogramPoint> origin;
    List<HistogramPoint> akamai;

    public List<HistogramPoint> getOrigin() {
        return origin;
    }

    public void setOrigin(List<HistogramPoint> origin) {
        this.origin = origin;
    }

    public List<HistogramPoint> getAkamai() {
        return akamai;
    }

    public void setAkamai(List<HistogramPoint> akamai) {
        this.akamai = akamai;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HistogramDataSetCollection that = (HistogramDataSetCollection) o;

        if (origin != null ? !origin.equals(that.origin) : that.origin != null) return false;
        return akamai != null ? akamai.equals(that.akamai) : that.akamai == null;
    }

    @Override
    public int hashCode() {
        int result = origin != null ? origin.hashCode() : 0;
        result = 31 * result + (akamai != null ? akamai.hashCode() : 0);
        return result;
    }
}
