package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.ValueConfirmationHeaderConstants;
import com.akamai.buyakamai.controller.model.valueconfirmations.WebDeliveryRequestModel;
import com.akamai.buyakamai.service.valueconfirmations.reportfetcher.ValueConfirmationReportFetcher;
import com.akamai.buyakamai.service.valueconfirmations.registers.WebDeliveryValueConfirmations;
import com.akamai.buyakamai.util.RequestFetcher;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.net.URI;

@RestController
@EnableAutoConfiguration
@RequestMapping(value = "v1/reports/value-confirmation")
public class ValueConfirmationController {

    @Autowired
    private WebDeliveryValueConfirmations webDeliveryValueConfirmations;

    @Autowired
    private ValueConfirmationReportFetcher valueConfirmationReportFetcher;

    @Autowired
    private RequestFetcher requestFetcher;

    private static final Logger logger = LoggerFactory.getLogger(ValueConfirmationController.class);

    @RequestMapping(value = "/report-request", method = RequestMethod.POST, headers = ValueConfirmationHeaderConstants.WEB_DELIVERY_REPORT_REQUEST)
    public ResponseEntity requestValueConfirmationForWebDelivery(@RequestBody WebDeliveryRequestModel requestModel) {
        String userName = requestFetcher.getUserName();
        String productType = requestFetcher.getHeader("Product-Type");
        Integer valueConfirmationId = webDeliveryValueConfirmations.createValueConfirmationRequest(userName, requestModel, productType);
        HttpHeaders responseHeaders = new HttpHeaders();
        try {
            String uriLocation = "/buy-akamai-api/v1/reports/value-confirmation/" + valueConfirmationId;
            responseHeaders.setLocation(new URI(uriLocation));
        } catch (Exception e) {
            logger.debug("Exception while creating URI location header for value confirmation Id {}", valueConfirmationId);
        }
        return new ResponseEntity<>(responseHeaders, HttpStatus.CREATED);
    }

    @RequestMapping(value = "/{valueConfirmationId}/report-type/{reportType}", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<String> getReport(@Valid @PathVariable Integer valueConfirmationId, @Valid @PathVariable String reportType) {

        String response = valueConfirmationReportFetcher.getReport(valueConfirmationId, reportType);
        if (StringUtils.isEmpty(response)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
