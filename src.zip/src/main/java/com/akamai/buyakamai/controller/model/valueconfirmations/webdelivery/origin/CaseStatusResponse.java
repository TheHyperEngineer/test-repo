package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.origin;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CaseStatusResponse {

    @JsonProperty("Status_txt")
    private String status;

    @JsonProperty("Product")
    private String product;

    @JsonProperty("Assigned_To")
    private String assignee;

    @JsonProperty("is_test_setup")
    private Boolean isTestSetUp ;

    @JsonProperty("RR_ID")
    private String caseId;


    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getAssignee() {
        return assignee;
    }

    public void setAssignee(String assignee) {
        this.assignee = assignee;
    }

    public Boolean getTestSetUp() {
        return isTestSetUp;
    }

    public void setTestSetUp(Boolean testSetUp) {
        isTestSetUp = testSetUp;
    }

    public String getCaseId() {
        return caseId;
    }

    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        CaseStatusResponse that = (CaseStatusResponse) o;

        return caseId != null ? caseId.equals(that.caseId) : that.caseId == null;
    }

    @Override
    public int hashCode() {
        return caseId != null ? caseId.hashCode() : 0;
    }

}
