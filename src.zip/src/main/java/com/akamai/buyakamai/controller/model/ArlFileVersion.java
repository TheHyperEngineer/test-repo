package com.akamai.buyakamai.controller.model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import org.apache.commons.lang.builder.ToStringBuilder;

import com.akamai.buyakamai.integration.clients.model.CustomARLFileVersion;
import com.akamai.buyakamai.service.dns.DNSCategorizedResolution;

/**
 * 
 * Enhanced com.akamai.se.domain.property.ArlFileVersion with DNSResolution
 * @author jplans
 *
 */
public class ArlFileVersion {
	/** Property fileVersion */
	private Integer fileVersion;

	/** Property arlFileHosts */
	private List<ArlFileHost> arlFileHosts;

	/** Property isActivatedOnProduction */
	private Boolean isActivatedOnProduction;

	/** Property isActivatedOnStaging */
	private Boolean isActivatedOnStaging;

	/** Property isDeleted */
	private Boolean isDeleted;

	/** Property comments */
	private String comments;

	/** Property arlConfigType */
	private String arlConfigType;

	/** Property quickstartVersion */
	private Integer quickstartVersion;

	/**
	 * Constructor
	 */
	public ArlFileVersion() {
	}

	/**
	 * Constructor
	 */
	public ArlFileVersion(CustomARLFileVersion other) {

		fileVersion = other.getFileVersion();
		arlFileHosts = new ArrayList<ArlFileHost>();
		other.getArlFileHosts().forEach(afhost -> arlFileHosts.add(new ArlFileHost(afhost)));

		isActivatedOnProduction = other.isActivatedOnProduction();
		isActivatedOnStaging = other.isActivatedOnStaging();
		isDeleted = other.isDeleted();
		comments = other.getComments();
		arlConfigType = other.getArlConfigType();
		quickstartVersion = other.getQuickstartVersion();
	}

	/**
	 * Builds the object based on a com.akamai.se.domain.property.ArlFileVersion and available resolutions
	 * @param other
	 * @param resolutions
	 */
	public ArlFileVersion(CustomARLFileVersion other,
			Map<String, DNSCategorizedResolution> resolutions) {

		fileVersion = other.getFileVersion();
		arlFileHosts = new ArrayList<ArlFileHost>();
		other.getArlFileHosts().forEach(afHost -> arlFileHosts.add(new ArlFileHost(afHost, resolutions)));
		
		isActivatedOnProduction = other.isActivatedOnProduction();
		isActivatedOnStaging = other.isActivatedOnStaging();
		isDeleted = other.isDeleted();
		comments = other.getComments();
		arlConfigType = other.getArlConfigType();
		quickstartVersion = other.getQuickstartVersion();
	}

	/**
	 * Gets the fileVersion
	 */
	public Integer getFileVersion() {
		return this.fileVersion;
	}

	/**
	 * Sets the fileVersion
	 */
	public void setFileVersion(Integer value) {
		this.fileVersion = value;
	}

	/**
	 * Gets the arlFileHosts
	 */
	public List<ArlFileHost> getArlFileHosts() {
		return this.arlFileHosts;
	}

	/**
	 * Sets the arlFileHosts
	 */
	public void setArlFileHosts(List<ArlFileHost> value) {
		this.arlFileHosts = value;
	}

	/**
	 * Gets the isActivatedOnProduction
	 */
	public Boolean getIsActivatedOnProduction() {
		return this.isActivatedOnProduction;
	}

	/**
	 * Sets the isActivatedOnProduction
	 */
	public void setIsActivatedOnProduction(Boolean value) {
		this.isActivatedOnProduction = value;
	}

	/**
	 * Gets the isActivatedOnStaging
	 */
	public Boolean getIsActivatedOnStaging() {
		return this.isActivatedOnStaging;
	}

	/**
	 * Sets the isActivatedOnStaging
	 */
	public void setIsActivatedOnStaging(Boolean value) {
		this.isActivatedOnStaging = value;
	}

	/**
	 * Gets the isDeleted
	 */
	public Boolean getIsDeleted() {
		return this.isDeleted;
	}

	/**
	 * Sets the isDeleted
	 */
	public void setIsDeleted(Boolean value) {
		this.isDeleted = value;
	}

	/**
	 * Gets the comments
	 */
	public String getComments() {
		return this.comments;
	}

	/**
	 * Sets the comments
	 */
	public void setComments(String value) {
		this.comments = value;
	}

	/**
	 * Gets the arlConfigType
	 */
	public String getArlConfigType() {
		return this.arlConfigType;
	}

	/**
	 * Sets the arlConfigType
	 */
	public void setArlConfigType(String value) {
		this.arlConfigType = value;
	}

	/**
	 * Gets the quickstartVersion
	 */
	public Integer getQuickstartVersion() {
		return this.quickstartVersion;
	}

	/**
	 * Sets the quickstartVersion
	 */
	public void setQuickstartVersion(Integer value) {
		this.quickstartVersion = value;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Long.hashCode(fileVersion);
		result = prime * result + ((arlFileHosts == null) ? 0 : arlFileHosts.hashCode());
		result = prime * result + ((isActivatedOnProduction == null) ? 0 : isActivatedOnProduction.hashCode());
		result = prime * result + ((isActivatedOnStaging == null) ? 0 : isActivatedOnStaging.hashCode());
		result = prime * result + ((isDeleted == null) ? 0 : isDeleted.hashCode());
		result = prime * result + ((comments == null) ? 0 : comments.hashCode());
		result = prime * result + ((arlConfigType == null) ? 0 : arlConfigType.hashCode());
		result = prime * result + ((quickstartVersion == null) ? 0 : quickstartVersion.hashCode());

		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		ArlFileVersion other = (ArlFileVersion) obj;
		if(!Objects.equals(fileVersion, other.fileVersion)) {
			return false;
		}
		if (!Objects.deepEquals(arlFileHosts, other.arlFileHosts)) {
			return false;
		}

		if(!Objects.equals(isActivatedOnProduction, other.isActivatedOnProduction)) {
			return false;
		}

		if(!Objects.equals(isActivatedOnStaging, other.isActivatedOnStaging)) {
			return false;
		}

		if(!Objects.equals(isDeleted, other.isDeleted)) {
			return false;
		}

		if(!Objects.equals(comments, other.comments)) {
			return false;
		}

		if(!Objects.equals(arlConfigType, other.arlConfigType)) {
			return false;
		}

		if(!Objects.equals(quickstartVersion, other.quickstartVersion)) {
			return false;
		}

		return true;
	}
}