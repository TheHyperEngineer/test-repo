package com.akamai.buyakamai.controller.model;

import java.util.List;

public class EventResponse {

    private String fromTimestamp;

    private String toTimestamp;
    private List<EventData> events;

    public String getFromTimestamp() {
        return fromTimestamp;
    }

    public void setFromTimestamp(String fromTimestamp) {
        this.fromTimestamp = fromTimestamp;
    }

    public String getToTimestamp() {
        return toTimestamp;
    }

    public void setToTimestamp(String toTimestamp) {
        this.toTimestamp = toTimestamp;
    }

    public List<EventData> getEvents() {
        return events;
    }

    public void setEvents(List<EventData> events) {
        this.events = events;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EventResponse that = (EventResponse) o;

        if (fromTimestamp != null ? !fromTimestamp.equals(that.fromTimestamp) : that.fromTimestamp != null)
            return false;
        if (toTimestamp != null ? !toTimestamp.equals(that.toTimestamp) : that.toTimestamp != null) return false;
        return events != null ? events.equals(that.events) : that.events == null;
    }

    @Override
    public int hashCode() {
        int result = fromTimestamp != null ? fromTimestamp.hashCode() : 0;
        result = 31 * result + (toTimestamp != null ? toTimestamp.hashCode() : 0);
        result = 31 * result + (events != null ? events.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "EventResponse{" +
                "fromTimestamp='" + fromTimestamp + '\'' +
                ", toTimestamp='" + toTimestamp + '\'' +
                ", events=" + events +
                '}';
    }
}
