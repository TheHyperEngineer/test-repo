package com.akamai.buyakamai.controller.model;

import java.util.Set;

public class UserSelectRequest {

    private Set<String> userIds;

    public Set<String> getUserIds() {
        return userIds;
    }

    public void setUserIds(Set<String> userIds) {
        this.userIds = userIds;
    }

    @Override
    public String toString() {
        return "UserSelectRequest{" +
                "userIds=" + userIds +
                '}';
    }
}
