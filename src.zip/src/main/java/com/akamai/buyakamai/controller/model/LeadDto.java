package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.integration.clients.model.CustomerOrderSourceDto;
import com.akamai.buyakamai.integration.clients.model.SalesRepOrderSourceDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LeadDto {

    private String id;
    private String name;
    private String currency;
    private String salesForceUrl;
    private String dealType;
    private String productName;
    private String date;
    private String bundleId;
    private String accountType;
    private CustomerOrderSourceDto customer;
    private String createdBySource;
    private String orderRegion;
    private String leadOwner;
	private SalesRepOrderSourceDto salesRep;
	
	@JsonInclude(JsonInclude.Include.NON_EMPTY)
	private Boolean owner;
	
	public Boolean getOwner() {
		return owner;
	}

	public void setOwner(Boolean owner) {
		this.owner = owner;
	}

	public SalesRepOrderSourceDto getSalesRep() {
		return salesRep;
	}

	public void setSalesRep(SalesRepOrderSourceDto salesRep) {
		this.salesRep = salesRep;
	}
	
	public String getLeadOwner() {
		return leadOwner;
	}
	public void setLeadOwner(String leadOwner) {
		this.leadOwner = leadOwner;
	}
	public String getOrderRegion() {
		return orderRegion;
	}
	public void setOrderRegion(String orderRegion) {
		this.orderRegion = orderRegion;
	}
	public String getCreatedBySource() {
		return createdBySource;
	}
	public void setCreatedBySource(String createdBySource) {
		this.createdBySource = createdBySource;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getSalesForceUrl() {
		return salesForceUrl;
	}
	public void setSalesForceUrl(String salesForceUrl) {
		this.salesForceUrl = salesForceUrl;
	}
	public String getDealType() {
		return dealType;
	}
	public void setDealType(String dealType) {
		this.dealType = dealType;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getBundleId() {
		return bundleId;
	}
	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public CustomerOrderSourceDto getCustomer() {
		return customer;
	}
	public void setCustomer(CustomerOrderSourceDto customer) {
		this.customer = customer;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountType == null) ? 0 : accountType.hashCode());
		result = prime * result + ((bundleId == null) ? 0 : bundleId.hashCode());
		result = prime * result + ((createdBySource == null) ? 0 : createdBySource.hashCode());
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + ((dealType == null) ? 0 : dealType.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((leadOwner == null) ? 0 : leadOwner.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + ((orderRegion == null) ? 0 : orderRegion.hashCode());
		result = prime * result + ((owner == null) ? 0 : owner.hashCode());
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + ((salesForceUrl == null) ? 0 : salesForceUrl.hashCode());
		result = prime * result + ((salesRep == null) ? 0 : salesRep.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LeadDto other = (LeadDto) obj;
		if (accountType == null) {
			if (other.accountType != null)
				return false;
		} else if (!accountType.equals(other.accountType))
			return false;
		if (bundleId == null) {
			if (other.bundleId != null)
				return false;
		} else if (!bundleId.equals(other.bundleId))
			return false;
		if (createdBySource == null) {
			if (other.createdBySource != null)
				return false;
		} else if (!createdBySource.equals(other.createdBySource))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (dealType == null) {
			if (other.dealType != null)
				return false;
		} else if (!dealType.equals(other.dealType))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (leadOwner == null) {
			if (other.leadOwner != null)
				return false;
		} else if (!leadOwner.equals(other.leadOwner))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (orderRegion == null) {
			if (other.orderRegion != null)
				return false;
		} else if (!orderRegion.equals(other.orderRegion))
			return false;
		if (owner == null) {
			if (other.owner != null)
				return false;
		} else if (!owner.equals(other.owner))
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (salesForceUrl == null) {
			if (other.salesForceUrl != null)
				return false;
		} else if (!salesForceUrl.equals(other.salesForceUrl))
			return false;
		if (salesRep == null) {
			if (other.salesRep != null)
				return false;
		} else if (!salesRep.equals(other.salesRep))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "LeadDto [id=" + id + ", name=" + name + ", currency=" + currency + ", salesForceUrl=" + salesForceUrl
				+ ", dealType=" + dealType + ", productName=" + productName + ", date=" + date + ", bundleId="
				+ bundleId + ", accountType=" + accountType + ", customer=" + customer + ", createdBySource="
				+ createdBySource + ", orderRegion=" + orderRegion + ", leadOwner=" + leadOwner + ", salesRep="
				+ salesRep + ", owner=" + owner + "]";
	}
	
}
