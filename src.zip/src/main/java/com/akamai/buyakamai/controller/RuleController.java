package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.model.oms.BuyOrderRequestDto;
import com.akamai.buyakamai.model.quote.ProductSslDetail;
import com.akamai.buyakamai.model.quote.approval.ApprovalDto;
import com.akamai.buyakamai.model.recommendation.ProductRecommendation;
import com.akamai.buyakamai.service.rule.RuleService;
import com.akamai.buyakamai.util.RequestFetcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import java.util.List;

@RestController
@RequestMapping("/v4")
public class RuleController {

    private static final Logger logger = LoggerFactory.getLogger(RuleController.class);


    @Autowired
    private RuleService ruleService;


    @PostMapping(value = "/rules/validate/quote", produces = "application/json")
    public ApprovalDto getApprovalsForQuote(@RequestBody BuyOrderRequestDto quote, @Context HttpServletRequest httpRequest) {
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        logger.info("Inside getApprovalsForQuote method of RuleController");
        return ruleService.getApprovalsForQuote(quote, userName);
    }

    @GetMapping(value = "/product-recommendations", produces = "application/json")
    public ProductRecommendation getProductRecommendations(
            @Context HttpServletRequest httpRequest) {
        logger.info("Entering getProductRecommendations ");
        ProductRecommendation response = ruleService.getProductRecommendations();
        logger.info("Exiting getProductRecommendations : response {} ", response);
        return response;
    }

    @PostMapping(value = "/rules/validate/products/sslCert", produces = "application/json")
    public List<ProductSslDetail> getSslDetailsForProducts(@RequestBody List<String> products, @Context HttpServletRequest httpRequest) {
        logger.info("Inside getSslDetailsForProducts method of RuleController");
        return ruleService.getSslDetailsForProducts(products);
    }
}
