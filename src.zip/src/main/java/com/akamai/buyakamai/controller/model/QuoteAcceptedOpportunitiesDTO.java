package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuoteAcceptedOpportunitiesDTO {

    Set<String> opportunityIds;

    public Set<String> getOpportunityIds() {
        return opportunityIds;
    }

    public void setOpportunityIds(Set<String> opportunityIds) {
        this.opportunityIds = opportunityIds;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        QuoteAcceptedOpportunitiesDTO that = (QuoteAcceptedOpportunitiesDTO) o;

        return opportunityIds != null ? opportunityIds.equals(that.opportunityIds) : that.opportunityIds == null;
    }

    @Override
    public int hashCode() {
        return opportunityIds != null ? opportunityIds.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "QuoteAcceptedOpportunitiesDTO{" +
                "opportunityIds=" + opportunityIds +
                '}';
    }
}
