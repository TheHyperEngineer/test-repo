package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.akamai.buyakamai.integration.clients.model.AccountDto;
import com.akamai.buyakamai.integration.clients.model.AccountOpportunityDto;
import com.akamai.buyakamai.integration.clients.model.AddressDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountOpportunityOrderDTO {

	private String opportunityId;
	private String opportunityName;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String opportunityOwner;
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String accountOwner;
	private String accountId;
	private String accountName;
	@JsonInclude(Include.NON_NULL)
	private AddressDto accountAddress;
	private String type;
	private List<OrderInformationDTO> orders;
	@JsonInclude(Include.NON_NULL)
	private String creditCheckStatus;

	@JsonProperty("isNoteUpdated")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean noteUpdated;

	@JsonProperty("isNoteUpdated")
	public Boolean getNoteUpdated() {
		return noteUpdated;
	}

	public void isNoteUpdated(Boolean noteUpdated) {
		this.noteUpdated = noteUpdated;
	}

	public AccountOpportunityOrderDTO(AccountOpportunityDto accountOpportunityDto) {
		AccountDto customerAccount = accountOpportunityDto.getCustomerAccount();
		this.opportunityId = accountOpportunityDto.getId();
		this.opportunityName = accountOpportunityDto.getName();
		if (customerAccount != null) {
			this.accountId = customerAccount.getAccountId();
			this.accountName = customerAccount.getAccountName();
			this.accountOwner = customerAccount.getOwnerFullName();
			this.accountAddress = customerAccount.getAddress();
			this.type=customerAccount.getAccountType();
			this.creditCheckStatus=accountOpportunityDto.getCustomerAccount().getCreditCheckStatus();
		}
		this.opportunityOwner = accountOpportunityDto.getOpportunityOwner();
	}
	public String getOpportunityId() {
		return opportunityId;
	}
	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}
	public String getOpportunityName() {
		return opportunityName;
	}
	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}
	public String getOpportunityOwner() {
		return opportunityOwner;
	}
	public void setOpportunityOwner(String opportunityOwner) {
		this.opportunityOwner = opportunityOwner;
	}
	public String getAccountOwner() {
		return accountOwner;
	}
	public void setAccountOwner(String accountOwner) {
		this.accountOwner = accountOwner;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public List<OrderInformationDTO> getOrders() {
		return orders;
	}
	public void setOrders(List<OrderInformationDTO> orders) {
		this.orders = orders;
	}
	
	public AddressDto getAccountAddress() {
		return accountAddress;
	}
	public void setAccountAddress(AddressDto accountAddress) {
		this.accountAddress = accountAddress;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCreditCheckStatus() {
		return creditCheckStatus;
	}
	public void setCreditCheckStatus(String creditCheckStatus) {
		this.creditCheckStatus = creditCheckStatus;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((accountOwner == null) ? 0 : accountOwner.hashCode());
		result = prime * result + ((opportunityId == null) ? 0 : opportunityId.hashCode());
		result = prime * result + ((opportunityOwner == null) ? 0 : opportunityOwner.hashCode());
		result = prime * result + ((orders == null) ? 0 : orders.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountOpportunityOrderDTO other = (AccountOpportunityOrderDTO) obj;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (accountOwner == null) {
			if (other.accountOwner != null)
				return false;
		} else if (!accountOwner.equals(other.accountOwner))
			return false;
		if (opportunityId == null) {
			if (other.opportunityId != null)
				return false;
		} else if (!opportunityId.equals(other.opportunityId))
			return false;
		if (opportunityOwner == null) {
			if (other.opportunityOwner != null)
				return false;
		} else if (!opportunityOwner.equals(other.opportunityOwner))
			return false;
		if (orders == null) {
			if (other.orders != null)
				return false;
		} else if (!orders.equals(other.orders))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "AccountOpportunityOrderDTO [opportunityId=" + opportunityId + ", opportunityName=" + opportunityName
				+ ", opportunityOwner=" + opportunityOwner + ", accountOwner=" + accountOwner + ", accountId="
				+ accountId + ", accountName=" + accountName + ", accountAddress=" + accountAddress + ", type=" + type
				+ ", orders=" + orders + "]";
	}
	
}
