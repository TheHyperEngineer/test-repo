package com.akamai.buyakamai.controller.model;

import java.util.Set;

public class QuoteAcceptedOrderSourceDTO {
    
	private Set<String> sourceIdList;

	public Set<String> getSourceIdList() {
		return sourceIdList;
	}

	public void setSourceIdList(Set<String> sourceIdList) {
		this.sourceIdList = sourceIdList;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((sourceIdList == null) ? 0 : sourceIdList.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuoteAcceptedOrderSourceDTO other = (QuoteAcceptedOrderSourceDTO) obj;
		if (sourceIdList == null) {
			if (other.sourceIdList != null)
				return false;
		} else if (!sourceIdList.equals(other.sourceIdList))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "QuoteAcceptedLeadsDTO [sourceIdList=" + sourceIdList + "]";
	}

}
