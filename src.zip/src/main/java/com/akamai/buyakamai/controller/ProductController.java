package com.akamai.buyakamai.controller;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.Context;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.config.AkamaiSEConfig;
import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.constants.EventDataPoint;
import com.akamai.buyakamai.constants.UserEventAction;
import com.akamai.buyakamai.controller.model.OKResponse;
import com.akamai.buyakamai.controller.model.ProductRecommendationRequest;
import com.akamai.buyakamai.controller.model.RecommendedProductResponse;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.Contact;
import com.akamai.buyakamai.model.oms.BuyOrderRequestDto;
import com.akamai.buyakamai.model.productmaster.ProductPricingResponse;
import com.akamai.buyakamai.service.events.EventInfo;
import com.akamai.buyakamai.service.events.EventProcessor;
import com.akamai.buyakamai.service.impl.BACoreAPIServiceImpl;
import com.akamai.buyakamai.service.impl.MarketplaceAPIServiceImpl;
import com.akamai.buyakamai.service.impl.ProductServiceImpl;
import com.akamai.buyakamai.util.RequestFetcher;
import com.akamai.se.account.Account;
import com.fasterxml.jackson.databind.node.ObjectNode;

@RestController
public class ProductController {

    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    private MarketplaceAPIServiceImpl mpAPIService;

    @Autowired
    private BACoreAPIServiceImpl baCoreAPIService;

    @Autowired
    private ProductServiceImpl productService;

    @Autowired
    private EventProcessor eventProcessor;

    @Autowired
    private AkamaiSEConfig akamaiSEConfig;

    @Autowired
    private RequestFetcher requestFetcher;

    @RequestMapping(value = "v1/accounts/{accountId}/products-to-recommend", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<String> getProductsToRecommendForAccount(@PathVariable String accountId,
                                                                   @Context HttpServletRequest httpRequest) {
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        logger.info("Inside getting account list for user: {}", userName);

        String response = mpAPIService.getProductsToRecommend(accountId);
        logger.info("Successfully retrieved product list to recommend for account {}", accountId);
        logger.debug("Product list : {}", response);
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/products/{productId}/recommendation/{recommendationType}",
            method = RequestMethod.POST, produces = "application/json;charset=UTF-8", consumes = "application/json;charset=UTF-8")
    public ResponseEntity<OKResponse> recommendProduct(@PathVariable String productId, @PathVariable String recommendationType,
                                                       @RequestBody ProductRecommendationRequest requestObj, @Context HttpServletRequest httpRequest) {
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        String contactId = requestObj.getContactId();
        Contact contact = null;
        Account account = null;

        this.checkIfProductIsValid(productId, requestObj.getProductName());
        this.checkIfRecTypeIsValid(recommendationType);
        try {
            contact = baCoreAPIService.getContactByContactId(contactId);
            account = akamaiSEConfig.getCoreManagerFactory().getAccountManager().getAccountForId(requestObj.getAccountId());
            if ((account == null) || (contact == null)) {
                throw new Exception();
            }
        } catch (Exception ex) {
            String msg = "Invalid account/contact in the request";
            logger.error(msg, ex);
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
        }
        logger.info("Recommending product with contactId : {} , accountId : {}", requestObj.getContactId(), requestObj.getAccountId());
        try {
            productService.recommendProduct(productId, requestObj, account);
        } catch (Exception ex) {
            this.raiseEventForProdRecommendation(productId, requestObj, contact, userName, UserEventAction.PROD_RECOMMENDATION_FAILURE);
            throw ex;
        }
        logger.info("Product recommendation completed for product id {} and account id {}", productId, requestObj.getAccountId());
        this.raiseEventForProdRecommendation(productId, requestObj, contact, userName, UserEventAction.PROD_RECOMMENDATION_SUCCESS);
        return new ResponseEntity<OKResponse>(new OKResponse(), HttpStatus.OK);
    }

    private void raiseEventForProdRecommendation(String productId, ProductRecommendationRequest requestObj, Contact contact,
                                                 String userName, UserEventAction userEventAction) {
        EventInfo eventInfo = new EventInfo(userName, userEventAction);
        Map<String, String> additionalInfo = new HashMap<>();
        additionalInfo.put(EventDataPoint.CONTACT_ID.name(), contact.getContactId());
        additionalInfo.put(EventDataPoint.PRODUCT_NAME.name(), requestObj.getProductName());
        additionalInfo.put(EventDataPoint.ACCOUNT_ID.name(), requestObj.getAccountId());
        additionalInfo.put(EventDataPoint.CONTACT_NAME.name(), contact.getFullName());
        additionalInfo.put(EventDataPoint.CONTACT_EMAIL.name(), contact.getEmail());
        eventInfo.setAdditionalInfo(additionalInfo);
        eventProcessor.initiateEventProcessorThread(eventInfo);
    }

    private void checkIfProductIsValid(String productId, String productName) {
        if (StringUtils.isBlank(productId) || StringUtils.isBlank(productName)) {
            String msg = "Invalid product id/name in the request";
            logger.error(msg);
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
        }
    }

    private void checkIfRecTypeIsValid(String recType) {
        if (StringUtils.isBlank(recType) || !recType.equalsIgnoreCase(BAConstants.TRIAL_REC_TYPE)) {
            String msg = "Invalid reccomendation type in the request. Only trial is supported...";
            logger.error(msg);
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "v1/accounts/{accountId}/products", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<RecommendedProductResponse>> getProducts(@Valid @NotNull @PathVariable String accountId, @RequestParam(value = "select", required = true) String select, @Context HttpServletRequest httpRequest) {
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        logger.info("Inside getProducts for user: {}", userName);

        if (BAConstants.RECOMMENDATION.equalsIgnoreCase(select)) {
            List<RecommendedProductResponse> response = mpAPIService.getProductsIntegrationDetails(accountId);
            logger.debug("Successfully retrieved product list along with their integration type support : {}", response);
            return new ResponseEntity<>(response, HttpStatus.OK);
        } else {
            String msg = "Invalid input. Product Integration Details can't be fetch.";
            throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST);
        }
    }

    @RequestMapping(value = "v1/products/ui-metadata", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    public ResponseEntity<ObjectNode> getUIMetaData(@RequestParam(value = "customerType", required = false) String customerType, @RequestParam(value = "userType", required = false) String userType) {
        List<String> roles = requestFetcher.getLoggedInUserRoles();
        logger.info("Entering getUIMetaData with customerType : {}", customerType);

        ObjectNode metadata = productService.getProductsUIMetadata(roles, customerType, userType);

        logger.info("Exiting getUIMetaData : response {} ", metadata);
        return new ResponseEntity<>(metadata, HttpStatus.OK);
    }

    private String getFile(String fileName) {

        StringBuilder result = new StringBuilder("");

        // Get file from resources folder
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(fileName).getFile());

        try (Scanner scanner = new Scanner(file)) {

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                result.append(line);
            }

            scanner.close();

        } catch (IOException e) {
            e.printStackTrace();
        }

        return result.toString();

    }
	
	@RequestMapping(value = "v4/products/bed-calculator", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public ResponseEntity<Map<String,String>> calculateBED(@Context HttpServletRequest httpRequest, @RequestBody BuyOrderRequestDto buyOrder) {
		logger.info("Entering calculateBed api ");
		validateBEDRequest(buyOrder);
		String bed = productService.calculateBED(buyOrder);
		logger.info("Calulated bed : response {} ", bed);
		Map<String,String> response = new HashMap<String,String>();
		response.put(BAConstants.BILLING_EFFECTIVE_DATE, bed);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
	
	private void validateBEDRequest(BuyOrderRequestDto buyOrder) {
		if(buyOrder.getContractTerms() == null || StringUtils.isEmpty(buyOrder.getContractTerms().getAnticipatedSignedDate()) || CollectionUtils.isEmpty(buyOrder.getProducts())) {
			String msg = "Contract term or anticipatedSignedDate or products can not be empty or null.";
			logger.error(msg);
			throw new BuyAkamaiApplicationException(msg, msg, HttpStatus.BAD_REQUEST, ErrorConstants.BILLING_EFFECTIVE_DATE_INVALID_INPUT);
		}
	}

	@RequestMapping(value = "v4/products/{productId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseEntity<ProductPricingResponse> getBuyProductPricingForProduct(@Valid @PathVariable String productId) {
		logger.info("Inside getting buy product for productId: {}", productId);
		ProductPricingResponse response = baCoreAPIService.getProductPricing(productId);
		productService.setPricingHelpText(response);
		logger.info("Successfully retrieved product pricing for product {}", productId);
		logger.debug("Product list : {}", response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}

	@RequestMapping(value = "v4/products", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public ResponseEntity<String> getBuyProductPricingForFunctionalCategory(
	        @Valid @RequestParam(value = "functionalCategory", required = true) String functionalCategory) {
		logger.info("Inside getting buy product for functionalCategory: {}", functionalCategory);
		String response = baCoreAPIService.getProductPricingForFunctionalCategory(functionalCategory);
		logger.info("Successfully retrieved product pricing for functionalCategory {}", functionalCategory);
		logger.debug("Product list : {}", response);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
