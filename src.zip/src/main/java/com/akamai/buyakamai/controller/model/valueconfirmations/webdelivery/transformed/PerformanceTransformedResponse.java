package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PerformanceTransformedResponse {

    private String product;
    private List<PerformanceDataSet> geography;
    private List<PerformanceDataSet> country;

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public List<PerformanceDataSet> getGeography() {
        return geography;
    }

    public void setGeography(List<PerformanceDataSet> geography) {
        this.geography = geography;
    }

    public List<PerformanceDataSet> getCountry() {
        return country;
    }

    public void setCountry(List<PerformanceDataSet> country) {
        this.country = country;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PerformanceTransformedResponse that = (PerformanceTransformedResponse) o;

        if (product != null ? !product.equals(that.product) : that.product != null) return false;
        if (geography != null ? !geography.equals(that.geography) : that.geography != null) return false;
        return country != null ? country.equals(that.country) : that.country == null;
    }

    @Override
    public int hashCode() {
        int result = product != null ? product.hashCode() : 0;
        result = 31 * result + (geography != null ? geography.hashCode() : 0);
        result = 31 * result + (country != null ? country.hashCode() : 0);
        return result;
    }
}
