package com.akamai.buyakamai.controller.model;


import java.util.List;

import com.akamai.buyakamai.controller.model.partner.OpportunityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectOrderResponse {

    private AccountInfo account;
    private ContactInfo customer;
    private ContactInfo salesRep;
    private ContactInfo se;
    private String type;
    private List<String> products;
    private String startDate;
    private String endDate;
    private String trialType;
    private Integer orderId;
    private String orderType;
    private String status;
    private String opportunityId;
    private String contractId;
    private List<HrefLink> links;
    private String baseProductId;
    private String sourceType;
    private String sourceId;
    private String updatedTime;
    private String signedDate;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String sourceConvertedId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String sourceConvertedType;

    private String createdByUserName;
    private String extensionReason;
    private TrialExtensionDetail childOrderHierarchy;
    private String bundleId;
    private Integer daysLeft;
    private String createdDate;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Integer daysSinceLastCredentialSent;

    private boolean isUpsellOrder;

    private boolean activeAccountNewContract;
    
    private String productType;

    @JsonIgnore
    private OpportunityInfo opportunity;

    @JsonIgnore
    private AccountInfo partnerAccount;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private Boolean owner;


    @JsonProperty("isUpsellOrder")
    public boolean isUpsellOrder() {
        return isUpsellOrder;
    }

    public void setUpsellOrder(boolean upsellOrder) {
        isUpsellOrder = upsellOrder;
    }

    public String getSourceConvertedType() {
        return sourceConvertedType;
    }

    public void setSourceConvertedType(String sourceConvertedType) {
        this.sourceConvertedType = sourceConvertedType;
    }

    public String getSourceConvertedId() {
        return sourceConvertedId;
    }

    public void setSourceConvertedId(String sourceConvertedId) {
        this.sourceConvertedId = sourceConvertedId;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public Integer getDaysLeft() {
        return daysLeft;
    }

    public void setDaysLeft(Integer daysLeft) {
        this.daysLeft = daysLeft;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public Boolean isOwner() {
        return owner;
    }

    public void setOwner(Boolean owner) {
        this.owner = owner;
    }

    public AccountInfo getAccount() {
        return account;
    }

    public void setAccount(AccountInfo account) {
        this.account = account;
    }

    public ContactInfo getCustomer() {
        return customer;
    }

    public void setCustomer(ContactInfo customer) {
        this.customer = customer;
    }

    public ContactInfo getSalesRep() {
        return salesRep;
    }

    public void setSalesRep(ContactInfo salesRep) {
        this.salesRep = salesRep;
    }

    public ContactInfo getSe() {
        return se;
    }

    public void setSe(ContactInfo se) {
        this.se = se;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getProducts() {
        return products;
    }

    public void setProducts(List<String> products) {
        this.products = products;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getTrialType() {
        return trialType;
    }

    public void setTrialType(String trialType) {
        this.trialType = trialType;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public List<HrefLink> getLinks() {
        return links;
    }

    public void setLinks(List<HrefLink> links) {
        this.links = links;
    }

    public String getOpportunityId() {
        return opportunityId;
    }

    public void setOpportunityId(String opportunityId) {
        this.opportunityId = opportunityId;
    }

    public String getContractId() {
        return contractId;
    }

    public void setContractId(String contractId) {
        this.contractId = contractId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBaseProductId() {
        return baseProductId;
    }

    public void setBaseProductId(String baseProductId) {
        this.baseProductId = baseProductId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getCreatedByUserName() {
        return createdByUserName;
    }

    public void setCreatedByUserName(String createdByUserName) {
        this.createdByUserName = createdByUserName;
    }

    public Boolean getOwner() {
        return owner;
    }

    public String getExtensionReason() {
        return extensionReason;
    }

    public void setExtensionReason(String extensionReason) {
        this.extensionReason = extensionReason;
    }

    public TrialExtensionDetail getChildOrderHierarchy() {
        return childOrderHierarchy;
    }

    public void setChildOrderHierarchy(TrialExtensionDetail childOrderHierarchy) {
        this.childOrderHierarchy = childOrderHierarchy;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public Integer getDaysSinceLastCredentialSent() {
        return daysSinceLastCredentialSent;
    }

    public void setDaysSinceLastCredentialSent(Integer daysSinceLastCredentialSent) {
        this.daysSinceLastCredentialSent = daysSinceLastCredentialSent;
    }

    public String getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(String updatedTime) {
        this.updatedTime = updatedTime;
    }

    public String getSignedDate() {
        return signedDate;
    }

    public void setSignedDate(String signedDate) {
        this.signedDate = signedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SelectOrderResponse that = (SelectOrderResponse) o;

        if (products != null ? !products.equals(that.products) : that.products != null) return false;
        if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
        if (status != null ? !status.equals(that.status) : that.status != null) return false;
        return createdByUserName != null ? createdByUserName.equals(that.createdByUserName) : that.createdByUserName == null;
    }

    @Override
    public int hashCode() {
        int result = products != null ? products.hashCode() : 0;
        result = 31 * result + (orderId != null ? orderId.hashCode() : 0);
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + (createdByUserName != null ? createdByUserName.hashCode() : 0);
        return result;
    }

    public OpportunityInfo getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(OpportunityInfo opportunity) {
        this.opportunity = opportunity;
    }

    public AccountInfo getPartnerAccount() {
        return partnerAccount;
    }

    public void setPartnerAccount(AccountInfo partnerAccount) {
        this.partnerAccount = partnerAccount;
    }

    public boolean isActiveAccountNewContract() {
		return activeAccountNewContract;
	}

	public void setActiveAccountNewContract(boolean activeAccountNewContract) {
		this.activeAccountNewContract = activeAccountNewContract;
	}

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("SelectOrderResponse{");
        sb.append("account=").append(account);
        sb.append(", customer=").append(customer);
        sb.append(", salesRep=").append(salesRep);
        sb.append(", se=").append(se);
        sb.append(", type='").append(type).append('\'');
        sb.append(", products=").append(products);
        sb.append(", startDate='").append(startDate).append('\'');
        sb.append(", endDate='").append(endDate).append('\'');
        sb.append(", trialType='").append(trialType).append('\'');
        sb.append(", orderId=").append(orderId);
        sb.append(", orderType='").append(orderType).append('\'');
        sb.append(", status='").append(status).append('\'');
        sb.append(", opportunityId='").append(opportunityId).append('\'');
        sb.append(", contractId='").append(contractId).append('\'');
        sb.append(", links=").append(links);
        sb.append(", baseProductId='").append(baseProductId).append('\'');
        sb.append(", sourceType='").append(sourceType).append('\'');
        sb.append(", sourceId='").append(sourceId).append('\'');
        sb.append(", updatedTime='").append(updatedTime).append('\'');
        sb.append(", signedDate='").append(signedDate).append('\'');
        sb.append(", sourceConvertedId='").append(sourceConvertedId).append('\'');
        sb.append(", sourceConvertedType='").append(sourceConvertedType).append('\'');
        sb.append(", createdByUserName='").append(createdByUserName).append('\'');
        sb.append(", extensionReason='").append(extensionReason).append('\'');
        sb.append(", childOrderHierarchy=").append(childOrderHierarchy);
        sb.append(", bundleId='").append(bundleId).append('\'');
        sb.append(", daysLeft=").append(daysLeft);
        sb.append(", createdDate='").append(createdDate).append('\'');
        sb.append(", daysSinceLastCredentialSent=").append(daysSinceLastCredentialSent);
        sb.append(", isUpsellOrder=").append(isUpsellOrder);
        sb.append(", activeAccountNewContract=").append(activeAccountNewContract);
        sb.append(", productType='").append(productType).append('\'');
        sb.append(", opportunity=").append(opportunity);
        sb.append(", partnerAccount=").append(partnerAccount);
        sb.append(", owner=").append(owner);
        sb.append('}');
        return sb.toString();
    }
}
