package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OpportunityCreationRequest {
	
	public enum OpportunityOrderType
	{
		Trial,Purchase
	}

    private String accountId;

    private String productName;

    private String opportunityName;

    private String stage;

    private String dealType;

    private String competitor;

    private String currency;
    
    private String customerContactId;

    private String partnerAccountId;

    private String partnerContactId;
    
    private OpportunityOrderType orderType;

    public String getCustomerContactId() {
		return customerContactId;
	}

	public void setCustomerContactId(String customerContactId) {
		this.customerContactId = customerContactId;
	}

	public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getOpportunityName() {
        return opportunityName;
    }

    public void setOpportunityName(String opportunityName) {
        this.opportunityName = opportunityName;
    }

    public String getStage() {
        return stage;
    }

    public void setStage(String stage) {
        this.stage = stage;
    }

    public String getDealType() {
        return dealType;
    }

    public void setDealType(String dealType) {
        this.dealType = dealType;
    }

    public String getCompetitor() {
        return competitor;
    }

    public void setCompetitor(String competitor) {
        this.competitor = competitor;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPartnerAccountId() {
        return partnerAccountId;
    }

    public void setPartnerAccountId(String partnerAccountId) {
        this.partnerAccountId = partnerAccountId;
    }

    public String getPartnerContactId() {
        return partnerContactId;
    }

    public void setPartnerContactId(String partnerContactId) {
        this.partnerContactId = partnerContactId;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OpportunityCreationRequest that = (OpportunityCreationRequest) o;

        if (accountId != null ? !accountId.equals(that.accountId) : that.accountId != null) return false;
        if (opportunityName != null ? !opportunityName.equals(that.opportunityName) : that.opportunityName != null)
            return false;
        if (stage != null ? !stage.equals(that.stage) : that.stage != null) return false;
        return dealType != null ? dealType.equals(that.dealType) : that.dealType == null;
    }

    @Override
    public int hashCode() {
        int result = accountId != null ? accountId.hashCode() : 0;
        result = 31 * result + (opportunityName != null ? opportunityName.hashCode() : 0);
        result = 31 * result + (stage != null ? stage.hashCode() : 0);
        result = 31 * result + (dealType != null ? dealType.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OpportunityCreationRequest{" +
                "accountId='" + accountId + '\'' +
                ", opportunityName='" + opportunityName + '\'' +
                ", stage='" + stage + '\'' +
                ", dealType='" + dealType + '\'' +
                ", competitor='" + competitor + '\'' +
                ", currency='" + currency + '\'' +
                ", customerContactId='" + customerContactId + '\'' +
                ", partnerAccountId='" + partnerAccountId + '\'' +
                ", partnerContactId='" + partnerContactId + '\'' +
                '}';
    }

	public OpportunityOrderType getOrderType() {
		return orderType;
	}

	public void setOrderType(OpportunityOrderType orderType) {
		this.orderType = orderType;
	}
}
