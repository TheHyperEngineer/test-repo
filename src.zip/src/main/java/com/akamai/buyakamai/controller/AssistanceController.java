package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.constants.enums.PulsarAuthZHeader;
import com.akamai.buyakamai.controller.model.AssistanceCategory;
import com.akamai.buyakamai.controller.model.AssistanceRequest;
import com.akamai.buyakamai.controller.model.OKResponse;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.AssistanceServiceImpl;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class AssistanceController {

    private static final Logger logger = LoggerFactory.getLogger(AssistanceController.class);

    @Autowired
    private AssistanceServiceImpl assistanceService;

    @RequestMapping(value = "v1/assistance-categories", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<AssistanceCategory>> getAllAssistanceCategories() {
        logger.info("Fetching all assistance categories...");
        List<AssistanceCategory> response = assistanceService.getAllAssistanceCategories();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/assistance", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public ResponseEntity<OKResponse> assistBAUser(@RequestBody AssistanceRequest assistanceReq,
    		@Context HttpServletRequest httpRequest) {
    	logger.info("Assistance request received...");
    	if ( (assistanceReq == null) || StringUtils.isBlank(assistanceReq.getAssistanceText())
    			|| (assistanceReq.getAssistanceText().length() > 1000)) {
			String title = "Invalid assistance text value. Either empty or more than 1000 chars";
			logger.error(title);
			throw new BuyAkamaiApplicationException(title,title, HttpStatus.BAD_REQUEST, ErrorConstants.INVALID_ASSISTANCE_TEXT);
    	}
    	if(StringUtils.isEmpty(assistanceReq.getRequestPage())){
            String title = "Request page cannot be empty";
            logger.error(title);
            throw new BuyAkamaiApplicationException(title,title, HttpStatus.BAD_REQUEST, ErrorConstants.EMPTY_ASSISTANCE_PAGE);
        }
    	String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        assistanceService.assistBAUser(assistanceReq, userName);
        logger.info("Assistance request completed successfully");
        OKResponse okResponse = new OKResponse();
        return new ResponseEntity<>(okResponse, HttpStatus.OK);
    }
}
