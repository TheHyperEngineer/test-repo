package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;

public class LeadBasicInfoResponse {

    private String name;
    private String id;
    private String accountId;
    private String ownerId;
    private String ownerUserName;
    private String ownerEmail;

    @JsonIgnore
    private String srcId;

    private List<OrderSourceLookupResponse> opportunity;

    public String getSrcId() {
        return srcId;
    }

    public void setSrcId(String srcId) {
        this.srcId = srcId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getOwnerId() {
        return ownerId;
    }

    public void setOwnerId(String ownerId) {
        this.ownerId = ownerId;
    }

    public List<OrderSourceLookupResponse> getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(List<OrderSourceLookupResponse> opportunity) {
        this.opportunity = opportunity;
    }

    public String getOwnerEmail() {
        return ownerEmail;
    }

    public void setOwnerEmail(String ownerEmail) {
        this.ownerEmail = ownerEmail;
    }

    public String getOwnerUserName() {

        return ownerUserName;
    }

    public void setOwnerUserName(String ownerUserName) {
        this.ownerUserName = ownerUserName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        LeadBasicInfoResponse that = (LeadBasicInfoResponse) o;

        if (name != null ? !name.equals(that.name) : that.name != null) return false;
        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (accountId != null ? !accountId.equals(that.accountId) : that.accountId != null) return false;
        if (ownerId != null ? !ownerId.equals(that.ownerId) : that.ownerId != null) return false;
        return opportunity != null ? opportunity.equals(that.opportunity) : that.opportunity == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (id != null ? id.hashCode() : 0);
        result = 31 * result + (accountId != null ? accountId.hashCode() : 0);
        result = 31 * result + (ownerId != null ? ownerId.hashCode() : 0);
        result = 31 * result + (opportunity != null ? opportunity.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "LeadBasicInfoResponse{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                ", accountId='" + accountId + '\'' +
                ", ownerId='" + ownerId + '\'' +
                ", opportunity=" + opportunity +
                '}';
    }
}
