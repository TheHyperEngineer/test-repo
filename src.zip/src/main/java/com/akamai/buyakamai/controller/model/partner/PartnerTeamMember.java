package com.akamai.buyakamai.controller.model.partner;

public class PartnerTeamMember {

    private String accountId;

    private String accountName;

    private PartnerAccountMembers accountMembers;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public PartnerAccountMembers getAccountMembers() {
        return accountMembers;
    }

    public void setAccountMembers(PartnerAccountMembers accountMembers) {
        this.accountMembers = accountMembers;
    }
}
