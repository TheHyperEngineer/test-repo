package com.akamai.buyakamai.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.ws.rs.core.Context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.akamai.buyakamai.controller.model.BasicProperty;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.BasicPropertyServiceImpl;
import com.akamai.ids.commons.model.request.IdsRequest;

/**
 * BasicProperty controller.
 * 
 * Provides access to enhanced BasicProperty (including DNSResolution) for ArlFileHost.
 * 
 * @author jplans
 *
 */
@RestController
@EnableAutoConfiguration
public class BasicPropertyController {

	// logger
	private static final Logger logger = LoggerFactory.getLogger(BasicPropertyController.class);

	// The Service that will be used as source of data
	@Autowired
	private BasicPropertyServiceImpl basicPropertyService;


	 /**
	 * Get the list of BasicProperties for a given account id
	 * @param accountId	Account id: if it is wrong it will return an empty list.
	 * @return	List of BasicProperty objects corresponding to the account
	 * @throws BuyAkamaiApplicationException
	 */
	@RequestMapping(value = "/v1/basicproperties/{accountId}", method = RequestMethod.GET)
	public ResponseEntity<List<BasicProperty>> getBasicPropertiesForAccountId(@Valid @PathVariable String accountId, @Context HttpServletRequest httpRequest) throws BuyAkamaiApplicationException {

		logger.info("Entering getBasicPropertiesForAccountId for account ID {} ",accountId);
		List<BasicProperty> response = null;
		try {
			response = basicPropertyService.getBasicPropertiesForAccountId(httpRequest == null ? null : IdsRequest.from((HttpServletRequest) httpRequest), accountId);
		} catch(BuyAkamaiApplicationException e) {
			logger.error("BasicPropertyController about to return error {}", e);
			throw(e);
		}
		logger.debug("Got {} property for accountId {}", response == null ? 0 : 1, accountId);
		
		final HttpHeaders httpHeaders= new HttpHeaders();
	    httpHeaders.setContentType(MediaType.APPLICATION_JSON);
	    
		ResponseEntity<List<BasicProperty>> result = new ResponseEntity<>(response, httpHeaders, HttpStatus.OK);
		
		logger.info("Exiting getBasicPropertiesForAccountId with Response {} ",accountId);
		return result;
	}
}