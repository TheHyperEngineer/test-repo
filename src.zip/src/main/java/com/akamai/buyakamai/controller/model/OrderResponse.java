package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.akamai.buyakamai.controller.model.partner.PartnerDetail;
import com.akamai.buyakamai.controller.model.valueconfirmations.ValueConfirmationOrderEntity;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class OrderResponse {

	private Integer orderId;

	private String bundleId;

	private String bundleName;

	private String productName;

	private String contractId;

	private String status;

	private String type;

	private CustomerInfo customerInfo;

	private AccountInfo account;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private AkamaiMembersInfo akamaiMembersInfo;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private PartnerDetail partnerInfo;

	private String trialType;

	private String startDate;

	private boolean isExtended;

	private String trialDuration;

	private String endDate;

	private String opportunityId;

	private String createdDate;

	private String createdByUserName;

	private List<OrderProductDetails> productDetails;

	private String category;

	private List<ValueConfirmationOrderEntity> valueConfirmation;

	private Integer daysLeft;

	private TrialExtensionDetail childOrderHierarchy;

	private String sourceId;

	private String sourceType;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String sourceConvertedId;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private String sourceConvertedType;

	@JsonInclude(JsonInclude.Include.NON_NULL)
	private ContactInfo opportunityOwner;
	
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Integer quoteExtensionDays;
	
	private boolean isBuyEnabled;

	private boolean activeAccountNewContract;
	private String trialName;

	public String getSourceConvertedType() {
		return sourceConvertedType;
	}

	public void setSourceConvertedType(String sourceConvertedType) {
		this.sourceConvertedType = sourceConvertedType;
	}

	public String getSourceConvertedId() {
		return sourceConvertedId;
	}

	public void setSourceConvertedId(String sourceConvertedId) {
		this.sourceConvertedId = sourceConvertedId;
	}

	public Integer getDaysLeft() {
		return daysLeft;
	}

	public void setDaysLeft(Integer daysLeft) {
		this.daysLeft = daysLeft;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public List<ValueConfirmationOrderEntity> getValueConfirmation() {
		return valueConfirmation;
	}

	public void setValueConfirmation(List<ValueConfirmationOrderEntity> valueConfirmation) {
		this.valueConfirmation = valueConfirmation;
	}

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}


	public String getBundleId() {
		return bundleId;
	}

	public ContactInfo getOpportunityOwner() {
		return opportunityOwner;
	}

	public void setOpportunityOwner(ContactInfo opportunityOwner) {
		this.opportunityOwner = opportunityOwner;
	}

	public AkamaiMembersInfo getAkamaiMembersInfo() {
		return akamaiMembersInfo;
	}

	public void setAkamaiMembersInfo(AkamaiMembersInfo akamaiMembersInfo) {
		this.akamaiMembersInfo = akamaiMembersInfo;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}



	public String getBundleName() {
		return bundleName;
	}



	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}



	public String getProductName() {
		return productName;
	}



	public void setProductName(String productName) {
		this.productName = productName;
	}



	public String getContractId() {
		return contractId;
	}



	public void setContractId(String contractId) {
		this.contractId = contractId;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(String status) {
		this.status = status;
	}



	public CustomerInfo getCustomerInfo() {
		return customerInfo;
	}



	public void setCustomerInfo(CustomerInfo customerInfo) {
		this.customerInfo = customerInfo;
	}


	public String getType() {
		return type;
	}



	public void setType(String type) {
		this.type = type;
	}


	public List<OrderProductDetails> getProductDetails() {
		return productDetails;
	}



	public void setProductDetails(List<OrderProductDetails> productDetails) {
		this.productDetails = productDetails;
	}


	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getTrialType() {
		return trialType;
	}

	public void setTrialType(String trialType) {
		this.trialType = trialType;
	}

	public String getTrialDuration() {
		return trialDuration;
	}

	public void setTrialDuration(String trialDuration) {
		this.trialDuration = trialDuration;
	}

	public String getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(String opportunityId) {
		this.opportunityId = opportunityId;
	}

	public AccountInfo getAccount() {
		return account;
	}

	public void setAccount(AccountInfo account) {
		this.account = account;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	@JsonProperty("isExtended")
	public boolean isExtended() {
		return isExtended;
	}

	public void setExtended(boolean extended) {
		isExtended = extended;
	}
	
	@JsonProperty("isBuyEnabled")
	public boolean isBuyEnabled() {
		return isBuyEnabled;
	}

	public void setBuyEnabled(boolean isBuyEnabled) {
		this.isBuyEnabled = isBuyEnabled;
	}

	public String getCreatedByUserName() {
		return createdByUserName;
	}

	public void setCreatedByUserName(String createdByUserName) {
		this.createdByUserName = createdByUserName;
	}

	public TrialExtensionDetail getChildOrderHierarchy() {
		return childOrderHierarchy;
	}

	public void setChildOrderHierarchy(TrialExtensionDetail childOrderHierarchy) {
		this.childOrderHierarchy = childOrderHierarchy;
	}

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public PartnerDetail getPartnerInfo() {
		return partnerInfo;
	}

	public void setPartnerInfo(PartnerDetail partnerInfo) {
		this.partnerInfo = partnerInfo;
	}
	
	public Integer getQuoteExtensionDays() {
		return quoteExtensionDays;
	}

	public void setQuoteExtensionDays(Integer quoteExtensionDays) {
		this.quoteExtensionDays = quoteExtensionDays;
	}

	public boolean isActiveAccountNewContract() {
		return activeAccountNewContract;
	}

	public void setActiveAccountNewContract(boolean activeAccountNewContract) {
		this.activeAccountNewContract = activeAccountNewContract;
	}

	public String getTrialName() {
		return trialName;
	}

	public void setTrialName(String trialName) {
		this.trialName = trialName;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;
		OrderResponse that = (OrderResponse) o;
		return orderId != null ? orderId.equals(that.orderId) : that.orderId == null;
	}

	@Override
	public int hashCode() {
		return orderId != null ? orderId.hashCode() : 0;
	}

	@Override
	public String toString() {
		return "OrderResponse [orderId=" + orderId + ", bundleId=" + bundleId + ", bundleName=" + bundleName
		        + ", productName=" + productName + ", contractId=" + contractId + ", status=" + status + ", type="
		        + type + ", customerInfo=" + customerInfo + ", account=" + account + ", akamaiMembersInfo="
		        + akamaiMembersInfo + ", partnerInfo=" + partnerInfo + ", trialType=" + trialType + ", startDate="
		        + startDate + ", isExtended=" + isExtended + ", trialDuration=" + trialDuration + ", endDate=" + endDate
		        + ", opportunityId=" + opportunityId + ", createdDate=" + createdDate + ", createdByUserName="
		        + createdByUserName + ", productDetails=" + productDetails + ", category=" + category
		        + ", valueConfirmation=" + valueConfirmation + ", daysLeft=" + daysLeft + ", childOrderHierarchy="
		        + childOrderHierarchy + ", sourceId=" + sourceId + ", sourceType=" + sourceType + ", sourceConvertedId="
		        + sourceConvertedId + ", sourceConvertedType=" + sourceConvertedType + ", opportunityOwner="
		        + opportunityOwner + ", quoteExtensionDays=" + quoteExtensionDays + ", activeAccountNewContract="
		        + activeAccountNewContract + "]";
	}

}