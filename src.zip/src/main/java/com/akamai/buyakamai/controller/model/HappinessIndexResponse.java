package com.akamai.buyakamai.controller.model;

public class HappinessIndexResponse {

    private Integer happinessIndex;
    private Integer orderId;
    private OrderEvent lastOccurredEvent;


    public Integer getHappinessIndex() {
        return happinessIndex;
    }

    public void setHappinessIndex(Integer happinessIndex) {
        this.happinessIndex = happinessIndex;
    }

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public OrderEvent getLastOccurredEvent() {
        return lastOccurredEvent;
    }

    public void setLastOccurredEvent(OrderEvent lastOccurredEvent) {
        this.lastOccurredEvent = lastOccurredEvent;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HappinessIndexResponse that = (HappinessIndexResponse) o;

        if (happinessIndex != null ? !happinessIndex.equals(that.happinessIndex) : that.happinessIndex != null)
            return false;
        if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
        return lastOccurredEvent != null ? lastOccurredEvent.equals(that.lastOccurredEvent) : that.lastOccurredEvent == null;
    }

    @Override
    public int hashCode() {
        int result = happinessIndex != null ? happinessIndex.hashCode() : 0;
        result = 31 * result + (orderId != null ? orderId.hashCode() : 0);
        result = 31 * result + (lastOccurredEvent != null ? lastOccurredEvent.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "HappinessIndexResponse{" +
                "happinessIndex=" + happinessIndex +
                ", orderId=" + orderId +
                ", lastOccurredEvent=" + lastOccurredEvent +
                '}';
    }
}
