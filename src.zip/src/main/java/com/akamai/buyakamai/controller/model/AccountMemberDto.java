package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.integration.clients.model.Contact;

public class AccountMemberDto {
    private String roleName;
    private Contact contact;

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String roleName) {
        this.roleName = roleName;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }


    @Override
    public String toString() {
        return "AccountMemberDto{" +
                "roleName='" + roleName + '\'' +
                ", contact=" + contact +
                '}';
    }
}
