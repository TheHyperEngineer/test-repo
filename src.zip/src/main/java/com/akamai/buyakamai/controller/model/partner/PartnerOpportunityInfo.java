package com.akamai.buyakamai.controller.model.partner;

import com.akamai.buyakamai.controller.model.AccountDetails;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PartnerOpportunityInfo {

    private AccountDetails accountDetails;
    private PartnerContact contact;

    public AccountDetails getAccountDetails() {
        return accountDetails;
    }

    public void setAccountDetails(AccountDetails accountDetails) {
        this.accountDetails = accountDetails;
    }

    public PartnerContact getContact() {
        return contact;
    }

    public void setContact(PartnerContact contact) {
        this.contact = contact;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PartnerOpportunityInfo that = (PartnerOpportunityInfo) o;

        if (accountDetails != null ? !accountDetails.equals(that.accountDetails) : that.accountDetails != null)
            return false;
        return contact != null ? contact.equals(that.contact) : that.contact == null;
    }

    @Override
    public int hashCode() {
        int result = accountDetails != null ? accountDetails.hashCode() : 0;
        result = 31 * result + (contact != null ? contact.hashCode() : 0);
        return result;
    }
}
