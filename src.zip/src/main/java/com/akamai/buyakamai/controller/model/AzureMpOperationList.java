package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AzureMpOperationList {
	
	private List<AzureMpOperation> operations;

	public List<AzureMpOperation> getOperations() {
		return operations;
	}

	public void setOperations(List<AzureMpOperation> operations) {
		this.operations = operations;
	}

	@Override
	public String toString() {
		return "AzureMpOperationList [operations=" + operations + "]";
	}
}
