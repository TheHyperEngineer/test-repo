package com.akamai.buyakamai.controller.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Alert {

    private int alertId;

    private String name;

    private String state;

    private String summary;

    private String details;

    private String level;

    private String severity;

    private String date;

    private List<String> actions;

    private boolean isPrimaryActionEnabled;

	public int getAlertId() {
		return alertId;
	}

	public void setAlertId(int alertId) {
		this.alertId = alertId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getSummary() {
		return summary;
	}

	public void setSummary(String summary) {
		this.summary = summary;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getSeverity() {
		return severity;
	}

	public void setSeverity(String severity) {
		this.severity = severity;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public List<String> getActions() {
		return actions;
	}

	public void setActions(List<String> actions) {
		this.actions = actions;
	}

	@JsonProperty("isPrimaryActionEnabled")
	public boolean isPrimaryActionEnabled() {
		return isPrimaryActionEnabled;
	}

	public void setPrimaryActionEnabled(boolean primaryActionEnabled) {
		isPrimaryActionEnabled = primaryActionEnabled;
	}
}
