package com.akamai.buyakamai.controller.model;

import java.util.List;

public class AccountAlertsDto {

    private String accountId;
    private List<Alert> alerts;

    public AccountAlertsDto(String accountId, List<Alert> alerts) {
        this.accountId = accountId;
        this.alerts = alerts;
    }

    public List<Alert> getAlerts() {
        return alerts;
    }

    public void setAlerts(List<Alert> alerts) {
        this.alerts = alerts;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }
}
