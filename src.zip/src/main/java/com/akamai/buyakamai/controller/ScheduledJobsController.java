package com.akamai.buyakamai.controller;

import com.akamai.buyakamai.controller.model.OKResponse;
import com.akamai.buyakamai.service.eventgenerators.EventGenerator;
import com.akamai.buyakamai.service.impl.ScheduledJobsServiceImpl;
import com.akamai.buyakamai.service.valueconfirmations.schedulerjobs.ValueConfirmationSchedulerJobService;
import com.akamai.ids.commons.model.request.IdsRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

@RestController
@EnableAutoConfiguration
public class ScheduledJobsController {

    private static Logger logger = LoggerFactory.getLogger(ScheduledJobsController.class);

    @Autowired
    private ScheduledJobsServiceImpl scheduledJobsServiceImpl;

    @Autowired
    private EventGenerator eventGenerator;

    @Autowired
    private ValueConfirmationSchedulerJobService valueConfirmationSchedulerJobService;


    @SuppressWarnings("rawtypes")
    @PostMapping(value = "v1/process-event")
    public ResponseEntity processEvents() {
        logger.info("Starting background job to process events");
        scheduledJobsServiceImpl.processOrderEvents();
        logger.info("Started background job to process events");
        return new ResponseEntity(HttpStatus.OK);
    }

    @PostMapping(value = "v1/generate-event")
    public ResponseEntity<OKResponse> generateBAevents(@Context HttpServletRequest httpRequest) {
        logger.info("Starting background job to process events");

        IdsRequest idsRequest = IdsRequest.from(httpRequest);

        eventGenerator.searchAndPersistEvents(idsRequest);
        logger.info("Started background job to generate BA events");
        OKResponse okResponse = new OKResponse();
        return new ResponseEntity<>(okResponse, HttpStatus.OK);
    }

    @PostMapping(value = "v1/process-email")
    public ResponseEntity<OKResponse> processEmails(@Context HttpServletRequest httpRequest) {
        logger.info("Starting background job to process emails");

        scheduledJobsServiceImpl.processEmails();
        logger.info("Started background job to process emails");
        OKResponse okResponse = new OKResponse();
        return new ResponseEntity<>(okResponse, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/value-confirmation-report", method = RequestMethod.POST)
    public ResponseEntity<OKResponse> generateValueConfirmationReport() {
        logger.info("Starting background job to populate value confirmation report data");
        valueConfirmationSchedulerJobService.generateValueConfirmationReports();
        OKResponse okResponse = new OKResponse();
        return new ResponseEntity<>(okResponse, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/value-confirmation-report", method = RequestMethod.DELETE)
    public ResponseEntity<OKResponse> purgeValueConfirmationReport() {
        logger.info("Starting background job to populate value confirmation report data");
        valueConfirmationSchedulerJobService.purgeValueConfirmationReports();
        OKResponse okResponse = new OKResponse();
        return new ResponseEntity<>(okResponse, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/resume-value-confirmation-request", method = RequestMethod.POST)
    public ResponseEntity<OKResponse> resumeValueConfirmationRequest() {
        logger.info("Starting background job to resume value confirmation requests");
        valueConfirmationSchedulerJobService.resumeValueConfirmationRequest();
        OKResponse okResponse = new OKResponse();
        return new ResponseEntity<>(okResponse, HttpStatus.OK);
    }
}