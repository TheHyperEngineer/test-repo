package com.akamai.buyakamai.controller.model.valueconfirmations;


import java.util.Date;

public class ValueConfirmationOrderEntity {

    private Integer id;
    private Date updatedTime;
    private Date createdTime;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Date getUpdatedTime() {
        return updatedTime;
    }

    public void setUpdatedTime(Date updatedTime) {
        this.updatedTime = updatedTime;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ValueConfirmationOrderEntity that = (ValueConfirmationOrderEntity) o;

        if (id != null ? !id.equals(that.id) : that.id != null) return false;
        if (updatedTime != null ? !updatedTime.equals(that.updatedTime) : that.updatedTime != null) return false;
        return createdTime != null ? createdTime.equals(that.createdTime) : that.createdTime == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (updatedTime != null ? updatedTime.hashCode() : 0);
        result = 31 * result + (createdTime != null ? createdTime.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "ValueConfirmationOrderEntity{" +
                "id=" + id +
                ", updatedTime='" + updatedTime + '\'' +
                ", createdTime='" + createdTime + '\'' +
                '}';
    }
}
