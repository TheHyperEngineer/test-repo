package com.akamai.buyakamai.controller.model;

public class AzureSubscriptionRequest {
	private String planId;

	public String getPlanId() {
		return planId;
	}

	public void setPlanId(String planId) {
		this.planId = planId;
	}

	@Override
	public String toString() {
		return "AzureSubscriptionRequest [planId=" + planId + "]";
	}

}
