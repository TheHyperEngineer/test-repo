package com.akamai.buyakamai.controller.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

public class QuoteProduct {
	
	@NotBlank(message="Marketing product Id cannot be empty")
	private String marketingProductId;
	
	@Valid
	@NotNull(message="Pricing details: List items can not be null for Product")
	@NotEmpty(message="Pricing details: List items can not be empty for Product")
	private List<QuoteRequestListItem> listItems;
	
	@Valid
	@NotEmpty(message = "OptionGroups list cannot be empty ")
	@NotNull(message = "OptionGroups list cannot be null ")
	private List<QuoteRequestOptionGroup> optionGroups;


	public String getMarketingProductId() {
		return marketingProductId;
	}

	public void setMarketingProductId(String marketingProductId) {
		this.marketingProductId = marketingProductId;
	}

	public List<QuoteRequestListItem> getListItems() {
		return listItems;
	}

	public void setListItems(List<QuoteRequestListItem> listItems) {
		this.listItems = listItems;
	}

	public List<QuoteRequestOptionGroup> getOptionGroups() {
		return optionGroups;
	}

	public void setOptionGroups(List<QuoteRequestOptionGroup> optionGroups) {
		this.optionGroups = optionGroups;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((listItems == null) ? 0 : listItems.hashCode());
		result = prime * result + ((marketingProductId == null) ? 0 : marketingProductId.hashCode());
		result = prime * result + ((optionGroups == null) ? 0 : optionGroups.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuoteProduct other = (QuoteProduct) obj;
		if (listItems == null) {
			if (other.listItems != null)
				return false;
		} else if (!listItems.equals(other.listItems))
			return false;
		if (marketingProductId == null) {
			if (other.marketingProductId != null)
				return false;
		} else if (!marketingProductId.equals(other.marketingProductId))
			return false;
		if (optionGroups == null) {
			if (other.optionGroups != null)
				return false;
		} else if (!optionGroups.equals(other.optionGroups))
			return false;
		return true;
	}

	@Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
	

}
