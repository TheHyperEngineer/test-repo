package com.akamai.buyakamai.controller.model;


import com.fasterxml.jackson.annotation.JsonInclude;

public class TrialExtensionDetail {

    private Integer orderId;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String startDate;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String duration;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String status;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String createdDate;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String type;

    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String createdBy;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String acceptedByContactId;
    
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String acceptedTime;
    
    private TrialExtensionDetail childOrder;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public TrialExtensionDetail getChildOrder() {
        return childOrder;
    }

    public void setChildOrder(TrialExtensionDetail childOrder) {
        this.childOrder = childOrder;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getAcceptedByContactId() {
		return acceptedByContactId;
	}

	public void setAcceptedByContactId(String acceptedByContactId) {
		this.acceptedByContactId = acceptedByContactId;
	}

	public String getAcceptedTime() {
		return acceptedTime;
	}

	public void setAcceptedTime(String acceptedTime) {
		this.acceptedTime = acceptedTime;
	}

	@Override
	public String toString() {
		return "TrialExtensionDetail [orderId=" + orderId + ", startDate=" + startDate + ", duration=" + duration
				+ ", status=" + status + ", createdDate=" + createdDate + ", type=" + type + ", createdBy=" + createdBy
				+ ", acceptedByContactId=" + acceptedByContactId + ", acceptedTime=" + acceptedTime + ", childOrder=" + childOrder + "]";
	}

}

