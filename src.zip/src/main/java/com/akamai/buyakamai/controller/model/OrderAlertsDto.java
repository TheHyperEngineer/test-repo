package com.akamai.buyakamai.controller.model;

import java.util.List;

public class OrderAlertsDto {
    Integer orderId;
    List<Alert> alerts;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public List<Alert> getAlerts() {
        return alerts;
    }

    public void setAlerts(List<Alert> alerts) {
        this.alerts = alerts;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderAlertsDto that = (OrderAlertsDto) o;

        if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
        return alerts != null ? alerts.equals(that.alerts) : that.alerts == null;
    }

    @Override
    public int hashCode() {
        int result = orderId != null ? orderId.hashCode() : 0;
        result = 31 * result + (alerts != null ? alerts.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OrderAlertsDto{" +
                "orderId=" + orderId +
                ", alerts=" + alerts +
                '}';
    }
}
