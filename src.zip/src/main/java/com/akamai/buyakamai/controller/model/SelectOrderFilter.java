package com.akamai.buyakamai.controller.model;

import java.util.List;

public class SelectOrderFilter {

    private String type;
    private List<String> ids;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<String> getIds() {
        return ids;
    }

    public void setIds(List<String> ids) {
        this.ids = ids;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        SelectOrderFilter that = (SelectOrderFilter) o;

        if (type != null ? !type.equals(that.type) : that.type != null) return false;
        return ids != null ? ids.equals(that.ids) : that.ids == null;
    }

    @Override
    public int hashCode() {
        int result = type != null ? type.hashCode() : 0;
        result = 31 * result + (ids != null ? ids.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "SelectOrderFilter{" +
                "type='" + type + '\'' +
                ", ids=" + ids +
                '}';
    }
}
