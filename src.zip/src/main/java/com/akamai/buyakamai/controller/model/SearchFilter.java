package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown=true)
public class SearchFilter {

    private List<String> stages;

    @Valid
    @NotNull(message = "Account filter cannot be empty")
    private AccountFilter account;
    
    private OpportunityFilter opportunity;

    public List<String> getStages() {
        return stages;
    }

    public void setStages(List<String> stages) {
        this.stages = stages;
    }

    public AccountFilter getAccount() {
        return account;
    }

    public void setAccount(AccountFilter account) {
        this.account = account;
    }

	public OpportunityFilter getOpportunity() {
		return opportunity;
	}

	public void setOpportunity(OpportunityFilter opportunity) {
		this.opportunity = opportunity;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((account == null) ? 0 : account.hashCode());
		result = prime * result + ((opportunity == null) ? 0 : opportunity.hashCode());
		result = prime * result + ((stages == null) ? 0 : stages.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SearchFilter other = (SearchFilter) obj;
		if (account == null) {
			if (other.account != null)
				return false;
		} else if (!account.equals(other.account))
			return false;
		if (opportunity == null) {
			if (other.opportunity != null)
				return false;
		} else if (!opportunity.equals(other.opportunity))
			return false;
		if (stages == null) {
			if (other.stages != null)
				return false;
		} else if (!stages.equals(other.stages))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SearchFilter [stages=" + stages + ", account=" + account + ", opportunity=" + opportunity + "]";
	}

}
