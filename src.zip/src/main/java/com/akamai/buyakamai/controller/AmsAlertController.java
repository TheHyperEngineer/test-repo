package com.akamai.buyakamai.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.service.impl.AlertService;

@RestController
public class AmsAlertController {

	@Autowired
	AlertService alertService;
	
	@RequestMapping(value = "v1/amsalerts/{alertId}", method = RequestMethod.PUT, produces = "application/json;charset=UTF-8")
	public boolean markAlertResolved(@PathVariable String alertId) {
		return alertService.markAlertResolved(alertId);
	}
}
