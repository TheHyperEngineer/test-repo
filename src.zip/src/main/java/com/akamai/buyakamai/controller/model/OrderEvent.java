package com.akamai.buyakamai.controller.model;

public class OrderEvent {
    private String name;
    private String time;

    public String getName() {
        return name;
    }

    public String getTime() {
        return time;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setTime(String time) {
        this.time = time;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrderEvent event = (OrderEvent) o;

        if (name != null ? !name.equals(event.name) : event.name != null) return false;
        return time != null ? time.equals(event.time) : event.time == null;
    }

    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + (time != null ? time.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "OrderEvent{" +
                "name='" + name + '\'' +
                ", time='" + time + '\'' +
                '}';
    }
}
