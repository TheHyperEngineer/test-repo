package com.akamai.buyakamai.controller.model;

public class ProductDesired {

    private String bundleId;
    private String bundleName;

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getBundleName() {
        return bundleName;
    }

    public void setBundleName(String bundleName) {
        this.bundleName = bundleName;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ProductDesired that = (ProductDesired) o;

        if (bundleId != null ? !bundleId.equals(that.bundleId) : that.bundleId != null) return false;
        return bundleName != null ? bundleName.equals(that.bundleName) : that.bundleName == null;
    }

    @Override
    public int hashCode() {
        int result = bundleId != null ? bundleId.hashCode() : 0;
        result = 31 * result + (bundleName != null ? bundleName.hashCode() : 0);
        return result;
    }
}
