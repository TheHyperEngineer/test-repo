package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class HistogramExperience {
    private  String good;
    private String bad;

    public String getGood() {
        return good;
    }

    public void setGood(String good) {
        this.good = good;
    }

    public String getBad() {
        return bad;
    }

    public void setBad(String bad) {
        this.bad = bad;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        HistogramExperience that = (HistogramExperience) o;

        if (good != null ? !good.equals(that.good) : that.good != null) return false;
        return bad != null ? bad.equals(that.bad) : that.bad == null;
    }

    @Override
    public int hashCode() {
        int result = good != null ? good.hashCode() : 0;
        result = 31 * result + (bad != null ? bad.hashCode() : 0);
        return result;
    }
}
