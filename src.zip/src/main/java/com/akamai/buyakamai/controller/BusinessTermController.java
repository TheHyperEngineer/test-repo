package com.akamai.buyakamai.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.akamai.buyakamai.model.oms.BusinessTermRequest;
import com.akamai.buyakamai.model.oms.BusinessTermResponse;
import com.akamai.buyakamai.service.impl.BusinessTermService;

@RestController
public class BusinessTermController {

	private static final Logger logger = LoggerFactory.getLogger(BusinessTermController.class);
			
	@Autowired
	BusinessTermService businessTermService;
	
	@RequestMapping(value = "v4/special-business-terms", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public ResponseEntity<List<BusinessTermResponse>> getSpecialBusinessTerms(@Context HttpServletRequest httpRequest, @RequestBody BusinessTermRequest businessTermRequest) {
		
		logger.info("intering getSpecialBusinessTerms() with service-flow : {} and orderSourceId : {}",businessTermRequest.getServiceFlow(),businessTermRequest.getOrderSourceId());
		List<BusinessTermResponse> response = businessTermService.getSpecialBusinessTerm(businessTermRequest);
		return new ResponseEntity<>(response, HttpStatus.OK);
	}
}
