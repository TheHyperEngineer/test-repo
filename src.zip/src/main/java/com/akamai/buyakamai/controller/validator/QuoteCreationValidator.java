package com.akamai.buyakamai.controller.validator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Currency;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.OrderSourceType;
import com.akamai.buyakamai.constants.ProductMasterConstants;
import com.akamai.buyakamai.controller.model.QuoteCreationRequest;
import com.akamai.buyakamai.controller.model.QuoteProduct;
import com.akamai.buyakamai.controller.model.QuoteRequestListItem;
import com.akamai.buyakamai.controller.model.QuoteRequestOption;
import com.akamai.buyakamai.controller.model.QuoteRequestOptionGroup;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.service.impl.PartnerService;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.HTTPResponseCodes;
import com.akamai.buyakamai.util.PropertyManager;
import com.akamai.buyakamai.util.PulsarUrlBuilder;
import com.akamai.se.dto.problem.Problem;
import com.akamai.se.dto.problem.ProblemBuilder;

@Component
@Transactional(propagation = Propagation.REQUIRED)
public class QuoteCreationValidator {

	private static final String INVALID_PARTNER_REQUEST = "Invalid Partner Request";


	@Autowired
	private PartnerService partnerService;

	@Autowired
	private PropertyManager propertyManager;
	
	private static Logger logger = LoggerFactory.getLogger(QuoteCreationValidator.class.getName());

    
	private static final String INVALID_QUOTE_CREATION_REQUEST = "Invalid Quote Creation Request.";
	private static final String FIELD_SANITY_CHECK = "FIELD_SANITY_CHECK";
    
	public boolean isValidQuoteCreationRequest(QuoteCreationRequest quoteCreationRequest, List<String> roles)  {
		logger.info("Validation started for request {} ",quoteCreationRequest);
		boolean isPartnerFlow = false;
		
		if(StringUtils.isNotBlank(quoteCreationRequest.getRequestorType())) {
			isPartnerFlow = true;
		}
		List<Problem> problems = new ArrayList<>();
		checkFieldValidity(quoteCreationRequest,problems);
		//This is hack because of WAP products
		checkListItemsExistsForOptions(quoteCreationRequest, problems);
		throwBadInputException(quoteCreationRequest, problems);

		checkIfValidCurrency(quoteCreationRequest,problems);

		validateSourceType(quoteCreationRequest, isPartnerFlow, problems);

		checkRoleAuthorization(quoteCreationRequest, isPartnerFlow, roles, problems);
		
		checkPartnerSpecificValidations(quoteCreationRequest, isPartnerFlow, problems);

		logger.info("Validation success for request {} ",quoteCreationRequest);
		return true;
	}

	/**
	 * In this method, we need to check if each option is having an list-item or
	 * not except for th products of WAP POC kit product.
	 */
	private void checkListItemsExistsForOptions(QuoteCreationRequest quoteCreationRequest, List<Problem> problems) {
		String bundleId = quoteCreationRequest.getBundleId();
		// get list of wap bundles
		List<String> wapPocBundleIds = CommonUtils.convertCommaSeparatedStringToList(
		        propertyManager.getProperty(ProductMasterConstants.WAP_POC_BUNDLE_IDS));
		List<String> wapProductsMktIds = null;
		if (propertyManager.getProperty(ProductMasterConstants.WAP_ION_POC_BUNDLE_ID).equals(bundleId)) {
			wapProductsMktIds = CommonUtils.convertCommaSeparatedStringToList(
			        propertyManager.getProperty(ProductMasterConstants.WAP_ION_POC_OPTIONS_MKT_IDS));
		} else if (propertyManager.getProperty(ProductMasterConstants.WAP_POC_BUNDLE_ID).equals(bundleId)) {
			wapProductsMktIds = CommonUtils.convertCommaSeparatedStringToList(
			        propertyManager.getProperty(ProductMasterConstants.WAP_POC_OPTIONS_MKT_IDS));
		} else if (propertyManager.getProperty(ProductMasterConstants.DEVELOPER_KIT_BUNDLE_ID).equals(bundleId)) {
			wapProductsMktIds = CommonUtils.convertCommaSeparatedStringToList(
			        propertyManager.getProperty(ProductMasterConstants.DEVELOPER_KIT_OPTIONS_MKT_IDS));

		}
		if (quoteCreationRequest.getProducts() != null) {
			List<List<QuoteRequestOptionGroup>> requestOptionGroupsList = quoteCreationRequest.getProducts().stream()
			        .map(QuoteProduct::getOptionGroups).collect(Collectors.toList());
			if (!CollectionUtils.isEmpty(requestOptionGroupsList)) {
				List<QuoteRequestOption> quoteRequestOptionList = requestOptionGroupsList.stream()
				        .flatMap(quoteRequestOptionGroups -> quoteRequestOptionGroups.stream().flatMap(
				                (Function<QuoteRequestOptionGroup, Stream<QuoteRequestOption>>) quoteRequestOptionGroup -> quoteRequestOptionGroup
				                        .getOptions().stream()))
				        .collect(Collectors.toList());

				for (QuoteRequestOption optionGroupList : quoteRequestOptionList) {
					if (wapPocBundleIds.contains(bundleId) && wapProductsMktIds.contains(optionGroupList.getOptionId())) {
						continue;//skip if the option is a part of product in WAP POC KIT
					} else {
						if (CollectionUtils.isEmpty(optionGroupList.getListItems())) {
							addProblem(FIELD_SANITY_CHECK, "Pricing details: List items can not be null or empty for Option", problems);
						}else {
							Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
							for (QuoteRequestListItem listItem : optionGroupList.getListItems()) {
								Set<ConstraintViolation<QuoteRequestListItem>> constraintViolations = validator.validate(listItem);
								Iterator<ConstraintViolation<QuoteRequestListItem>> constraintViolationIterator = constraintViolations.iterator();
								while (constraintViolationIterator.hasNext()) {
									ConstraintViolation<QuoteRequestListItem> constraintViolation = constraintViolationIterator.next();
									addProblem(FIELD_SANITY_CHECK, constraintViolation.getMessage(), problems);
								}
							}
						}

					}
				}
			}
		}
	}

	private void checkPartnerSpecificValidations(QuoteCreationRequest quoteCreationRequest, boolean isPartnerFlow,
	        List<Problem> problems) {
		boolean isPartnerLoggedIn = partnerService.isPartnerUserLoggedIn();
		if (isPartnerLoggedIn && !isPartnerFlow) {
			logger.error("Partner is trying to access direct flow");
			addProblem(FIELD_SANITY_CHECK, INVALID_PARTNER_REQUEST, problems);
			throwBadInputException(quoteCreationRequest, problems);
		}
		if (isPartnerFlow) {
			if (StringUtils.isBlank(quoteCreationRequest.getPartnerAccountId())
			        || StringUtils.isBlank(quoteCreationRequest.getAccountId())
			        || StringUtils.isBlank(quoteCreationRequest.getTrialManagerContactId())) {
				logger.error("Invalid partner Request");
				addProblem(FIELD_SANITY_CHECK, INVALID_PARTNER_REQUEST, problems);
				throwBadInputException(quoteCreationRequest, problems);
			}
			if (isPartnerLoggedIn && (StringUtils.isBlank(quoteCreationRequest.getPartnerContractId())
			        || !quoteCreationRequest.isTncAccepted())) {
				logger.error("Invalid partner Request");
				addProblem(FIELD_SANITY_CHECK, INVALID_PARTNER_REQUEST, problems);
				throwBadInputException(quoteCreationRequest, problems);
			}
			partnerService.validateForBlockedPartnerAccount(quoteCreationRequest.getPartnerAccountId());
		}

		if (!isPartnerLoggedIn && (quoteCreationRequest.isTncAccepted()
		        || StringUtils.isNotBlank(quoteCreationRequest.getPartnerContractId()))) {
			logger.error("Invalid Non Partner Request");
			addProblem(FIELD_SANITY_CHECK, INVALID_PARTNER_REQUEST, problems);
			throwBadInputException(quoteCreationRequest, problems);
		}

		if (!isPartnerFlow && (StringUtils.isNotBlank(quoteCreationRequest.getPartnerAccountId())
		        || StringUtils.isNotBlank(quoteCreationRequest.getAccountId())
		        || StringUtils.isNotBlank(quoteCreationRequest.getTrialManagerContactId()))) {
			logger.error("Invalid Request");
			addProblem(FIELD_SANITY_CHECK, INVALID_PARTNER_REQUEST, problems);
			throwBadInputException(quoteCreationRequest, problems);
		}
	}

	private void checkRoleAuthorization(QuoteCreationRequest quoteCreationRequest, boolean isPartnerFlow,
	        List<String> roles, List<Problem> problems) {
		if (roles.contains(BAConstants.INTEGRATED_OPS_ROLE)) {
			return;
		}

		if (!roles.contains(BAConstants.SDR_ROLE)
		        && OrderSourceType.LEAD.name().equalsIgnoreCase(quoteCreationRequest.getSourceType())) {
			addProblem("AUTHORIZATION_CHECK", "Only SDR can create quote from Lead", problems);
			throwBadInputException(quoteCreationRequest, problems);
		}
		List<String> salesRepRoles = new ArrayList<>(BAConstants.SALES_RELATED_ROLES);
		if (isPartnerFlow) {
			salesRepRoles.add(BAConstants.PARTNER_ADMIN_ROLE);
			salesRepRoles.add(BAConstants.PAE_ROLE);
			salesRepRoles.add(BAConstants.INTEGRATED_OPS_ROLE);
		}
		if (Collections.disjoint(roles, salesRepRoles)
		        && OrderSourceType.OPPORTUNITY.name().equalsIgnoreCase(quoteCreationRequest.getSourceType())) {
			addProblem("AUTHORIZATION_CHECK", "Only Sales rep can create quote from Opportunity", problems);
			throwBadInputException(quoteCreationRequest, problems);
		}
	}


	private void throwBadInputException(QuoteCreationRequest quoteCreationRequest, List<Problem> problems) {
		if (!problems.isEmpty()) {
			HTTPResponseCodes httpResponseCode = HTTPResponseCodes.valueOf(HttpStatus.BAD_REQUEST.name());
			Problem problem = new ProblemBuilder()
        				.title(INVALID_QUOTE_CREATION_REQUEST).detail("REQUEST_FIELDS_SANITY_CHECK")
        				.type(PulsarUrlBuilder.path(httpResponseCode.getStatusTitle()).toUriString()).errors(problems)
        				.status(HttpStatus.BAD_REQUEST.value())
        				.appendProblemIdToInstance()
        				.build();  
			BuyAkamaiApplicationException badInputException =  new BuyAkamaiApplicationException(problem,HttpStatus.BAD_REQUEST);
			logger.error(INVALID_QUOTE_CREATION_REQUEST, " In correct Input Data {}",quoteCreationRequest);
		    throw badInputException;
		}
	}

	private void validateSourceType(QuoteCreationRequest quoteCreationRequest, boolean isPartnerFlow,
	        List<Problem> problems) {
			try {
				String sourceType = quoteCreationRequest.getSourceType();
				if (!EnumUtils.isValidEnum(OrderSourceType.class, sourceType.toUpperCase())) {
					throw new RuntimeException();
				}
				if(OrderSourceType.LEAD.name().equalsIgnoreCase(quoteCreationRequest.getSourceType())){
					throw new RuntimeException();
				}
				if (isPartnerFlow
						&& !OrderSourceType.OPPORTUNITY.name().equalsIgnoreCase(quoteCreationRequest.getSourceType())) {
					throw new RuntimeException();
				}
				
			} catch (Exception e) {
				logger.error("Invalid source type ");
				addProblem(FIELD_SANITY_CHECK, "Invalid source Type", problems);
				throwBadInputException(quoteCreationRequest, problems);
			}
	}

	private void checkIfValidCurrency(QuoteCreationRequest quoteCreationRequest,List<Problem> problems) {
		String opportunityCurrency = quoteCreationRequest.getCurrency();
		logger.debug("Validation in progress : currency valid {} ",opportunityCurrency);
    	try {
			Currency.getInstance(opportunityCurrency);
    	} catch (IllegalArgumentException exception) {
    		logger.error("Invalid currency code ",exception);
    		addProblem(FIELD_SANITY_CHECK,  "Invalid Currency Code", problems);
    		throwBadInputException(quoteCreationRequest, problems);
    	}
    }
	
	private void checkFieldValidity(QuoteCreationRequest quoteCreationRequest, List<Problem> problems) {
		Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
		Set<ConstraintViolation<QuoteCreationRequest>> constraintViolations = validator.validate(quoteCreationRequest);
		Iterator<ConstraintViolation<QuoteCreationRequest>> constraintViolationIterator =  constraintViolations.iterator();

		while(constraintViolationIterator.hasNext()) {
			ConstraintViolation<QuoteCreationRequest> constraintViolation = constraintViolationIterator.next();
			addProblem(FIELD_SANITY_CHECK, constraintViolation.getMessage() , problems); 
		}
	}
	
	private void addProblem(String title, String detail, List<Problem> problems) {
		 String type = PulsarUrlBuilder.path(HTTPResponseCodes.BAD_REQUEST.getStatusTitle()).toUriString();
		Problem problem = new ProblemBuilder().title(title).detail(detail).type(type).build();
		logger.info("Adding a problem into the system. title :{}, details: {}", title, detail);
		problems.add(problem);
	}

}
