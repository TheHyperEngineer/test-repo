package com.akamai.buyakamai.controller.model;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Map;


@JsonIgnoreProperties(ignoreUnknown = true)
public class EventData {

    private Integer id;
    
    private Integer orderId;

    private String eventType;

    private String eventAction;

    private String timestamp;

    private String accountId;

    private String accountName;

    private String contactId;

    private String bundleId;

	private String marketingProductId;

    private Map<String, String> data;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventAction() {
        return eventAction;
    }

    public void setEventAction(String eventAction) {
        this.eventAction = eventAction;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }
    public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

    public String getMarketingProductId() {
		return marketingProductId;
	}

	public void setMarketingProductId(String marketingProductId) {
		this.marketingProductId = marketingProductId;
	}

	public Map<String, String> getData() {
        return data;
    }

    public void setData(Map<String, String> data) {
        this.data = data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EventData eventData = (EventData) o;

        if (id != null ? !id.equals(eventData.id) : eventData.id != null) return false;
        if (eventType != null ? !eventType.equals(eventData.eventType) : eventData.eventType != null) return false;
        if (eventAction != null ? !eventAction.equals(eventData.eventAction) : eventData.eventAction != null)
            return false;
        if (timestamp != null ? !timestamp.equals(eventData.timestamp) : eventData.timestamp != null) return false;
        if (accountId != null ? !accountId.equals(eventData.accountId) : eventData.accountId != null) return false;
        if (accountName != null ? !accountName.equals(eventData.accountName) : eventData.accountName != null)
            return false;
        if (contactId != null ? !contactId.equals(eventData.contactId) : eventData.contactId != null) return false;
        if (bundleId != null ? !bundleId.equals(eventData.bundleId) : eventData.bundleId != null) return false;
        if (marketingProductId != null ? !marketingProductId.equals(eventData.marketingProductId) : eventData.marketingProductId != null)
            return false;
        return data != null ? data.equals(eventData.data) : eventData.data == null;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (eventType != null ? eventType.hashCode() : 0);
        result = 31 * result + (eventAction != null ? eventAction.hashCode() : 0);
        result = 31 * result + (timestamp != null ? timestamp.hashCode() : 0);
        result = 31 * result + (accountId != null ? accountId.hashCode() : 0);
        result = 31 * result + (accountName != null ? accountName.hashCode() : 0);
        result = 31 * result + (contactId != null ? contactId.hashCode() : 0);
        result = 31 * result + (bundleId != null ? bundleId.hashCode() : 0);
        result = 31 * result + (marketingProductId != null ? marketingProductId.hashCode() : 0);
        result = 31 * result + (data != null ? data.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "EventData{" +
                "id=" + id +
                ", orderId='" + orderId + '\'' +
                ", eventType='" + eventType + '\'' +
                ", eventAction='" + eventAction + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", accountId='" + accountId + '\'' +
                ", accountName='" + accountName + '\'' +
                ", contactId='" + contactId + '\'' +
                ", bundleIds=" + bundleId +
                ", marketingProductIds=" + marketingProductId +
                ", data=" + data +
                '}';
    }
}
