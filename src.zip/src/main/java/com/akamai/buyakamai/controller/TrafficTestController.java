package com.akamai.buyakamai.controller;


import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.model.reports.ReportInterval;
import com.akamai.buyakamai.integration.model.reports.ReportRequest;
import com.akamai.buyakamai.integration.model.reports.ReportRequestBuilder;
import com.akamai.buyakamai.service.impl.TrafficServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.LocalDate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.List;

@Slf4j
@RestController
@EnableAutoConfiguration
public class TrafficTestController {

    // Separator used when passing CPCodes
    public static final String LIST_SEPARATOR = ",";

    // Traffic Service
    @Autowired
    private TrafficServiceImpl trafficService;


    @RequestMapping(value = "/v1/traffic/{cpCodes}", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<Long> getTrafficForCPCodes(
            @Valid @PathVariable String cpCodes,
            @RequestParam(value = "accountId", required = true) String accountId,
            @RequestParam(value = "contractId", required = true) String contractId,
            @RequestParam(value = "start_date", required = true) String start_date,
            @RequestParam(value = "end_date", required = true) String end_date,
            @RequestParam(value = "interval", required = true) String interval) {
        log.info("Entering getTrafficForCPCodeInBytes for cpCodes ", cpCodes);

        List<String> cpCodeList = Arrays.asList(cpCodes.split(TrafficTestController.LIST_SEPARATOR));
        ReportRequest request = buildTrafficReportRequest(accountId, contractId, start_date, end_date, interval, cpCodeList);

        Long trafficBytes;
        try {
            trafficBytes = trafficService.getTrafficForCPCodeInBytes(request);
        } catch (BuyAkamaiApplicationException ex) {
            log.error(String.format("Failed to get traffic data for CPCodes %s", cpCodeList), ex);
            throw ex;
        }

        log.debug("Obtained traffic {}", trafficBytes);

        return new ResponseEntity<>(trafficBytes, HttpStatus.OK);

    }

    private ReportRequest buildTrafficReportRequest(String accountId, String contractId, String start_date, String end_date, String interval, List<String> cpCodeList) {
        LocalDate startDate = new LocalDate(CommonUtils.getDateFromStringLenient(start_date));
        LocalDate endDate = new LocalDate(CommonUtils.getDateFromStringLenient(end_date));
        return new ReportRequestBuilder().accountId(accountId).contractId(contractId).cpCodes(cpCodeList)
                .interval(ReportInterval.valueOf(interval)).startDate(startDate).endDate(endDate).build();
    }
}