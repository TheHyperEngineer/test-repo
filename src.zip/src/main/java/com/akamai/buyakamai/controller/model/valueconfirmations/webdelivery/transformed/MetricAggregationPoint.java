package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class MetricAggregationPoint {

    private String date;
    private String averageResponse;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getAverageResponse() {
        return averageResponse;
    }

    public void setAverageResponse(String averageResponse) {
        this.averageResponse = averageResponse;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MetricAggregationPoint that = (MetricAggregationPoint) o;

        if (date != null ? !date.equals(that.date) : that.date != null) return false;
        return averageResponse != null ? averageResponse.equals(that.averageResponse) : that.averageResponse == null;
    }

    @Override
    public int hashCode() {
        int result = date != null ? date.hashCode() : 0;
        result = 31 * result + (averageResponse != null ? averageResponse.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "MetricAggregationPoint{" +
                "date='" + date + '\'' +
                ", averageResponse='" + averageResponse + '\'' +
                '}';
    }
}
