package com.akamai.buyakamai.controller.model;

import java.util.List;
import java.util.Optional;

public class EventRequest {

    private List<Filter> filters;

    public List<Filter> getFilters() {
        return filters;
    }

    public void setFilters(List<Filter> filters) {
        this.filters = filters;
    }

    public Optional<Filter> getFilterObject(String key) {
    	if(getFilters()==null)
    	{
    		return Optional.empty();
    	}
        return getFilters().stream().filter(filter -> filter.getKey().equalsIgnoreCase(key)).findFirst();
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        EventRequest that = (EventRequest) o;

        return filters != null ? filters.equals(that.filters) : that.filters == null;
    }

    @Override
    public int hashCode() {
        return filters != null ? filters.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "EventRequest{" +
                "filters=" + filters +
                '}';
    }

    public static class Filter {
        private String key;
        private String value;
        private List<String> values;

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }

        public List<String> getValues() {
            return values;
        }

        public void setValues(List<String> values) {
            this.values = values;
        }



        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;

            Filter filter = (Filter) o;

            if (key != null ? !key.equals(filter.key) : filter.key != null) return false;
            if (value != null ? !value.equals(filter.value) : filter.value != null) return false;
            return values != null ? values.equals(filter.values) : filter.values == null;
        }

        @Override
        public int hashCode() {
            int result = key != null ? key.hashCode() : 0;
            result = 31 * result + (value != null ? value.hashCode() : 0);
            result = 31 * result + (values != null ? values.hashCode() : 0);
            return result;
        }

        @Override
        public String toString() {
            return "Filter{" +
                    "key='" + key + '\'' +
                    ", value='" + value + '\'' +
                    ", values=" + values +
                    '}';
        }
    }
}
