package com.akamai.buyakamai.controller.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.hibernate.validator.constraints.NotEmpty;

public class QuoteRequestOption {
	
	@NotNull(message="OptionId cannot be null")
	@NotEmpty(message="OptionId cannot be empty")
	private String optionId;
	
	/*This is commented because to support the WAP POC products.
	@Valid
	@NotNull(message="Pricing details: List items can not be null for Option")
	@NotEmpty(message="Pricing details: List items can not be empty for Option")*/
	private List<QuoteRequestListItem> listItems;
	

	public String getOptionId() {
		return optionId;
	}

	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	public List<QuoteRequestListItem> getListItems() {
		return listItems;
	}

	public void setListItems(List<QuoteRequestListItem> listItems) {
		this.listItems = listItems;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((listItems == null) ? 0 : listItems.hashCode());
		result = prime * result + ((optionId == null) ? 0 : optionId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuoteRequestOption other = (QuoteRequestOption) obj;
		if (listItems == null) {
			if (other.listItems != null)
				return false;
		} else if (!listItems.equals(other.listItems))
			return false;
		if (optionId == null) {
			if (other.optionId != null)
				return false;
		} else if (!optionId.equals(other.optionId))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
