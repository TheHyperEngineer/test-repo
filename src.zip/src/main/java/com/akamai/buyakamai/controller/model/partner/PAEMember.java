package com.akamai.buyakamai.controller.model.partner;

public class PAEMember {

    private String fullName;

    private String email;

    private String phoneNo;

    private String contactId;

    private boolean isMaster;

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public boolean isMaster() {
        return isMaster;
    }

    public void setMaster(boolean master) {
        isMaster = master;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PAEMember paeMember = (PAEMember) o;

        return contactId != null ? contactId.equals(paeMember.contactId) : paeMember.contactId == null;
    }

    @Override
    public int hashCode() {
        return contactId != null ? contactId.hashCode() : 0;
    }
}
