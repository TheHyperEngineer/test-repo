package com.akamai.buyakamai.controller.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;

import com.akamai.buyakamai.integration.model.productmaster.ListItemDTO;


@JsonIgnoreProperties(ignoreUnknown = true)
public class OptionResponse {

	private String optionId;

	private String optionName;

	private String optionNotes;

	private String provisioningURL;

	private List<String> serverType;

	private Boolean mandatory;

	private List<ListItemDTO> listItems;

	public String getOptionId() {
		return optionId;
	}

	public void setOptionId(String optionId) {
		this.optionId = optionId;
	}

	public String getOptionName() {
		return optionName;
	}

	public void setOptionName(String optionName) {
		this.optionName = optionName;
	}

	public String getOptionNotes() {
		return optionNotes;
	}

	public void setOptionNotes(String optionNotes) {
		this.optionNotes = optionNotes;
	}

	public String getProvisioningURL() {
		return provisioningURL;
	}

	public void setProvisioningURL(String provisioningURL) {
		this.provisioningURL = provisioningURL;
	}

	public List<String> getServerType() {
		return serverType;
	}

	public void setServerType(List<String> serverType) {
		this.serverType = serverType;
	}

	public Boolean getMandatory() {
		return mandatory;
	}

	public void setMandatory(Boolean mandatory) {
		this.mandatory = mandatory;
	}

	public List<ListItemDTO> getListItems() {
		return listItems;
	}

	public void setListItems(List<ListItemDTO> listItems) {
		this.listItems = listItems;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		OptionResponse that = (OptionResponse) o;

		if (optionId != null ? !optionId.equals(that.optionId) : that.optionId != null) return false;
		if (optionName != null ? !optionName.equals(that.optionName) : that.optionName != null) return false;
		if (optionNotes != null ? !optionNotes.equals(that.optionNotes) : that.optionNotes != null) return false;
		if (provisioningURL != null ? !provisioningURL.equals(that.provisioningURL) : that.provisioningURL != null)
			return false;
		if (serverType != null ? !serverType.equals(that.serverType) : that.serverType != null) return false;
		if (mandatory != null ? !mandatory.equals(that.mandatory) : that.mandatory != null) return false;
		return listItems != null ? listItems.equals(that.listItems) : that.listItems == null;
	}

	@Override
	public int hashCode() {
		int result = optionId != null ? optionId.hashCode() : 0;
		result = 31 * result + (optionName != null ? optionName.hashCode() : 0);
		result = 31 * result + (optionNotes != null ? optionNotes.hashCode() : 0);
		result = 31 * result + (provisioningURL != null ? provisioningURL.hashCode() : 0);
		result = 31 * result + (serverType != null ? serverType.hashCode() : 0);
		result = 31 * result + (mandatory != null ? mandatory.hashCode() : 0);
		result = 31 * result + (listItems != null ? listItems.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}
