package com.akamai.buyakamai.controller.model;

public class TermsAndConditionResponse {

	private String boilerplate;
	
	private String terms;

	public TermsAndConditionResponse() {
	}

	public TermsAndConditionResponse(String boilerplate, String terms) {
		this.boilerplate = boilerplate;
		this.terms = terms;
	}

	public String getBoilerplate() {
		return boilerplate;
	}

	public void setBoilerplate(String boilerplate) {
		this.boilerplate = boilerplate;
	}

	public String getTerms() {
		return terms;
	}

	public void setTerms(String terms) {
		this.terms = terms;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (!(o instanceof TermsAndConditionResponse))
			return false;

		TermsAndConditionResponse that = (TermsAndConditionResponse) o;

		if (boilerplate != null ? !boilerplate.equals(that.boilerplate) : that.boilerplate != null)
			return false;
		return terms != null ? terms.equals(that.terms) : that.terms == null;
	}

	@Override
	public int hashCode() {
		int result = boilerplate != null ? boilerplate.hashCode() : 0;
		result = 31 * result + (terms != null ? terms.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("TermsAndConditionResponse{");
		sb.append("boilerplate='").append(boilerplate).append('\'');
		sb.append(", terms='").append(terms).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
