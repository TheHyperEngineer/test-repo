package com.akamai.buyakamai.controller.model.partner;

import java.util.Set;

public class PartnerAccountMembers {

    private Set<PAEMember> pae;

    public Set<PAEMember> getPae() {
        return pae;
    }

    public void setPae(Set<PAEMember> pae) {
        this.pae = pae;
    }
}
