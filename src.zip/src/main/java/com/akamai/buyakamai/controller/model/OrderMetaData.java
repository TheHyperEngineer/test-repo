package com.akamai.buyakamai.controller.model;

import java.util.List;

public class OrderMetaData {

    private List<String> competitors;

    public void setCompetitors(List<String> competitors) {
        this.competitors = competitors;
    }

    public List<String> getCompetitors() {
        return competitors;
    }
}
