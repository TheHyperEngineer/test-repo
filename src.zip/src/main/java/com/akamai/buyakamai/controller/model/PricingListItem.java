package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.math.BigDecimal;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PricingListItem {
	private String listItemId;
	private Integer optionId;
	private Long defaultQuantity;
	private boolean isQuantityUserSelectable;
	private Long maxQuantity;
	private UOMInfo uom;
	private String billingFrequency;
	private BigDecimal basePrice;
	private List<TierResponse> tiers;

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((listItemId == null) ? 0 : listItemId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PricingListItem other = (PricingListItem) obj;
		if (listItemId == null) {
			if (other.listItemId != null)
				return false;
		} else if (!listItemId.equals(other.listItemId))
			return false;
		return true;
	}
	public String getListItemId() {
		return listItemId;
	}
	public void setListItemId(String listItemId) {
		this.listItemId = listItemId;
	}
	public Long getDefaultQuantity() {
		return defaultQuantity;
	}
	public void setDefaultQuantity(Long defaultQuantity) {
		this.defaultQuantity = defaultQuantity;
	}
	public boolean isQuantityUserSelectable() {
		return isQuantityUserSelectable;
	}
	public void setQuantityUserSelectable(boolean isQuantityUserSelectable) {
		this.isQuantityUserSelectable = isQuantityUserSelectable;
	}
	public Long getMaxQuantity() {
		return maxQuantity;
	}
	public void setMaxQuantity(Long maxQuantity) {
		this.maxQuantity = maxQuantity;
	}
	
	public UOMInfo getUom() {
		return uom;
	}
	public void setUom(UOMInfo uom) {
		this.uom = uom;
	}
	public String getBillingFrequency() {
		return billingFrequency;
	}
	public void setBillingFrequency(String billingFrequency) {
		this.billingFrequency = billingFrequency;
	}
	public BigDecimal getBasePrice() {
		return basePrice;
	}
	public void setBasePrice(BigDecimal basePrice) {
		this.basePrice = basePrice;
	}
	public List<TierResponse> getTiers() {
		return tiers;
	}
	public void setTiers(List<TierResponse> tiers) {
		this.tiers = tiers;
	}
	@Override
	public String toString() {
		return "PricingListItem [listItemId=" + listItemId + ", defaultQuantity=" + defaultQuantity
				+ ", isQuantityUserSelectable=" + isQuantityUserSelectable + ", maxQuantity=" + maxQuantity + ", uom="
				+ uom + ", billingFrequency=" + billingFrequency + ", basePrice=" + basePrice + ", tiers=" + tiers
				+ "]";
	}

	public Integer getOptionId() {
		return optionId;
	}

	public void setOptionId(Integer optionId) {
		this.optionId = optionId;
	}
}
