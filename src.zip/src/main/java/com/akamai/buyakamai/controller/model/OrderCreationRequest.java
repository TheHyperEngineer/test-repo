package com.akamai.buyakamai.controller.model;

import org.hibernate.validator.constraints.NotBlank;

import java.util.List;

import javax.validation.constraints.Pattern;

public class OrderCreationRequest {

    @NotBlank(message = "prodOptId cannot be blank")
    private String prodOptId;

    @NotBlank(message = "prodOptType cannot be blank")
    private String prodOptType;

    @NotBlank(message = "Currency cannot be empty")
    private String currency;

    @NotBlank(message = "ContactId cannot be empty")
    private String contactId;

    private String sourceId;

    @NotBlank(message = "sourceId cannot be empty")
    private String sourceType;

    @NotBlank(message = "accountId cannot be empty")
    private String accountId;

    @NotBlank(message = "integrationType cannot be empty")
    private String integrationType;

    @NotBlank(message = "trialDuration cannot be empty")
    @Pattern(regexp = "[P]([0-9]+)[D]")
    private String trialDuration;

    @NotBlank(message = "type cannot be empty")
    private String type;

    private String orderInitiator;
    private String contractType;
    private String createdByUserId;
    
    private String partnerAccountId;
    
    private boolean tncAccepted;
    
    private String trialManagerContactId;
    
    private String requestorType;
    
    private List<String> contractIds;
    
	private boolean existingAccountNewContract;

    public String getCreatedByUserId() {
        return createdByUserId;
    }

    public void setCreatedByUserId(String createdByUserId) {
        this.createdByUserId = createdByUserId;
    }

    public String getProdOptId() {
        return prodOptId;
    }

    public void setProdOptId(String prodOptId) {
        this.prodOptId = prodOptId;
    }

    public String getProdOptType() {
        return prodOptType;
    }

    public void setProdOptType(String prodOptType) {
        this.prodOptType = prodOptType;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getContactId() {
        return contactId;
    }

    public void setContactId(String contactId) {
        this.contactId = contactId;
    }

    public String getSourceId() {
        return sourceId;
    }

    public void setSourceId(String sourceId) {
        this.sourceId = sourceId;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getIntegrationType() {
        return integrationType;
    }

    public void setIntegrationType(String integrationType) {
        this.integrationType = integrationType;
    }

    public String getTrialDuration() {
        return trialDuration;
    }

    public void setTrialDuration(String trialDuration) {
        this.trialDuration = trialDuration;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOrderInitiator() {
        return orderInitiator;
    }

    public void setOrderInitiator(String orderInitiator) {
        this.orderInitiator = orderInitiator;
    }

    public String getContractType() {
        return contractType;
    }

    public void setContractType(String contractType) {
        this.contractType = contractType;
    }

    public String getPartnerAccountId() {
		return partnerAccountId;
	}

	public void setPartnerAccountId(String partnerAccountId) {
		this.partnerAccountId = partnerAccountId;
	}

	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}

	public String getTrialManagerContactId() {
		return trialManagerContactId;
	}

	public void setTrialManagerContactId(String trialManagerContactId) {
		this.trialManagerContactId = trialManagerContactId;
	}

	public String getRequestorType() {
		return requestorType;
	}

	public void setRequestorType(String requestorType) {
		this.requestorType = requestorType;
	}

	public List<String> getContractIds() {
		return contractIds;
	}

	public void setContractIds(List<String> contractIds) {
		this.contractIds = contractIds;
	}
	

	public boolean isExistingAccountNewContract() {
		return existingAccountNewContract;
	}

	public void setExistingAccountNewContract(boolean existingAccountNewContract) {
		this.existingAccountNewContract = existingAccountNewContract;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderCreationRequest other = (OrderCreationRequest) obj;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (contactId == null) {
			if (other.contactId != null)
				return false;
		} else if (!contactId.equals(other.contactId))
			return false;
		if (contractIds == null) {
			if (other.contractIds != null)
				return false;
		} else if (!contractIds.equals(other.contractIds))
			return false;
		if (contractType == null) {
			if (other.contractType != null)
				return false;
		} else if (!contractType.equals(other.contractType))
			return false;
		if (createdByUserId == null) {
			if (other.createdByUserId != null)
				return false;
		} else if (!createdByUserId.equals(other.createdByUserId))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (existingAccountNewContract != other.existingAccountNewContract)
			return false;
		if (integrationType == null) {
			if (other.integrationType != null)
				return false;
		} else if (!integrationType.equals(other.integrationType))
			return false;
		if (orderInitiator == null) {
			if (other.orderInitiator != null)
				return false;
		} else if (!orderInitiator.equals(other.orderInitiator))
			return false;
		if (partnerAccountId == null) {
			if (other.partnerAccountId != null)
				return false;
		} else if (!partnerAccountId.equals(other.partnerAccountId))
			return false;
		if (prodOptId == null) {
			if (other.prodOptId != null)
				return false;
		} else if (!prodOptId.equals(other.prodOptId))
			return false;
		if (prodOptType == null) {
			if (other.prodOptType != null)
				return false;
		} else if (!prodOptType.equals(other.prodOptType))
			return false;
		if (requestorType == null) {
			if (other.requestorType != null)
				return false;
		} else if (!requestorType.equals(other.requestorType))
			return false;
		if (sourceId == null) {
			if (other.sourceId != null)
				return false;
		} else if (!sourceId.equals(other.sourceId))
			return false;
		if (sourceType == null) {
			if (other.sourceType != null)
				return false;
		} else if (!sourceType.equals(other.sourceType))
			return false;
		if (tncAccepted != other.tncAccepted)
			return false;
		if (trialDuration == null) {
			if (other.trialDuration != null)
				return false;
		} else if (!trialDuration.equals(other.trialDuration))
			return false;
		if (trialManagerContactId == null) {
			if (other.trialManagerContactId != null)
				return false;
		} else if (!trialManagerContactId.equals(other.trialManagerContactId))
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type))
			return false;
		return true;
	}

    @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((contactId == null) ? 0 : contactId.hashCode());
		result = prime * result + ((contractIds == null) ? 0 : contractIds.hashCode());
		result = prime * result + ((contractType == null) ? 0 : contractType.hashCode());
		result = prime * result + ((createdByUserId == null) ? 0 : createdByUserId.hashCode());
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + (existingAccountNewContract ? 1231 : 1237);
		result = prime * result + ((integrationType == null) ? 0 : integrationType.hashCode());
		result = prime * result + ((orderInitiator == null) ? 0 : orderInitiator.hashCode());
		result = prime * result + ((partnerAccountId == null) ? 0 : partnerAccountId.hashCode());
		result = prime * result + ((prodOptId == null) ? 0 : prodOptId.hashCode());
		result = prime * result + ((prodOptType == null) ? 0 : prodOptType.hashCode());
		result = prime * result + ((requestorType == null) ? 0 : requestorType.hashCode());
		result = prime * result + ((sourceId == null) ? 0 : sourceId.hashCode());
		result = prime * result + ((sourceType == null) ? 0 : sourceType.hashCode());
		result = prime * result + (tncAccepted ? 1231 : 1237);
		result = prime * result + ((trialDuration == null) ? 0 : trialDuration.hashCode());
		result = prime * result + ((trialManagerContactId == null) ? 0 : trialManagerContactId.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

    @Override
	public String toString() {
		return "OrderCreationRequest [prodOptId=" + prodOptId + ", prodOptType=" + prodOptType + ", currency="
		        + currency + ", contactId=" + contactId + ", sourceId=" + sourceId + ", sourceType=" + sourceType
		        + ", accountId=" + accountId + ", integrationType=" + integrationType + ", trialDuration="
		        + trialDuration + ", type=" + type + ", orderInitiator=" + orderInitiator + ", contractType="
		        + contractType + ", createdByUserId=" + createdByUserId + ", partnerAccountId=" + partnerAccountId
		        + ", tncAccepted=" + tncAccepted + ", trialManagerContactId=" + trialManagerContactId
		        + ", requestorType=" + requestorType + ", contractIds=" + contractIds + ", existingAccountNewContract="
		        + existingAccountNewContract + "]";
	}
}