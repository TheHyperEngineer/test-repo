package com.akamai.buyakamai.controller.model.partner;

public class OpportunityInfo {

    private String repCreatedOppId;
    private String stpOppId;


    public String getRepCreatedOppId() {
        return repCreatedOppId;
    }

    public void setRepCreatedOppId(String repCreatedOppId) {
        this.repCreatedOppId = repCreatedOppId;
    }

    public String getStpOppId() {
        return stpOppId;
    }

    public void setStpOppId(String stpOppId) {
        this.stpOppId = stpOppId;
    }

}
