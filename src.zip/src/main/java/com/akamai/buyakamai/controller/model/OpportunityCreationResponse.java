package com.akamai.buyakamai.controller.model;

public class OpportunityCreationResponse {
    private String opportunityId;

    public String getOpportunityId() {
        return opportunityId;
    }

    public void setOpportunityId(String opportunityId) {
        this.opportunityId = opportunityId;
    }
}
