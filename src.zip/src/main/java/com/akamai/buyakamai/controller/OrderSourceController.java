package com.akamai.buyakamai.controller;


import com.akamai.buyakamai.constants.BAConstants;
import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.constants.EventDataPoint;
import com.akamai.buyakamai.constants.UserEventAction;
import com.akamai.buyakamai.controller.model.*;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.integration.clients.model.AccountOpportunityDto;
import com.akamai.buyakamai.service.events.EventInfo;
import com.akamai.buyakamai.service.events.EventProcessor;
import com.akamai.buyakamai.service.impl.AuthorizationServiceImpl;
import com.akamai.buyakamai.service.impl.OrderSourceServiceImpl;
import com.akamai.buyakamai.util.CommonUtils;
import com.akamai.buyakamai.util.RequestFetcher;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StopWatch;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.ws.rs.core.Context;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class OrderSourceController {

    private static final Logger logger = LoggerFactory.getLogger(OrderSourceController.class);

    @Autowired
    private AuthorizationServiceImpl authService;

    @Autowired
    private OrderSourceServiceImpl orderSourceService;

    @Autowired
    private EventProcessor eventProcessor;
    
    @Autowired
    private RequestFetcher requestFetcher;


    @RequestMapping(value = "/v1/opportunities/{opportunityId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<OpportunityResponse> fetchOpportunityDetails(@PathVariable(value = "opportunityId") String opportunityId) {

        logger.info("Entering Get Oppurtunity Details API for oppID  {}", opportunityId);
        OpportunityResponse oppDetails = orderSourceService.fetchOpportunityDetails(opportunityId);

        logger.info("Exiting get oppurtunity Details API for oppID {}",opportunityId);
        logger.debug("Exiting Get Oppurtunity Details API for oppID  {} response as {} ", opportunityId, oppDetails);
        return new ResponseEntity<>(oppDetails, HttpStatus.OK);
    }

    @RequestMapping(value = "/v1/opportunities/{opportunityId}/basic-info", method = RequestMethod.GET, produces = "application/json")
    public ResponseEntity<String> fetchOpportunityDealType(@PathVariable(value = "opportunityId") String opportunityId,
                                                           @RequestParam(name = "attribute", required = true) String attribute) {
        logger.info("Entering Get Opportunity deal type for oppID  {}", opportunityId);
        String dealType = orderSourceService.getOpportunityBasicDetails(opportunityId, attribute);
        logger.debug("Exiting Get Opportunity Details API for oppID  {} response as {} ", opportunityId, dealType);
        return new ResponseEntity<>(dealType, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/opportunities", method = RequestMethod.POST, produces = "application/json")
    public ResponseEntity<OpportunityCreationResponse> createOpportunity(
            @RequestBody OpportunityCreationRequest creationRequest, @Context HttpServletRequest httpRequest) {

        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        
        //to remove : hardcoding - this logic is just to pass integration test. 
        List<String> roles = requestFetcher.getLoggedInUserRoles();
        if(StringUtils.isEmpty(creationRequest.getProductName()) && roles.contains("SALES_REP_PURCHASE")) {
        		creationRequest.setProductName("Ion");
        }
        
        logger.info("Create Opportunity Flow Started");
        String opportunityId = orderSourceService.createOpportunity(creationRequest, userName);

        OpportunityCreationResponse creationResponse = new OpportunityCreationResponse();
        creationResponse.setOpportunityId(opportunityId);
        logger.info("Opportunity created successfully");
        raiseEventForCreateOpportunity(userName, opportunityId, creationRequest.getProductName());
        return new ResponseEntity<>(creationResponse, HttpStatus.CREATED);
    }

    private void raiseEventForCreateOpportunity(String userName, String opportunityId, String productName) {
        EventInfo eventInfo = new EventInfo(userName, UserEventAction.CREATE_OPPORTUNITY_SUCCESS);
        Map<String, String> additionalInfo = new HashMap<>();
        additionalInfo.put(EventDataPoint.OPPORTUNITY_ID.name(), opportunityId);
        additionalInfo.put(EventDataPoint.PRODUCT_NAME.name(), productName);
        eventInfo.setAdditionalInfo(additionalInfo);
        eventProcessor.initiateEventProcessorThread(eventInfo);
    }

    @RequestMapping(value = "/v1/opportunities-metadata", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<OpportunityMetaData> getOpportunityMetaData() {

        logger.info("Get opportunity meta data");
        OpportunityMetaData opportunityMetaData = orderSourceService.getOpportunityMetaData();
        logger.info("Opportunity meta data retrieval successful");
        return new ResponseEntity<>(opportunityMetaData, HttpStatus.OK);
    }

    @RequestMapping(value = "v1/opportunities/search", method = RequestMethod.POST, produces = "application/json;charset=UTF-8",consumes = "application/json;charset=UTF-8")
    public ResponseEntity<List<OrderSourceLookupResponse>> searchOpportunities(@RequestBody OrderSourceLookupRequest requestObj) {

        logger.info("Inside search opportunities with request {}", requestObj);
        CommonUtils.validateRequestedData(requestObj,"Invalid opportunity search request");
        List<OrderSourceLookupResponse> response = orderSourceService.searchOpportunities(requestObj);

        logger.debug("Exiting search opportunity with response {}", response);
        logger.info("search opportunity successful");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @RequestMapping(value = "/v1/leads/search", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<OrderSourceLookupResponse>> searchLeads(@RequestBody OrderSourceLookupRequest requestObj) {
        logger.info("Inside lead lookup with request : {}", requestObj);
        List<OrderSourceLookupResponse> responseList = orderSourceService.searchLeads(requestObj);
        logger.info("Exiting lead lookup");
        logger.debug("lead lookup response is {}", responseList);
        return new ResponseEntity<>(responseList, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/v1/leads", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<LeadDto>> getLeads(@Context HttpServletRequest httpRequest) {
        String userName = httpRequest.getHeader(BAConstants.USER_NAME);
        String impUserName = httpRequest.getHeader(BAConstants.IMP_USER_ID);
        logger.info("Getting role list for user name: {}", userName);
        List<String> roles;
        try{
             roles = authService.getRolesForUser(userName, !StringUtils.isBlank(impUserName), false);
        }catch (BuyAkamaiApplicationException e){
            e.setErrorKey(ErrorConstants.GET_ALL_LEADS_FAILED_KEY);
            throw e;
        }

        StopWatch timer = new StopWatch("Total");
        timer.start();
        List<LeadDto> response = orderSourceService.getLeads(roles, userName.toUpperCase());
        timer.stop();
        logger.info("Exiting get leads for user {} with response {}. Total time taken in millisecond {}.",userName, response,timer.prettyPrint());
        return new ResponseEntity<>(response, HttpStatus.OK);
    }


    @RequestMapping(value = "/v1/leads/{leadId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity<LeadResponse> getLeadDetails(@PathVariable(value = "leadId") String leadId) {
        logger.info("Entering get lead details API for leadId :  {}", leadId);
        
        LeadResponse leadDetails = orderSourceService.getLeadDetails(leadId);
        
        
        logger.info("Exiting get lead Details API for leadId : {}. Lead details are : {}.",leadId,leadDetails);
        return new ResponseEntity<>(leadDetails, HttpStatus.OK);
    }
    
    @RequestMapping(value = "/v1/opportunities/select", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
    public ResponseEntity<List<AccountOpportunityDto>> getOpportunities(@Context HttpServletRequest httpRequest, @RequestBody SearchFilter requestFilter) {
      	String userName = httpRequest.getHeader(BAConstants.USER_NAME);
		logger.info("Entering getOpportunities for account : {}", userName);	
		
		List<AccountOpportunityDto> response = orderSourceService.getOpportunities(requestFilter);
		return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
}
