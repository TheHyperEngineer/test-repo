package com.akamai.buyakamai.controller.model;

import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;


@JsonIgnoreProperties(ignoreUnknown = true)
public class OptionGroupResponse {

	private String optionGroupId;

	private String optionGroupName;

	private Integer minOptions;

	private Integer maxOptions;

	private String optionGroupNotes;

	private List<OptionResponse> options;

	public String getOptionGroupId() {
		return optionGroupId;
	}

	public void setOptionGroupId(String optionGroupId) {
		this.optionGroupId = optionGroupId;
	}

	public String getOptionGroupName() {
		return optionGroupName;
	}

	public void setOptionGroupName(String optionGroupName) {
		this.optionGroupName = optionGroupName;
	}

	public Integer getMinOptions() {
		return minOptions;
	}

	public void setMinOptions(Integer minOptions) {
		this.minOptions = minOptions;
	}

	public Integer getMaxOptions() {
		return maxOptions;
	}

	public void setMaxOptions(Integer maxOptions) {
		this.maxOptions = maxOptions;
	}

	public String getOptionGroupNotes() {
		return optionGroupNotes;
	}

	public void setOptionGroupNotes(String optionGroupNotes) {
		this.optionGroupNotes = optionGroupNotes;
	}

	public List<OptionResponse> getOptions() {
		return options;
	}

	public void setOptions(List<OptionResponse> options) {
		this.options = options;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		OptionGroupResponse that = (OptionGroupResponse) o;

		if (optionGroupId != null ? !optionGroupId.equals(that.optionGroupId) : that.optionGroupId != null)
			return false;
		if (optionGroupName != null ? !optionGroupName.equals(that.optionGroupName) : that.optionGroupName != null)
			return false;
		if (minOptions != null ? !minOptions.equals(that.minOptions) : that.minOptions != null) return false;
		if (maxOptions != null ? !maxOptions.equals(that.maxOptions) : that.maxOptions != null) return false;
		if (optionGroupNotes != null ? !optionGroupNotes.equals(that.optionGroupNotes) : that.optionGroupNotes != null)
			return false;
		return options != null ? options.equals(that.options) : that.options == null;
	}

	@Override
	public int hashCode() {
		int result = optionGroupId != null ? optionGroupId.hashCode() : 0;
		result = 31 * result + (optionGroupName != null ? optionGroupName.hashCode() : 0);
		result = 31 * result + (minOptions != null ? minOptions.hashCode() : 0);
		result = 31 * result + (maxOptions != null ? maxOptions.hashCode() : 0);
		result = 31 * result + (optionGroupNotes != null ? optionGroupNotes.hashCode() : 0);
		result = 31 * result + (options != null ? options.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}


}