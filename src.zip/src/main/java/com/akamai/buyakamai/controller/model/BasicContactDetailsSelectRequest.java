package com.akamai.buyakamai.controller.model;

import java.util.Set;

public class BasicContactDetailsSelectRequest {

    private Set<String> emailIds;

    public Set<String> getEmailIds() {
        return emailIds;
    }

    public void setEmailIds(Set<String> emailIds) {
        this.emailIds = emailIds;
    }

    @Override
    public String toString() {
        return "BasicContactDetailsSelectRequest{" +
                "emailIds=" + emailIds +
                '}';
    }
}
