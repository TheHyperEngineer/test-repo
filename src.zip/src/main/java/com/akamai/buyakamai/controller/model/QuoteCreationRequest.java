package com.akamai.buyakamai.controller.model;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

@JsonIgnoreProperties(ignoreUnknown = true)
public class QuoteCreationRequest {

	@NotBlank(message = "BundleId cannot be empty")
	private String bundleId;

	private String sourceId;

	@NotBlank(message = "sourceType cannot be empty")
	private String sourceType;

	@NotBlank(message = "Trial Duration cannot be null")
	@Pattern(regexp = "[P]([0-9]+)[D]")
	private String trialDuration;

	@NotBlank(message = "Currency cannot be empty")
	private String currency;

	@NotNull(message = "ContactId cannot be null")
	@Size(max = 1, min = 1, message = "One contact id is supported in Quote Creation flow")
	private List<String> contactId;

	private String createdByUserId;

	@Valid
	@NotNull(message = "Products List can not be null")
	@NotEmpty(message = "Products List must contain atleast one element")
	private List<QuoteProduct> products;

	private String accountId;

	private String partnerAccountId;

	private String partnerContractId;

	private String trialManagerContactId;

	private String integrationType;
	
	private String requestorType;
	
	private boolean tncAccepted;
	
	private boolean existingAccountNewContract;

	public String getSourceId() {
		return sourceId;
	}

	public void setSourceId(String sourceId) {
		this.sourceId = sourceId;
	}

	public String getSourceType() {
		return sourceType;
	}

	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}

	public String getTrialDuration() {
		return trialDuration;
	}

	public void setTrialDuration(String trialDuration) {
		this.trialDuration = trialDuration;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public List<String> getContactId() {
		return contactId;
	}

	public void setContactId(List<String> contactId) {
		this.contactId = contactId;
	}

	public List<QuoteProduct> getProducts() {
		return products;
	}

	public void setProducts(List<QuoteProduct> products) {
		this.products = products;
	}

	public String getCreatedByUserId() {
		return createdByUserId;
	}

	public void setCreatedByUserId(String createdByUserId) {
		this.createdByUserId = createdByUserId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getPartnerAccountId() {
		return partnerAccountId;
	}

	public void setPartnerAccountId(String partnerAccountId) {
		this.partnerAccountId = partnerAccountId;
	}

	public String getPartnerContractId() {
		return partnerContractId;
	}

	public void setPartnerContractId(String partnerContractId) {
		this.partnerContractId = partnerContractId;
	}

	public String getIntegrationType() {
		return integrationType;
	}

	public void setIntegrationType(String integrationType) {
		this.integrationType = integrationType;
	}

	public String getTrialManagerContactId() {
		return trialManagerContactId;
	}

	public void setTrialManagerContactId(String trialManagerContactId) {
		this.trialManagerContactId = trialManagerContactId;
	}

	public String getRequestorType() {
		return requestorType;
	}

	public void setRequestorType(String requestorType) {
		this.requestorType = requestorType;
	}

	public boolean isTncAccepted() {
		return tncAccepted;
	}

	public void setTncAccepted(boolean tncAccepted) {
		this.tncAccepted = tncAccepted;
	}
	
	public boolean isExistingAccountNewContract() {
		return existingAccountNewContract;
	}

	public void setExistingAccountNewContract(boolean existingAccountNewContract) {
		this.existingAccountNewContract = existingAccountNewContract;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountId == null) ? 0 : accountId.hashCode());
		result = prime * result + ((bundleId == null) ? 0 : bundleId.hashCode());
		result = prime * result + ((contactId == null) ? 0 : contactId.hashCode());
		result = prime * result + ((createdByUserId == null) ? 0 : createdByUserId.hashCode());
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		result = prime * result + (existingAccountNewContract ? 1231 : 1237);
		result = prime * result + ((integrationType == null) ? 0 : integrationType.hashCode());
		result = prime * result + ((partnerAccountId == null) ? 0 : partnerAccountId.hashCode());
		result = prime * result + ((partnerContractId == null) ? 0 : partnerContractId.hashCode());
		result = prime * result + ((products == null) ? 0 : products.hashCode());
		result = prime * result + ((requestorType == null) ? 0 : requestorType.hashCode());
		result = prime * result + ((sourceId == null) ? 0 : sourceId.hashCode());
		result = prime * result + ((sourceType == null) ? 0 : sourceType.hashCode());
		result = prime * result + (tncAccepted ? 1231 : 1237);
		result = prime * result + ((trialDuration == null) ? 0 : trialDuration.hashCode());
		result = prime * result + ((trialManagerContactId == null) ? 0 : trialManagerContactId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QuoteCreationRequest other = (QuoteCreationRequest) obj;
		if (accountId == null) {
			if (other.accountId != null)
				return false;
		} else if (!accountId.equals(other.accountId))
			return false;
		if (bundleId == null) {
			if (other.bundleId != null)
				return false;
		} else if (!bundleId.equals(other.bundleId))
			return false;
		if (contactId == null) {
			if (other.contactId != null)
				return false;
		} else if (!contactId.equals(other.contactId))
			return false;
		if (createdByUserId == null) {
			if (other.createdByUserId != null)
				return false;
		} else if (!createdByUserId.equals(other.createdByUserId))
			return false;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (existingAccountNewContract != other.existingAccountNewContract)
			return false;
		if (integrationType == null) {
			if (other.integrationType != null)
				return false;
		} else if (!integrationType.equals(other.integrationType))
			return false;
		if (partnerAccountId == null) {
			if (other.partnerAccountId != null)
				return false;
		} else if (!partnerAccountId.equals(other.partnerAccountId))
			return false;
		if (partnerContractId == null) {
			if (other.partnerContractId != null)
				return false;
		} else if (!partnerContractId.equals(other.partnerContractId))
			return false;
		if (products == null) {
			if (other.products != null)
				return false;
		} else if (!products.equals(other.products))
			return false;
		if (requestorType == null) {
			if (other.requestorType != null)
				return false;
		} else if (!requestorType.equals(other.requestorType))
			return false;
		if (sourceId == null) {
			if (other.sourceId != null)
				return false;
		} else if (!sourceId.equals(other.sourceId))
			return false;
		if (sourceType == null) {
			if (other.sourceType != null)
				return false;
		} else if (!sourceType.equals(other.sourceType))
			return false;
		if (tncAccepted != other.tncAccepted)
			return false;
		if (trialDuration == null) {
			if (other.trialDuration != null)
				return false;
		} else if (!trialDuration.equals(other.trialDuration))
			return false;
		if (trialManagerContactId == null) {
			if (other.trialManagerContactId != null)
				return false;
		} else if (!trialManagerContactId.equals(other.trialManagerContactId))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "QuoteCreationRequest [bundleId=" + bundleId + ", sourceId=" + sourceId + ", sourceType=" + sourceType
		        + ", trialDuration=" + trialDuration + ", currency=" + currency + ", contactId=" + contactId
		        + ", createdByUserId=" + createdByUserId + ", products=" + products + ", accountId=" + accountId
		        + ", partnerAccountId=" + partnerAccountId + ", partnerContractId=" + partnerContractId
		        + ", trialManagerContactId=" + trialManagerContactId + ", integrationType=" + integrationType
		        + ", requestorType=" + requestorType + ", tncAccepted=" + tncAccepted + ", existingAccountNewContract="
		        + existingAccountNewContract + "]";
	}
}