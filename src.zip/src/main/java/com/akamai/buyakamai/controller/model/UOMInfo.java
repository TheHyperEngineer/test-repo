package com.akamai.buyakamai.controller.model;

import org.apache.commons.lang.builder.ToStringBuilder;

public class UOMInfo{
	
	private String singular;
	
	private String plural;

	public String getSingular() {
		return singular;
	}

	public void setSingular(String singular) {
		this.singular = singular;
	}

	public String getPlural() {
		return plural;
	}

	public void setPlural(String plural) {
		this.plural = plural;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((plural == null) ? 0 : plural.hashCode());
		result = prime * result + ((singular == null) ? 0 : singular.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UOMInfo other = (UOMInfo) obj;
		if (plural == null) {
			if (other.plural != null)
				return false;
		} else if (!plural.equals(other.plural))
			return false;
		if (singular == null) {
			if (other.singular != null)
				return false;
		} else if (!singular.equals(other.singular))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
}