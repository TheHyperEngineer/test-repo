package com.akamai.buyakamai.controller;


import com.akamai.buyakamai.constants.ErrorConstants;
import com.akamai.buyakamai.exceptions.BuyAkamaiApplicationException;
import com.akamai.buyakamai.model.oms.BuyOrderRequestDto;
import com.akamai.buyakamai.model.oms.CreatedResourceResponse;
import com.akamai.buyakamai.model.oms.OrderVersionResponse;
import com.akamai.buyakamai.service.impl.DraftServiceImpl;
import com.akamai.buyakamai.util.RequestFetcher;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@Slf4j
@RestController
public class DraftController {


    @Autowired
    private RequestFetcher requestFetcher;

    @Autowired
    private DraftServiceImpl draftService;

    @RequestMapping(value = "/v4/drafts/{draftId}", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
    public ResponseEntity getDraftDetails(@Valid @PathVariable Integer draftId) {
        List<String> roles = requestFetcher.getLoggedInUserRoles();
        OrderVersionResponse response = draftService.getDraftDetails(draftId, requestFetcher.getUserName(), roles);
        return new ResponseEntity(response, HttpStatus.OK);
    }

    @PostMapping(value = "/v4/drafts", produces = "application/json;charset=UTF-8")
    public ResponseEntity createDraft(@RequestBody BuyOrderRequestDto buyOrderRequestDto) {
        restrictAccessForImpersonation();
        String contactId = requestFetcher.getContactId();
        buyOrderRequestDto.setCreatedBy(contactId);
        CreatedResourceResponse createdResourceResponse = draftService.createDraft(buyOrderRequestDto, requestFetcher.getUserName());
        return new ResponseEntity(createdResourceResponse, HttpStatus.CREATED);
    }

    @PutMapping(value = "/v4/drafts/{draftId}", produces = "application/json;charset=UTF-8")
    public ResponseEntity updateDraft(@Valid @PathVariable Integer draftId, @RequestBody BuyOrderRequestDto buyOrderRequestDto) {
        restrictAccessForImpersonation();
        String contactId = requestFetcher.getContactId();
        buyOrderRequestDto.setCreatedBy(contactId);
        CreatedResourceResponse response = draftService.updateDraft(buyOrderRequestDto, draftId, requestFetcher.getUserName());
        return new ResponseEntity(response, HttpStatus.OK);
    }

    private void restrictAccessForImpersonation() {
        if (!StringUtils.isEmpty(requestFetcher.getCurrentImpersonator())) {
            String msg = "Restricting the api access for impersonated user.";
            BuyAkamaiApplicationException exc = new BuyAkamaiApplicationException(msg, msg, HttpStatus.FORBIDDEN);
            exc.setErrorKey(ErrorConstants.OMS_RESTRICTION_ON_IMPERSONATION);
            throw exc;
        }
    }

}