package com.akamai.buyakamai.controller.model;

import com.akamai.buyakamai.integration.clients.model.SalesRepOrderSourceDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class LeadResponse {
	
	private String id;

	private String name;

	private String currency;
	
	private String orderRegion;

	private String bundleId;

	private String dealType;

	private String productName;

	private String salesForceUrl;

	private CustomerInfoDTO customer;
	
	private SalesRepOrderSourceDto salesRep;
	
	public SalesRepOrderSourceDto getSalesRep() {
		return salesRep;
	}

	public void setSalesRep(SalesRepOrderSourceDto salesRep) {
		this.salesRep = salesRep;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getOrderRegion() {
		return orderRegion;
	}

	public void setOrderRegion(String orderRegion) {
		this.orderRegion = orderRegion;
	}

	public String getBundleId() {
		return bundleId;
	}

	public void setBundleId(String bundleId) {
		this.bundleId = bundleId;
	}

	public String getDealType() {
		return dealType;
	}

	public void setDealType(String dealType) {
		this.dealType = dealType;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getSalesForceUrl() {
		return salesForceUrl;
	}

	public void setSalesForceUrl(String salesForceUrl) {
		this.salesForceUrl = salesForceUrl;
	}

	public CustomerInfoDTO getCustomer() {
		return customer;
	}

	public void setCustomer(CustomerInfoDTO customer) {
		this.customer = customer;
	}

}
