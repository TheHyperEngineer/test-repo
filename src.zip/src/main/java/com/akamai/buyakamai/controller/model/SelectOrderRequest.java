package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SelectOrderRequest {

    private String orderType;
    private String orderStatus;
    private List<SelectOrderFilter> filters;

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public List<SelectOrderFilter> getFilters() {
        return filters;
    }

    public void setFilters(List<SelectOrderFilter> filters) {
        this.filters = filters;
    }

    @Override
    public String toString() {
        return "SelectOrderRequest{" +
                "orderType='" + orderType + '\'' +
                ", orderStatus='" + orderStatus + '\'' +
                ", filters=" + filters +
                '}';
    }
}
