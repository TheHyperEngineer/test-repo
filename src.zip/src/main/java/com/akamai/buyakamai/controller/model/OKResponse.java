package com.akamai.buyakamai.controller.model;

public class OKResponse {

	private String status = "OK";

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (o == null || getClass() != o.getClass()) return false;

		OKResponse that = (OKResponse) o;

		return status != null ? status.equals(that.status) : that.status == null;
	}

	@Override
	public int hashCode() {
		return status != null ? status.hashCode() : 0;
	}
}
