package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class PerformanceDataSet {

    private String region;
    private PerformanceDataMetric result;

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public PerformanceDataMetric getResult() {
        return result;
    }

    public void setResult(PerformanceDataMetric result) {
        this.result = result;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PerformanceDataSet that = (PerformanceDataSet) o;

        if (region != null ? !region.equals(that.region) : that.region != null) return false;
        return result != null ? result.equals(that.result) : that.result == null;
    }

    @Override
    public int hashCode() {
        int result1 = region != null ? region.hashCode() : 0;
        result1 = 31 * result1 + (result != null ? result.hashCode() : 0);
        return result1;
    }
}
