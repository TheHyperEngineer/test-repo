package com.akamai.buyakamai.controller.model;

import java.util.List;
import java.util.Optional;

/**
 * ArlSummary
 */
public class ArlSummary {
 
   /** Property fileName */
	private String fileName;
   
	private Integer fileId;
	
	private String propertyName;
 
   /** Property cpCodes */
	private List<Integer> cpCodes;
 
   /** Property accountId */
	private String accountId;
 
   /** Property contractId */
	private String contractId;
 
   /** Property stagingVersion */
	private Integer stagingVersion;
 
   /** Property productionVersion */
	private Integer productionVersion;

	private String stagingDate;

	private String productionDate;
 
   /** Property akamaizedHosts */
	private List<String> akamaizedHosts;
 
   /** Property nonAkamaizedHosts */
	private List<String> nonAkamaizedHosts;
   
   /** Property trafficSummary */
	private Optional<Float> trafficSummary;
 
   /**
    * Constructor
    */
   public ArlSummary() {
   }
 
   /**
    * Gets the fileName
    */
   public String getFileName() {
      return this.fileName;
   }
 
   /**
    * Sets the fileName
    */
   public void setFileName(String value) {
      this.fileName = value;
   }

   public String getStagingDate() {
      return stagingDate;
   }

   public void setStagingDate(String stagingDate) {
      this.stagingDate = stagingDate;
   }

   public String getProductionDate() {
      return productionDate;
   }

   public void setProductionDate(String productionDate) {
      this.productionDate = productionDate;
   }

   public Integer getFileId() {
	return fileId;
   }

   public void setFileId(Integer fileId) {
	   this.fileId = fileId;
   }

	public String getPropertyName() {
		return propertyName;
	}
	
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}

/**
    * Gets the cpCodes
    */
   public List<Integer> getCpCodes() {
      return this.cpCodes;
   }
 
   /**
    * Sets the cpCodes
    */
   public void setCpCodes(List<Integer> value) {
      this.cpCodes = value;
   }
 
   /**
    * Gets the accountId
    */
   public String getAccountId() {
      return this.accountId;
   }
 
   /**
    * Sets the accountId
    */
   public void setAccountId(String value) {
      this.accountId = value;
   }
 
   /**
    * Gets the contractId
    */
   public String getContractId() {
      return this.contractId;
   }
 
   /**
    * Sets the contractId
    */
   public void setContractId(String value) {
      this.contractId = value;
   }
 
   /**
    * Gets the stagingVersion
    */
   public Integer getStagingVersion() {
      return this.stagingVersion;
   }
 
   /**
    * Sets the stagingVersion
    */
   public void setStagingVersion(Integer value) {
      this.stagingVersion = value;
   }
 
   /**
    * Gets the productionVersion
    */
   public Integer getProductionVersion() {
      return this.productionVersion;
   }
 
   /**
    * Sets the productionVersion
    */
   public void setProductionVersion(Integer value) {
      this.productionVersion = value;
   }
 
   /**
    * Gets the akamaizedHosts
    */
   public List<String> getAkamaizedHosts() {
      return this.akamaizedHosts;
   }
 
   /**
    * Sets the akamaizedHosts
    */
   public void setAkamaizedHosts(List<String> value) {
      this.akamaizedHosts = value;
   }
 
   /**
    * Gets the nonAkamaizedHosts
    */
   public List<String> getNonAkamaizedHosts() {
      return this.nonAkamaizedHosts;
   }
 
   /**
    * Sets the nonAkamaizedHosts
    */
   public void setNonAkamaizedHosts(List<String> value) {
      this.nonAkamaizedHosts = value;
   }

   public void setTraficSummary(Float f) {
	   trafficSummary = Optional.of(f);
   }
   
   /**
    * Gets the contractId
    */
   public Optional<Float> getTraficSummary() {
      return this.trafficSummary;
   }
}
