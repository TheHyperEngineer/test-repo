package com.akamai.buyakamai.controller.model;

import java.util.Objects;

import org.apache.commons.lang.builder.ToStringBuilder;

public class UIComponent {

	/** Property id */
	String id;

	/** Property type */
	String type;

	/** Property box_value */
	String box_value;

	/** Property box_header */
	String box_header;

	/** Property box_units */
	String box_units;

	/** Property box_date */
	String box_date;

	/**
	 * Constructor
	 */
	public UIComponent() {
	}

	/**
	 * Gets the id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * Sets the id
	 */
	public void setId(String value) {
		this.id = value;
	}

	/**
	 * Gets the type
	 */
	public String getType() {
		return this.type;
	}

	/**
	 * Sets the type
	 */
	public void setType(String value) {
		this.type = value;
	}

	/**
	 * Gets the box_value
	 */
	public String getBox_value() {
		return this.box_value;
	}

	/**
	 * Sets the box_value
	 */
	public void setBox_value(String value) {
		this.box_value = value;
	}

	/**
	 * Gets the box_header
	 */
	public String getBox_header() {
		return this.box_header;
	}

	/**
	 * Sets the box_header
	 */
	public void setBox_header(String value) {
		this.box_header = value;
	}

	/**
	 * Gets the box_units
	 */
	public String getBox_units() {
		return this.box_units;
	}

	/**
	 * Sets the box_units
	 */
	public void setBox_units(String value) {
		this.box_units = value;
	}

	/**
	 * Gets the box_date
	 */
	public String getBox_date() {
		return this.box_date;
	}

	/**
	 * Sets the box_date
	 */
	public void setBox_date(String value) {
		this.box_date = value;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		result = prime * result + ((box_value == null) ? 0 : box_value.hashCode());
		result = prime * result + ((box_header == null) ? 0 : box_header.hashCode());
		result = prime * result + ((box_units == null) ? 0 : box_units.hashCode());
		result = prime * result + ((box_date == null) ? 0 : box_date.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {

		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		UIComponent other = (UIComponent) obj;

		if(!Objects.equals(id, other.id)) {
			return false;
		}
		
		if(!Objects.equals(type, other.type)) {
			return false;
		}
		
		if(!Objects.equals(box_value, other.box_value)) {
			return false;
		}
		
		if(!Objects.equals(box_header, other.box_header)) {
			return false;
		}
		
		if(!Objects.equals(box_units, other.box_units)) {
			return false;
		}
		
		if(!Objects.equals(box_date, other.box_date)) {
			return false;
		}
		
		return true;
	}
}