package com.akamai.buyakamai.controller.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
@NoArgsConstructor
@Data
public class RevenueResponse {
    private BigDecimal totalMrr;
    private BigDecimal oneTimeFees;
    private BigDecimal pmov;

    public RevenueResponse(BigDecimal oneTimeFees, BigDecimal totalMrr, BigDecimal pmov) {
        this.totalMrr = totalMrr;
        this.oneTimeFees = oneTimeFees;
        this.pmov = pmov;
    }
}
