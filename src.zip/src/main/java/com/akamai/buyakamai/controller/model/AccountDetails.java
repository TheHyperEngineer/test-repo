package com.akamai.buyakamai.controller.model;


import com.akamai.buyakamai.integration.clients.model.AddressDto;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountDetails {

    private String name;

    private String id;

    private AddressDto address;

    private String salesForceURL;

    private String status;

    private String ownerName;
    
    private String ownerId;

    private Boolean restrictedCountry;

    private String accountType;

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public Boolean isRestrictedCountry() {
        return restrictedCountry;
    }

    public void setRestrictedCountry(Boolean restrictedCountry) {
        this.restrictedCountry = restrictedCountry;
    }

    public String getSalesForceURL() {
        return salesForceURL;
    }

    public void setSalesForceURL(String salesForceURL) {
        this.salesForceURL = salesForceURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }


    public void setId(String id) {
        this.id = id;
    }


    public AddressDto getAddress() {
        return address;
    }


    public void setAddress(AddressDto address) {
        this.address = address;
    }
    
    public String getOwnerId() {
		return ownerId;
	}

	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccountDetails that = (AccountDetails) o;

        return id != null ? id.equals(that.id) : that.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "AccountDetails{" +
                "name='" + name + '\'' +
                ", id='" + id + '\'' +
                ", address=" + address +
                ", salesForceURL='" + salesForceURL + '\'' +
                ", status='" + status + '\'' +
                ", ownerName='" + ownerName + '\'' +
                ", restrictedCountry=" + restrictedCountry +
                ", accountType='" + accountType + '\'' +
                '}';
    }
}