package com.akamai.buyakamai.controller.model.valueconfirmations;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.hibernate.validator.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@JsonIgnoreProperties(ignoreUnknown = true)
public class WebDeliveryRequestModel {

    @NotNull(message = "OrderId cannot be empty")
    private Integer orderId;

    @NotBlank(message = "BundleId cannot be empty")
    private String bundleId;

    @NotBlank(message = "Host cannot be empty")
    private String host;

    @NotBlank(message = "TestUrl cannot be empty")
    private String testUrl;

    @NotBlank(message = "Agents cannot be empty")
    private String agents;

    @NotBlank(message = "Test Platform cannot be empty")
    private String testPlatform;

    private String countries;

    private String specificInterest;
    private String successCriteria;

    public Integer getOrderId() {
        return orderId;
    }

    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public String getBundleId() {
        return bundleId;
    }

    public void setBundleId(String bundleId) {
        this.bundleId = bundleId;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getTestUrl() {
        return testUrl;
    }

    public void setTestUrl(String testUrl) {
        this.testUrl = testUrl;
    }

    public String getAgents() {
        return agents;
    }

    public void setAgents(String agents) {
        this.agents = agents;
    }

    public String getSpecificInterest() {
        return specificInterest;
    }

    public void setSpecificInterest(String specificInterest) {
        this.specificInterest = specificInterest;
    }

    public String getTestPlatform() {
        return testPlatform;
    }

    public void setTestPlatform(String testPlatform) {
        this.testPlatform = testPlatform;
    }

    public String getSuccessCriteria() {
        return successCriteria;
    }

    public void setSuccessCriteria(String successCriteria) {
        this.successCriteria = successCriteria;
    }

    public String getCountries() {
        return countries;
    }

    public void setCountries(String countries) {
        this.countries = countries;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        WebDeliveryRequestModel that = (WebDeliveryRequestModel) o;

        if (orderId != null ? !orderId.equals(that.orderId) : that.orderId != null) return false;
        if (bundleId != null ? !bundleId.equals(that.bundleId) : that.bundleId != null) return false;
        if (host != null ? !host.equals(that.host) : that.host != null) return false;
        if (testUrl != null ? !testUrl.equals(that.testUrl) : that.testUrl != null) return false;
        if (agents != null ? !agents.equals(that.agents) : that.agents != null) return false;
        if (specificInterest != null ? !specificInterest.equals(that.specificInterest) : that.specificInterest != null)
            return false;
        if (testPlatform != null ? !testPlatform.equals(that.testPlatform) : that.testPlatform != null) return false;
        return successCriteria != null ? successCriteria.equals(that.successCriteria) : that.successCriteria == null;
    }

    @Override
    public int hashCode() {
        int result = orderId != null ? orderId.hashCode() : 0;
        result = 31 * result + (bundleId != null ? bundleId.hashCode() : 0);
        result = 31 * result + (host != null ? host.hashCode() : 0);
        result = 31 * result + (testUrl != null ? testUrl.hashCode() : 0);
        result = 31 * result + (agents != null ? agents.hashCode() : 0);
        result = 31 * result + (specificInterest != null ? specificInterest.hashCode() : 0);
        result = 31 * result + (testPlatform != null ? testPlatform.hashCode() : 0);
        result = 31 * result + (successCriteria != null ? successCriteria.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "WebDeliveryRequestModel{" +
                "orderId=" + orderId +
                ", bundleId='" + bundleId + '\'' +
                ", host='" + host + '\'' +
                ", testUrl='" + testUrl + '\'' +
                ", agents='" + agents + '\'' +
                ", specificInterest='" + specificInterest + '\'' +
                ", testPlatform='" + testPlatform + '\'' +
                ", successCriteria='" + successCriteria + '\'' +
                '}';
    }
}
