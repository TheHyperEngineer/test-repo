package com.akamai.buyakamai.controller.model;

import java.util.List;

import org.springframework.hateoas.ResourceSupport;

import com.akamai.buyakamai.model.oms.OMSOrder;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderInformationDTO extends ResourceSupport {
    @JsonInclude(JsonInclude.Include.NON_NULL)
	private String orderId;
	
    @JsonInclude(JsonInclude.Include.NON_NULL)
	private String draftId;
    private String title;
    private String status;
    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String version;
    @JsonProperty("isLatest")
    private String latest;

	@JsonProperty("isNoteUpdated")
	@JsonInclude(JsonInclude.Include.NON_NULL)
	private Boolean noteUpdated;

    private String lastModifiedTime;
    private String lastModifiedBy;
    private List<Note> notes;

	public OrderInformationDTO(OMSOrder omsOrder, String contactFullName) {
		this.orderId = omsOrder.getOrderId();
		this.title = omsOrder.getTitle();
		this.status = omsOrder.getStatus();
		this.version = (omsOrder.getVersion() == null) ? null : omsOrder.getVersion().toString();
		this.latest = Boolean.toString(omsOrder.getLatest());
		this.lastModifiedBy = contactFullName;
		this.lastModifiedTime = omsOrder.getLastModifiedTime();
		this.notes = omsOrder.getNotes();
		this.draftId = omsOrder.getDraftId();
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	@JsonProperty("isNoteUpdated")
	public Boolean getNoteUpdated() {
		return noteUpdated;
	}

	public void isNoteUpdated(Boolean noteUpdated) {
		this.noteUpdated = noteUpdated;
	}

	public String getDraftId() {
		return draftId;
	}
	public void setDraftId(String draftId) {
		this.draftId = draftId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	   @JsonProperty("isLatest")
	public String getLatest() {
		return latest;
	}
	   @JsonProperty("isLatest")
	public void setLatest(String latest) {
		this.latest = latest;
	}
	public String getLastModifiedTime() {
		return lastModifiedTime;
	}
	public void setLastModifiedTime(String lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}
	public String getLastModifiedBy() {
		return lastModifiedBy;
	}
	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
	public List<Note> getNotes() {
		return notes;
	}
	public void setNotes(List<Note> notes) {
		this.notes = notes;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((lastModifiedTime == null) ? 0 : lastModifiedTime.hashCode());
		result = prime * result + ((orderId == null) ? 0 : orderId.hashCode());
		result = prime * result + ((version == null) ? 0 : version.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OrderInformationDTO other = (OrderInformationDTO) obj;
		if (lastModifiedTime == null) {
			if (other.lastModifiedTime != null)
				return false;
		} else if (!lastModifiedTime.equals(other.lastModifiedTime))
			return false;
		if (orderId == null) {
			if (other.orderId != null)
				return false;
		} else if (!orderId.equals(other.orderId))
			return false;
		if (version == null) {
			if (other.version != null)
				return false;
		} else if (!version.equals(other.version))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "OrderInformationDTO [orderId=" + orderId + ", draftId=" + draftId + ", title=" + title + ", status="
				+ status + ", version=" + version + ", isLatest=" + latest + ", lastModifiedTime=" + lastModifiedTime
				+ ", lastModifiedBy=" + lastModifiedBy + ", notes=" + notes + "]";
	}
	
}
