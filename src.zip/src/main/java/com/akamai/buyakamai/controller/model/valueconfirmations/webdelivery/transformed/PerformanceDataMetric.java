package com.akamai.buyakamai.controller.model.valueconfirmations.webdelivery.transformed;

public class PerformanceDataMetric {

    private String origin;
    private String akamai;
    private String comparison;

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getAkamai() {
        return akamai;
    }

    public void setAkamai(String akamai) {
        this.akamai = akamai;
    }

    public String getComparison() {
        return comparison;
    }

    public void setComparison(String comparison) {
        this.comparison = comparison;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        PerformanceDataMetric that = (PerformanceDataMetric) o;

        if (origin != null ? !origin.equals(that.origin) : that.origin != null) return false;
        if (akamai != null ? !akamai.equals(that.akamai) : that.akamai != null) return false;
        return comparison != null ? comparison.equals(that.comparison) : that.comparison == null;
    }

    @Override
    public int hashCode() {
        int result = origin != null ? origin.hashCode() : 0;
        result = 31 * result + (akamai != null ? akamai.hashCode() : 0);
        result = 31 * result + (comparison != null ? comparison.hashCode() : 0);
        return result;
    }
}
